﻿#include "EventMigration.h"
//#include "EventDetectionAndMigration.h"
#include <string.h> 
#include "strtokenizer.h"

extern int getUserProfileNew(char userid[], UserProfile& up);

int EventMigration::uploadUserProfilesNew(char* flist, char *path)
{
	int ret = 0;

	char userProfilePath[200];
	//strcpy_s(userProfilePath, "..\\..\\213_21all\\");
	strcpy_s(userProfilePath, "..\\..\\Xi_Feb26\\TexasFloodExperimentData\\ExperimentData\\");
	FILE* fileDescriptor = NULL, * resultFile = NULL;

	char buffer[BUFFERSIZE];

	char userProfilename[MSGLEN];

	//strcpy_s(userProfilename, userProfilePath);
	strcpy_s(userProfilename, path);
	strcat_s(userProfilename, flist);
	
	//strcat_s(userProfilename, ".txt");

	int fre = 0;
	int eventfre = 0;	
	string line;

	UserProfile up;
	//reset up for next user profile reading.
	up.PostNum = 0;
	up.userId = 0;
	up.UserInfluenceDistri.clear();
	up.UserInterestEvents.clear();
	up.UserPhysicalLocation.lat = 0;
	up.UserPhysicalLocation.longi = 0;
	up.UserPhysicalLocation.radius = 0;
	up.UserResponseNumbers.clear();
	up.Inserted = 0;
	///////==========================
	if ((fopen_s(&fileDescriptor, userProfilename, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", userProfilename);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) document!\n");
				return 1;
			}

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<userid>") == 0) {					
					i++;
					int j = 0;
					while (strcmp(strtok.token(i).c_str(), "</userid>") != 0)
					{
						up.userId = (int)atoi(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}
				if (strcmp(strtok.token(i).c_str(), "<location>") == 0) {
					i++;
					int j = 0;
					while (strcmp(strtok.token(i).c_str(), "</location>") != 0)
					{
						if (j == 0) {
							up.UserPhysicalLocation.lat = (float)atof(strtok.token(i).c_str());
							j++;
						}
						else {
							up.UserPhysicalLocation.longi = (float)atof(strtok.token(i).c_str());
						}
						i++;
					}
					up.UserPhysicalLocation.radius = SPACERADIUST;
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<MSGNUM>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</MSGNUM>") != 0)
					{
						up.PostNum = (int)atoi(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<RESPONSENUMBERS>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</RESPONSENUMBERS>") != 0) 
					{						
						UPRespnseEle UPRele;
						UPRele.userid = (int)atoi(strtok.token(i).c_str());
						i++;
						UPRele.userResponse = (int)atoi(strtok.token(i).c_str());
						if (UPRele.userResponse > up.PostNum)
							UPRele.userResponse = up.PostNum;

						i++;
						up.UserResponseNumbers.push_back(UPRele);		

						UPInfluDistriEle UPIde;
						UPIde.userid = UPRele.userid;
						if (up.userId == UPIde.userid)
							UPIde.userInflu = 1;
						else
							UPIde.userInflu = 0;//initialization to 0.
						up.UserInfluenceDistri.push_back(UPIde);
					}
					i++;
					///===finish a user profile record and insert it into the graph
					uiGraph.loadtoUplist(up);
					//reset up for next user profile reading.
					up.PostNum = 0;
					up.userId = 0;
					up.UserInfluenceDistri.clear();
					up.UserInterestEvents.clear();
					up.UserPhysicalLocation.lat = 0;
					up.UserPhysicalLocation.longi = 0;
					up.UserPhysicalLocation.radius = 0;
					up.UserResponseNumbers.clear();	
					up.Inserted = 0;
					///////==========================
					continue;
				}
				i++;
			}
		}
		fclose(fileDescriptor);
	}
	return ret;
}

int EventMigration::uploadUserProfilesIntoHashMap(char* flist, char * userProfilePath)
{
	int ret = 0;

	//char userProfilePath[200];
	//strcpy_s(userProfilePath, "C:\\scratch\\MyProgramsRMIT\\PVLDB20CPP\\EventMigrationRecom\\EventMigrationRecom\\");
	FILE* fileDescriptor = NULL, * resultFile = NULL;

	char buffer[BUFFERSIZE];

	char userProfilename[MSGLEN];

	strcpy_s(userProfilename, userProfilePath);
	strcat_s(userProfilename, flist);
	
	int fre = 0;
	int eventfre = 0;
	string line;

	UserProfile up;
	//reset up for next user profile reading.
	up.PostNum = 0;
	up.userId = 0;
	up.UserInfluenceDistri.clear();
	up.UserInterestEvents.clear();
	up.UserPhysicalLocation.lat = 0;
	up.UserPhysicalLocation.longi = 0;
	up.UserPhysicalLocation.radius = 0;
	up.UserResponseNumbers.clear();
	up.Inserted = 0;
	///////==========================
	if ((fopen_s(&fileDescriptor, userProfilename, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", userProfilename);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) document!\n");
				return 1;
			}

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<userid>") == 0) {
					i++;
					int j = 0;
					while (strcmp(strtok.token(i).c_str(), "</userid>") != 0)
					{
						up.userId = (int)atoi(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}
				if (strcmp(strtok.token(i).c_str(), "<userOid>") == 0) {
					i++;
					int j = 0;
					while (strcmp(strtok.token(i).c_str(), "</userOid>") != 0)
					{
						up.userOId = stoull(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}
				if (strcmp(strtok.token(i).c_str(), "<location>") == 0) {
					i++;
					int j = 0;
					while (strcmp(strtok.token(i).c_str(), "</location>") != 0)
					{
						if (j == 0) {
							up.UserPhysicalLocation.lat = (float)atof(strtok.token(i).c_str());
							j++;
						}
						else {
							up.UserPhysicalLocation.longi = (float)atof(strtok.token(i).c_str());
						}
						i++;
					}
					up.UserPhysicalLocation.radius = SPACERADIUST;
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<MSGNUM>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</MSGNUM>") != 0)
					{
						up.PostNum = (int)atoi(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<RESPONSENUMBERS>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</RESPONSENUMBERS>") != 0)
					{
						UPRespnseEle UPRele;
						UPRele.userid = (int)atoi(strtok.token(i).c_str());
						i++;
						UPRele.userResponse = (int)atoi(strtok.token(i).c_str());
						i++;
						up.UserResponseNumbers.push_back(UPRele);

						UPInfluDistriEle UPIde;
						UPIde.userid = UPRele.userid;
						if (up.userId == UPIde.userid)
							UPIde.userInflu = 1;
						else
							UPIde.userInflu = 0;//initialization to 0.
						up.UserInfluenceDistri.push_back(UPIde);
					}
					i++;
					///===finish a user profile record and insert it into the hashmap
					UserProfileHashMap[up.userId].userId = up.userId;
					UserProfileHashMap[up.userId].PostNum = up.PostNum;
					UserProfileHashMap[up.userId].UserPhysicalLocation.lat = up.UserPhysicalLocation.lat;
					UserProfileHashMap[up.userId].UserPhysicalLocation.longi = up.UserPhysicalLocation.longi;
					UserProfileHashMap[up.userId].UserPhysicalLocation.radius = up.UserPhysicalLocation.radius;
					UserProfileHashMap[up.userId].UserResponseNumbers.insert(UserProfileHashMap[up.userId].UserResponseNumbers.end(),
						up.UserResponseNumbers.begin(), up.UserResponseNumbers.end());
					UserProfileHashMap[up.userId].Inserted = 0;
					//reset up for next user profile reading.
					up.PostNum = 0;
					up.userId = 0;
					up.UserInfluenceDistri.clear();
					up.UserInterestEvents.clear();
					up.UserPhysicalLocation.lat = 0;
					up.UserPhysicalLocation.longi = 0;
					up.UserPhysicalLocation.radius = 0;
					up.UserResponseNumbers.clear();
					up.Inserted = 0;
					///////==========================
					continue;
				}
				i++;
			}
		}
		fclose(fileDescriptor);
	}
	return ret;
}
/*==============================================
set the maximal probability from node v to each of other nodes

// 各数组都从下标1开始
//int dist[maxnum];     // 表示当前点到源点的最短路径长度
//int prev[maxnum];     // 记录当前点的前一个结点
//int c[maxnum][maxnum];   // 记录图的两点间路径长度
//int n, line;             // 图的结点数和路径数

// n -- n nodes
// v -- the source node
// simi[] -- the influence probability from the ith node to the source node
// prev[] -- the previous node of the ith node
// c[][] -- every two nodes' director probabilty

//by xm zhou --change the initial Dijkstra algorithm for influence probability calculation. 
the original sourcecode was from https://blog.csdn.net/u013443618/article/details/49099195 
================================================*/
//void EventMigration::Dijkstra(int n, int v, float *simi, int *prev, float c[][TUNUM+1])
void EventMigration::Dijkstra(int n, int v, float* simi, int* prev, float c[][ROWSV+1])
{	
	bool s[TUNUM+1];    // 判断是否已存入该点到S集合中
	for (int i = 1; i <= n; ++i)
	{
		simi[i] = c[v][i];
		s[i] = 0;     // 初始都未用过该点
		if (simi[i] == 0)
			prev[i] = 0;
		else
			prev[i] = v;
	}
	simi[v] = 1;
	s[v] = 1;

	// 依次将未放入S集合的结点中，取simi[]最大值的结点，放入结合S中
	// 一旦S包含了所有V中顶点，simi就记录了从源点到所有其他顶点之间的最大影响值
	for (int i = 2; i <= n; ++i)
	{
		float tmp = 0;
		int u = v;
		// 找出当前未使用的点j的simi[j] maximal value
		for (int j = 1; j <= n; ++j)
			if ((!s[j]) && simi[j] > tmp)
			{
				u = j;              // u保存当前邻接点中距离最小的点的号码
				tmp = simi[j];
			}
		s[u] = 1;    // 表示u点已存入S集合中

		// update simi
		for (int j = 1; j <= n; ++j)
			if ((!s[j]) && c[u][j] > 0)
			{
				float newdist = simi[u] * c[u][j];
				if (newdist > simi[j])
				{
					simi[j] = newdist;
					prev[j] = u;
				}
			}
	}	
}

float EventMigration::GetDirectInfluence(UserProfile &up1, UserProfile &up2, GraphEdge & gedge) {
	float overallInflu = 0;
	float Is = 0.0000000000001;
	float LocationSim = 0.0000000000001;
	float WUIP = uiGraph.getWUIP();

	gedge.physicalRel = 0;
	gedge.SocialRel = 0;

	vector<UPRespnseEle>::iterator uprit = up1.UserResponseNumbers.begin();
	while (uprit != up1.UserResponseNumbers.end())
	{
		if ((*uprit).userid == up2.userId)
			break;
		uprit++;
	}
	if (uprit != up1.UserResponseNumbers.end())
	{
		Is = (float)(*uprit).userResponse / up1.PostNum;

		///for test, correct error processing
		if (Is > 1)
			Is=1;
	}
			
	if (Is > 0.000000000001) {
		float locationDist = get_distance(up1.UserPhysicalLocation.lat, up1.UserPhysicalLocation.longi, up2.UserPhysicalLocation.lat, up2.UserPhysicalLocation.longi) / (PI * EARTH_RADIUS);
		LocationSim = 1 / (1 + locationDist);
		overallInflu = WUIP * Is + (1 - WUIP) * LocationSim;

		gedge.physicalRel = LocationSim;
		gedge.SocialRel = Is;
	}
	else
		overallInflu = 0;

	return overallInflu;
}
/*==============================================
return the maximal probability from up1 to up2
================================================*/
float EventMigration::GetUserSimi(UserProfile &up1, UserProfile &up2) {
	float ret = 0;
	//ret = up1.UserInfluenceDistri[up2.userId];

	vector<UPInfluDistriEle>::iterator upidit = up1.UserInfluenceDistri.begin();
	while (upidit != up1.UserInfluenceDistri.end()) {
		if ((*upidit).userid == up2.userId) {
			ret = (*upidit).userInflu;
			break;
		}
		upidit++;
	}
	return ret;
}

//construct edges between user profile nodes
int EventMigration::constructIGEdges() 
{
	int ret = 0;
	vector<UserProfile>::iterator ulitStart, ulitEnd, outulitEnd;
	
	vector<UserProfile> ulist = uiGraph.Getuplist();
	GraphEdge curGEdge;
	//float WUIP = uiGraph.getWUIP();

	ulitStart = ulist.begin();

	outulitEnd = ulitStart + ulist.size();

	//while (ulitStart != ulist.end())
	while(ulitStart!=outulitEnd)
	{
		int resUserNum = (*ulitStart).UserResponseNumbers.size();
		if (resUserNum <= 1)  //no one respond to this user
		{
			ulitStart++;
			continue;
		}
		printf("ulitStart userid: %d\t graphSize: %d\n", (*ulitStart).userId, ret);	
		
		for (int i = 0; i < resUserNum; i++)
		{
			ulitEnd = ulist.begin() + (*ulitStart).UserResponseNumbers[i].userid;
			if (ulitStart != ulitEnd)
			{
				//construct edge and compute the influence probability from ulitStart to ulitEnd
				curGEdge.upStart.userId = (*ulitStart).userId;
				curGEdge.upEnd.userId = (*ulitEnd).userId;
				curGEdge.weight = GetDirectInfluence(*ulitStart, *ulitEnd, curGEdge);

				//add the edge to uiGraph
				if (curGEdge.weight > 0) //has social influence, then add it. 
				{
					uiGraph.setEdge(curGEdge);
					ret++;
				}
			}
		}

	
		ulitStart++;
	}
	return ret;
}


int EventMigration::GenerateUserGroups(vector<UserProfile>& uplist, vector<vector<int>>& uidPPtr)
{
	int maxGroupSize = 0;
	int i, j;
	vector<GraphEdge> gedge = uiGraph.GetEdgeSet();

	//put the users with connected edges into same groups based on gedge
	vector<GraphEdge>::iterator geit = gedge.begin();
	while (geit != gedge.end())
	{			
		//search uidPPtr
		int sizeUID = uidPPtr.size();
		for (i = 0; i < sizeUID; i++) {
			//check if (*geit).upStart.userid is in uidPPtr[i]
			int sizeInner = uidPPtr[i].size();
			if (sizeInner >= ROWSV-2)//control the size of groups
				continue;
			for (j = 0; j < sizeInner; j++)
			{
				if ((*geit).upStart.userId == uidPPtr[i][j]) {					
					if (!InGroup(uidPPtr[i], (*geit).upEnd.userId))
					{
						uidPPtr[i].push_back((*geit).upEnd.userId);
						uplist[(*geit).upEnd.userId].Inserted = 1;
					}
					break;
				}
				else if ((*geit).upEnd.userId == uidPPtr[i][j])
				{					
					if (!InGroup(uidPPtr[i], (*geit).upStart.userId))
					{
						uidPPtr[i].push_back((*geit).upStart.userId);
						uplist[(*geit).upStart.userId].Inserted = 1;
					}
					break;
				}
			}
			if (j < sizeInner) //inserted
				break;
		}

		if (i == sizeUID)//not found, can not be kept in any existing cluster, generate new cluster
		{
			vector<int> newcluster;
			newcluster.push_back((*geit).upStart.userId);
			newcluster.push_back((*geit).upEnd.userId);
			uplist[(*geit).upStart.userId].Inserted = 1;			
			uplist[(*geit).upEnd.userId].Inserted = 1;
			uidPPtr.push_back(newcluster);
		}
		geit++;
	}
	
	for (i = 0; i < uidPPtr.size(); i++)
	{
		if (uidPPtr[i].size() > maxGroupSize)
			maxGroupSize = uidPPtr[i].size();
	}
	return maxGroupSize;
}

int EventMigration::InGroup(vector<int>& userlist, int userid) {
	int ret = 0;
	vector<int>::iterator uit = userlist.begin();
	int index = 1;
	while (uit != userlist.end()) {
		if ((*uit) == userid) {
			ret = index;
			break;
		}
		index++;
		uit++;
	}
	return ret;
}

int EventMigration::loadIGEdges() {
	int ret = 0;
	FILE* fileDescriptor = NULL;
	char buffer[BUFFERSIZE];

	char UIfname[200];
	//strcpy_s(UIfname, "IGEdgefile_Nepal(0-148884).txt");
	//strcpy_s(UIfname, "NepalIGEdgefile(Training)07.txt");
	strcpy_s(UIfname, "NepalIGEdgefile(Training25April-9May)07.txt");
		
	string line;

	if ((fopen_s(&fileDescriptor, UIfname, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", UIfname);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) line!\n");
				return 1;
			}

			int i = 0;
			GraphEdge gedge;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "StartUser:") == 0) {
					i++;					
					gedge.upStart.userId = (int)atoi(strtok.token(i).c_str());					
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "EndUser:") == 0) {
					i++;
					gedge.upEnd.userId = (int)atoi(strtok.token(i).c_str());
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "Weight:") == 0) {
					i++;
					gedge.weight = atof(strtok.token(i).c_str());
					i++;
					continue;
				}
				i++;
			}			
			uiGraph.setEdge(gedge);
		}
		fclose(fileDescriptor);
	}
	////////////

	return ret;
}

int EventMigration::ContinuousUserInfluenceGraphUpdate(char* flistname, char* path) {
	int ret = 0;
	char  FullSlotFileName[200];

	char buffer[200];
	FILE* fileDescriptor = NULL;
	//strcpy_s(buffer, "NepalUserProfile(Training).txt");
	//strcpy_s(buffer, "NepalUserProfileResult(Training25April-9May).txt");
	strcpy_s(buffer, "NepalUserProfile(Training15April-24April).txt");
	//upload userprofiles in training data to this uiGraph
	uploadUserProfilesNew(buffer,path);
//	loadIGEdges();
	//process the user profiles in each time slot of the streaming mode

	if ((fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		while (fscanf_s(fileDescriptor, "%s ", buffer, 200) != EOF)
		{   //load data			
			strcpy_s(FullSlotFileName, 200, buffer);
			//strcat_s(FullSlotFileName, 200, ".txt");
			IncrementalUserInfluenceGraphUpdate(FullSlotFileName, path);
		}
		fclose(fileDescriptor);
	}	
	return ret;
}

int EventMigration::constructSlotIGEdges(EventMigration& em) {
	int ret = 0;
	vector<UserProfile>::iterator ulitStart, ulitEnd, outulitEnd;

	vector<UserProfile> ulist = em.uiGraph.Getuplist();
	vector<UserProfile> thisUlist=uiGraph.Getuplist();
	GraphEdge curGEdge;
	//float WUIP = uiGraph.getWUIP();

	ulitStart = ulist.begin();
	outulitEnd = ulitStart + ulist.size();
	
	while (ulitStart != outulitEnd)
	{
		int resUserNum = (*ulitStart).UserResponseNumbers.size();
		if (resUserNum <= 1)  //no one respond to this user
		{
			ulitStart++;
			continue;
		}
		//printf("ulitStart userid: %d\t graphSize: %d\n", (*ulitStart).userId, ret);

		for (int i = 0; i < resUserNum; i++)
		{
			ulitEnd = thisUlist.begin() + (*ulitStart).UserResponseNumbers[i].userid;
			if ((*ulitStart).userId != (*ulitEnd).userId)
			{
				//construct edge and compute the influence probability from ulitStart to ulitEnd
				curGEdge.upStart.userId = (*ulitStart).userId;
				curGEdge.upEnd.userId = (*ulitEnd).userId;
				curGEdge.weight = GetDirectInfluence(*ulitStart, *ulitEnd, curGEdge);

				//add the edge to uiGraph
				if (curGEdge.weight > 0) //has social influence, then add it. 
				{
					em.uiGraph.setEdge(curGEdge);
					ret++;
				}
			}
		}
		ulitStart++;
	}
	return ret;
}


int EventMigration::IncrementalUserInfluenceGraphUpdate(char* filename, char*path)
{
	int ret = 0; 

	EventMigration tmpEM;
	
	//printf("start loading updated info on user profiles\n");
	tmpEM.uploadUserProfilesNew(filename, path); // upload user profiles
	//printf("updated user profile info loading finished\n");

	//copy the related user profiles in this current uiGraph with tmpUIG.uiGraph
	
	vector<UserProfile>::iterator uit, tmpUit, eraseit;
	vector<UserProfile> thisUPlist = uiGraph.Getuplist();
	vector<UserProfile> tmpUPlist = tmpEM.uiGraph.Getuplist();
	vector<UPRespnseEle>::iterator rit;

	int OriginaltmpUPlistSize = tmpUPlist.size();

	tmpUit = tmpUPlist.begin();
	int tmpcount = 0;
	while (tmpUit != tmpUPlist.end()) 
	{
		//combine the user profile in thisUPlist with same user id as (tmpUit)
		int tuid = (*tmpUit).userId;
		if (thisUPlist[tuid].Inserted == 0) {
			(*tmpUit).PostNum += thisUPlist[tuid].PostNum;

			thisUPlist[tuid].Inserted = 1;

			int i = 0;
			int resNum = thisUPlist[tuid].UserResponseNumbers.size();
			for (i = 0; i < resNum; i++)
			{
				rit = (*tmpUit).UserResponseNumbers.begin();
				int ritcount = 0;
				int tmpUitSize = (*tmpUit).UserResponseNumbers.size();
				while (rit != (*tmpUit).UserResponseNumbers.end()) 
				{
					if ((*rit).userid == thisUPlist[tuid].UserResponseNumbers[i].userid) {
						(*rit).userResponse += thisUPlist[tuid].UserResponseNumbers[i].userResponse;
						break;
					}
					else if ((*rit).userid > thisUPlist[tuid].UserResponseNumbers[i].userid) {
						(*tmpUit).UserResponseNumbers.insert(rit, thisUPlist[tuid].UserResponseNumbers[i]);
						break;
					}
					rit++;
					ritcount++;
				}
				//if (rit == (*tmpUit).UserResponseNumbers.end())
				if(ritcount==tmpUitSize)//not inserted
					(*tmpUit).UserResponseNumbers.push_back(thisUPlist[tuid].UserResponseNumbers[i]);
			}
		}
		//find all user profiles that have interactions with (*tmpUit) from thisUPlist
		int tmpRes = (*tmpUit).UserResponseNumbers.size();
		for (int i = 0; i < tmpRes; i++) {
			int ritUid = (*tmpUit).UserResponseNumbers[i].userid;
			if (thisUPlist[ritUid].Inserted == 0) {
				tmpUPlist.push_back(thisUPlist[ritUid]);
				tmpUit = tmpUPlist.begin() + tmpcount;
				thisUPlist[ritUid].Inserted = 1;
			}
		}
		tmpUit++;
		tmpcount++;
	}

	//union the profiles with same userid in tmpUIG.uiGraph
	vector<UPRespnseEle>::iterator tmpRit, ExTmpRit, eraseRit;
	tmpUit = tmpUPlist.begin()+tmpUPlist.size()-1;
	while (tmpUit != tmpUPlist.begin()) {
		uit = tmpUit;
		uit--;
		while (uit != tmpUPlist.begin()) {
			if ((*uit).userId == (*tmpUit).userId) {//union
				eraseit = tmpUit;
				tmpUit--;
				tmpUPlist.erase(eraseit);
				break;
			}
			else
				uit--;
		}
		//if(uit != tmpUPlist.begin())
			tmpUit--;			
	}

	for (int i = 0; i < thisUPlist.size(); i++) {
		thisUPlist[i].Inserted = 0;
	}

	//copy tmpUIG.uiGraph back to this current uiGraph
	for (int i = 0; i < OriginaltmpUPlistSize; i++){
		uiGraph.setNewUpValue(tmpUPlist[i]);		
	}

	for (int i = 0; i < tmpUPlist.size(); i++)
		tmpEM.uiGraph.setNewUpValue(tmpUPlist[i]);

	//count time
	std::clock_t start;
	double duration;
	start = std::clock();

	constructSlotIGEdges(tmpEM);//construct edges between user profile nodes	
	ConstructSlotUserInfluenceGraphSubRoutine(filename, path, tmpEM);
	
	duration = (std::clock() - start) / (double)CLOCKS_PER_SEC;
	std::cout << filename << ": " << duration << '\n';

	

	tmpUPlist.clear();
	tmpEM.uiGraph.GetEdgeSet().clear();
	return ret;
}

int EventMigration::ConstructSlotUserInfluenceGraphSubRoutine(char* flist, char* path, EventMigration& em)
{
	int ret = 0;
	vector<UserProfile>::iterator ulitStart, ulitEnd;
	vector<UserProfile> ulist = em.uiGraph.Getuplist();

	vector<vector<int>> uidPPtr;
	int ROWS = GenerateSlotUserGroups(ulist, uidPPtr,em);
			   
	int n, line;             // 图的结点数和路径数


	int prev[ROWSV + 1];     // 记录当前点的前一个结点
	float c[ROWSV + 1][ROWSV + 1];
	
	// 输入结点数
	n = TUNUM;
	// 输入路径数
	line = uiGraph.GetEdgeSet().size();
	int p, q;          // get p, q两点及其路径长度

	for (int i = 0; i < uidPPtr.size(); i++)
	{
		//process each group of users
		// 初始化c[][]为maxint
		for (int k = 1; k <= ROWSV; ++k) {
			for (int l = 1; l <= ROWSV; ++l)
				c[k][l] = 0.0;
		}
		//set c[][] values
		vector<GraphEdge>::iterator geit = em.uiGraph.GetEdgeSet().begin();
		vector<GraphEdge>::iterator geitEnd = em.uiGraph.GetEdgeSet().end();
		while (geit != geitEnd) {
			p = (*geit).upStart.userId;
			q = (*geit).upEnd.userId;

			int indexP = InGroup(uidPPtr[i], p);
			int indexQ = InGroup(uidPPtr[i], q);

			if (indexP && indexQ)
				c[indexP][indexQ] = (*geit).weight; // p指向q, or indexP to indexQ
			geit++;
		}

		//====================
		for (int j = 0; j < uidPPtr[i].size(); j++)
		{
			float influVector[ROWSV + 1] = { 0 };
			n = uidPPtr[i].size();

			if (n > 1) //n==1, that means this group contains only one user, which is not connected to any other users, then his influence to others is 0 and no need to search
				Dijkstra(n, j + 1, influVector, prev, c);  //(*ulitStart).userId+1, the ith node's index is i-1

			ulitStart = ulist.begin();
			while (ulitStart != ulist.end())
			{
				if ((*ulitStart).userId == uidPPtr[i][j])
				{
					//set values
					int indexP;
					vector<UPInfluDistriEle>::iterator upidit = (*ulitStart).UserInfluenceDistri.begin();
					while (upidit != (*ulitStart).UserInfluenceDistri.end())
					{
						indexP = InGroup(uidPPtr[i], (*upidit).userid);
						if (indexP)
							(*upidit).userInflu = influVector[indexP];

						if ((*upidit).userid == (*ulitStart).userId)
							(*upidit).userInflu = 1.0;

						upidit++;
					}
				}
				ulitStart++;
			}
		}

		uidPPtr[i].clear();
		//=======================
	}
	uidPPtr.clear();


	//===output the user graph infomration. 
	FILE* resultFile = NULL;
	//char* dictfile = "UserInfluDictfile.txt";
	char dictfile[200];
	strcpy_s(dictfile, "UserInfluDictfile_Nepal07");

	//for dymamic one
	strcat_s(dictfile, ".");
	strcat_s(dictfile, flist);
	/////////////
	if (fopen_s(&resultFile, dictfile, "a+") == 0)
	{
		ulitStart = ulist.begin();
		while (ulitStart != ulist.end())
		{
			fprintf_s(resultFile, "<USERID> %d </USERID>\n", (*ulitStart).userId);
			fprintf_s(resultFile, "<USERINFLUENCEDISTRI> ");

			vector<UPInfluDistriEle>::iterator upit = (*ulitStart).UserInfluenceDistri.begin();
			while (upit != (*ulitStart).UserInfluenceDistri.end())
			{
				fprintf_s(resultFile, "%d %f\t", (*upit).userid, (*upit).userInflu);
				upit++;
			}
			fprintf_s(resultFile, "</USERINFLUENCEDISTRI>\n");
			ulitStart++;
		}
		fclose(resultFile);
	}
	//////////////////////////////////////////////

	return ret;
}
int EventMigration::GenerateSlotUserGroups(vector<UserProfile>& uplist, vector<vector<int>>& uidPPtr, EventMigration& em)
{
	int maxGroupSize = 0;
	int i, j;
	vector<GraphEdge> gedge = em.uiGraph.GetEdgeSet();

	vector<UserProfile> Wholeuplist=uiGraph.Getuplist();

	//put the users with connected edges into same groups based on gedge
	vector<GraphEdge>::iterator geit = gedge.begin();
	while (geit != gedge.end())
	{
		//search uidPPtr
		int sizeUID = uidPPtr.size();
		for (i = 0; i < sizeUID; i++) {
			//check if (*geit).upStart.userid is in uidPPtr[i]
			int sizeInner = uidPPtr[i].size();
			if (sizeInner >= ROWSV - 2)//control the size of groups
				continue;
			for (j = 0; j < sizeInner; j++)
			{
				if ((*geit).upStart.userId == uidPPtr[i][j]) {
					if (!InGroup(uidPPtr[i], (*geit).upEnd.userId))
					{
						uidPPtr[i].push_back((*geit).upEnd.userId);
						Wholeuplist[(*geit).upEnd.userId].Inserted = 1;
					}
					break;
				}
				else if ((*geit).upEnd.userId == uidPPtr[i][j])
				{
					if (!InGroup(uidPPtr[i], (*geit).upStart.userId))
					{
						uidPPtr[i].push_back((*geit).upStart.userId);
						Wholeuplist[(*geit).upStart.userId].Inserted = 1;
					}
					break;
				}
			}
			if (j < sizeInner) //inserted
				break;
		}

		if (i == sizeUID)//not found, can not be kept in any existing cluster, generate new cluster
		{
			vector<int> newcluster;
			newcluster.push_back((*geit).upStart.userId);
			newcluster.push_back((*geit).upEnd.userId);
			Wholeuplist[(*geit).upStart.userId].Inserted = 1;
			Wholeuplist[(*geit).upEnd.userId].Inserted = 1;
			uidPPtr.push_back(newcluster);
		}
		geit++;
	}

	for (i = 0; i < uidPPtr.size(); i++)
	{
		if (uidPPtr[i].size() > maxGroupSize)
			maxGroupSize = uidPPtr[i].size();
	}
	return maxGroupSize;
}
/*
flist--the file containing the user list
construct user influence graph over the whole training set
*/

int EventMigration::ConstructUserInfluenceGraph(char* flist, char* path)
{
	int ret = 0;

	printf("start loading user profiles\n");
	uploadUserProfilesNew(flist, path); // upload user profiles
	printf("user profile loading finished\n");


	constructIGEdges();//construct edges between user profile nodes		
//	loadIGEdges();
	printf("constructIGEdges() is finished\n");
	
	ConstructUserInfluenceGraphSubRoutine(flist, path);
	return ret;
}
int EventMigration::ConstructUserInfluenceGraphSubRoutine(char *flist, char *path) 
{
	int ret=0;
	
//	printf("start loading user profiles\n");
//	uploadUserProfilesNew(flist, path); // upload user profiles
//	printf("user profile loading finished\n");

/*	constructIGEdges();//construct edges between user profile nodes		
//	loadIGEdges();
	printf("constructIGEdges() is finished\n");

	*////////////////===output the user graph infomration. 
	FILE* resultFile = NULL;
	char dictfile[200];
	//strcpy_s(dictfile,"NepalIGEdgefile(Training).txt");
	//strcpy_s(dictfile, "NepalIGEdgefile(Training25April-9May).txt");
	strcpy_s(dictfile, "NepalIGEdgefile(Training15April-24April).txt");
	
	//strcpy_s(dictfile, "IGEdgefile_TexasFlood(60000-120000).txt");
	if (fopen_s(&resultFile, dictfile, "a+") == 0)
	{		
		vector<GraphEdge>::iterator	Gesit = uiGraph.GetEdgeSet().begin();
		while (Gesit != uiGraph.GetEdgeSet().end())
		{
			fprintf_s(resultFile, "StartUser: %d\t EndUser: %d\t Weight: %.8f\t physicalRel: %.8f\t SocialRel: %.8f\n", 
				(*Gesit).upStart.userId, (*Gesit).upEnd.userId, (*Gesit).weight, (*Gesit).physicalRel, (*Gesit).SocialRel);
			Gesit++;
		}
		fclose(resultFile);
	}
	/*return ret;*/
	////////////////


	vector<UserProfile>::iterator ulitStart, ulitEnd;
	vector<UserProfile> ulist = uiGraph.Getuplist();
	
	vector<vector<int>> uidPPtr;
	int ROWS =GenerateUserGroups(ulist, uidPPtr);

	printf("ROWS=%d \t GroupNum:%d\n", ROWS, uidPPtr.size());
	for (int i = 0; i < uidPPtr.size(); i++) {
		printf("cluster: i=%d, size=%d\n", i, uidPPtr[i].size());
		vector<int>::iterator uit = uidPPtr[i].begin();
		printf("<useridlist> ");
		while (uit != uidPPtr[i].end()) {
			printf("%d\t", (*uit));
			uit++;
		}
		printf("</useridlist>\n");
	}

	
		
	///////// ConstructUserInfluenceDistribution set UserInfluenceDistri values of each node in graph///////////////////////////////////	
	//////when TUNUM is big, c has memory overflow, needs Emily's revision later. 
	//I can add one more step here to divide the users into several subgroups, and then do the Dijkstra over each subgroup
	// 各数组都从下标1开始
	//int prev[TUNUM+1];     // 记录当前点的前一个结点
	//float c[TUNUM+1][TUNUM+1];   // 记录图的两点间路径长度	
	int n, line;             // 图的结点数和路径数
	
	
	int prev[ROWSV + 1];     // 记录当前点的前一个结点
	float c[ROWSV + 1][ROWSV + 1];
	///////

	// 输入结点数
	n = TUNUM;
	// 输入路径数
	line = uiGraph.GetEdgeSet().size();
	int p, q;          // get p, q两点及其路径长度
	
	for (int i = 0; i < uidPPtr.size(); i++)
	{
		//process each group of users
		// 初始化c[][]为maxint
		for (int k = 1; k <= ROWSV; ++k) {
			for (int l = 1; l <= ROWSV; ++l)
				c[k][l] = 0.0;
		}
		//set c[][] values
		vector<GraphEdge>::iterator geit = uiGraph.GetEdgeSet().begin();
		vector<GraphEdge>::iterator geitEnd = uiGraph.GetEdgeSet().end();
		while (geit != geitEnd) {
			p = (*geit).upStart.userId;
			q = (*geit).upEnd.userId;

			int indexP = InGroup(uidPPtr[i], p);
			int indexQ = InGroup(uidPPtr[i], q);
			
			if(indexP&&indexQ)
				c[indexP][indexQ] = (*geit).weight; // p指向q, or indexP to indexQ
			geit++;
		}		
		
		//====================
		for (int j = 0; j < uidPPtr[i].size(); j++) 
		{
			float influVector[ROWSV + 1] = { 0 };
			n = uidPPtr[i].size();
						
			if(n>1) //n==1, that means this group contains only one user, which is not connected to any other users, then his influence to others is 0 and no need to search
				Dijkstra(n, j + 1, influVector, prev, c);  //(*ulitStart).userId+1, the ith node's index is i-1

			ulitStart = ulist.begin();
			while (ulitStart != ulist.end())
			{
				if ((*ulitStart).userId == uidPPtr[i][j])
				{
					//set values
					int indexP;
					vector<UPInfluDistriEle>::iterator upidit = (*ulitStart).UserInfluenceDistri.begin();
					while (upidit != (*ulitStart).UserInfluenceDistri.end()) 
					{
						indexP = InGroup(uidPPtr[i], (*upidit).userid);
						if(indexP)
							(*upidit).userInflu = influVector[indexP];

						if ((*upidit).userid == (*ulitStart).userId)
							(*upidit).userInflu = 1.0;

						upidit++;
					}					
				}
				ulitStart++;
			}
		}		

		uidPPtr[i].clear();
		//=======================
	}
	uidPPtr.clear();
	
	
	//===output the user graph infomration. 
	/*FILE* resultFile = NULL;
	//char* dictfile = "UserInfluDictfile.txt";
	char dictfile[200];*/
	strcpy_s(dictfile, "UserInfluDictfile_Nepal07(Training15April-24April).txt");

	//for dymamic one
	/*strcat_s(dictfile, ".");
	strcat_s(dictfile, flist);*/
	/////////////
	if (fopen_s(&resultFile, dictfile, "a+") == 0)
	{
		ulitStart = ulist.begin();
		while (ulitStart != ulist.end())
		{		
			fprintf_s(resultFile, "<USERID> %d </USERID>\n", (*ulitStart).userId);
			fprintf_s(resultFile, "<USERINFLUENCEDISTRI> ");
			
			vector<UPInfluDistriEle>::iterator upit = (*ulitStart).UserInfluenceDistri.begin();
			while (upit != (*ulitStart).UserInfluenceDistri.end()) 
			{
				fprintf_s(resultFile, "%d %f\t", (*upit).userid, (*upit).userInflu);
				upit++;
			}
			fprintf_s(resultFile, "</USERINFLUENCEDISTRI>\n");
			ulitStart++;
		}
		fclose(resultFile);
	}
	//////////////////////////////////////////////
	
	return ret;
}

int EventMigration::loadUserInfluenceGraph(char* UIfname) {
	int ret = 0;
	
	FILE* fileDescriptor = NULL;
	char buffer[BUFFERSIZE];

	UserProfile up;
	
	string line;

	if ((fopen_s(&fileDescriptor, UIfname, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", UIfname);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) line!\n");
				return 1;
			}

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<USERID>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</USERID>") != 0)
					{
						up.userId = (int)atoi(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<USERINFLUENCEDISTRI>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</USERINFLUENCEDISTRI>") != 0) {									
						UPInfluDistriEle UPIele;
						UPIele.userid = atoi(strtok.token(i).c_str());
						i++;
						UPIele.userInflu = atof(strtok.token(i).c_str());
						i++;
						up.UserInfluenceDistri.push_back(UPIele);
					}
					uiGraph.loadtoUplist(up);
					up.UserInfluenceDistri.clear();
					i++;
					continue;
				}
				i++;
			}
		}
		fclose(fileDescriptor);
	}
	return ret;
}
//for parallel
int EventMigration::BulkLoadUserHistoryEvents(char* userEventflist, char* path) {
	int ret = 0;
	char  FullSlotFileName[200];
	char buffer[200];
	FILE* fileDescriptor = NULL;

	//int skipDocNum = 168;
	int count = 0;	
	int StartClusterNo = 0;// 7672;
	if ((fopen_s(&fileDescriptor, userEventflist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", userEventflist);
	}
	else {
		while (fscanf_s(fileDescriptor, "%s ", buffer, 200) != EOF)
		{   			
			count++;		
			//if (count > 6)
			if (count > 24)  //the first day event is put into user profiles as initial user history activity
			//if (count > 168)  //for statistics
				break;
			if (count % 2 > 0)
				continue;
			//load data
			strcpy_s(FullSlotFileName, 200, path);
			strcat_s(FullSlotFileName, 200, buffer);
			strcat_s(FullSlotFileName, 200, ".UPdata");
			
			printf("FullSlotFileName: %s\n", buffer);			
			LoadUserProfileEvents(FullSlotFileName, StartClusterNo);
		}
		fclose(fileDescriptor);
	}
	return ret;
}

//added by emily on Sept 11, put event statistics information. No message kept to save memory
int EventMigration::LoadUserProfileEvents(char* UEventfname, int StartClusterNo) {
	int ret = 0;

	FILE* fileDescriptor = NULL;
	char buffer[BUFFERSIZE];

	float vec[TFIDF_DIM];
	
	TimeRange newTR = { 0.0,0.0 };
	SpaceRange newSR = { 0.0,0.0,0.0 };
	vector<EUserFrePair> euids;
	vector<EUserFrePair>::iterator euit;

	string line;
	SubEvent curEvent;
	int eid = 0;
	if ((fopen_s(&fileDescriptor, UEventfname, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", UEventfname);
	}
	else
	{
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) line!\n");
				return 1;
			}

			int i = 0;			
			if (strcmp(strtok.token(i).c_str(), "<clusterid>") == 0) {					
				i++;
				while (strcmp(strtok.token(i).c_str(), "</clusterid>") != 0){
					//curEvent.SetEventNo(atoi(strtok.token(i).c_str())- StartClusterNo);
					curEvent.SetEventNo(atoi(strtok.token(i).c_str()));
					i++;
				}
				i++;
				continue;
			}		

			if (strcmp(strtok.token(i).c_str(), "<UserSvd>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</UserSvd>") != 0)
				{
					for (int j = 0; j < TFIDF_DIM; j++) {
						vec[j] = atof(strtok.token(i).c_str());
						i++;
					}
				}

				curEvent.setUserInfluVec(vec);
				i++;
				continue;
			}

			if (strcmp(strtok.token(i).c_str(), "<msgcontfidf>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</msgcontfidf>") != 0)
				{
					for (int j = 0; j < TFIDF_DIM; j++) {
						vec[j]= atof(strtok.token(i).c_str());
						i++;	
					}									
				}
				
				curEvent.setConceptTFIDFVec(vec);
				i++;
				continue;
			}			

			/*if (strcmp(strtok.token(i).c_str(), "<HashkeyValues>") == 0) {
				i++;
				int j = 0;
				while (strcmp(strtok.token(i).c_str(), "</HashkeyValues>") != 0) {
					curEvent.EHashV[j]== atoi(strtok.token(i).c_str());
					i++;
					j++;
				}
				i++;
				continue;
			}		*/	

			if (strcmp(strtok.token(i).c_str(), "<SpaceRange>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</SpaceRange>") != 0)
				{						
					newSR.lat = (float)atof(strtok.token(i).c_str());
					i++;
					newSR.longi = (float)atof(strtok.token(i).c_str());
					i++;
					newSR.radius= (float)atof(strtok.token(i).c_str());
					i++;
				}					
				curEvent.setSpaceRange(newSR);
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<TimeRange>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</TimeRange>") != 0) {						
					newTR.TimeStampCentre = (float)atof(strtok.token(i).c_str());
					i++;
					newTR.range = (float)atof(strtok.token(i).c_str());;
					i++;
				}
				curEvent.setTimeRange(newTR);
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<SpaceRangeSet>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</SpaceRangeSet>") != 0)
				{
					SpaceRange srtmp;
					srtmp.lat=atof(strtok.token(i).c_str());
					i++;
					srtmp.longi= atof(strtok.token(i).c_str());
					i++;
					srtmp.radius = atof(strtok.token(i).c_str());
					curEvent.uploadmsgSRset(srtmp);
					i++;
				}
			}
			if (strcmp(strtok.token(i).c_str(), "<TimeRangeSet>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</TimeRangeSet>") != 0)
				{
					TimeRange trtmp;
					trtmp.TimeStampCentre = atof(strtok.token(i).c_str());
					i++;
					trtmp.range = atof(strtok.token(i).c_str());
					curEvent.uploadmsgTRset(trtmp);
					i++;
				}
			}
			if (strcmp(strtok.token(i).c_str(), "<useridlist>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</useridlist>") != 0)
				{
					EUserFrePair eufPair;
					eufPair.userid = atoi(strtok.token(i).c_str());
					i++;
					eufPair.frequency=atoi(strtok.token(i).c_str());
					//sort based on user id
					euit = euids.begin();
					while (euit != euids.end())	{
						if ((*euit).userid > eufPair.userid){
							euids.insert(euit, eufPair);
							euit = euids.begin();
							break;
						}
						euit++;
					}
					if(euit==euids.end())
						euids.push_back(eufPair);						
					i++;
				}
				curEvent.setEventUserIDs(euids);
				euids.clear();
								
				if (UPEventList.size() <= curEvent.GetEventNo())
					UPEventList.resize(curEvent.GetEventNo() + 1);
				UPEventList[curEvent.GetEventNo()] = curEvent;
				i++;				
				
				curEvent.cleansubEvent();  //only keep the eventno in user profile to save memory
				euit = UPEventList[curEvent.GetEventNo()].GetEventUserIDs().begin();
				while (euit != UPEventList[curEvent.GetEventNo()].GetEventUserIDs().end()) {
					UserProfileHashMap[(*euit).userid].UserInterestEvents.push_back(curEvent);
					euit++;
				}
				//reset curEvent;
				curEvent.EventReset();
			}
		}		
		//=====================
		fclose(fileDescriptor);
	}
	
	ret = UPEventList.size();
	TimePeriodLastClusterNoList.push_back(ret);

	return ret;
}


int EventMigration::UpdateUserProfileHashMap(char* UIfname) //input the user influence filename, and load the user influence information into UserProfileHashMap
{
	int ret = 0;

	FILE* fileDescriptor = NULL;
	char buffer[BUFFERSIZE];

	UserProfile up;

	string line;
	int uid = 0;

	if ((fopen_s(&fileDescriptor, UIfname, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", UIfname);
	}
	else {

		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) line!\n");
				return 1;
			}

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<USERID>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</USERID>") != 0)
					{
						uid = atoi(strtok.token(i).c_str());
						UserProfileHashMap[uid].userId = uid;
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<USERINFLUENCEDISTRI>") == 0) {
					i++;
					UserProfileHashMap[uid].UserInfluenceDistri.clear();

					while (strcmp(strtok.token(i).c_str(), "</USERINFLUENCEDISTRI>") != 0)
					{
						UPInfluDistriEle upide;
						upide.userid = atoi(strtok.token(i).c_str());
						i++;
						upide.userInflu = atof(strtok.token(i).c_str());
						i++;
						UserProfileHashMap[uid].UserInfluenceDistri.push_back(upide);
					}

					i++;
					continue;
				}
				i++;
			}
		}
		fclose(fileDescriptor);
	}
	return ret;
}

int EventMigration::loadUserProfileHashMap(char* UIfname) //input the user influence filename, and load the user influence information into UserProfileHashMap
{
	int ret = 0;

	FILE* fileDescriptor = NULL;
	char buffer[BUFFERSIZE];

	UserProfileHashMap.resize(TUNUM);

	UserProfile up;
	
	string line;
	int uid = 0;

	if ((fopen_s(&fileDescriptor, UIfname, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", UIfname);
	}
	else {

		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) line!\n");
				return 1;
			}
			
			int i = 0;			
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<USERID>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</USERID>") != 0)
					{
						uid=atoi(strtok.token(i).c_str());
						UserProfileHashMap[uid].userId = uid;
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<USERINFLUENCEDISTRI>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</USERINFLUENCEDISTRI>") != 0) 
					{												
						UPInfluDistriEle upide;
						upide.userid= atoi(strtok.token(i).c_str());
						i++;
						upide.userInflu = atof(strtok.token(i).c_str());
						i++;
						UserProfileHashMap[uid].UserInfluenceDistri.push_back(upide);
					}
					
					i++;
					continue;
				}				
				i++;
			}
		}
		fclose(fileDescriptor);
	}
	return ret;
}
//compute the relevance probability of seFirst and seMigrate
float EventMigration::EventMigrationProb(SubEvent&seFirst, SubEvent&seMigrate)
{
	float Probr = 0; //if seMigrate is the migration of social event seFirst, then ret=1, otherwise ret=0;

	vector<EUserFrePair>::iterator sfit = seFirst.GetEventUserIDs().begin();
	vector<EUserFrePair>::iterator sfitend = seFirst.GetEventUserIDs().end();
	int seFirstULen = seFirst.GetEventUserIDs().size();
	int migrateULen = seMigrate.GetEventUserIDs().size();
	
	while (sfit!=sfitend) {		 
		vector<EUserFrePair>::iterator sefit = seMigrate.GetEventUserIDs().begin();
		vector<EUserFrePair>::iterator sefitend = seMigrate.GetEventUserIDs().end();
		while (sefit != sefitend) {				
			Probr+=GetUserSimi(UserProfileHashMap[(*sfit).userid], UserProfileHashMap[(*sefit).userid]);
			sefit++;
		}		
		sfit++;
	}

	int lenTimes = seFirstULen * migrateULen;
	if (lenTimes == 0)
		Probr = 0;
	else
		Probr /= (seFirstULen* migrateULen);

	return Probr;
}

int EventMigration::IsMigrateEvent(SubEvent&seFirst, SubEvent&seMigrate, float migrateT) {
	int ret = 0;
	float prob=EventMigrationProb(seFirst, seMigrate);
	if (prob >= migrateT)
		ret = 1; //is migrated event

	return ret;
}

//for parallel
int EventMigration::BulkLoadUserHistoryEventsForSpark(char* userflist, vector<SubEvent>& elist){//for all users {
	int ret = 0;
	char path[200];
	strcpy_s(path, "..\\..\\213_21all\\VirtualHisEventPath\\");
	char  FullSlotFileName[200];

	char buffer[200];
	FILE* fileDescriptor = NULL;


	if ((fopen_s(&fileDescriptor, userflist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", userflist);
	}
	else {
		while (fscanf_s(fileDescriptor, "%s ", buffer, 200) != EOF)
		{   //load data
			int userid = atoi(buffer);
			strcpy_s(FullSlotFileName, 200, path);
			strcat_s(FullSlotFileName, 200, buffer);
			strcat_s(FullSlotFileName, 200, ".UPdata");

			LoadUserHistoryEventsForSpark(FullSlotFileName, userid,elist);
		}
		fclose(fileDescriptor);
	}
	return ret;
}
int EventMigration::LoadUserHistoryEventsForSpark(char* UEventfname, int userid, vector<SubEvent>& elist) {
	int ret = 0;

	FILE* fileDescriptor = NULL;
	char buffer[BUFFERSIZE];

	float vec[TFIDF_DIM] = { 0 };

	TimeRange newTR = { 0.0,0.0 };
	SpaceRange newSR = { 0.0,0.0,0.0 };
	vector<EUserFrePair> euids;
	unsigned long long int msgid = 0;
	
	string line;
	int isMSG = 0;
	int isHashtag = 0;
	SubEvent curEvent;
	int eid = 0;
	if ((fopen_s(&fileDescriptor, UEventfname, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", UEventfname);
	}
	else
	{
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) line!\n");
				return 1;
			}

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<clusterid>") == 0) {
					isMSG = 0;
					//=====================
					if (curEvent.GetEventMSGs().size() > 0)  //not the first event, then insert the previous event
					{
						//set the user-event interaction recorders between curEvent and user id
						curEvent.SetEventUserIDs();
						curEvent.SetCluster_ConceptTFIDFVec();
						curEvent.SetSpaceRange();
						curEvent.SetTimeRange();
						//===========================================
						elist.push_back(curEvent);
						//reset curEvent;
						curEvent.EventReset();
					}
					//=====================
					i++;
					while (strcmp(strtok.token(i).c_str(), "</clusterid>") != 0)
					{
						curEvent.SetEventNo(atoi(strtok.token(i).c_str()));
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<hashtags>") == 0)
				{
					isMSG = 1;
					i++;
					while (strcmp(strtok.token(i).c_str(), "</hashtags>") != 0) {
						isHashtag = atoi(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<msgcontfidf>") == 0) {
					int j = 0;
					i++;
					while (strcmp(strtok.token(i).c_str(), "</msgcontfidf>") != 0)
					{
						vec[j] = (float)atof(strtok.token(i).c_str());
						i++;
						j++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
					isMSG = 1;
					i++;
					while (strcmp(strtok.token(i).c_str(), "</msgid>") != 0) {
						msgid = stoull(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}
								
				if (strcmp(strtok.token(i).c_str(), "<coordinates>") == 0) {
					isMSG = 1;
					i++;
					int j = 0;
					while (strcmp(strtok.token(i).c_str(), "</coordinates>") != 0)
					{
						if (j == 0) {
							newSR.lat = (float)atof(strtok.token(i).c_str());
							j++;
						}
						else {
							newSR.longi = (float)atof(strtok.token(i).c_str());
						}
						i++;
					}
					newSR.radius = SPACERADIUST;
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<timestamp_ms>") == 0) {
					isMSG = 1;
					i++;
					while (strcmp(strtok.token(i).c_str(), "</timestamp_ms>") != 0) {
						newTR.TimeStampCentre = (float)atof(strtok.token(i).c_str()) / 60;
						newTR.range = TIMERADIUST;
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<useridlist>") == 0) {
					isMSG = 1;
					i++;
					while (strcmp(strtok.token(i).c_str(), "</useridlist>") != 0)
					{
						EUserFrePair eufPair;
						eufPair.userid = atoi(strtok.token(i).c_str());
						vector<EUserFrePair>::iterator uit = euids.begin();
						while (uit != euids.end()) {
							if ((*uit).userid == eufPair.userid)
								break;
							uit++;
						}
						if (uit != euids.end()) {
							(*uit).frequency++;
						}
						else {
							eufPair.frequency = 1;
							euids.push_back(eufPair);
						}
						i++;
					}
					i++;
					continue;
				}
			}
			if (isMSG == 1) {  //is message, then add it into the messagelist of 
				SocialMSG  newsocialmsg(0, vec, newTR, newSR, euids);
				newsocialmsg.setMSGID(msgid);
				if (isHashtag) {
					newsocialmsg.hashtaged = isHashtag;
					isHashtag = 0;
				}
				curEvent.uploadEventMsg(newsocialmsg);
				euids.clear();
			}
		}
		if (curEvent.GetEventMSGs().size() > 0)  // insert the last event
		{
			//set the user-event interaction recorders between curEvent and user id
			curEvent.SetEventUserIDs();
			curEvent.SetCluster_ConceptTFIDFVec();
			curEvent.SetSpaceRange();
			curEvent.SetTimeRange();

			elist.push_back(curEvent);
			//reset curEvent;
			curEvent.EventReset();
		}
		//=====================
		fclose(fileDescriptor);
	}
	ret = elist.size();
	return ret;
}



