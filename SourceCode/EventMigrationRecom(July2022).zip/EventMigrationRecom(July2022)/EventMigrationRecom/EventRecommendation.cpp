#include "EventRecommendation.h"

float EventRecommendation::GetESim(SubEvent &En, SubEvent &Eu) {
	EventMigration emig;
	float probr = 0;
	if(alpha>0)
		probr= emig.EventMigrationProb(En, Eu);
	if (probr > 0)
	//if(probr==1)		
		printf("probr=%f\t EventID=%d\t UserEventID=%d\n", probr, En.GetEventNo(), Eu.GetEventNo());
	float Sim = En.EventSimi(Eu);
	float overallsim = (1 - alpha)* Sim + alpha *probr;
	return overallsim;
}

float EventRecommendation::GetESimUser(SubEvent &En, UserProfile &up) {
	float ESim = 0;
	vector<SubEvent>::iterator eit = up.UserInterestEvents.begin();
	while (eit != up.UserInterestEvents.end()) {
		//float overallsim = GetESim(En, (*eit));
		//ignore the events in the current time slot
		if ((*eit).GetEventNo() > curEventNum)
			continue;
		//=================================
		//float overallsim = GetESim(En, UPEventList[(*eit).GetEventNo()]);
		//use pre stored similarity
		float overallsim = UPEventList[(*eit).GetEventNo()].HistEventSimilarity;
		if (overallsim > ESim)
			ESim = overallsim;
		eit++;
	}
	return ESim;
}

float EventRecommendation::GetIntraSjIa( int gjattrJx_eventlistSize, int gjattrJy_eventlistSize) {
	float SjIaEn = 0;
	
	int NvEn = gjattrJx_eventlistSize;
	int NvEu = gjattrJy_eventlistSize;

	SjIaEn = (float)(NvEn*NvEu) / (NvEn + NvEu + NvEn * NvEu);
	
	return SjIaEn;
}

//here j is the user number, x is the value in CouplingInfomrationTable, return the size of a list of event ids
int EventRecommendation::Get_gjx_eventlist_Size(int j, float x) {
	/*for (int i = 0; i < curEventNum; i++)
	{
		if (CouplingInformationTable[i][j] == x)
			gjx.push_back(i);
	}*/
	int eventNum = 0;
	if (x == 0) {
		for (int i = 0; i < curEventNum; i++) {
			vector<EUserFrePair> CouplEleList = UPEventList[i].GetEventUserIDs();
			int k = 0;
			for (k = 0; k < CouplEleList.size(); k++) {
				if (CouplEleList[k].userid > j){  //not in list, means frequency is 0
					eventNum++;
					break;
				}
			}
			CouplEleList.clear();
		}
	}
	else {
		for (int i = 0; i < curEventNum; i++) {
			vector<EUserFrePair> CouplEleList = UPEventList[i].GetEventUserIDs();
			int k = 0;
			for (k = 0; k < CouplEleList.size(); k++) {
				if (CouplEleList[k].userid == j)  //here j is the userid
				{
					if (CouplEleList[k].frequency == x)
						eventNum++;
					break;
				}
			}
			CouplEleList.clear();
		}
	}
	return eventNum;
}


float EventRecommendation::GetProbEventClusters(int EnNo, int EuNo) {
	float CoupledEventSimi = 0;
	
	vector<EUserFrePair> CouplingInformationTable_EnNo = UPEventList[EnNo].GetEventUserIDs();
	vector<EUserFrePair> CouplingInformationTable_EuNo = UPEventList[EuNo].GetEventUserIDs();

	vector<EUserFrePair>::iterator EnUit, EuUit;

	EnUit = CouplingInformationTable_EnNo.begin();
	EuUit = CouplingInformationTable_EuNo.begin();
/*	for (int j = 0; j < TUNUM; j++) 
	{
		int attrJ = j;
		float attrJx;
		float attrJy;
		if (EnUit != CouplingInformationTable_EnNo.end()) {
			if (j == (*EnUit).userid) {
				attrJx = (*EnUit).frequency;
				EnUit++;
			}
			else
				attrJx = 0;
		}
		else
			attrJx = 0;

		if (EuUit != CouplingInformationTable_EuNo.end()) {
			if (j == (*EuUit).userid)
			{
				attrJy = (*EuUit).frequency;
				EuUit++;
			}
			else
				attrJy = 0;
		}
		else
			attrJy = 0;

		int gjattrJx_eventlistSize = Get_gjx_eventlist_Size(attrJ, attrJx);
		int gjattrJy_eventlistSize = Get_gjx_eventlist_Size(attrJ, attrJy);

		float intraSJ = GetIntraSjIa(gjattrJx_eventlistSize, gjattrJy_eventlistSize);

		CoupledEventSimi += intraSJ;
	}
	CoupledEventSimi /= TUNUM;*/

	int attrJ;
	float attrJx;
	float attrJy;

	int UserCount = 0;
	while (EnUit != CouplingInformationTable_EnNo.end() && EuUit != CouplingInformationTable_EuNo.end()) {		
		if ((*EnUit).userid == (*EuUit).userid) 
		{
			attrJ = (*EnUit).userid;
			attrJx = (*EnUit).frequency;
			attrJy = (*EuUit).frequency;			
			EnUit++;
			EuUit++;
		}
		else if ((*EnUit).userid < (*EuUit).userid) {
			attrJ = (*EnUit).userid;
			attrJx = (*EnUit).frequency;
			attrJy = 0;

			EnUit++;
		}
		else {
			attrJ = (*EuUit).userid;
			attrJx = 0;
			attrJy = (*EuUit).frequency;
			EuUit++;
		}

		int gjattrJx_eventlistSize = Get_gjx_eventlist_Size(attrJ, attrJx);
		int gjattrJy_eventlistSize = Get_gjx_eventlist_Size(attrJ, attrJy);

		float intraSJ = GetIntraSjIa(gjattrJx_eventlistSize, gjattrJy_eventlistSize);

		CoupledEventSimi += intraSJ;
		UserCount++;
	}

	while (EnUit != CouplingInformationTable_EnNo.end()) {
		attrJ = (*EnUit).userid;
		attrJx = (*EnUit).frequency;
		attrJy = 0;		
		int gjattrJx_eventlistSize = Get_gjx_eventlist_Size(attrJ, attrJx);
		int gjattrJy_eventlistSize = Get_gjx_eventlist_Size(attrJ, attrJy);
		float intraSJ = GetIntraSjIa(gjattrJx_eventlistSize, gjattrJy_eventlistSize);
		CoupledEventSimi += intraSJ;
		EnUit++;
		UserCount++;
	}
	while (EuUit != CouplingInformationTable_EuNo.end()) {
		attrJ = (*EuUit).userid;
		attrJx = 0;
		attrJy = (*EuUit).frequency;
		int gjattrJx_eventlistSize = Get_gjx_eventlist_Size(attrJ, attrJx);
		int gjattrJy_eventlistSize = Get_gjx_eventlist_Size(attrJ, attrJy);
		float intraSJ = GetIntraSjIa(gjattrJx_eventlistSize, gjattrJy_eventlistSize);
		CoupledEventSimi += intraSJ;
		EuUit++;
		UserCount++;
	}

	CoupledEventSimi /= UserCount;   //average, ignore the case where both events are not interacted by a user
	
	/*for (int j = 0; j < TUNUM; j++) {
		list<int> gjattrJx_eventlist;
		list<int> gjattrJy_eventlist;
		int attrJ = j;
		float attrJx = CouplingInformationTable[EnNo][j];
		float attrJy = CouplingInformationTable[EuNo][j];

		Get_gjx_eventlist(gjattrJx_eventlist, attrJ, attrJx);
		Get_gjx_eventlist(gjattrJy_eventlist, attrJ, attrJy);

		float intraSJ = GetIntraSjIa(attrJ, attrJx, attrJy,gjattrJx_eventlist,gjattrJy_eventlist);
		float interSJ = GetInterSJIe(attrJ, attrJx, attrJy,gjattrJx_eventlist,gjattrJy_eventlist);
		CoupledEventSimi += intraSJ * interSJ;

		gjattrJx_eventlist.clear();
		gjattrJy_eventlist.clear();
	}*/
	return CoupledEventSimi;
}
float EventRecommendation::GetProbUserEvent(SubEvent &En, int EnNo, UserProfile &up) {
	float UserEventProb = 0;

	float ESim = 0;
	vector<SubEvent>::iterator eit = up.UserInterestEvents.begin();
	while (eit != up.UserInterestEvents.end()) {
		//float overallsim = GetESim(En, (*eit));
		//note that the user history events are not stored in UPEventList[HTSize] table, not in user profiles to save space
	/*	float overallsim = GetESim(En, UPEventList[(*eit).GetEventNo()]);
		if (overallsim<=ESim) {
			eit++;
			continue;
		}

		int EuNo = (*eit).GetEventNo();

		UserEventProb = GetProbEventClusters(EnNo, EuNo);
		//UserEventProb *= overallsim;
		overallsim *= UserEventProb;

		//if (overallsim > UserEventProb)
		if(overallsim>ESim)
			ESim = overallsim;*/

		//use pre computed history event similarity
		float overallsim = UPEventList[(*eit).GetEventNo()].HistEventSimilarity;
		if (overallsim > ESim)
			ESim = overallsim;
		eit++;
	}
	return ESim;
}

