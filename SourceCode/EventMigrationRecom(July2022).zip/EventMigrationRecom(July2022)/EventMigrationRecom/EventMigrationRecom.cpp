// EventMigrationRecom.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

#include "SocialMessage.h"
#include "Event.h"
#include "EventMigrationRecom.h"
#include "EventMigration.h"

vector<SubEvent> UPEventList; //store the events in user profiles. user profiles only keep the event no, not the attributes of events
vector<UserProfile> UserProfileHashMap;
vector<string> GTHashtagHashTable[HTSize]; //keep event related hashtags
vector<strFre> DocHashtagHashTable[HTSize]; //keep hashtag in a time slot
set<long long int> GTMsgSet; //keep the groud truth messages
vector<int> TimePeriodLastClusterNoList;


float ELIPSE;//social message similarity threshold, can be variable. Get value from main parameter list
float SPACERADIUST;
float TIMERADIUST;
float omeg1; //concept net weight
float omeg2; //time weight, then the weight of location is 1-omeg1-omeg2
int MethodChoice;
int TOPK;
float alp;
float WUIPV;
int histTimePeriods;
int staticOrDynamic=1;  //0: static, 1: dynamic. default is dynamic

int main(int argc, char* argv[])
{
    //========================
	bool		failed = false;
	char		c = -1;
	char		para[200];
	char		tpara[200];
	char* cp = NULL;
	int			cnt = 1;
	char* flistname = NULL;
	char* path = NULL;
	char* outpath = NULL;
	char* UserInfluFilePath = NULL;
	char* TrainingSetGramMSGNoFname = NULL;
	char* UserInfluFileName = NULL;
	char* userlist = NULL;
	char* userProfilePath = NULL;
	char* ext = NULL;
	char* HistoryPartition = NULL;
	char* partitionPath = NULL;
	float migrateT; //0.001;  //this value is varied to be evaluated in experimental evaluation part in the part.
	int coupling; //the flag to select if coupling event similarity is applied in recommendation

	char* PARM = NULL;
	

	while (cnt < argc && !failed)
	{
		cp = argv[cnt];

		c = cp[0];
		if (c != '-')
		{
			failed = true;
			break;
		}

		strcpy_s(tpara, cp + 1);

		cnt++;
		if (cnt == argc) {
			failed = true;
			break;
		}

		cp = argv[cnt];

		if (strcmp(tpara, "em") == 0)
		{
			flistname = cp;// ContinuousEventMigration
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "tfidfnorm") == 0) {
			flistname = cp;
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "ccuid") == 0)
		{
			flistname = cp;
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "er") == 0)
		{
			flistname = cp;// for ContinousEventRecommendation
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "gue") == 0)
		{
			flistname = cp;// for GenerateVisualUserProfileEventsForRecTest
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "fe") == 0) {
			flistname = cp;// FindSubEvents;
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "cig") == 0) {
			flistname = cp; //
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "upa") == 0) {
			flistname = cp;
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "parm") == 0) {
			PARM = cp;
		}
		else if (strcmp(tpara, "upqg") == 0) {
			flistname = cp;
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "cigu") == 0) {
			flistname = cp; //
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "hp") == 0) {
			HistoryPartition = cp;
		}
		else if (strcmp(tpara, "hpp") == 0) {
			partitionPath = cp;
		}
		else if (strcmp(tpara, "pa") == 0) {
			path = cp;
		}
		else if (strcmp(tpara, "op") == 0) {
			outpath = cp;
		}
		else if (strcmp(tpara, "uip") == 0) {
			UserInfluFilePath = cp;
		}
		else if (strcmp(tpara, "uif") == 0) {
			UserInfluFileName = cp;
		}
		else if (strcmp(tpara, "ul") == 0) {
			userlist = cp;
		}
		else if (strcmp(tpara, "upp") == 0) {
			userProfilePath = cp;
		}
		else if (strcmp(tpara, "mt") == 0) {
			migrateT = atof(cp);
		}
		else if (strcmp(tpara, "coup") == 0) {
			coupling = atoi(cp);
		}
		else if (strcmp(tpara, "ext") == 0) {
			ext = cp;
		}
		else if (strcmp(tpara, "elip") == 0) {
			ELIPSE = atof(cp);
		}
		else if (strcmp(tpara, "tau") == 0)
		{
			TIMERADIUST = atof(cp);
		}
		else if (strcmp(tpara, "r") == 0) {
			SPACERADIUST = atof(cp);
		}
		else if (strcmp(tpara, "omeg1") == 0) {
			omeg1 = atof(cp);
		}
		else if (strcmp(tpara, "omeg2") == 0) {
			omeg2 = atof(cp);
		}
		else if (strcmp(tpara, "MC") == 0)
			MethodChoice = atoi(cp);
		else if (strcmp(tpara, "K") == 0) {
			TOPK = atoi(cp);
		}
		else if (strcmp(tpara, "migalp") == 0) {
			alp = atof(cp);
		}
		else if (strcmp(tpara, "wuipv") == 0)
			WUIPV = atof(cp);
		else if (strcmp(tpara, "histTP") == 0)
			histTimePeriods = atoi(cp);
		else if (strcmp(tpara, "sd")==0)
			staticOrDynamic = atoi(cp);
		cnt++;
	}

	
	if (strcmp(para, "em") == 0) {
		char HashTags[200];
		if(strcmp(flistname,"napelDataTestFlist(April25-May1).txt") == 0)//
			strcpy_s(HashTags, "NepalGTHashTags.txt");
		else if(strcmp(flistname,"TexasFloodDataFlist(22-28May).txt") == 0)
			strcpy_s(HashTags, "TexasGTHashTags_73.txt");
		else
			return 0; //only two datasets are tested. For other datasets, the code for this part needs to be changed to fit new datasets.
		ReadHashtags(HashTags); //all event reated hashtags are read into GTHashtagHashTable[HTSize]
		ContinuousEventMigration(flistname, path, outpath, ext, migrateT, UserInfluFilePath);  //Done
	}
	else if (strcmp(para, "er") == 0) {		
		TimePeriodLastClusterNoList.clear();
		ContinuousEventRecommedation(flistname, path, outpath, ext, migrateT, UserInfluFilePath, UserInfluFileName, userlist, coupling, userProfilePath);  //Done
		TimePeriodLastClusterNoList.clear();		
	}
	else if (strcmp(para, "gue") == 0) {
		GenerateVisualUserProfileEventsForRecTestNew(flistname, path, outpath, ext, UserInfluFilePath);		
	}	
	else if (strcmp(para, "cig") == 0) {  //Done
		EventMigration em;	
		em.ConstructUserInfluenceGraph(flistname, path);  //here path means userprofileflist, flistname means userprofile_TexasFlood...
	}
	else if (strcmp(para, "cigu") == 0) { //done
		EventMigration em;
		em.ContinuousUserInfluenceGraphUpdate(flistname, path);
	}
	else if (strcmp(para, "upa") == 0) {
		if(strcmp(PARM,"c")==0)
			UserProfileAllocation(flistname, path,outpath, userlist, userProfilePath, UserInfluFilePath, UserInfluFileName);
		if(strcmp(PARM,"cu")==0)
			UserProfileAllocationContentUser(flistname, path, outpath, userlist, userProfilePath, UserInfluFilePath, UserInfluFileName);
		if(strcmp(PARM,"hp")==0)
			UserProfileAllocationHP(flistname, path, outpath, userlist, userProfilePath, UserInfluFilePath, UserInfluFileName);
	}
	else if (strcmp(para, "upqg") == 0) {
		UserProfileQueryGeneration(flistname, HistoryPartition, path, partitionPath, outpath, userlist, userProfilePath, UserInfluFilePath, UserInfluFileName);
	}
	else if (strcmp(para, "tfidfnorm") == 0) {
		NormalizeTFIDF(flistname, path, outpath);
	}
	else if (strcmp(para, "ccuid") == 0)
	{
		ContinuousConstructUID(flistname, path, outpath, ext, UserInfluFilePath);
	}
	//======================

	return 0;
}


int ReadGTMsg(char* GTmsgs, set<long long int>& GTNonGTset) {

	int ret = 0;

	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	if ((err = fopen_s(&fileDescriptor, GTmsgs, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", GTmsgs);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
			if (length > 0)
			{
				GTNonGTset.insert(atoll(strtok.token(0).c_str()));
			}
		}
		fclose(fileDescriptor);
	}
	ret = GTNonGTset.size();

	return ret;
}
//SAX string hash
unsigned hashString(string const& key, unsigned tableSize)
{
	unsigned hashVal = 0;
	for (int x = 0; x < key.length(); ++x)
	{
		hashVal ^= (hashVal << 5) +
			(hashVal >> 2) +
			key[x];
	}
	return hashVal % tableSize;
}

int ReadHashtags(char* HashTags) {
	int ret = 0;

	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	if ((err = fopen_s(&fileDescriptor, HashTags, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", HashTags);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
			if (length > 0)
			{
				int hashkey = hashString(strtok.token(0), HTSize);
				GTHashtagHashTable[hashkey].push_back(strtok.token(0));
				ret++;
			}
		}
		fclose(fileDescriptor);
	}

	return ret;
}

/*
for this message loading function, CurMSGlist--> EUserFrPair can be read from the user profile information 
obtained from training data
*/
int loadMessageSlotForStreamming(char* FullSlotFileName, vector<SocialMSG>& HashTagedMSGlist,
	vector<SocialMSG>& NonHashTagedMSGlist, int startMSGno) {
	int size = 0;

	FILE* fileDescriptor = NULL;
	errno_t err;

	float vec[TFIDF_DIM] = { 0 };
	for (int j = 0; j < TFIDF_DIM; j++)
		vec[j] = 0;
	
	TimeRange newTR = { 0.0,0.0 };
	SpaceRange newSR = { 0.0,0.0,0.0 };
	vector<EUserFrePair> euids;
	unsigned long long int msgid=0;

	bool hflag = false;

	vector<string> hashtags;

	char buffer[BUFFERSIZE];
	string line;
	int msgno = startMSGno;
	int tpno = 0;
	unsigned long long retweetstatus = 0;

	char** endptr = NULL;

	int count = 0;
	int RepeatMsgFlag = 0;

	if ((err = fopen_s(&fileDescriptor, FullSlotFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {			
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
			if (length <= 0) {
				printf("Invalid (empty) document!\n");
				return 1;
			}

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<hashtags>") == 0)
				{
					i++;
					hashtags.clear();
					while (strcmp(strtok.token(i).c_str(), "</hashtags>") != 0) {
						hflag = true;
						//search if htag is in hashtags, and insert it if needed 
						string htag = strtok.token(i);
						vector<string>::iterator hit = hashtags.begin();
						while (hit != hashtags.end()) {
							if (strcmp((*hit).c_str(), htag.c_str()) == 0)
								break;
							hit++;
						}
						if(hit == hashtags.end())
							hashtags.push_back(htag);
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<msgcontfidf>") == 0) {
					int j = 0;
					i++;
					while (strcmp(strtok.token(i).c_str(), "</msgcontfidf>") != 0)
					{
						vec[j] = (float)atof(strtok.token(i).c_str());
						i++;
						j++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
					i++;
					RepeatMsgFlag = 0;  //set initial value to 0 to show it is not repeated message.
					while (strcmp(strtok.token(i).c_str(), "</msgid>") != 0) {						
						msgid = stoull(strtok.token(i).c_str());

						i++;
					}
					i++;
					continue;
				}				

				if (strcmp(strtok.token(i).c_str(), "<rtmsgid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</rtmsgid>") != 0) {
						retweetstatus = stoull(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<coordinates>") == 0) {
					i++;
					int j = 0;
					while (strcmp(strtok.token(i).c_str(), "</coordinates>") != 0)
					{
						if (j == 0) {
							newSR.lat = (float)atof(strtok.token(i).c_str());
							j++;
						}
						else {
							newSR.longi = (float)atof(strtok.token(i).c_str());
						}
						i++;
					}
					newSR.radius = SPACERADIUST;
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<timestamp_ms>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</timestamp_ms>") != 0) {
						newTR.TimeStampCentre = (float)atof(strtok.token(i).c_str()) / 60; //we use minutes not s
						newTR.range = TIMERADIUST;
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<useridlist>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</useridlist>") != 0)
					{
						EUserFrePair eufPair;
						eufPair.userid = atoi(strtok.token(i).c_str());
						vector<EUserFrePair>::iterator uit = euids.begin();
						while (uit != euids.end()) {
							if ((*uit).userid == eufPair.userid)
								break;
							uit++;
						}
						if (uit != euids.end()) {
							(*uit).frequency++;
						}
						else {
							eufPair.frequency = 1;
							euids.push_back(eufPair);
						}
						i++;
					}
					i++;
					continue;
				}

				i++;
			}
			//check if this is a repeat message
			int mlsize= HashTagedMSGlist.size();
			for(int j=0;j<mlsize;j++)
				if (HashTagedMSGlist[j].getMSGID() == msgid){  //repeated message
					RepeatMsgFlag = 1;
					break;
				}
			if (RepeatMsgFlag == 0) { //check if it is in NonHashTagedMSGlist
				mlsize = NonHashTagedMSGlist.size();
				for (int j = 0; j < mlsize; j++) {
					if (NonHashTagedMSGlist[j].getMSGID() == msgid) {//repeated message
						RepeatMsgFlag = 1;
						break;
					}
				}
			}
			//=====================
			if (RepeatMsgFlag == 0) {  //insert
				SocialMSG  newsocialmsg(retweetstatus, vec, newTR, newSR, euids);
				newsocialmsg.setMSGID(msgid);

				msgno++;
				if (msgno == 9773)
					printf("msgno: %d\n", msgno);  //for dbug
				if (hflag) {
					newsocialmsg.hashtaged = 1;
					vector<string>::iterator hit = newsocialmsg.HashtagList.begin();
					newsocialmsg.HashtagList.insert(hit, hashtags.begin(), hashtags.end());
					HashTagedMSGlist.push_back(newsocialmsg);
				}
				else {
					newsocialmsg.hashtaged = 0;
					NonHashTagedMSGlist.push_back(newsocialmsg);
				}
			}
			//deallocate and reset
			hflag = false;
			newTR.TimeStampCentre = 0.0;
			newSR.lat = 0.0;
			newSR.longi = 0.0;
			euids.clear();
			hashtags.clear();
			retweetstatus = 0;
			msgid = 0;
			RepeatMsgFlag = 0;
			////////////////////////////
		}
		fclose(fileDescriptor);
	}
	return msgno;
}

void MigrationDetection(vector<SubEvent>& Eventclusters, vector<SubEvent>& Eventcandidates, EventMigration &migrateEvent, float migrateT)
{
	vector<SubEvent>::iterator ecit = Eventcandidates.begin();
	vector<SubEvent>::iterator inecit;
	while (ecit != Eventcandidates.end())
	{
		inecit = Eventclusters.begin();
		while (inecit != Eventclusters.end())
		{
			int ismigrate1 = migrateEvent.IsMigrateEvent((*ecit), (*inecit), migrateT);
			if (ismigrate1) {
				//set event no and keep connection with its parent subevent
				(*ecit).SetEventNo(Eventclusters.size() + 1);
				(*ecit).SetmigEventNo((*inecit).GetEventNo());
				//================
				Eventclusters.push_back(*ecit); //put into eventclusters list
				break;
			}
			inecit++;
		}
		Eventcandidates.erase(ecit);
		ecit = Eventcandidates.begin();
	}
}

// label True results from hashtaged subevents
int labelTrueHashtagedSubevents(vector<SubEvent>& Eventclusters) {	
	int clusterNum = Eventclusters.size();
	int hashtagEventNum = 0;
	for (int i = 0; i < clusterNum; i++)
	{
		int j;
		int hashtagListsize = Eventclusters[i].HashtagList.size();
		for (j = 0; j < hashtagListsize; j++)
		{
			//check if the current hashtag is in GTHashtagHashTable[HTSize]
			int hashkey = hashString(Eventclusters[i].HashtagList[j], HTSize);
			int k = 0;
			for (k = 0; k < GTHashtagHashTable[hashkey].size(); k++)
			{
				if (GTHashtagHashTable[hashkey][k] == Eventclusters[i].HashtagList[j])
				{
					Eventclusters[i].eventCluster = 1;					
					break;
				}
			}
			if (Eventclusters[i].eventCluster)//set already
				break;
		}
		if (hashtagListsize > 0)
			hashtagEventNum++;
		else
			break;
	}
	return hashtagEventNum;

}

//label hashtaged/nonhashtaged subclusters related to the hashtag based true results by MIG-based KNN;
void LabelSubclutersWithMIGTopK(vector<SubEvent>& Eventclusters, vector<SubEvent>& RelevantEventsPreSlot,
	float migrateT, EventMigration& migrateEvent)
{
	list<int> EventclusterGT;
	list<int>::iterator gtIt;
	list<EventNoSimiPair> TopKList;
	list<EventNoSimiPair>::iterator tkit;
	int EndEventNo = Eventclusters.size();

	EventNoSimiPair curEP;

	for (int i = 0; i < EndEventNo; i++) {
		if (Eventclusters[i].eventCluster == 1)
			EventclusterGT.push_back(i);
	}
	if (EventclusterGT.empty() && RelevantEventsPreSlot.empty()) {
		return;
	}
	for (int i = 0; i < EndEventNo; i++) {//for non labeled subevents
		if (Eventclusters[i].eventCluster == 1)  //labeled, skip
			continue;
		gtIt = EventclusterGT.begin();
		curEP.eventNo = i + 1;
		curEP.migEno = 0;
		curEP.simi = 0;
		while (gtIt != EventclusterGT.end()) {
			float ESim = 0;// Eventclusters[i].EventSimi(Eventclusters[*gtIt]);
			if (migrateT < 1.0) {  //detect migration to label the true 
				float prob1 = migrateEvent.EventMigrationProb(Eventclusters[*gtIt], Eventclusters[i]);
				float prob2 = migrateEvent.EventMigrationProb(Eventclusters[i], Eventclusters[*gtIt]);
				float prob = 0;
				vector<TimeRange> gtTime = Eventclusters[*gtIt].GetEventTimeRanges();
				vector<TimeRange> iTime = Eventclusters[i].GetEventTimeRanges();

				//Eventclusters[*gtIt] should happen before Eventclusters[i] to affect it
				if ((iTime[iTime.size() - 1].TimeStampCentre - gtTime[0].TimeStampCentre) < 0) // i affect gtit
					prob = prob2;
				else if ((gtTime[gtTime.size() - 1].TimeStampCentre - iTime[0].TimeStampCentre) < 0)  //gtit affect it
					prob = prob1;
				else  //affect each other
					prob = (prob1 + prob2) / 2;


				ESim = prob;
			}
			if (ESim >= ELIPSE && ESim > curEP.simi) {
				curEP.simi = ESim;
				curEP.migEno = Eventclusters[*gtIt].GetEventNo();
			}
			gtIt++;
		}
		for (int j = 0; j < RelevantEventsPreSlot.size(); j++)  //for labeled subevents in previous time slot
		{
			float ESim = 0;//Eventclusters[i].EventSimi(RelevantEventsPreSlot[j]);
			if (migrateT < 1.0) {  //detect migration to label the true 
				float prob1 = migrateEvent.EventMigrationProb(RelevantEventsPreSlot[j], Eventclusters[i]);
				float prob = prob1;
				ESim = prob;
			}
			if (ESim >= ELIPSE && ESim > curEP.simi) {
				curEP.simi = ESim;
				curEP.migEno = RelevantEventsPreSlot[j].GetEventNo() * (-1) - 2;//means the cluster in previous slot	
			}
		}

		if (curEP.simi >= ELIPSE)
		{
			//check curEP.simi
			tkit = TopKList.begin();
			int inserted = 0;
			while (tkit != TopKList.end()) {
				if ((*tkit).simi < curEP.simi) {
					TopKList.insert(tkit, curEP);
					inserted = 1;
					break;
				}
				tkit++;
			}
			if (!inserted) {
				if (TopKList.size() < TOPK)
					TopKList.push_back(curEP);
			}
			if (TopKList.size() > TOPK) //REMOVE THE LAST ONE
			{
				tkit = TopKList.end();
				tkit--;
				TopKList.erase(tkit);
			}
		}
	}

	//label events
	tkit = TopKList.begin();
	while (tkit != TopKList.end()) {
		Eventclusters[(*tkit).eventNo - 1].SetmigEventNo((*tkit).migEno);
		Eventclusters[(*tkit).eventNo - 1].eventCluster = 1;
		Eventclusters[(*tkit).eventNo - 1].SetmigSimi((*tkit).simi);
		tkit++;
	}
	TopKList.clear();
	EventclusterGT.clear();
}

//label hashtaged/nonhashtaged subclusters related to the hashtag based true results by KNN;
void LabelSubclutersWithESimMIGTopK(vector<SubEvent>& Eventclusters, vector<SubEvent>& RelevantEventsPreSlot, 
	float migrateT, EventMigration& migrateEvent)
{
	list<int> EventclusterGT;
	list<int>::iterator gtIt;
	list<EventNoSimiPair> TopKList;
	list<EventNoSimiPair>::iterator tkit;
	int EndEventNo = Eventclusters.size();

	EventNoSimiPair curEP;

	for (int i = 0; i < EndEventNo; i++) {
		if (Eventclusters[i].eventCluster == 1)
			EventclusterGT.push_back(i);
	}
	if (EventclusterGT.empty() && RelevantEventsPreSlot.empty()) {
		return;
	}
	for (int i = 0; i < EndEventNo; i++) {//for non labeled subevents
		if (Eventclusters[i].eventCluster == 1)  //labeled, skip
			continue;
		gtIt = EventclusterGT.begin();
		curEP.eventNo = i + 1;
		curEP.migEno = 0;
		curEP.simi = 0;
		while (gtIt != EventclusterGT.end()) {
			float ESim = Eventclusters[i].EventSimi(Eventclusters[*gtIt]);
			if (migrateT < 1.0) {  //detect migration to label the true 
				float prob1 = migrateEvent.EventMigrationProb(Eventclusters[*gtIt], Eventclusters[i]);
				float prob2 = migrateEvent.EventMigrationProb(Eventclusters[i],Eventclusters[*gtIt]);
				//float prob = (prob1 + prob2) / 2;
				float prob = 0;
				vector<TimeRange> gtTime = Eventclusters[*gtIt].GetEventTimeRanges();
				vector<TimeRange> iTime = Eventclusters[i].GetEventTimeRanges();

				//Eventclusters[*gtIt] should happen before Eventclusters[i] to affect it
				if ((iTime[iTime.size() - 1].TimeStampCentre - gtTime[0].TimeStampCentre) < 0) // i affect gtit
					prob = prob2;
				else if ((gtTime[gtTime.size() - 1].TimeStampCentre - iTime[0].TimeStampCentre) < 0)  //gtit affect it
					prob = prob1;
				else  //affect each other
					prob = (prob1 + prob2) / 2;


				ESim = ESim * (1 - alp) + prob * alp;
			}
			if (ESim >= ELIPSE && ESim > curEP.simi) {
				curEP.simi = ESim;
				curEP.migEno = Eventclusters[*gtIt].GetEventNo();
			}
			gtIt++;
		}
		for (int j = 0; j < RelevantEventsPreSlot.size(); j++)  //for labeled subevents in previous time slot
		{
			float ESim = Eventclusters[i].EventSimi(RelevantEventsPreSlot[j]);
			if (migrateT < 1.0) {  //detect migration to label the true 
				float prob1 = migrateEvent.EventMigrationProb(RelevantEventsPreSlot[j], Eventclusters[i]);
				float prob = prob1;
				ESim = ESim * (1 - alp) + prob * alp;
			}
			if (ESim >= ELIPSE && ESim > curEP.simi) {
				curEP.simi = ESim;
				curEP.migEno = RelevantEventsPreSlot[j].GetEventNo() * (-1) - 2;//means the cluster in previous slot	
			}
		}

		if (curEP.simi >= ELIPSE)
		{
			//check curEP.simi
			tkit = TopKList.begin();
			int inserted = 0;
			while (tkit != TopKList.end()) {
				if ((*tkit).simi < curEP.simi) {
					TopKList.insert(tkit, curEP);
					inserted = 1;
					break;
				}
				tkit++;
			}
			if (!inserted) {
				if (TopKList.size() < TOPK)
					TopKList.push_back(curEP);
			}
			if (TopKList.size() > TOPK) //REMOVE THE LAST ONE
			{
				tkit = TopKList.end();
				tkit--;
				TopKList.erase(tkit);
			}
		}
	}

	//label events
	tkit = TopKList.begin();
	while (tkit != TopKList.end()) {
		Eventclusters[(*tkit).eventNo - 1].SetmigEventNo((*tkit).migEno);
		Eventclusters[(*tkit).eventNo - 1].eventCluster = 1;
		Eventclusters[(*tkit).eventNo - 1].SetmigSimi((*tkit).simi);
		tkit++;
	}
	TopKList.clear();
	EventclusterGT.clear();
}

//label hashtaged/nonhashtaged subclusters related to the hashtag based true results by KNN;
void LabelSubclutersWithESimTopK(vector<SubEvent>& Eventclusters, vector<SubEvent>& RelevantEventsPreSlot)
{
	list<int> EventclusterGT;
	list<int>::iterator gtIt;
	list<EventNoSimiPair> TopKList;
	list<EventNoSimiPair>::iterator tkit;
	int EndEventNo = Eventclusters.size();

	EventNoSimiPair curEP;

	for (int i = 0; i < EndEventNo; i++){
		if (Eventclusters[i].eventCluster == 1)
			EventclusterGT.push_back(i);
	}
	if (EventclusterGT.empty()&& RelevantEventsPreSlot.empty()) {
		return;
	}
	for (int i = 0; i < EndEventNo; i++) {//for non labeled subevents
		if (Eventclusters[i].eventCluster == 1)  //labeled, skip
			continue;
		gtIt = EventclusterGT.begin();
		curEP.eventNo = i+1;
		curEP.migEno = 0;
		curEP.simi = 0;
		while (gtIt != EventclusterGT.end()) {
			float ESim = Eventclusters[i].EventSimi(Eventclusters[*gtIt]);
			if (ESim >= ELIPSE && ESim > curEP.simi) {
				curEP.simi = ESim;
				curEP.migEno = Eventclusters[*gtIt].GetEventNo();
			}
			gtIt++;
		}
		for (int j = 0; j < RelevantEventsPreSlot.size(); j++)  //for labeled subevents in previous time slot
		{
			float ESim = Eventclusters[i].EventSimi(RelevantEventsPreSlot[j]);
			if (ESim >= ELIPSE && ESim > curEP.simi) {
				curEP.simi = ESim;
				curEP.migEno = RelevantEventsPreSlot[j].GetEventNo() * (-1) - 2;//means the cluster in previous slot	
			}
		}

		if (curEP.simi >= ELIPSE)
		{
			//check curEP.simi
			tkit = TopKList.begin();
			int inserted = 0;
			while (tkit != TopKList.end()) {
				if ((*tkit).simi < curEP.simi) {
					TopKList.insert(tkit, curEP);
					inserted = 1;
					break;
				}
				tkit++;
			}
			if (!inserted) {
				if (TopKList.size() < TOPK)
					TopKList.push_back(curEP);
			}
			if (TopKList.size() > TOPK) //REMOVE THE LAST ONE
			{
				tkit = TopKList.end();
				tkit--;
				TopKList.erase(tkit);
			}
		}
	}

	//label events
	tkit = TopKList.begin();  
	while (tkit != TopKList.end()) {
		Eventclusters[(*tkit).eventNo-1].SetmigEventNo((*tkit).migEno);
		Eventclusters[(*tkit).eventNo-1].eventCluster = 1;
		Eventclusters[(*tkit).eventNo-1].SetmigSimi((*tkit).simi);
		tkit++;
	}
	TopKList.clear();
	EventclusterGT.clear();
}
/*
//-----Continuous search---------------
MTimeSlotFlist--a list of media blocks, each block has the messages in a time slot
char *path--media block file location
if migrateT= 1, then we donot consider migration. 
*/
void ContinuousEventMigration(char* MTimeSlotFlist, char* path, char * outpath, char* ext, float migrateT,
	char* UserInfluFilePath)
{
	FILE* dataSetDescriptor = NULL, * resultFile = NULL;
	char FullSlotFileName[300], SlotFileName[300];

	vector<SocialMSG> HashTagedMSGlist, NonHashTagedMSGlist;
	SocialEventOperation SEO;
	vector<SubEvent> Eventclusters;
	vector<SubEvent> Eventcandidates;
	vector<SubEvent> RelevantEventsPreSlot;
	int startMSGno = 1;
	//===Event Migration Preloading=============
	EventMigration migrateEvent;
	//loading UserProfileHashMap
	char userinfluenceFile[200];
	//strcpy_s(userinfluenceFile, "UserInfluDictfile.txt");
	strcpy_s(userinfluenceFile, UserInfluFilePath);
	//strcat_s(userinfluenceFile, "UserInfluDictfile_Nepal07(Training25April-9May).txt");
	//strcat_s(userinfluenceFile, "UserInfluDictfile_Nepal07(Training15April-24April).txt");

	//=============================================
	char WUIPV_str[10];
	if (strcmp(MTimeSlotFlist, "napelDataTestFlist(April25-May1).txt") == 0)//
	{//for Nepal earthquake dataset	
		strcat_s(userinfluenceFile, "UserInfluDictfile_Nepal0");
		_itoa_s(10 * WUIPV, WUIPV_str,_countof(WUIPV_str),10);
		strcat_s(userinfluenceFile, WUIPV_str);
		strcat_s(userinfluenceFile, "(Training15April-24April).txt");/**/
	}
	else if (strcmp(MTimeSlotFlist, "TexasFloodDataFlist(22-28May).txt") == 0)
	{//for texasFlood dataset	
		strcat_s(userinfluenceFile, "UserInfluDictfile_TexasFlood0");
		_itoa_s(10 * WUIPV, WUIPV_str, _countof(WUIPV_str), 10);
		strcat_s(userinfluenceFile, WUIPV_str);
		strcat_s(userinfluenceFile, "(Training12-21May).txt");
	}
	else
		return;
	
	//=========================================================

	migrateEvent.loadUserProfileHashMap(userinfluenceFile);
	//========================================
	int DocCount = 0;
	if ((fopen_s(&dataSetDescriptor, MTimeSlotFlist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", MTimeSlotFlist);
	}
	else 
	{
		while (fscanf_s(dataSetDescriptor, "%s ", SlotFileName, 300) != EOF)
		{   //load data
			strcpy_s(FullSlotFileName, 300, path);
			strcat_s(FullSlotFileName, 300, SlotFileName);
			strcat_s(FullSlotFileName, 300, ext);
			printf("SlotFileName: %s", SlotFileName);

			startMSGno = loadMessageSlotForStreamming(FullSlotFileName, HashTagedMSGlist, NonHashTagedMSGlist, startMSGno);
			//======this part is for dynamic update, hide it for static database processing=========================
			//update the user influence graph
			if (staticOrDynamic) {
				if (strcmp(MTimeSlotFlist, "napelDataTestFlist(April25-May1).txt") == 0)//
				{//for Nepal earthquake dataset
					strcpy_s(userinfluenceFile, UserInfluFilePath);
					strcat_s(userinfluenceFile, "UserInfluDictfile_Nepal0");
					strcat_s(userinfluenceFile, WUIPV_str);
					strcat_s(userinfluenceFile, ".NepalUserProfile(");
				}
				else if (strcmp(MTimeSlotFlist, "TexasFloodDataFlist(22-28May).txt") == 0)
				{
					//for TexasFlood dataset
					strcpy_s(userinfluenceFile, UserInfluFilePath);
					strcat_s(userinfluenceFile, "UserInfluDictfile_TexasFlood0");
					strcat_s(userinfluenceFile, WUIPV_str);
					strcat_s(userinfluenceFile, ".TexasUserProfile(");
				}
				else
					return;
				//==========================================

				std::string s(SlotFileName);
				strcat_s(userinfluenceFile, s.substr(13, 13).c_str());
				strcat_s(userinfluenceFile, ").txt");

				migrateEvent.UpdateUserProfileHashMap(userinfluenceFile);/**/
			}

			DocCount++;
			if (DocCount % 2 > 0)			
				continue;
						
			//clustering for event cluster detection
			Eventclusters.clear();			
			SEO.FindSubEvents(HashTagedMSGlist, NonHashTagedMSGlist, Eventclusters, Eventcandidates);
			
			if (migrateT < 1.0) {  //detect migration								
				MigrationDetection(Eventclusters, Eventcandidates, migrateEvent,migrateT);
				Eventcandidates.clear();
			}
			else
				Eventcandidates.clear();

			//label True results from hashtaged subevents
			int clusterNum = Eventclusters.size();
			int hashtagEventNum = 0;
			hashtagEventNum=labelTrueHashtagedSubevents(Eventclusters);

			//label hashtaged subclusters related to the hashtag based true results;
			int StartEventNo = 0;
			//LabelSubclutersWithESimTopK(Eventclusters, RelevantEventsPreSlot);
			LabelSubclutersWithESimMIGTopK(Eventclusters, RelevantEventsPreSlot, migrateT, migrateEvent);
			//LabelSubclutersWithMIGTopK(Eventclusters, RelevantEventsPreSlot, migrateT, migrateEvent);
			
			//output the event clusters, including migrating event clusters
			FILE* resultFile = NULL;			
			char Eventpath[300];
			strcpy_s(Eventpath, outpath);
			strcpy_s(FullSlotFileName, 300, Eventpath);
			strcat_s(FullSlotFileName, 300, SlotFileName);			
			strcat_s(FullSlotFileName, 300, ".txt");

			if (fopen_s(&resultFile, FullSlotFileName, "a+") == 0) 
			{
				int clusterNum = Eventclusters.size();
				for(int i=0;i< clusterNum;i++)
				{
					int eventCluster = 0;
				
					vector<SocialMSG> emsg = Eventclusters[i].GetEventMSGs();					
					fprintf(resultFile, "<clusterid> %d </clusterid>\t <migclusterid> %d </migclusterid>\t<IsEvent> %d </IsEvent> \n", 
						Eventclusters[i].GetEventNo(), Eventclusters[i].GetmigEventNo(), Eventclusters[i].eventCluster);
					vector<SocialMSG>::iterator msgit = emsg.begin();
					while (msgit != emsg.end()) {
						//fprintf(resultFile, "<msgid>\t%lld\t</msgid>\n", (*msgit).getMSGID());
						//output the message=====================================
						if ((*msgit).hashtaged)
						{
							fprintf(resultFile, "<hashtags> ");
							for (int j = 0; j < (*msgit).HashtagList.size(); j++) {
								fprintf(resultFile, "%s ", (*msgit).HashtagList[j].c_str());								
							}
							fprintf(resultFile, "</hashtags>\t");							
						}

						fprintf(resultFile, "<msgid> %llu </msgid>\t", (*msgit).getMSGID());	
						fprintf(resultFile, "<rtmsgid> %llu </rtmsgid>\t", (*msgit).getRetweetStatus());
					
						//	===output details of event messages, this is necessary for the next step recommendation task
					
					/*	fprintf(resultFile, "<coordinates> %.4f %.4f </coordinates>\t", 
							(*msgit).getSpaceRange().lat, (*msgit).getSpaceRange().longi);						

						fprintf(resultFile, "<timestamp_ms> %.4f </timestamp_ms>\t",(*msgit).getTimeRange().TimeStampCentre);
						fprintf(resultFile, "<userid> %d </userid>\t", (*msgit).getEventUserIDsFre()[0].userid);

						fprintf(resultFile, "<msgcontfidf> ");
						float * cvlist = (*msgit).getConceptTFIDFVec();
						for (int j = 0; j < TFIDF_DIM; j++){
							fprintf(resultFile, "%.4f\t", cvlist[j]);
						}
						fprintf(resultFile, "</msgcontfidf> ");
											
						
						fprintf(resultFile, "<useridlist> ");
						vector<EUserFrePair> ulist = (*msgit).getEventUserIDsFre();
						for (int j = 0; j < ulist.size(); j++) {
							fprintf(resultFile, "%d %d\t", ulist[j].userid, ulist[j].frequency);
						}
						fprintf(resultFile, "</useridlist>");
						ulist.clear();	

						*///

						fprintf(resultFile, "\n");
						(*msgit).cleanMSG();
						msgit++;
					}
					emsg.clear();						
				}
				fclose(resultFile);	
			}
			
			//////////////////////////////////////////////////////////
			for (int i = 0; i < RelevantEventsPreSlot.size(); i++) {
				RelevantEventsPreSlot[i].cleansubEvent();
			}
			RelevantEventsPreSlot.clear();	/**/

			for (int i = 0; i < hashtagEventNum; i++) {
				if (Eventclusters[i].eventCluster == 1&&Eventclusters[i].GetmigEventNo()==0)
				{
					Eventclusters[i].cleanMsg();  //save space
					RelevantEventsPreSlot.push_back(Eventclusters[i]);
				}
			}

			cout << "RelevantEventsPreSlot Size: " << RelevantEventsPreSlot.size() << endl;						
			for (int i = 0; i < clusterNum; i++)
				Eventclusters[i].cleansubEvent();
			
			Eventclusters.clear();
			HashTagedMSGlist.clear();
			NonHashTagedMSGlist.clear();			
		}
		fclose(dataSetDescriptor);

		for (int i = 0; i < RelevantEventsPreSlot.size(); i++) {
			RelevantEventsPreSlot[i].cleansubEvent();
		}
		RelevantEventsPreSlot.clear();
		for (int i = 0; i < UserProfileHashMap.size(); i++) {
			UserProfileHashMap[i].UserInfluenceDistri.clear();
			UserProfileHashMap[i].UserInterestEvents.clear();
			UserProfileHashMap[i].UserResponseNumbers.clear();
		}
		UserProfileHashMap.clear();
	}
}

//added by emily on Jan 13, 2021, load event statistics information. 
int loadMigrationEventDetectResultSummary(char* FullSlotFileName, vector<SubEvent>& eventClusters)
{
	int ret = 0;

	FILE* fileDescriptor = NULL;
	char buffer[BUFFERSIZE];

	float vec[TFIDF_DIM];
	set<long long int> eventmsgSet;
	set<long long int> CommonRetGTevent;
	TimeRange newTR = { 0.0,0.0 };
	SpaceRange newSR = { 0.0,0.0,0.0 };
	vector<EUserFrePair> euids;
	vector<EUserFrePair>::iterator euit;

	string line;
	SubEvent curEvent;
	int eid = 0;
	if ((fopen_s(&fileDescriptor, FullSlotFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else
	{
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) line!\n");
				return 1;
			}

			int i = 0;
			if (strcmp(strtok.token(i).c_str(), "<clusterMsgIds>") == 0) {
				i++;
				eventmsgSet.clear();
				while (strcmp(strtok.token(i).c_str(), "</clusterMsgIds>") != 0) {
					eventmsgSet.insert(atoll(strtok.token(i).c_str()));
					i++;
				}
				i++;
				continue;
			}

			if (strcmp(strtok.token(i).c_str(), "<clusterid>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</clusterid>") != 0) {
					curEvent.SetEventNo(atoi(strtok.token(i).c_str()));
					i++;
				}
				i++;
				continue;
			}

			if (strcmp(strtok.token(i).c_str(), "<UserSvd>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</UserSvd>") != 0)
				{
					for (int j = 0; j < TFIDF_DIM; j++) {
						vec[j] = atof(strtok.token(i).c_str());
						i++;
					}
				}

				curEvent.setUserInfluVec(vec);
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<msgcontfidf>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</msgcontfidf>") != 0)
				{
					for (int j = 0; j < TFIDF_DIM; j++) {
						vec[j] = atof(strtok.token(i).c_str());
						i++;
					}
				}

				curEvent.setConceptTFIDFVec(vec);
				i++;
				continue;
			}
			
			if (strcmp(strtok.token(i).c_str(), "<SpaceRange>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</SpaceRange>") != 0)
				{
					newSR.lat = (float)atof(strtok.token(i).c_str());
					i++;
					newSR.longi = (float)atof(strtok.token(i).c_str());
					i++;
					newSR.radius = (float)atof(strtok.token(i).c_str());
					i++;
				}
				curEvent.setSpaceRange(newSR);
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<TimeRange>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</TimeRange>") != 0) {
					newTR.TimeStampCentre = (float)atof(strtok.token(i).c_str());
					i++;
					newTR.range = (float)atof(strtok.token(i).c_str());;
					i++;
				}
				curEvent.setTimeRange(newTR);
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<SpaceRangeSet>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</SpaceRangeSet>") != 0)
				{
					SpaceRange srtmp;
					srtmp.lat = atof(strtok.token(i).c_str());
					i++;
					srtmp.longi = atof(strtok.token(i).c_str());
					i++;
					srtmp.radius = atof(strtok.token(i).c_str());
					curEvent.uploadmsgSRset(srtmp);
					i++;
				}
			}
			if (strcmp(strtok.token(i).c_str(), "<TimeRangeSet>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</TimeRangeSet>") != 0)
				{
					TimeRange trtmp;
					trtmp.TimeStampCentre = atof(strtok.token(i).c_str());
					i++;
					trtmp.range = atof(strtok.token(i).c_str());
					curEvent.uploadmsgTRset(trtmp);
					i++;
				}
			}
			if (strcmp(strtok.token(i).c_str(), "<useridlist>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</useridlist>") != 0)
				{
					EUserFrePair eufPair;
					eufPair.userid = atoi(strtok.token(i).c_str());
					i++;
					eufPair.frequency = atoi(strtok.token(i).c_str());
					//sort based on user id
					euit = euids.begin();
					while (euit != euids.end()) {
						if ((*euit).userid > eufPair.userid) {
							euids.insert(euit, eufPair);
							euit = euids.begin();
							break;
						}
						euit++;
					}
					if (euit == euids.end())
						euids.push_back(eufPair);
					i++;
				}
				curEvent.setEventUserIDs(euids);
				euids.clear();

				//=======================
				int TrueMatch = 0;				
				CommonRetGTevent.clear();
				set_intersection(GTMsgSet.begin(), GTMsgSet.end(), eventmsgSet.begin(),
					eventmsgSet.end(), inserter(CommonRetGTevent, CommonRetGTevent.end()));
				TrueMatch = CommonRetGTevent.size();
				if (TrueMatch)//not event related, clear the messages
					curEvent.eventCluster = 1;
				else
					curEvent.eventCluster = 0;
				eventmsgSet.clear();
				CommonRetGTevent.clear();
				//========================
				eventClusters.push_back(curEvent);
				i++;				
				//reset curEvent;
				curEvent.EventReset();
			}
		}
		//=====================
		fclose(fileDescriptor);
	}
	ret = eventClusters.size();
	TimePeriodLastClusterNoList.push_back(ret);

	return ret;
}
int loadMigrationEventDetectResult(char *FullSlotFileName, vector<SubEvent>& eventClusters)
{
	int ret = 0;

	char buffer[BUFFERSIZE];
	string line;
	
	FILE * resultFile = NULL;

	float vec[TFIDF_DIM] = { 0 };
	for (int j = 0; j < TFIDF_DIM; j++)
		vec[j] = 0;
	
	TimeRange newTR = { 0.0,0.0 };
	SpaceRange newSR = { 0.0,0.0,0.0 };
	vector<EUserFrePair> euids;
	unsigned long long msgid = 0;
	int tpno = 0;

	int isMSG = 0;
	int isHashtag = 0;
	SubEvent curEvent;
	vector<string> msgHashtags;
	int eid = 0;
	unsigned long long retweetstatus = 0;

	if ((fopen_s(&resultFile, FullSlotFileName, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, resultFile)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
			
			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<clusterid>") == 0)
				{
					if (!curEvent.GetEventMSGs().empty())
					{
						//set the user-event interaction recorders between curEvent and user id
						curEvent.SetEventUserIDs();
						curEvent.SetCluster_ConceptTFIDFVec();
						curEvent.SetSpaceRange();
						curEvent.SetTimeRange();						

						eventClusters.push_back(curEvent);
					}
					i++;
					isMSG = 0;
					curEvent.EventReset();
					while (strcmp(strtok.token(i).c_str(), "</clusterid>") != 0) {
						curEvent.SetEventNo(atoi(strtok.token(i).c_str()));
						i++;
					}
					i++;
					continue;
				}
				if (strcmp(strtok.token(i).c_str(), "<migclusterid>") == 0)
				{
					i++;					
					curEvent.SetmigEventNo(atoi(strtok.token(i).c_str()));
					i++;
					i++;
					continue;
				}
				//================
				if (strcmp(strtok.token(i).c_str(), "<hashtags>") == 0)
				{
					i++;
					isHashtag = 1;
					msgHashtags.clear();
					while (strcmp(strtok.token(i).c_str(), "</hashtags>") != 0) {
						string htag = strtok.token(i);
						msgHashtags.push_back(htag);						
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<msgcontfidf>") == 0) {
					int j = 0;
					i++;
					while (strcmp(strtok.token(i).c_str(), "</msgcontfidf>") != 0)
					{
						vec[j] = (float)atof(strtok.token(i).c_str());
						i++;
						j++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
					i++;
					isMSG = 1;
					msgid = stoull(strtok.token(i).c_str());
					i++;
					
					i++;
					continue;
				}			

				if (strcmp(strtok.token(i).c_str(), "<rtmsgid>") == 0) {
					i++;
						retweetstatus = stoull(strtok.token(i).c_str());
						i++;
					
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<coordinates>") == 0) {
					i++;
					int j = 0;
					while (strcmp(strtok.token(i).c_str(), "</coordinates>") != 0)
					{
						if (j == 0) {
							newSR.lat = (float)atof(strtok.token(i).c_str());
							j++;
						}
						else {
							newSR.longi = (float)atof(strtok.token(i).c_str());
						}
						i++;
					}
					newSR.radius = SPACERADIUST;
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<timestamp_ms>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</timestamp_ms>") != 0) {
						newTR.TimeStampCentre = (float)atof(strtok.token(i).c_str());// / 60; //(float)atof(strtok.token(i).substr(4,10).c_str())/60;  //we use minutes not ms
						newTR.range = TIMERADIUST;
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<useridlist>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</useridlist>") != 0)
					{
						EUserFrePair eufPair;
						eufPair.userid = atoi(strtok.token(i).c_str());
						i++;
						eufPair.frequency= atoi(strtok.token(i).c_str());
						euids.push_back(eufPair);						
						i++;
					}
					i++;
					continue;
				}
				i++;
			}
			if (isMSG == 1) {  //is message, then add it into the messagelist of 
				SocialMSG  newsocialmsg(0, vec, newTR, newSR, euids);				
				newsocialmsg.setMSGID(msgid);
				if (isHashtag) {
					newsocialmsg.hashtaged = isHashtag;
					newsocialmsg.HashtagList.insert(newsocialmsg.HashtagList.begin(),
						msgHashtags.begin(), msgHashtags.end());
					isHashtag = 0;
				}
				curEvent.uploadEventMsg(newsocialmsg);
				//check if newSR is in curEvent.msgSRset
				vector<SpaceRange> curmsgSRset = curEvent.getmsgSRset();
				int size = curmsgSRset.size();
				int k=0;
				for (k = 0; k < size; k++){
					if (curmsgSRset[k].lat == newSR.lat && curmsgSRset[k].longi == newSR.longi)
						break;
				}
				if(k==size)
					curEvent.uploadmsgSRset(newSR);
				//curEvent.uploadmsgTRset(newTR);
				newsocialmsg.cleanMSG();
				
				euids.clear();				
			}
		}
		eventClusters.push_back(curEvent); //insert the last event;
		curEvent.EventReset();
		fclose(resultFile);
	}	

	ret = eventClusters.size();
	return ret;
}


void ContinuousEventRecommedation(char* MTimeSlotFlist, char* path, char* outpath, char* ext, 
	float migrateT, char* UserInfluFilePath, char *UserInfluFileName, char * userlist, 
	int coupling, char * userProfilePath) //coupling=1, then the coupling function is applied, otherwise, only consider migration similarity
{
	FILE* dataSetDescriptor = NULL, * resultFile = NULL;
	char FullSlotFileName[200], SlotFileName[200]; 

	vector<SocialMSG> HashTagedMSGlist, NonHashTagedMSGlist;
	SocialEventOperation SEO;
	vector<SubEvent> Eventclusters;

	//recommend top KUNUM users, keep in a vector
	vector<RecItem> topKUsers;
	vector<RecItem>::iterator rit;	
	//===Event Migration Preloading=============
	EventMigration migrateEvent;
	//loading UserProfileHashMap
	char userinfluenceFile[200];
	strcpy_s(userinfluenceFile, UserInfluFilePath);
	strcat_s(userinfluenceFile, UserInfluFileName);

	migrateEvent.loadUserProfileHashMap(userinfluenceFile);

	//char userlist[200];
	//strcpy_s(userlist, "UserProfileResult(Training15April-24April).txt");
	migrateEvent.uploadUserProfilesIntoHashMap(userlist, userProfilePath); //locations...
	//========================================
	//load userlist history events
	migrateEvent.BulkLoadUserHistoryEvents(MTimeSlotFlist, path);

	int addorDel = 1;
	int DeleteNum = Eventclusters.size();
	UpdateUPeventList(Eventclusters, addorDel, DeleteNum);

	EventRecommendation eventRec(alp, UPEventList.size());
		
	int DocCount = 0;
	float maxDimVal = 0;
	if ((fopen_s(&dataSetDescriptor, MTimeSlotFlist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", MTimeSlotFlist);
	}
	else {
		while (fscanf_s(dataSetDescriptor, "%s ", SlotFileName, 200) != EOF)
		{
			DocCount++;

			//for dynamic
			if (staticOrDynamic)  
			{
				//update the user influence graph
				strcpy_s(userinfluenceFile, UserInfluFilePath);
				if (strcmp(MTimeSlotFlist, "napelDataTestFlist(April25-May1).txt") == 0)
				{//for Nepal earthquake dataset	
					strcat_s(userinfluenceFile, "UserInfluDictfile_Nepal010.NepalUserProfile(");
				}
				else if (strcmp(MTimeSlotFlist, "TexasFloodDataFlist(22-28May).txt") == 0)
				{//for texasFlood dataset	
					strcat_s(userinfluenceFile, "UserInfluDictfile_TexasFlood010.TexasUserProfile(");
				}
				else
					return;

				std::string s(SlotFileName);

				strcat_s(userinfluenceFile, s.substr(13, 13).c_str());
				strcat_s(userinfluenceFile, ").txt");

				migrateEvent.UpdateUserProfileHashMap(userinfluenceFile);/**/
			}
			//==========================================
			if (DocCount % 2 > 0)
				continue;
			if (DocCount <= 24)  //the first day event is put into user profiles as initial user history activity
				continue;
			
			//load data//loadMessageSlot(FullSlotFileName, messagelist)
			strcpy_s(FullSlotFileName, 200, path);
			strcat_s(FullSlotFileName, 200, SlotFileName);
			strcat_s(FullSlotFileName, 200, ext);
						
			//read the migration event detection results directly for event recommendation
			Eventclusters.clear();
			//loadMigrationEventDetectResult(FullSlotFileName,Eventclusters);
			loadMigrationEventDetectResultSummary(FullSlotFileName, Eventclusters);
			printf("event generation %s\n", SlotFileName);
			
			/*//test for checking the maximal dimension value
			int cNum = Eventclusters.size();
			for (int i = 0; i < cNum; i++) {
				float* convec = Eventclusters[i].GetCluster_ConceptTFIDFVec();
				for (int j = 0; j < TFIDF_DIM; j++)
					if (convec[j] > maxDimVal)
						maxDimVal = convec[j];
			}
			continue;
			*/
			//update event ids in Eventclusters to fit userprofile events
			int curEno = UPEventList.size();			
			for (int i = 0; i < Eventclusters.size(); i++) {
				Eventclusters[i].SetEventNo(curEno);
				curEno++;
			}
			
			//===presetting recommendation parameters or variables===================
			/*====Here, The CouplingInforTable information is stored in UserProfileHashMap and UPEventList
			UPEventList should include all the clusters in history and the current Eventclusters*/
			int addorDel = 1;  //append
			int DeleteNum = 0;  //no deletion
			UpdateUPeventList(Eventclusters, addorDel, DeleteNum);				
			//----------------------------------------------
			char Eventpath[200];
			strcpy_s(Eventpath, outpath);
			strcat_s(Eventpath, 200, SlotFileName);
			strcat_s(Eventpath, 200, ".txt");

			int maxi = eventRec.getEventNum();				
			if (fopen_s(&resultFile, Eventpath, "a+") == 0)
			{
				//recommending clusters to users
				vector<SubEvent>::iterator ecit;
				ecit = Eventclusters.begin();
				int StartHistClusterNo = 0;
				int CurTimePeriod = DocCount / 2;

				/*if (DocCount == 50) {
					cout << "dbug" << endl;
				}*/
				if (CurTimePeriod > histTimePeriods+1)
				{
					int resetstart = 0; 
					int resetEnd = 0;
					if (CurTimePeriod - histTimePeriods > 2) 
						resetstart=TimePeriodLastClusterNoList[CurTimePeriod - histTimePeriods - 3];

					resetEnd=TimePeriodLastClusterNoList[CurTimePeriod - histTimePeriods-2];

					for (int i = resetstart; i < resetEnd; i++) {
						UPEventList[i].HistEventSimilarity = 0;
					}
					StartHistClusterNo = resetEnd;
				}
				while (ecit != Eventclusters.end())
				{
					printf("clusterNo: %d\n", (*ecit).GetEventNo());
					//pre compute the similarity between (*ecit) and all the history event clusters in UPEventList
					//for (int i = 0; i < maxi; i++)
					for (int i = StartHistClusterNo; i < maxi; i++)
					{						
						/*float curdist = SEO.l2_dist_int((*ecit).EHashV, UPEventList[i].EHashV, MVALUE);
						if (curdist <= 0.00001) //close to 0, 
							UPEventList[i].HistEventSimilarity = 0;//not conflict, not similar
						else*/						
							UPEventList[i].HistEventSimilarity = eventRec.GetESim((*ecit), UPEventList[i]);
						/*if (coupling){
							//=================														
							int EnNo = (*ecit).GetEventNo();
							int EuNo = UPEventList[i].GetEventNo();
							float UserEventProb = eventRec.GetProbEventClusters(EnNo, EuNo);
							UPEventList[i].HistEventSimilarity *= UserEventProb;							
						}*/
					}
					//check (*ecit) should be recommended to any users, and output the userid
					for (int i = 0; i < TUNUM; i++)
					{						
						if (UserProfileHashMap[i].UserInterestEvents.empty()){
							continue;
						}
						//check if ecit should be recommended to user i, UserProfileHashMap[i]
						float SimEuser;
						if (!coupling)  // With	GetESimUser(...), the recommendation only considers the event migration similarity part == =
							SimEuser = eventRec.GetESimUser((*ecit), UserProfileHashMap[i]);
						else
							return; //hide the other function
						/*else //The following code considers both Coupled event similarity and event migration similarity in recommendation.
						{
							float CoupledSimi = eventRec.GetProbUserEvent((*ecit), (*ecit).GetEventNo(), UserProfileHashMap[i]);
							SimEuser = CoupledSimi;
						}*/

						//ELIPSE:0.3
						if (SimEuser < 0.001||(topKUsers.size()==KUNUM&& SimEuser<topKUsers[topKUsers.size()-1].simi))
							continue;
						/*==========================================================================================*/
						RecItem item;
						item.UserID = i;  //the ith user
						item.simi = SimEuser;
						//insert item into topKUsers;
					
						int endPos = topKUsers.size();
						//if (endPos > 0)
						//	endPos -= 1;
						int startPos = 0;
						while (endPos - startPos > 0) {
							int midPos = (endPos + startPos) / 2;
							int flagEnd = 0;
							if (midPos == startPos)
								flagEnd = 1;
							if (topKUsers[midPos].simi > item.simi) {
								startPos = midPos;
							}
							else if (topKUsers[midPos].simi <= item.simi) {
								endPos = midPos;
							}	
							if (flagEnd)
								break;
						}

						rit = topKUsers.begin() + endPos;
						topKUsers.insert(rit, item);
						if (topKUsers.size() > KUNUM)
							topKUsers.erase(topKUsers.begin() + KUNUM - 1);
					}
					//output the top k users/////////
					//output (*ecit), including its messages, output the event id and its messages as well
					//output the event clusters, including migrating event clusters			

					fprintf(resultFile, "<clusterid> %d </clusterid>\n", (*ecit).GetEventNo());
					/*vector<SocialMSG> msgset = (*ecit).GetEventMSGs();
					vector<SocialMSG>::iterator msgit = msgset.begin();
					while (msgit != msgset.end())
					{
						fprintf(resultFile, "<msgid>\t%llu\t</msgid>\n", (*msgit).getMSGID());
						msgit++;
					}*/
					rit = topKUsers.begin();
					//fprintf(resultFile, "<recitem>\t");
					while (rit != topKUsers.end())
					{
						fprintf(resultFile, "<recitem>\t %d %f %llu\t</recitem>\n", (*rit).UserID, (*rit).simi, UserProfileHashMap[(*rit).UserID].userOId);//(*rit).timeslotFile);
						rit++;
					}
					
					topKUsers.clear();
					//==================
					ecit++;
				}
				fclose(resultFile);
			}
			//====update userprofile history events===============
			int curUPElistSize = UPEventList.size();
			SubEvent curEvent;
			for (int i = maxi; i < curUPElistSize; i++)
			{
				curEvent.SetEventNo(UPEventList[i].GetEventNo());
				vector<EUserFrePair> CurEUserIdsFre = UPEventList[i].GetEventUserIDs();
				int CurEUsize = CurEUserIdsFre.size();
				for (int j = 0; j < CurEUsize; j++) {
					int uid = CurEUserIdsFre[j].userid;					
					UserProfileHashMap[uid].UserInterestEvents.push_back(curEvent);
				}
			}
			//================================
			/*addorDel = 0;
			DeleteNum = Eventclusters.size();
			UpdateUPeventList(Eventclusters, addorDel,DeleteNum);*/
			eventRec.setcurEventNum(UPEventList.size());
			//=================================
			
		}
		
		fclose(dataSetDescriptor);
		Eventclusters.clear();			
	}
	for (int i = 0; i < UserProfileHashMap.size(); i++) {
		UserProfileHashMap[i].UserInfluenceDistri.clear();
		UserProfileHashMap[i].UserInterestEvents.clear();
		UserProfileHashMap[i].UserResponseNumbers.clear();
	}
	UserProfileHashMap.clear();
	for (int i = 0; i < UPEventList.size(); i++) {
		UPEventList[i].cleansubEvent();
	}
	UPEventList.clear();

	printf("maxDimVal=%.6f\n", maxDimVal);
}


//=============================


/*/put the current slot events into the list, remove the expired ones, 
AddorDel is a flag to indicate if it is appending operation or erase operation
AddorDel=1, appending incomingEvents to UPEventList; 
AddorDel=0: remove the incomingEvents.size() expired events from UPEventList;
*/
int UpdateUPeventList(vector<SubEvent>& incomingEvents, int AddorDel, int DeleteNum) {
	int ret = 0;	
	if (AddorDel) {
		UPEventList.insert(UPEventList.end(), incomingEvents.begin(), incomingEvents.end());
	}
	else
	{
		// erase the first DeleteNum elements:
		UPEventList.erase(UPEventList.begin(), UPEventList.begin() + DeleteNum);
		//change the event id of other events in the history and user profiles
		for (int i = 0; i < UPEventList.size(); i++) {
			UPEventList[i].SetEventNo(UPEventList[i].GetEventNo() - DeleteNum);
		}
		for (int i = 0; i < UserProfileHashMap.size(); i++) {
			vector<SubEvent>::iterator eit= UserProfileHashMap[i].UserInterestEvents.begin();
			int offset = 0;
			while (eit != UserProfileHashMap[i].UserInterestEvents.end()) {
				if ((*eit).GetEventNo() < DeleteNum)
				{
					UserProfileHashMap[i].UserInterestEvents.erase(eit);
					eit = UserProfileHashMap[i].UserInterestEvents.begin() + offset;				
				}
				else
				{
					(*eit).SetEventNo((*eit).GetEventNo() - DeleteNum);
					eit++;
					offset++;
				}
			}
		}
	}
	ret = UPEventList.size();
	return ret;
}

void GenerateVisualUserProfileEventsForRecTestNew(char* MTimeSlotFlist, char* path, char* outpath, 
	char* ext, char* UserInfluFilePath)
{
	vector<SubEvent> Eventclusters;
	SocialEventOperation SEO;
	char  FullSlotFileName[200];
	char SlotFileName[200];
	FILE* fileDescriptor = NULL;
	FILE* resultFile = NULL;
	   
	char para[50];
	strcpy_s(para, "PVLDB21para_t1.txt");  //this file is used to keep the hash function parameter information.
	LSB lsb;
	lsb.readParaFile(para);

	//==============
	//===Event Migration Preloading=============
	EventMigration migrateEvent;
	//loading UserProfileHashMap
	char userinfluenceFile[200];
	strcpy_s(userinfluenceFile, UserInfluFilePath);
	//strcpy_s(userinfluenceFile, "UserInfluDictfile_Nepal07(Training15April-24April).txt");
	strcat_s(userinfluenceFile, "UserInfluDictfile_TexasFlood010(Training12-21May).txt");
	//strcat_s(userinfluenceFile, "UserInfluDictfile_Nepal010(Training15April-24April).txt");

	migrateEvent.loadUserProfileHashMap(userinfluenceFile);	
	//=====================	
	char Eventpath[200];
	//strcpy_s(Eventpath, "C:\\scratch\\MyProgramsRMIT\\PVLDB21CPP\\Datasets\\Nepal_UserHistUP\\");
	//strcpy_s(Eventpath, "C:\\scratch\\MyProgramsRMIT\\SIGMOD21DR\\Datasets\\Texas_UserHistUP\\");
	//strcpy_s(Eventpath, "C:\\scratch\\MyProgramsRMIT\\SIGMOD21DR\\Datasets\\Nepal_UserHistUP\\");
	strcpy_s(Eventpath, outpath);

	int eventNo = 0;
	int DocCount = 0;
	vector<SubEvent>::iterator ecit;
	if ((fopen_s(&fileDescriptor, MTimeSlotFlist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", MTimeSlotFlist);
	}
	else
	{
		while (fscanf_s(fileDescriptor, "%s ", SlotFileName, 200) != EOF)
		{   
			DocCount++;
			if (DocCount % 2 > 0)
				continue;
			//load data				
			strcpy_s(FullSlotFileName, 200, path);
			strcat_s(FullSlotFileName, 200, SlotFileName);
			strcat_s(FullSlotFileName, 200, ext);
			printf("SlotFileName: %s", SlotFileName);
			//================			
			//read the migration event detection results directly for event recommendation
			Eventclusters.clear();
			loadMigrationEventDetectResult(FullSlotFileName, Eventclusters);
			printf("event generation %s\n", SlotFileName);
			//=================

			strcpy_s(FullSlotFileName, 200, Eventpath);
			strcat_s(FullSlotFileName, 200, SlotFileName);
			strcat_s(FullSlotFileName, 200, ".UPdata");//store user interested events

			if (fopen_s(&resultFile, FullSlotFileName, "a+") == 0)
			{
				ecit = Eventclusters.begin();				
				//output clusters in user history
				while (ecit != Eventclusters.end())
				{				
					fprintf(resultFile, "<clusterOid> %d </clusterOid>\n", (*ecit).GetEventNo());
					fprintf(resultFile, "<clusterMsgIds>\t");
					MSGSET msgset = (*ecit).GetEventMSGs();
					vector<SocialMSG>::iterator msgit = msgset.begin();
					while (msgit != msgset.end()) {
						fprintf(resultFile, "%llu\t", (*msgit).getMSGID());
						msgit++;
					}
					fprintf(resultFile, "</clusterMsgIds>\n");

					//==for msg author ids output==================
					fprintf(resultFile, "<authoridlist>\t");
					msgit = msgset.begin();
					while (msgit != msgset.end()) {
						fprintf(resultFile, "%d\t", (*msgit).getEventUserIDsFre()[0].userid);
						msgit++;
					}
					fprintf(resultFile, "</authoridlist>\n");
					//=======================
					(*ecit).SetEventNo(eventNo);
					eventNo++;
					
					//(*ecit).ProduceEventPresentation();  //this is for recommendation data
					(*ecit).ProduceEventPresentationForRecEvaluation(); //this is for evaluating recommendation results.

					fprintf(resultFile, "<clusterid> %d </clusterid>\n", (*ecit).GetEventNo());
					fprintf(resultFile, "<msgcontfidf>\t");
					float * conceptvec = (*ecit).GetCluster_ConceptTFIDFVec();
					for (int k = 0; k < TFIDF_DIM; k++) {
						fprintf(resultFile, "%.4f\t", conceptvec[k]);
					}
					fprintf(resultFile, "</msgcontfidf>\n");
					fprintf(resultFile, "<SpaceRange>\t%.4f\t%.4f\t%.4f\t</SpaceRange>\n", (*ecit).GetSpaceRange().lat, (*ecit).GetSpaceRange().longi, (*ecit).GetSpaceRange().radius);
					fprintf(resultFile, "<TimeRange>\t%.4f\t%.4f\t</TimeRange>\n", (*ecit).GetTimeRange().TimeStampCentre, (*ecit).GetTimeRange().range);
										
					vector<SpaceRange> srset = (*ecit).getmsgSRset();
					if (!srset.empty())
					{
						fprintf(resultFile, "<SpaceRangeSet>\t");
						for (int k = 0; k < srset.size(); k++) {
							fprintf(resultFile, "%.4f %.4f %.4f\t",srset[k].lat,srset[k].longi, srset[k].radius);
						}
						fprintf(resultFile, "</SpaceRangeSet>\n");
					}

					vector<TimeRange> trset = (*ecit).getmsgTRset();
					if (!trset.empty())
					{
						fprintf(resultFile, "<TimeRangeSet>\t");
						for (int k = 0; k < trset.size(); k++) {
							fprintf(resultFile, "%.4f %.4f\t", trset[k].TimeStampCentre, trset[k].range);
						}
						fprintf(resultFile, "</TimeRangeSet>\n");
					}
					SEO.HashMappingEvent((*ecit), lsb);
					fprintf(resultFile, "<HashkeyValues>\t");
					for (int i = 0; i < MVALUE; i++)
						fprintf(resultFile, "%d\t", (*ecit).EHashV[i]);
					fprintf(resultFile, "</HashkeyValues>\n");/**/

					fprintf(resultFile, "<useridlist>\t");
					vector<EUserFrePair> eventuserlist = (*ecit).GetEventUserIDs();
					for (int i = 0; i < eventuserlist.size(); i++) {
						fprintf(resultFile, "%d %d\t", eventuserlist[i].userid, eventuserlist[i].frequency);
					}
					fprintf(resultFile, "</useridlist>\n");

					eventuserlist.clear();
					ecit++;
				}
				//===============			
				fclose(resultFile);
				printf("clusterNum: %zd\t eventNo: %d\n", Eventclusters.size(), eventNo);
			}
			Eventclusters.clear();			
		}
		fclose(fileDescriptor);				
	}	

	for (int i = 0; i < TUNUM; i++) {
		UserProfileHashMap[i].UserInfluenceDistri.clear();
		UserProfileHashMap[i].UserInterestEvents.clear();
		UserProfileHashMap[i].UserResponseNumbers.clear();
	}
}

///////////Emily Feb
//=======for parallel processing
void NormalizeTFIDF(char* MTimeSlotFlist, char* path, char* outpath) 
{
	FILE* dataSetDescriptor = NULL;
	char FullSlotFileName[200], SlotFileName[200], outFullSlotFileName[200];
	int DocCount = 0;
	float maxDimVal = 0;
	if ((fopen_s(&dataSetDescriptor, MTimeSlotFlist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", MTimeSlotFlist);
	}
	else {
		while (fscanf_s(dataSetDescriptor, "%s ", SlotFileName, 200) != EOF)
		{
			DocCount++;
			if (DocCount % 2 > 0)
				continue;

			//load data
			strcpy_s(FullSlotFileName, 200, path);
			strcat_s(FullSlotFileName, 200, SlotFileName);
			strcat_s(FullSlotFileName, 200, ".UPdata");

			strcpy_s(outFullSlotFileName, 200, outpath);
			strcat_s(outFullSlotFileName, 200, SlotFileName);
			strcat_s(outFullSlotFileName, 200, ".UPdata");
						
			NormalizeMigrationEventDetectResultSummary(FullSlotFileName, outFullSlotFileName);
		}
		fclose(dataSetDescriptor);
	}
}

void NormalizeMigrationEventDetectResultSummary(char *inputFileName, char* outputFileName) {
	int ret = 0;

	FILE* fileDescriptor = NULL;
	FILE* resultFile = NULL;
	char buffer[BUFFERSIZE];

	float vec[TFIDF_DIM];
	set<long long int> eventmsgSet;
	set<long long int> CommonRetGTevent;
	TimeRange newTR = { 0.0,0.0 };
	SpaceRange newSR = { 0.0,0.0,0.0 };
	vector<EUserFrePair> euids;
	vector<EUserFrePair>::iterator euit;

	string line;
	SubEvent curEvent;
	int eid = 0;
	if (fopen_s(&resultFile, outputFileName, "a+") == 0)
	{
		if ((fopen_s(&fileDescriptor, inputFileName, "r")) != 0) {
			printf("load msg error \n");
			printf("The file 'crt_fopen_s.c' was not opened: %s\n", inputFileName);
		}
		else
		{
			while (fgets(buffer, BUFFERSIZE, fileDescriptor))
			{
				line = buffer;
				strtokenizer strtok(line, " \t\r\n");
				int length = strtok.count_tokens();

				if (length <= 0) {
					printf("Invalid (empty) line!\n");
					return;
				}

				int i = 0;
				if (strcmp(strtok.token(i).c_str(), "<msgcontfidf>") == 0) {
					i++;
					float varTFIDF = 0;//compute variance
					while (strcmp(strtok.token(i).c_str(), "</msgcontfidf>") != 0){
						for (int j = 0; j < TFIDF_DIM; j++) {
							vec[j] = atof(strtok.token(i).c_str());
							varTFIDF += vec[j] * vec[j];
							i++;
						}
					}		
					varTFIDF = sqrt(varTFIDF);		
					fprintf(resultFile, "<msgcontfidf>\t");
					for (int k = 0; k < TFIDF_DIM; k++) {
						vec[k] /= varTFIDF;
						fprintf(resultFile, "%.4f\t", vec[k]);
					}
					fprintf(resultFile, "</msgcontfidf>\n");
					i++;
					continue;
				}
				else {//output directly
					fprintf(resultFile, buffer);
				}
			}
			//=====================
			fclose(fileDescriptor);
		}
		fclose(resultFile);
	}
}
void UserProfileAllocation(char* MTimeSlotFlist, char* path, char *outpath, char * userlist, char *userProfilePath, char* UserInfluFilePath, char* UserInfluFileName)
{
	//read user profiles
	//===Event Migration Preloading=============
	EventMigration migrateEvent;
	char userinfluenceFile[200];
	strcpy_s(userinfluenceFile, UserInfluFilePath);
	strcat_s(userinfluenceFile, UserInfluFileName);

	migrateEvent.loadUserProfileHashMap(userinfluenceFile);
	migrateEvent.uploadUserProfilesIntoHashMap(userlist, userProfilePath); //locations...
	//========================================
	//load userlist history events
	migrateEvent.BulkLoadUserHistoryEvents(MTimeSlotFlist, path);	
	
	//================
	EventRecomOpti eropti;
	int numofGroups = NUMOfGROUPS;
	std::vector<UPEventPartition> uprofileEventGroupSet;
	LSB lsb;
	char parafile[200];
	strcpy_s(parafile, "PVLDB22paraNepal.txt");
	lsb.readParaFile(parafile);
	printf("para loading finished\n");
	   	 	
	SocialEventOperation seopt;
	uprofileEventGroupSet.resize(numofGroups);
	eropti.UserProfileDataPartition(UPEventList, numofGroups, uprofileEventGroupSet, lsb, seopt);
	//eropti.UserProfileDataPartitionAngleHashMixedHashKMeans(UPEventList, numofGroups, uprofileEventGroupSet, seopt);//kmeans clustering for partitions and hash-based buckets

	FILE* dataSetDescriptor = NULL, * resultFile = NULL;
	//=========================
	//output the recommendation list of IncomingEventSubset
	char FullSlotPartitionFileName[200];
	strcpy_s(FullSlotPartitionFileName, 200, outpath);
	strcat_s(FullSlotPartitionFileName, 200, MTimeSlotFlist);
	strcat_s(FullSlotPartitionFileName, 200, ".UPP");
	if (fopen_s(&resultFile, FullSlotPartitionFileName, "a+") == 0)
	{
	//	for (int i = 0; i < numofGroups; i++)
		for(int i=0;i< uprofileEventGroupSet.size();i++)
		{
			int BucketSize = uprofileEventGroupSet[i].getUProfileEventGroup().size();
			fprintf(resultFile, "<groupid> %d </groupid>\n", i);
			fprintf(resultFile, "<BucketNum> %d </BucketNum>\n", BucketSize);
		
			float* centvec = uprofileEventGroupSet[i].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
			fprintf(resultFile, "<TopicCentre>\t");
			for (int k = 0; k < TFIDF_DIM; k++) {
				fprintf(resultFile, "%.8f\t", centvec[k]);
			}
			fprintf(resultFile, "</TopicCentre>\n");

			fprintf(resultFile, "<minAngleCos>\t");
			float minAngleCosV = uprofileEventGroupSet[i].getminAngleCos();
			fprintf(resultFile, "%.8f\t", minAngleCosV);
			fprintf(resultFile, "</minAngleCos>\n");

			ValueRangePair TRPair=uprofileEventGroupSet[i].getTimeRangePair();
			fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", TRPair.maxV, TRPair.minV);

			vector<UserValueRangePair> UVRPair = uprofileEventGroupSet[i].getInfluenceRangeVector();
			int influSize = UVRPair.size();
			fprintf(resultFile, "<influenceRangeVec>\t");
			for(int k = 0; k < influSize; k++)	{
				fprintf(resultFile, "%d %.4f %.4f\t", UVRPair[k].userid, UVRPair[k].maxV, UVRPair[k].minV);
				if (k % 10 == 0)
					fprintf(resultFile, "\n");
			}
			fprintf(resultFile, "</influenceRangeVec>\n");

			fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n", uprofileEventGroupSet[i].getMaxNumInfluencedUsers(), uprofileEventGroupSet[i].getMinNumInfluencedUsers());

			//centreP minimalRadius
			SpaceRange sr = uprofileEventGroupSet[i].getSpaceRangecentreP();
			fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n",sr.lat,sr.longi,sr.radius);
			float miniRadius = uprofileEventGroupSet[i].GetminimalRadius();
			fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", miniRadius);
			
			for (int j = 0; j < BucketSize; j++)
			{
				//=======output bucket statistics information================================
				int CurBucketSize = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().size();
				fprintf(resultFile, "<bucketid> %d </bucketid>\n", j);
				fprintf(resultFile, "<BucketSize> %d </BucketSize>\n", CurBucketSize);
				
				float* bucketcentvec = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
				fprintf(resultFile, "<TopicCentre>\t");
				for (int k = 0; k < TFIDF_DIM; k++) {
					fprintf(resultFile, "%.8f\t", bucketcentvec[k]);
				}
				fprintf(resultFile, "</TopicCentre>\n");

				fprintf(resultFile, "<minAngleCos>\t");
				float bucketminAngleCosV = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getminAngleCos();
				fprintf(resultFile, "%.8f\t", bucketminAngleCosV);
				fprintf(resultFile, "</minAngleCos>\n");
								
				ValueRangePair bucketTRPair = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getTimeRangePair();
				fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", bucketTRPair.maxV, bucketTRPair.minV);

				
				vector<UserValueRangePair> bucketUVRPair = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getInfluenceRangeVector();
				int bucketinfluSize = bucketUVRPair.size();
				fprintf(resultFile, "<influenceRangeVec>\t");
				for (int k = 0; k < bucketinfluSize; k++) {
					fprintf(resultFile, "%d %.4f %.4f\t", bucketUVRPair[k].userid, bucketUVRPair[k].maxV, bucketUVRPair[k].minV);
					if (k % 10 == 0)
						fprintf(resultFile, "\n");
				}
				fprintf(resultFile, "</influenceRangeVec>\n");
				fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n",
					uprofileEventGroupSet[i].getUProfileEventGroup()[j].getMaxNumInfluencedUsers(),
					uprofileEventGroupSet[i].getUProfileEventGroup()[j].getMinNumInfluencedUsers());

				//centreP minimalRadius
				SpaceRange sr = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getSpaceRangecentreP();
				fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", sr.lat, sr.longi, sr.radius);
				float bucketminiRadius = uprofileEventGroupSet[i].getUProfileEventGroup()[j].GetminimalRadius();
				fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", bucketminiRadius);
				//finish bucket statistics
			}
				for (int j = 0; j < BucketSize; j++)
				{
				//=======================================
				vector<SubEvent>::iterator iesit = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().begin();
				while (iesit != uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().end()) {
					fprintf(resultFile, "<clusterid> %d </clusterid>\n", (*iesit).GetEventNo());
					/////////////////////////
					fprintf(resultFile, "<msgcontfidf>\t");
					float* conceptvec = (*iesit).GetCluster_ConceptTFIDFVec();
					for (int k = 0; k < TFIDF_DIM; k++) {
						fprintf(resultFile, "%.8f\t", conceptvec[k]);
					}
					fprintf(resultFile, "</msgcontfidf>\n");
					fprintf(resultFile, "<SpaceRange>\t%.8f\t%.8f\t%.8f\t</SpaceRange>\n", (*iesit).GetSpaceRange().lat, (*iesit).GetSpaceRange().longi, (*iesit).GetSpaceRange().radius);
					fprintf(resultFile, "<TimeRange>\t%.8f\t%.8f\t</TimeRange>\n", (*iesit).GetTimeRange().TimeStampCentre, (*iesit).GetTimeRange().range);

					vector<SpaceRange> srset = (*iesit).getmsgSRset();
					if (!srset.empty())
					{
						fprintf(resultFile, "<SpaceRangeSet>\t");
						for (int k = 0; k < srset.size(); k++) {
							fprintf(resultFile, "%.8f %.8f %.8f\t", srset[k].lat, srset[k].longi, srset[k].radius);
						}
						fprintf(resultFile, "</SpaceRangeSet>\n");
					}

					vector<TimeRange> trset = (*iesit).getmsgTRset();
					if (!trset.empty())
					{
						fprintf(resultFile, "<TimeRangeSet>\t");
						for (int k = 0; k < trset.size(); k++) {
							fprintf(resultFile, "%.8f %.8f\t", trset[k].TimeStampCentre, trset[k].range);
						}
						fprintf(resultFile, "</TimeRangeSet>\n");
					}
					
					fprintf(resultFile, "<useridlist>\t");
					vector<EUserFrePair> eventuserlist = (*iesit).GetEventUserIDs();
					for (int k = 0; k < eventuserlist.size(); k++) {
						fprintf(resultFile, "%d %d\t", eventuserlist[k].userid, eventuserlist[k].frequency);
					}
					fprintf(resultFile, "</useridlist>\n");
					//////////////////////////
					iesit++;
				}
			}			
		}
		fclose(resultFile);
	}
	UPEventList.clear();
	//return; //to save time for test
	//==========================
	char FullSlotFileName[200], SlotFileName[200];
	vector<SubEvent> Eventclusters;
	int DocCount = 0;
	float maxDimVal = 0;
	if ((fopen_s(&dataSetDescriptor, MTimeSlotFlist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", MTimeSlotFlist);
	}
	else {
		while (fscanf_s(dataSetDescriptor, "%s ", SlotFileName, 200) != EOF)
		{
			DocCount++;
			if (DocCount % 2 > 0)
				continue;
			if (DocCount <= 24)  //the first day event is put into user profiles as initial user history activity
			//if (DocCount <= 6)  //the first day event is put into user profiles as initial user history activity
				continue;	

			//if (DocCount >= 10)  //get a small set for test
			//	break;
			//load data
			strcpy_s(FullSlotFileName, 200, path);
			strcat_s(FullSlotFileName, 200, SlotFileName);
			strcat_s(FullSlotFileName, 200, ".UPdata");

			//read the migration event detection results directly for event recommendation
			Eventclusters.clear();
			loadMigrationEventDetectResultSummary(FullSlotFileName, Eventclusters);
			printf("event generation %s\n", SlotFileName);
			///==============	
			eropti.ContinuousUserProfileDataPartition(Eventclusters, numofGroups, uprofileEventGroupSet, lsb, seopt);
			//eropti.ContinuousUserProfileDataPartitionAngleHashMixedHashKMeans(Eventclusters, numofGroups, uprofileEventGroupSet);
			
			//eropti.ContinuousUserProfileDataPartitionAngleHash(Eventclusters, numofGroups, uprofileEventGroupSet);
			//eropti.ContinuousUserProfileSubspaceDataPartitionAngleHash(Eventclusters, numofGroups, uprofileEventGroupSet);
			//eropti.ContinuousUserProfileDataPartitionAngleHashFix(Eventclusters, numofGroups, uprofileEventGroupSet);
			
			char FullSlotPartitionFileName[200];
			strcpy_s(FullSlotPartitionFileName, 200, outpath);
			strcat_s(FullSlotPartitionFileName, 200, SlotFileName);
			strcat_s(FullSlotPartitionFileName, 200, ".UPP");
			int startClusterno = Eventclusters[0].GetEventNo();
			if (fopen_s(&resultFile, FullSlotPartitionFileName, "a+") == 0)
			{
				for (int i = 0; i < uprofileEventGroupSet.size(); i++)
				{
					int BucketSize = uprofileEventGroupSet[i].getUProfileEventGroup().size();
					fprintf(resultFile, "<groupid> %d </groupid>\n", i);
					fprintf(resultFile, "<BucketNum> %d </BucketNum>\n", BucketSize);
					
					float* centvec = uprofileEventGroupSet[i].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
					fprintf(resultFile, "<TopicCentre>\t");
					for (int k = 0; k < TFIDF_DIM; k++) {
						fprintf(resultFile, "%.8f\t", centvec[k]);
					}
					fprintf(resultFile, "</TopicCentre>\n");
					
					fprintf(resultFile, "<minAngleCos>\t");
					float minAngleCosV = uprofileEventGroupSet[i].getminAngleCos();
					fprintf(resultFile, "%.8f\t", minAngleCosV);
					fprintf(resultFile, "</minAngleCos>\n");
					
					ValueRangePair TRPair = uprofileEventGroupSet[i].getTimeRangePair();
					fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", TRPair.maxV, TRPair.minV);
				
					vector<UserValueRangePair> UVRPair = uprofileEventGroupSet[i].getInfluenceRangeVector();
					int influSize = UVRPair.size();
					fprintf(resultFile, "<influenceRangeVec>\t");
					for (int k = 0; k < influSize; k++) {
						fprintf(resultFile, "%d %.4f %.4f\t", UVRPair[k].userid, UVRPair[k].maxV, UVRPair[k].minV);
						if (k % 10 == 0)
							fprintf(resultFile, "\n");
					}
					fprintf(resultFile, "</influenceRangeVec>\n");

					fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n", uprofileEventGroupSet[i].getMaxNumInfluencedUsers(), uprofileEventGroupSet[i].getMinNumInfluencedUsers());

					//centreP minimalRadius
					SpaceRange sr = uprofileEventGroupSet[i].getSpaceRangecentreP();
					fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", sr.lat, sr.longi, sr.radius);
					float miniRadius = uprofileEventGroupSet[i].GetminimalRadius();
					fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", miniRadius);

					for (int j = 0; j < BucketSize; j++)
					{
						//=======output bucket statistics information================================
						int CurBucketSize = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().size();
						fprintf(resultFile, "<bucketid> %d </bucketid>\n", j);
						fprintf(resultFile, "<BucketSize> %d </BucketSize>\n", CurBucketSize);
						
						float* bucketcentvec = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
						fprintf(resultFile, "<TopicCentre>\t");
						for (int k = 0; k < TFIDF_DIM; k++) {
							fprintf(resultFile, "%.8f\t", bucketcentvec[k]);
						}
						fprintf(resultFile, "</TopicCentre>\n");

						fprintf(resultFile, "<minAngleCos>\t");
						float bucketminAngleCosV = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getminAngleCos();
						fprintf(resultFile, "%.8f\t", bucketminAngleCosV);
						fprintf(resultFile, "</minAngleCos>\n");

						ValueRangePair bucketTRPair = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getTimeRangePair();
						fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", bucketTRPair.maxV, bucketTRPair.minV);

						vector<UserValueRangePair> bucketUVRPair = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getInfluenceRangeVector();
						int bucketinfluSize = bucketUVRPair.size();
						fprintf(resultFile, "<influenceRangeVec>\t");
						for (int k = 0; k < bucketinfluSize; k++) {
							fprintf(resultFile, "%d %.4f %.4f\t", bucketUVRPair[k].userid, bucketUVRPair[k].maxV, bucketUVRPair[k].minV);
							if (k % 10 == 0)
								fprintf(resultFile, "\n");
						}
						fprintf(resultFile, "</influenceRangeVec>\n");
						fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n",
							uprofileEventGroupSet[i].getUProfileEventGroup()[j].getMaxNumInfluencedUsers(),
							uprofileEventGroupSet[i].getUProfileEventGroup()[j].getMinNumInfluencedUsers());

						//centreP minimalRadius
						SpaceRange sr = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getSpaceRangecentreP();
						fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", sr.lat, sr.longi, sr.radius);
						float bucketminiRadius = uprofileEventGroupSet[i].getUProfileEventGroup()[j].GetminimalRadius();
						fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", bucketminiRadius);
						//finish bucket statistics
					}
					/*for (int j = 0; j < BucketSize; j++)
					{
						//=======================================
						vector<SubEvent>::iterator iesit = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().begin();
						while (iesit != uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().end()) {
							fprintf(resultFile, "<clusterid> %d </clusterid>\n", (*iesit).GetEventNo());
							/////////////////////////
							fprintf(resultFile, "<msgcontfidf>\t");
							float* conceptvec = (*iesit).GetCluster_ConceptTFIDFVec();
							for (int k = 0; k < TFIDF_DIM; k++) {
								fprintf(resultFile, "%.8f\t", conceptvec[k]);
							}
							fprintf(resultFile, "</msgcontfidf>\n");
							fprintf(resultFile, "<SpaceRange>\t%.8f\t%.8f\t%.8f\t</SpaceRange>\n", (*iesit).GetSpaceRange().lat, (*iesit).GetSpaceRange().longi, (*iesit).GetSpaceRange().radius);
							fprintf(resultFile, "<TimeRange>\t%.8f\t%.8f\t</TimeRange>\n", (*iesit).GetTimeRange().TimeStampCentre, (*iesit).GetTimeRange().range);

							vector<SpaceRange> srset = (*iesit).getmsgSRset();
							if (!srset.empty())
							{
								fprintf(resultFile, "<SpaceRangeSet>\t");
								for (int k = 0; k < srset.size(); k++) {
									fprintf(resultFile, "%.8f %.8f %.8f\t", srset[k].lat, srset[k].longi, srset[k].radius);
								}
								fprintf(resultFile, "</SpaceRangeSet>\n");
							}

							vector<TimeRange> trset = (*iesit).getmsgTRset();
							if (!trset.empty())
							{
								fprintf(resultFile, "<TimeRangeSet>\t");
								for (int k = 0; k < trset.size(); k++) {
									fprintf(resultFile, "%.8f %.8f\t", trset[k].TimeStampCentre, trset[k].range);
								}
								fprintf(resultFile, "</TimeRangeSet>\n");
							}							
							fprintf(resultFile, "<useridlist>\t");
							vector<EUserFrePair> eventuserlist = (*iesit).GetEventUserIDs();
							for (int k = 0; k < eventuserlist.size(); k++) {
								fprintf(resultFile, "%d %d\t", eventuserlist[k].userid, eventuserlist[k].frequency);
							}
							fprintf(resultFile, "</useridlist>\n");
							//////////////////////////
							iesit++;
						}
					}*/
				}
				/*
				for (int i = 0; i < numofGroups; i++)
				{	
					if(i==9)
						printf("i=%d\n", i);
					int BucketSize = uprofileEventGroupSet[i].getUProfileEventGroup().size();
					fprintf(resultFile, "<groupid> %d </groupid>\n", i);
					ValueRangePair* topicRangeVec = uprofileEventGroupSet[i].getTopicRangeVector();
					fprintf(resultFile, "<TopicRange>\t");
					for (int k = 0; k < TFIDF_DIM; k++) {
						fprintf(resultFile, "%.8f %.8f\t", topicRangeVec[k].maxV, topicRangeVec[k].minV);
					}
					fprintf(resultFile, "</TopicRange>\n");

					float* centvec = uprofileEventGroupSet[i].getUProfileEventGroup()[0].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
					fprintf(resultFile, "<TopicCentre>\t");
					for (int k = 0; k < TFIDF_DIM; k++) {
						fprintf(resultFile, "%.8f\t", centvec[k]);
					}
					fprintf(resultFile, "</TopicCentre>\n");

					ValueRangePair* topicAngleRangeVec = uprofileEventGroupSet[i].getTopicVectorAngleTanRanges();
					fprintf(resultFile, "<TopicAngleRange>\t");
					for (int k = 0; k < TFIDF_DIM-1; k++) {
						fprintf(resultFile, "%.8f %.8f\t", topicAngleRangeVec[k].maxV, topicAngleRangeVec[k].minV);
					}
					fprintf(resultFile, "</TopicAngleRange>\n");

					fprintf(resultFile, "<minAngleCos>\t");
					float minAngleCosV = uprofileEventGroupSet[i].getUProfileEventGroup()[0].getminAngleCos();
					fprintf(resultFile, "%.8f\t", minAngleCosV);
					fprintf(resultFile, "</minAngleCos>\n");

					ValueRangePair TRPair = uprofileEventGroupSet[i].getTimeRangePair();
					fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", TRPair.maxV, TRPair.minV);

					ValueRangePair* SRPair = uprofileEventGroupSet[i].getSpaceRangePair();
					fprintf(resultFile, "<SpaceRangePair> %.8f %.8f\t%.8f %.8f\t</SpaceRangePair>\n", SRPair[0].maxV, SRPair[0].minV, SRPair[1].maxV, SRPair[1].minV);

					vector<UserValueRangePair> UVRPair = uprofileEventGroupSet[i].getInfluenceRangeVector();
					int influSize = UVRPair.size();
					fprintf(resultFile, "<influenceRangeVec>\t");
					for (int k = 0; k < influSize; k++) {
						fprintf(resultFile, "%d %.8f %.8f\t", UVRPair[k].userid, UVRPair[k].maxV, UVRPair[k].minV);
						if(k%10==0)
							fprintf(resultFile, "\n");
					}
					fprintf(resultFile, "</influenceRangeVec>\n");

					fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n", uprofileEventGroupSet[i].getMaxNumInfluencedUsers(), uprofileEventGroupSet[i].getMinNumInfluencedUsers());

					//for minimalRadius;  the centreP
					SpaceRange centP = uprofileEventGroupSet[i].getSpaceRangecentreP();
					fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", centP.lat, centP.longi, centP.radius);
					fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", uprofileEventGroupSet[i].GetminimalRadius());

					for (int j = 0; j < BucketSize; j++)
					{
						vector<SubEvent>::iterator iesit = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().begin();
						while (iesit != uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().end()) 
						{
							if ((*iesit).GetEventNo() < startClusterno)	{
								iesit++;
								continue;
							}
							fprintf(resultFile, "<clusterid> %d </clusterid>\n", (*iesit).GetEventNo());
							/////////////////////////
							fprintf(resultFile, "<msgcontfidf>\t");
							float* conceptvec = (*iesit).GetCluster_ConceptTFIDFVec();
							for (int k = 0; k < TFIDF_DIM; k++) {
								fprintf(resultFile, "%.8f\t", conceptvec[k]);
							}
							fprintf(resultFile, "</msgcontfidf>\n");
							fprintf(resultFile, "<SpaceRange>\t%.8f\t%.8f\t%.8f\t</SpaceRange>\n", (*iesit).GetSpaceRange().lat, (*iesit).GetSpaceRange().longi, (*iesit).GetSpaceRange().radius);
							fprintf(resultFile, "<TimeRange>\t%.8f\t%.8f\t</TimeRange>\n", (*iesit).GetTimeRange().TimeStampCentre, (*iesit).GetTimeRange().range);

							vector<SpaceRange> srset = (*iesit).getmsgSRset();
							if (!srset.empty()){
								fprintf(resultFile, "<SpaceRangeSet>\t");
								for (int k = 0; k < srset.size(); k++) {
									fprintf(resultFile, "%.8f %.8f %.8f\t", srset[k].lat, srset[k].longi, srset[k].radius);
								}
								fprintf(resultFile, "</SpaceRangeSet>\n");
							}

							vector<TimeRange> trset = (*iesit).getmsgTRset();
							if (!trset.empty())
							{
								fprintf(resultFile, "<TimeRangeSet>\t");
								for (int k = 0; k < trset.size(); k++) {
									fprintf(resultFile, "%.8f %.8f\t", trset[k].TimeStampCentre, trset[k].range);
								}
								fprintf(resultFile, "</TimeRangeSet>\n");
							}
							fprintf(resultFile, "<HashkeyValues>\t");
							for (int k = 0; k < MVALUE; k++)
								fprintf(resultFile, "%d\t", (*iesit).EHashV[k]);
							fprintf(resultFile, "</HashkeyValues>\n");

							fprintf(resultFile, "<useridlist>\t");
							vector<EUserFrePair> eventuserlist = (*iesit).GetEventUserIDs();
							for (int k = 0; k < eventuserlist.size(); k++) {
								fprintf(resultFile, "%d %d\t", eventuserlist[k].userid, eventuserlist[k].frequency);
							}
							fprintf(resultFile, "</useridlist>\n");
							//////////////////////////
							iesit++;
						}
					}					
				}
				//=======================================================	
				*/fclose(resultFile);					
			}
		
			Eventclusters.clear();
		}
		fclose(dataSetDescriptor);	

		//output the last overall history
		char FullSlotPartitionFileName[300];
		strcpy_s(FullSlotPartitionFileName, 300, outpath);
		strcat_s(FullSlotPartitionFileName, 300, MTimeSlotFlist);

		strcat_s(FullSlotPartitionFileName, 300, ".UPPWhole");
		//int startClusterno = Eventclusters[0].GetEventNo();
		if (fopen_s(&resultFile, FullSlotPartitionFileName, "a+") == 0)
		{
			for (int i = 0; i < uprofileEventGroupSet.size(); i++)
			{
				printf("i=%d\n", i);
				int BucketSize = uprofileEventGroupSet[i].getUProfileEventGroup().size();
				fprintf(resultFile, "<groupid> %d </groupid>\n", i);
				fprintf(resultFile, "<BucketNum> %d </BucketNum>\n", BucketSize);

				float* centvec = uprofileEventGroupSet[i].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
				fprintf(resultFile, "<TopicCentre>\t");
				for (int k = 0; k < TFIDF_DIM; k++) {
					fprintf(resultFile, "%.8f\t", centvec[k]);
				}
				fprintf(resultFile, "</TopicCentre>\n");

				fprintf(resultFile, "<minAngleCos>\t");
				float minAngleCosV = uprofileEventGroupSet[i].getminAngleCos();
				fprintf(resultFile, "%.8f\t", minAngleCosV);
				fprintf(resultFile, "</minAngleCos>\n");

				ValueRangePair TRPair = uprofileEventGroupSet[i].getTimeRangePair();
				fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", TRPair.maxV, TRPair.minV);

				vector<UserValueRangePair> UVRPair = uprofileEventGroupSet[i].getInfluenceRangeVector();
				int influSize = UVRPair.size();
				fprintf(resultFile, "<influenceRangeVec>\t");
				for (int k = 0; k < influSize; k++) {
					fprintf(resultFile, "%d %.4f %.4f\t", UVRPair[k].userid, UVRPair[k].maxV, UVRPair[k].minV);
					if (k % 10 == 0)
						fprintf(resultFile, "\n");
				}
				fprintf(resultFile, "</influenceRangeVec>\n");

				fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n", uprofileEventGroupSet[i].getMaxNumInfluencedUsers(), uprofileEventGroupSet[i].getMinNumInfluencedUsers());

				//centreP minimalRadius
				SpaceRange sr = uprofileEventGroupSet[i].getSpaceRangecentreP();
				fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", sr.lat, sr.longi, sr.radius);
				float miniRadius = uprofileEventGroupSet[i].GetminimalRadius();
				fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", miniRadius);

				for (int j = 0; j < BucketSize; j++)
				{
					//=======output bucket statistics information================================
					int CurBucketSize = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().size();
					fprintf(resultFile, "<bucketid> %d </bucketid>\n", j);
					fprintf(resultFile, "<BucketSize> %d </BucketSize>\n", CurBucketSize);

					float* bucketcentvec = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
					fprintf(resultFile, "<TopicCentre>\t");
					for (int k = 0; k < TFIDF_DIM; k++) {
						fprintf(resultFile, "%.8f\t", bucketcentvec[k]);
					}
					fprintf(resultFile, "</TopicCentre>\n");

					fprintf(resultFile, "<minAngleCos>\t");
					float bucketminAngleCosV = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getminAngleCos();
					fprintf(resultFile, "%.8f\t", bucketminAngleCosV);
					fprintf(resultFile, "</minAngleCos>\n");

					ValueRangePair bucketTRPair = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getTimeRangePair();
					fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", bucketTRPair.maxV, bucketTRPair.minV);

					vector<UserValueRangePair> bucketUVRPair = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getInfluenceRangeVector();
					int bucketinfluSize = bucketUVRPair.size();
					fprintf(resultFile, "<influenceRangeVec>\t");
					for (int k = 0; k < bucketinfluSize; k++) {
						fprintf(resultFile, "%d %.4f %.4f\t", bucketUVRPair[k].userid, bucketUVRPair[k].maxV, bucketUVRPair[k].minV);
						if (k % 10 == 0)
							fprintf(resultFile, "\n");
					}
					fprintf(resultFile, "</influenceRangeVec>\n");
					fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n",
						uprofileEventGroupSet[i].getUProfileEventGroup()[j].getMaxNumInfluencedUsers(),
						uprofileEventGroupSet[i].getUProfileEventGroup()[j].getMinNumInfluencedUsers());

					//centreP minimalRadius
					SpaceRange sr = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getSpaceRangecentreP();
					fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", sr.lat, sr.longi, sr.radius);
					float bucketminiRadius = uprofileEventGroupSet[i].getUProfileEventGroup()[j].GetminimalRadius();
					fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", bucketminiRadius);
					//finish bucket statistics
				}
				for (int j = 0; j < BucketSize; j++)
				{					
					//=======================================
					vector<SubEvent>::iterator iesit = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().begin();
					while (iesit != uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().end()) {
						fprintf(resultFile, "<clusterid> %d </clusterid>\n", (*iesit).GetEventNo());
						/////////////////////////
						fprintf(resultFile, "<msgcontfidf>\t");
						float* conceptvec = (*iesit).GetCluster_ConceptTFIDFVec();
						for (int k = 0; k < TFIDF_DIM; k++) {
							fprintf(resultFile, "%.8f\t", conceptvec[k]);
						}
						fprintf(resultFile, "</msgcontfidf>\n");
						fprintf(resultFile, "<SpaceRange>\t%.8f\t%.8f\t%.8f\t</SpaceRange>\n", (*iesit).GetSpaceRange().lat, (*iesit).GetSpaceRange().longi, (*iesit).GetSpaceRange().radius);
						fprintf(resultFile, "<TimeRange>\t%.8f\t%.8f\t</TimeRange>\n", (*iesit).GetTimeRange().TimeStampCentre, (*iesit).GetTimeRange().range);

						vector<SpaceRange> srset = (*iesit).getmsgSRset();
						if (!srset.empty())
						{
							fprintf(resultFile, "<SpaceRangeSet>\t");
							for (int k = 0; k < srset.size(); k++) {
								fprintf(resultFile, "%.8f %.8f %.8f\t", srset[k].lat, srset[k].longi, srset[k].radius);
							}
							fprintf(resultFile, "</SpaceRangeSet>\n");
						}

						vector<TimeRange> trset = (*iesit).getmsgTRset();
						if (!trset.empty())
						{
							fprintf(resultFile, "<TimeRangeSet>\t");
							for (int k = 0; k < trset.size(); k++) {
								fprintf(resultFile, "%.8f %.8f\t", trset[k].TimeStampCentre, trset[k].range);
							}
							fprintf(resultFile, "</TimeRangeSet>\n");
						}
						fprintf(resultFile, "<useridlist>\t");
						vector<EUserFrePair> eventuserlist = (*iesit).GetEventUserIDs();
						for (int k = 0; k < eventuserlist.size(); k++) {
							fprintf(resultFile, "%d %d\t", eventuserlist[k].userid, eventuserlist[k].frequency);
						}
						fprintf(resultFile, "</useridlist>\n");
						//////////////////////////
						iesit++;
					}
				}
			}
		}
	}

	//exit for not conducting the query operations. 
	return;



	//query generation
	//===generate clusters for test
//	FILE* dataSetDescriptor = NULL, * resultFile = NULL;
	if ((fopen_s(&dataSetDescriptor, MTimeSlotFlist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", MTimeSlotFlist);
	}
	else {
		while (fscanf_s(dataSetDescriptor, "%s ", SlotFileName, 200) != EOF)
		{
			DocCount++;
			if (DocCount % 2 > 0)
				continue;
			if (DocCount <= 24)  //the first day event is put into user profiles as initial user history activity
				continue;

			
			//load data
			strcpy_s(FullSlotFileName, 200, path);
			strcat_s(FullSlotFileName, 200, SlotFileName);
			strcat_s(FullSlotFileName, 200, ".UPdata");

			//read the migration event detection results directly for event recommendation
			Eventclusters.clear();
			loadMigrationEventDetectResultSummary(FullSlotFileName, Eventclusters);
			printf("event generation %s\n", SlotFileName);						
			///==============
			std::vector<SubEvent> IncomingEventSubset;
			float SimiThreshold = 0.1;
			float alpha = ALPHA;
			EventRecommendation eventRec(ALPHA, UPEventList.size());

			for (int i = 0; i < numofGroups; i++)
			{
				eropti.IncomingEventSubsetIdentification(Eventclusters, IncomingEventSubset, uprofileEventGroupSet[i], SimiThreshold, alpha);
				eropti.EventSimilarityJoin(uprofileEventGroupSet[i], IncomingEventSubset, SimiThreshold, eventRec);
				//output the recommendation list of IncomingEventSubset
				char RecommendationResult[200];
				strcpy_s(RecommendationResult, 200, "EventRecResult.txt");
				if (fopen_s(&resultFile, RecommendationResult, "a+") == 0)
				{
					vector<SubEvent>::iterator iesit = IncomingEventSubset.begin();
					while (iesit != IncomingEventSubset.end()) {
						fprintf(resultFile, "<clusterid> %d </clusterid>\n", (*iesit).GetEventNo());
						vector<EventUserSimi>::iterator eusit = (*iesit).RecUserSimi.begin();
						while (eusit != (*iesit).RecUserSimi.end()) {
							fprintf(resultFile, "<recitem>\t %d %f\t</recitem>\n", (*eusit).userid, (*eusit).simi);
							eusit++;
						}
						(*iesit).RecUserSimi.clear();
						iesit++;
					}	
					fclose(resultFile);
				}
				//=======================================================
				IncomingEventSubset.clear();				
			}
			//=================
			//update event ids in Eventclusters to fit userprofile events
			int curEno = UPEventList.size();
			for (int i = 0; i < Eventclusters.size(); i++) {
				Eventclusters[i].SetEventNo(curEno);
				curEno++;
			}
			int addorDel = 1;  //append
			int DeleteNum = 0;  //no deletion
			UpdateUPeventList(Eventclusters, addorDel, DeleteNum);/**/
		}
		fclose(dataSetDescriptor);
		Eventclusters.clear();
	}
	for (int i = 0; i < UserProfileHashMap.size(); i++) {
		UserProfileHashMap[i].UserInfluenceDistri.clear();
		UserProfileHashMap[i].UserInterestEvents.clear();
		UserProfileHashMap[i].UserResponseNumbers.clear();
	}
	UserProfileHashMap.clear();
	for (int i = 0; i < UPEventList.size(); i++) {
		UPEventList[i].cleansubEvent();
	}
	UPEventList.clear();
}

//=======for parallel processing with content vector and user influence vector
void UserProfileAllocationContentUser(char* MTimeSlotFlist, char* path, char* outpath, char* userlist, char* userProfilePath, char* UserInfluFilePath, char* UserInfluFileName) {
	//read user profiles
//===Event Migration Preloading=============
	EventMigration migrateEvent;
	char userinfluenceFile[200];
	strcpy_s(userinfluenceFile, UserInfluFilePath);
	strcat_s(userinfluenceFile, UserInfluFileName);

	migrateEvent.loadUserProfileHashMap(userinfluenceFile);
	migrateEvent.uploadUserProfilesIntoHashMap(userlist, userProfilePath); //locations...
	//========================================
	//load userlist history events
	migrateEvent.BulkLoadUserHistoryEvents(MTimeSlotFlist, path);

	//================
	EventRecomOpti eropti;
	int numofGroups = NUMOfGROUPS;
	std::vector<UPEventPartition> uprofileEventGroupSet;
	LSB lsb;
	char parafile[200];
	strcpy_s(parafile, "PVLDB21para_t1.txt");  //for conceptTF/IDF vector hashing
	lsb.readParaFile(parafile);
	printf("para loading finished\n");

	LSB lsb1;
	char parafileUserInfl[200];
	strcpy_s(parafileUserInfl, "PVLDB21para_t1_UserInflu.txt");  //for user influence vector hashing
	lsb1.readParaFile(parafileUserInfl);
	printf("para loading finished\n");

	SocialEventOperation seopt;
	uprofileEventGroupSet.resize(numofGroups);
	eropti.UserProfileDataPartitionContentUser(UPEventList, numofGroups, uprofileEventGroupSet, lsb,lsb1, seopt);
	   
	FILE* dataSetDescriptor = NULL, * resultFile = NULL;
	//=========================
	//output the recommendation list of IncomingEventSubset
	char FullSlotPartitionFileName[200];
	strcpy_s(FullSlotPartitionFileName, 200, outpath);
	strcat_s(FullSlotPartitionFileName, 200, MTimeSlotFlist);
	strcat_s(FullSlotPartitionFileName, 200, ".UPP");
	if (fopen_s(&resultFile, FullSlotPartitionFileName, "a+") == 0)
	{
		for (int i = 0; i < numofGroups; i++)
		{
			int BucketSize = uprofileEventGroupSet[i].getUProfileEventGroup().size();
			fprintf(resultFile, "<groupid> %d </groupid>\n", i);
			ValueRangePair* topicRangeVec = uprofileEventGroupSet[i].getTopicRangeVector();
			fprintf(resultFile, "<TopicRange>\t");
			for (int k = 0; k < TFIDF_DIM; k++) {
				fprintf(resultFile, "%.8f %.8f\t", topicRangeVec[k].maxV, topicRangeVec[k].minV);
			}
			fprintf(resultFile, "</TopicRange>\n");

			ValueRangePair TRPair = uprofileEventGroupSet[i].getTimeRangePair();
			fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", TRPair.maxV, TRPair.minV);

			ValueRangePair* SRPair = uprofileEventGroupSet[i].getSpaceRangePair();
			fprintf(resultFile, "<SpaceRangePair> %.8f %.8f\t%.8f %.8f\t</SpaceRangePair>\n", SRPair[0].maxV, SRPair[0].minV, SRPair[1].maxV, SRPair[1].minV);

			vector<UserValueRangePair> UVRPair = uprofileEventGroupSet[i].getInfluenceRangeVector();
			int influSize = UVRPair.size();
			fprintf(resultFile, "<influenceRangeVec>\t");
			for (int k = 0; k < influSize; k++) {
				fprintf(resultFile, "%d %.8f %.8f\t", UVRPair[k].userid, UVRPair[k].maxV, UVRPair[k].minV);
				if (k % 10 == 0)
					fprintf(resultFile, "\n");
			}
			fprintf(resultFile, "</influenceRangeVec>\n");

			fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n", uprofileEventGroupSet[i].getMaxNumInfluencedUsers(), uprofileEventGroupSet[i].getMinNumInfluencedUsers());

			//centreP minimalRadius
			SpaceRange sr = uprofileEventGroupSet[i].getSpaceRangecentreP();
			fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", sr.lat, sr.longi, sr.radius);
			float miniRadius = uprofileEventGroupSet[i].GetminimalRadius();
			fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", miniRadius);

			for (int j = 0; j < BucketSize; j++)
			{
				vector<SubEvent>::iterator iesit = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().begin();
				while (iesit != uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().end()) {
					fprintf(resultFile, "<clusterid> %d </clusterid>\n", (*iesit).GetEventNo());
					/////////////////////////
					fprintf(resultFile, "<msgcontfidf>\t");
					float* conceptvec = (*iesit).GetCluster_ConceptTFIDFVec();
					for (int k = 0; k < TFIDF_DIM; k++) {
						fprintf(resultFile, "%.8f\t", conceptvec[k]);
					}
					fprintf(resultFile, "</msgcontfidf>\n");
					fprintf(resultFile, "<SpaceRange>\t%.8f\t%.8f\t%.8f\t</SpaceRange>\n", (*iesit).GetSpaceRange().lat, (*iesit).GetSpaceRange().longi, (*iesit).GetSpaceRange().radius);
					fprintf(resultFile, "<TimeRange>\t%.8f\t%.8f\t</TimeRange>\n", (*iesit).GetTimeRange().TimeStampCentre, (*iesit).GetTimeRange().range);

					vector<SpaceRange> srset = (*iesit).getmsgSRset();
					if (!srset.empty())
					{
						fprintf(resultFile, "<SpaceRangeSet>\t");
						for (int k = 0; k < srset.size(); k++) {
							fprintf(resultFile, "%.8f %.8f %.8f\t", srset[k].lat, srset[k].longi, srset[k].radius);
						}
						fprintf(resultFile, "</SpaceRangeSet>\n");
					}

					vector<TimeRange> trset = (*iesit).getmsgTRset();
					if (!trset.empty())
					{
						fprintf(resultFile, "<TimeRangeSet>\t");
						for (int k = 0; k < trset.size(); k++) {
							fprintf(resultFile, "%.8f %.8f\t", trset[k].TimeStampCentre, trset[k].range);
						}
						fprintf(resultFile, "</TimeRangeSet>\n");
					}
					/*SEO.HashMappingEvent((*ecit), lsb);*/
					fprintf(resultFile, "<HashkeyValues>\t");
					for (int k = 0; k < MVALUE; k++)
						fprintf(resultFile, "%d\t", (*iesit).EHashV[k]);
					fprintf(resultFile, "</HashkeyValues>\n");

					fprintf(resultFile, "<useridlist>\t");
					vector<EUserFrePair> eventuserlist = (*iesit).GetEventUserIDs();
					for (int k = 0; k < eventuserlist.size(); k++) {
						fprintf(resultFile, "%d %d\t", eventuserlist[k].userid, eventuserlist[k].frequency);
					}
					fprintf(resultFile, "</useridlist>\n");
					//////////////////////////
					iesit++;
				}
			}
		}
		fclose(resultFile);
	}
	UPEventList.clear();
	//==========================
	char FullSlotFileName[200], SlotFileName[200];
	vector<SubEvent> Eventclusters;
	int DocCount = 0;
	float maxDimVal = 0;
	if ((fopen_s(&dataSetDescriptor, MTimeSlotFlist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", MTimeSlotFlist);
	}
	else {
		while (fscanf_s(dataSetDescriptor, "%s ", SlotFileName, 200) != EOF)
		{
			DocCount++;
			if (DocCount % 2 > 0)
				continue;
			if (DocCount <= 24)  //the first day event is put into user profiles as initial user history activity
				continue;
			//load data
			strcpy_s(FullSlotFileName, 200, path);
			strcat_s(FullSlotFileName, 200, SlotFileName);
			strcat_s(FullSlotFileName, 200, ".UPdata");

			//read the migration event detection results directly for event recommendation
			Eventclusters.clear();
			loadMigrationEventDetectResultSummary(FullSlotFileName, Eventclusters);
			printf("event generation %s\n", SlotFileName);
			///==============	
			eropti.ContinuousUserProfileDataPartitionContentUser(Eventclusters, numofGroups, uprofileEventGroupSet, lsb,lsb1, seopt);
			//output the recommendation list of IncomingEventSubset
			char FullSlotPartitionFileName[200];
			strcpy_s(FullSlotPartitionFileName, 200, outpath);
			strcat_s(FullSlotPartitionFileName, 200, SlotFileName);
			strcat_s(FullSlotPartitionFileName, 200, ".UPP");
			int startClusterno = Eventclusters[0].GetEventNo();
			if (fopen_s(&resultFile, FullSlotPartitionFileName, "a+") == 0)
			{
				for (int i = 0; i < numofGroups; i++)
				{
					if (i == 9)
						printf("i=%d\n", i);
					int BucketSize = uprofileEventGroupSet[i].getUProfileEventGroup().size();
					fprintf(resultFile, "<groupid> %d </groupid>\n", i);
					ValueRangePair* topicRangeVec = uprofileEventGroupSet[i].getTopicRangeVector();
					fprintf(resultFile, "<TopicRange>\t");
					for (int k = 0; k < TFIDF_DIM; k++) {
						fprintf(resultFile, "%.8f %.8f\t", topicRangeVec[k].maxV, topicRangeVec[k].minV);
					}
					fprintf(resultFile, "</TopicRange>\n");

					ValueRangePair TRPair = uprofileEventGroupSet[i].getTimeRangePair();
					fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", TRPair.maxV, TRPair.minV);

					ValueRangePair* SRPair = uprofileEventGroupSet[i].getSpaceRangePair();
					fprintf(resultFile, "<SpaceRangePair> %.8f %.8f\t%.8f %.8f\t</SpaceRangePair>\n", SRPair[0].maxV, SRPair[0].minV, SRPair[1].maxV, SRPair[1].minV);

					vector<UserValueRangePair> UVRPair = uprofileEventGroupSet[i].getInfluenceRangeVector();
					int influSize = UVRPair.size();
					fprintf(resultFile, "<influenceRangeVec>\t");
					for (int k = 0; k < influSize; k++) {
						fprintf(resultFile, "%d %.8f %.8f\t", UVRPair[k].userid, UVRPair[k].maxV, UVRPair[k].minV);
						if (k % 10 == 0)
							fprintf(resultFile, "\n");
					}
					fprintf(resultFile, "</influenceRangeVec>\n");

					fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n", uprofileEventGroupSet[i].getMaxNumInfluencedUsers(), uprofileEventGroupSet[i].getMinNumInfluencedUsers());

					//for minimalRadius;  the centreP
					SpaceRange centP = uprofileEventGroupSet[i].getSpaceRangecentreP();
					fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", centP.lat, centP.longi, centP.radius);
					fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", uprofileEventGroupSet[i].GetminimalRadius());

					for (int j = 0; j < BucketSize; j++)
					{
						vector<SubEvent>::iterator iesit = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().begin();
						while (iesit != uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().end())
						{
							if ((*iesit).GetEventNo() < startClusterno) {
								iesit++;
								continue;
							}
							fprintf(resultFile, "<clusterid> %d </clusterid>\n", (*iesit).GetEventNo());
							/////////////////////////
							fprintf(resultFile, "<msgcontfidf>\t");
							float* conceptvec = (*iesit).GetCluster_ConceptTFIDFVec();
							for (int k = 0; k < TFIDF_DIM; k++) {
								fprintf(resultFile, "%.8f\t", conceptvec[k]);
							}
							fprintf(resultFile, "</msgcontfidf>\n");
							fprintf(resultFile, "<SpaceRange>\t%.8f\t%.8f\t%.8f\t</SpaceRange>\n", (*iesit).GetSpaceRange().lat, (*iesit).GetSpaceRange().longi, (*iesit).GetSpaceRange().radius);
							fprintf(resultFile, "<TimeRange>\t%.8f\t%.8f\t</TimeRange>\n", (*iesit).GetTimeRange().TimeStampCentre, (*iesit).GetTimeRange().range);

							vector<SpaceRange> srset = (*iesit).getmsgSRset();
							if (!srset.empty()) {
								fprintf(resultFile, "<SpaceRangeSet>\t");
								for (int k = 0; k < srset.size(); k++) {
									fprintf(resultFile, "%.8f %.8f %.8f\t", srset[k].lat, srset[k].longi, srset[k].radius);
								}
								fprintf(resultFile, "</SpaceRangeSet>\n");
							}

							vector<TimeRange> trset = (*iesit).getmsgTRset();
							if (!trset.empty())
							{
								fprintf(resultFile, "<TimeRangeSet>\t");
								for (int k = 0; k < trset.size(); k++) {
									fprintf(resultFile, "%.8f %.8f\t", trset[k].TimeStampCentre, trset[k].range);
								}
								fprintf(resultFile, "</TimeRangeSet>\n");
							}
							/*SEO.HashMappingEvent((*ecit), lsb);*/
							fprintf(resultFile, "<HashkeyValues>\t");
							for (int k = 0; k < MVALUE; k++)
								fprintf(resultFile, "%d\t", (*iesit).EHashV[k]);
							fprintf(resultFile, "</HashkeyValues>\n");

							fprintf(resultFile, "<useridlist>\t");
							vector<EUserFrePair> eventuserlist = (*iesit).GetEventUserIDs();
							for (int k = 0; k < eventuserlist.size(); k++) {
								fprintf(resultFile, "%d %d\t", eventuserlist[k].userid, eventuserlist[k].frequency);
							}
							fprintf(resultFile, "</useridlist>\n");
							//////////////////////////
							iesit++;
						}
					}
				}
				//=======================================================	
				fclose(resultFile);
			}
			
			Eventclusters.clear();
		}
		fclose(dataSetDescriptor);
	}
}


void LoadHistPartitions(char* FullSlotPartitionFileName, std::vector<UPEventPartition>& uprofileEventGroupSet) {
	FILE* resultFile = NULL;
	char buffer[BUFFERSIZE];
	string line;
	int curGroupNo = 0;
	ValueRangePair topicRangeVec[TFIDF_DIM];
	ValueRangePair topicAngleRangeVec[TFIDF_DIM];
	
	int IsBucket = 0; //0: group, 1: Bucket.
	int curBucketNo = 0;
	vector<UserValueRangePair> UVRPair;
	SubEvent curSubevent;
	UPEventBucket eBucket;
	if (fopen_s(&resultFile, FullSlotPartitionFileName, "r") == 0)
	{
		while (fgets(buffer, BUFFERSIZE, resultFile))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) line!\n");
				return;
			}

			int i = 0;
			if (strcmp(strtok.token(i).c_str(), "<groupid>") == 0) {
				IsBucket = 0;
				i++;
				while (strcmp(strtok.token(i).c_str(), "</groupid>") != 0) {
					curGroupNo = atoi(strtok.token(i).c_str());
					i++;
				}
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<bucketid>") == 0) {
				IsBucket = 1;
				i++;
				while (strcmp(strtok.token(i).c_str(), "</bucketid>") != 0) {
					curBucketNo = atoi(strtok.token(i).c_str());
					i++;
				}
				
				eBucket.commonHashDimSet.clear();
				uprofileEventGroupSet[curGroupNo].setUProfileEventGroup(eBucket);
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<TopicRange>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</TopicRange>") != 0)
				{
					for (int j = 0; j < TFIDF_DIM; j++) {
						topicRangeVec[j].maxV = atof(strtok.token(i).c_str());
						i++;
						topicRangeVec[j].minV = atof(strtok.token(i).c_str());
						i++;
					}
				}
				if (IsBucket)
					uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setTopicRangeVector(topicRangeVec);
				else
					uprofileEventGroupSet[curGroupNo].setTopicRangeVector(topicRangeVec);
				i++;
				continue;
			}

			if (strcmp(strtok.token(i).c_str(), "<TopicAngleRange>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</TopicAngleRange>") != 0)
				{
					for (int j = 0; j < TFIDF_DIM-1; j++) {
						topicAngleRangeVec[j].maxV = atof(strtok.token(i).c_str());
						i++;
						topicAngleRangeVec[j].minV = atof(strtok.token(i).c_str());
						i++;
					}
				}
				if (IsBucket)
					uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setTopicVectorAngleTanRanges(topicAngleRangeVec);
				else
					uprofileEventGroupSet[curGroupNo].setTopicVectorAngleTanRanges(topicAngleRangeVec);
				i++;
				continue;
			}

			if (strcmp(strtok.token(i).c_str(), "<TopicCentre>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</TopicCentre>") != 0)
				{
					float conceptvec[TFIDF_DIM];
					for (int j = 0; j < TFIDF_DIM; j++) {
						conceptvec[j] = atof(strtok.token(i).c_str());
						i++;						
					}
					curSubevent.setConceptTFIDFVec(conceptvec);
					if (IsBucket)
						uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setTFIDFCenter(curSubevent);
					else
						uprofileEventGroupSet[curGroupNo].setTFIDFCenter(curSubevent);
				}
				
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<minAngleCos>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</minAngleCos>") != 0)
				{
					float miniAngleCos;
					miniAngleCos = atof(strtok.token(i).c_str());
					i++;
					if (IsBucket)
						uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setminAngleCos(miniAngleCos);
					else
						uprofileEventGroupSet[curGroupNo].setminAngleCos(miniAngleCos);
				}
				i++;
				continue;
			}

			if (strcmp(strtok.token(i).c_str(), "<minAngleCosForCHDSet>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</minAngleCosForCHDSet>") != 0)
				{
					float miniAngleCos;
					miniAngleCos = atof(strtok.token(i).c_str());
					i++;
					if (IsBucket)
						uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setminAngleCosForCHDSet(miniAngleCos);
					else
						uprofileEventGroupSet[curGroupNo].setminAngleCosForCHDSet(miniAngleCos);
				}
				i++;
				continue;
			}

			if (strcmp(strtok.token(i).c_str(), "<minAngleCosForNonCHDSet>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</minAngleCosForNonCHDSet>") != 0)
				{
					float miniAngleCos;
					miniAngleCos = atof(strtok.token(i).c_str());
					i++;
					if (IsBucket)
						uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setminAngleCosForNonCHDSet(miniAngleCos);
					else
						uprofileEventGroupSet[curGroupNo].setminAngleCosForNonCHDSet(miniAngleCos);
				}
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<commonHashDimSet>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</commonHashDimSet>") != 0)
				{
					DimHashKeyPair DHPairEle;
					DHPairEle.dim = atoi(strtok.token(i).c_str());
					i++;
					DHPairEle.HashKey = atoi(strtok.token(i).c_str());
					i++;					
					if (IsBucket)
						uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].commonHashDimSet.push_back(DHPairEle);
					else
						uprofileEventGroupSet[curGroupNo].commonHashDimSet.push_back(DHPairEle);
				}				
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<TimeRangePair>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</TimeRangePair>") != 0)
				{
					ValueRangePair TRPair;
					TRPair.maxV = atof(strtok.token(i).c_str());
					i++;
					TRPair.minV = atof(strtok.token(i).c_str());
					i++;
					if (IsBucket)
						uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setTimeRangePair(TRPair);
					else
						uprofileEventGroupSet[curGroupNo].setTimeRangePair(TRPair);
				}
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<SpaceRangePair>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</SpaceRangePair>") != 0)
				{
					ValueRangePair SRPair[2];
					for (int j = 0; j < 2; j++) {
						SRPair[j].maxV = atof(strtok.token(i).c_str());
						i++;
						SRPair[j].minV = atof(strtok.token(i).c_str());
						i++;
					}
					if (IsBucket)
						uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setSpaceRangePair(SRPair);
					else
						uprofileEventGroupSet[curGroupNo].setSpaceRangePair(SRPair);
				}

				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<influenceRangeVec>") == 0) {
				i++;
				UVRPair.clear();
				while (strcmp(strtok.token(i).c_str(), "</influenceRangeVec>") != 0)
				{
					UserValueRangePair UVRPairEle;
					UVRPairEle.userid = atoi(strtok.token(i).c_str());
					i++;
					UVRPairEle.maxV = atof(strtok.token(i).c_str());
					i++;
					UVRPairEle.minV = atof(strtok.token(i).c_str());
					i++;
					UVRPair.push_back(UVRPairEle);
					if (i == length)
					{
						fgets(buffer, BUFFERSIZE, resultFile);
						line = buffer;
						strtok.cleantokens();
						strtok.parse(line, " \t\r\n");
						length = strtok.count_tokens();
						i = 0;
					}
				}
				if (IsBucket)
					uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setInfluenceRangeVector(UVRPair);
				else
					uprofileEventGroupSet[curGroupNo].setInfluenceRangeVector(UVRPair);
				UVRPair.clear();
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<MaxMinUN>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</MaxMinUN>") != 0)
				{
					int maxNuminfUser = 0;
					int minNuminfUser = 0;
					maxNuminfUser = atoi(strtok.token(i).c_str());

					i++;
					minNuminfUser = atoi(strtok.token(i).c_str());
					if (IsBucket) {
						uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setMaxNumInfluencedUsers(maxNuminfUser);
						uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setMinNumInfluencedUsers(minNuminfUser);
					}
					else
					{
						uprofileEventGroupSet[curGroupNo].setMaxNumInfluencedUsers(maxNuminfUser);
						uprofileEventGroupSet[curGroupNo].setMinNumInfluencedUsers(minNuminfUser);
					}
					i++;
				}
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<centreP>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</centreP>") != 0)
				{
					SpaceRange sr;
					sr.lat = atof(strtok.token(i).c_str());
					i++;
					sr.longi = atof(strtok.token(i).c_str());
					i++;
					sr.radius = atof(strtok.token(i).c_str());
					i++;
					if (IsBucket) 
						uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setSpaceRangecentreP(sr);
					else
						uprofileEventGroupSet[curGroupNo].setSpaceRangecentreP(sr);
				}

				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<minimalRadius>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</minimalRadius>") != 0)
				{
					float miniRadius;
					miniRadius = atof(strtok.token(i).c_str());
					i++;
					if (IsBucket) 
						uprofileEventGroupSet[curGroupNo].getUProfileEventGroup()[curBucketNo].setminimalRadius(miniRadius);
					else
						uprofileEventGroupSet[curGroupNo].setminimalRadius(miniRadius);
				}
				i++;
				continue;
			}
			//read into curSubevent
			if (strcmp(strtok.token(i).c_str(), "<clusterid>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</clusterid>") != 0) {
					curSubevent.SetEventNo(atoi(strtok.token(i).c_str()));
					i++;
				}
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<msgcontfidf>") == 0) {
				i++;
				float conceptvec[TFIDF_DIM];
				while (strcmp(strtok.token(i).c_str(), "</msgcontfidf>") != 0)
				{
					for (int j = 0; j < TFIDF_DIM; j++) {
						conceptvec[j] = atof(strtok.token(i).c_str());
						i++;
					}
				}
				curSubevent.setConceptTFIDFVec(conceptvec);
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<SpaceRange>") == 0) {
				i++;
				SpaceRange sr;
				while (strcmp(strtok.token(i).c_str(), "</SpaceRange>") != 0) {
					sr.lat = atof(strtok.token(i).c_str());
					i++;
					sr.longi = atof(strtok.token(i).c_str());
					i++;
					sr.radius = atof(strtok.token(i).c_str());
					i++;
				}
				curSubevent.setSpaceRange(sr);
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<TimeRange>") == 0) {
				i++;
				TimeRange tr;
				while (strcmp(strtok.token(i).c_str(), "</TimeRange>") != 0) {
					tr.TimeStampCentre = atof(strtok.token(i).c_str());
					i++;
					tr.range = atof(strtok.token(i).c_str());
					i++;
				}
				curSubevent.setTimeRange(tr);
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<SpaceRangeSet>") == 0) {
				i++;
				SpaceRange sr;
				while (strcmp(strtok.token(i).c_str(), "</SpaceRangeSet>") != 0) {
					sr.lat = atof(strtok.token(i).c_str());
					i++;
					sr.longi = atof(strtok.token(i).c_str());
					i++;
					sr.radius = atof(strtok.token(i).c_str());
					i++;
					curSubevent.uploadmsgSRset(sr);
				}
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<TimeRangeSet>") == 0) {
				i++;
				TimeRange tr;
				while (strcmp(strtok.token(i).c_str(), "</TimeRangeSet>") != 0) {
					tr.TimeStampCentre = atof(strtok.token(i).c_str());
					i++;
					tr.range = atof(strtok.token(i).c_str());
					i++;
					curSubevent.uploadmsgTRset(tr);
				}
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<HashkeyValues>") == 0) {
				i++;
				int j = 0;
				while (strcmp(strtok.token(i).c_str(), "</HashkeyValues>") != 0)
				{
					curSubevent.EHashV[j] = atoi(strtok.token(i).c_str());
					i++;
					j++;					
				}
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<useridlist>") == 0) {
				i++;
				EUserFrePair eufp;
				vector<EUserFrePair> eventuserlist;
				eventuserlist.clear();
				while (strcmp(strtok.token(i).c_str(), "</useridlist>") != 0)
				{
					eufp.userid = atoi(strtok.token(i).c_str());
					i++;
					eufp.frequency = atoi(strtok.token(i).c_str());
					i++;
					eventuserlist.push_back(eufp);
				}
				curSubevent.setEventUserIDs(eventuserlist);
				eventuserlist.clear();
				uprofileEventGroupSet[curGroupNo].setUProfileEvent(curSubevent, curBucketNo);
				curSubevent.cleansubEvent();
				i++;
				continue;
			}
		}
		fclose(resultFile);
	}
}
void UserProfileQueryGeneration(char* MTimeSlotFlist, char* HistoryPartition, char* path, char*partitionPath, 
	char* outpath, char* userlist, char* userProfilePath, char* UserInfluFilePath, char* UserInfluFileName) 
{
	FILE* dataSetDescriptor = NULL, * resultFile = NULL;
	char FullSlotFileName[FNAMEBUFSIZE], SlotFileName[FNAMEBUFSIZE];
	vector<SubEvent> Eventclusters;
	int DocCount = 0;

	//===Event Migration Preloading=============
	EventMigration migrateEvent;
	char userinfluenceFile[FNAMEBUFSIZE];
	strcpy_s(userinfluenceFile, UserInfluFilePath);
	strcat_s(userinfluenceFile, UserInfluFileName);

	migrateEvent.loadUserProfileHashMap(userinfluenceFile);
	migrateEvent.uploadUserProfilesIntoHashMap(userlist, userProfilePath); //locations...
	//=======================================
	
	EventRecomOpti eropti;
	int numofGroups = NUMOfGROUPS;
	std::vector<UPEventPartition> uprofileEventGroupSet;
	uprofileEventGroupSet.resize(numofGroups);
	/*UPEventBucket e;
	for(int i=0;i<numofGroups;i++)
		uprofileEventGroupSet[i].setUProfileEventGroup(e);*/

	//read the initial history uprofileEventGroupSet partition information.
	char FullSlotPartitionFileName[FNAMEBUFSIZE];
	strcpy_s(FullSlotPartitionFileName, FNAMEBUFSIZE, partitionPath);
	strcat_s(FullSlotPartitionFileName, FNAMEBUFSIZE, HistoryPartition);
	strcat_s(FullSlotPartitionFileName, FNAMEBUFSIZE, ".UPP");
	LoadHistPartitions(FullSlotPartitionFileName, uprofileEventGroupSet);
	//==============================

	if ((fopen_s(&dataSetDescriptor, MTimeSlotFlist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", MTimeSlotFlist);
	}
	else {
		while (fscanf_s(dataSetDescriptor, "%s ", SlotFileName, FNAMEBUFSIZE) != EOF)
		{
			DocCount++;
			if (DocCount % 2 > 0)
				continue;
			if (DocCount <= 24)  //the first day event is put into user profiles as initial user history activity
				continue;/**/

			//load data
			strcpy_s(FullSlotFileName, FNAMEBUFSIZE, path);
			strcat_s(FullSlotFileName, FNAMEBUFSIZE, SlotFileName);
			strcat_s(FullSlotFileName, FNAMEBUFSIZE, ".UPdata");

			//read the migration event detection results directly for event recommendation
			//Eventclusters.clear();
			loadMigrationEventDetectResultSummary(FullSlotFileName, Eventclusters);
			printf("event generation %s\n", SlotFileName);
			//continue;
			///==============
			std::vector<SubEvent> IncomingEventSubset;
			float SimiThreshold = 0.3;
			float alpha = ALPHA;			
			EventRecommendation eventRec(ALPHA, UPEventList.size());
						
			for (int i = 0; i < numofGroups; i++)
			{				
				eropti.IncomingEventSubsetIdentification(Eventclusters, IncomingEventSubset, uprofileEventGroupSet[i], SimiThreshold, alpha);
				eropti.EventSimilarityJoin(uprofileEventGroupSet[i], IncomingEventSubset, SimiThreshold, eventRec);

				
				//output the recommendation list of IncomingEventSubset
				char RecommendationResult[FNAMEBUFSIZE];
				strcpy_s(RecommendationResult, FNAMEBUFSIZE, "EventRecResult.txt");
				if (fopen_s(&resultFile, RecommendationResult, "a+") == 0)
				{
					vector<SubEvent>::iterator iesit = IncomingEventSubset.begin();
					while (iesit != IncomingEventSubset.end()) {
						fprintf(resultFile, "<clusterid> %d </clusterid>\n", (*iesit).GetEventNo());
						vector<EventUserSimi>::iterator eusit = (*iesit).RecUserSimi.begin();
						while (eusit != (*iesit).RecUserSimi.end()) {
							fprintf(resultFile, "<recitem>\t %d %f\t</recitem>\n", (*eusit).userid, (*eusit).simi);
							eusit++;
						}
						(*iesit).RecUserSimi.clear();
						iesit++;
					}
					fclose(resultFile);
				}/**/
				//=======================================================
				cout << "ClusterSize: " << Eventclusters.size() << "\t IncomingEventSubset Size: " << IncomingEventSubset.size() << endl;
				IncomingEventSubset.clear();
				printf("join %d\n", i);
			}
			
			//=================
			//update event ids in Eventclusters to fit userprofile events
			/*int curEno = UPEventList.size();
			for (int i = 0; i < Eventclusters.size(); i++) {
				Eventclusters[i].SetEventNo(curEno);
				curEno++;
			}*/
			strcpy_s(FullSlotPartitionFileName, FNAMEBUFSIZE, partitionPath);
			strcat_s(FullSlotPartitionFileName, FNAMEBUFSIZE, SlotFileName);
			strcat_s(FullSlotPartitionFileName, FNAMEBUFSIZE, ".UPP");

			LoadHistPartitions(FullSlotPartitionFileName, uprofileEventGroupSet);
		}
		fclose(dataSetDescriptor);		
		Eventclusters.clear();
	}
	for (int i = 0; i < UserProfileHashMap.size(); i++) {
		UserProfileHashMap[i].UserInfluenceDistri.clear();
		UserProfileHashMap[i].UserInterestEvents.clear();
		UserProfileHashMap[i].UserResponseNumbers.clear();
	}
	UserProfileHashMap.clear();
	for (int i = 0; i < UPEventList.size(); i++) {
		UPEventList[i].cleansubEvent();
	}
	UPEventList.clear();
}


void UserProfileAllocationHP(char* MTimeSlotFlist, char* path, char* outpath, char* userlist, char* userProfilePath, char* UserInfluFilePath, char* UserInfluFileName) {
	//read user profiles
	//===Event Migration Preloading=============
	EventMigration migrateEvent;
	char userinfluenceFile[200];
	strcpy_s(userinfluenceFile, UserInfluFilePath);
	strcat_s(userinfluenceFile, UserInfluFileName);

	migrateEvent.loadUserProfileHashMap(userinfluenceFile);
	migrateEvent.uploadUserProfilesIntoHashMap(userlist, userProfilePath); //locations...
	//========================================
	//load userlist history events
	migrateEvent.BulkLoadUserHistoryEvents(MTimeSlotFlist, path);

	//================
	EventRecomOpti eropti;
	int numofGroups = NUMOfGROUPS;
	std::vector<UPEventPartition> uprofileEventGroupSet;
	
	SocialEventOperation seopt;
	uprofileEventGroupSet.resize(numofGroups);	
	eropti.UserProfileDataPartitionHP(UPEventList, numofGroups, uprofileEventGroupSet, seopt);
	
	FILE* dataSetDescriptor = NULL, * resultFile = NULL;
	//=========================
	
	//output the recommendation list of IncomingEventSubset
	char FullSlotPartitionFileName[200];
	strcpy_s(FullSlotPartitionFileName, 200, outpath);
	strcat_s(FullSlotPartitionFileName, 200, MTimeSlotFlist);
	strcat_s(FullSlotPartitionFileName, 200, ".UPP");
	if (fopen_s(&resultFile, FullSlotPartitionFileName, "a+") == 0)
	{
		for (int i = 0; i < uprofileEventGroupSet.size(); i++)
		{
			int BucketSize = uprofileEventGroupSet[i].getUProfileEventGroup().size();
			fprintf(resultFile, "<groupid> %d </groupid>\n", i);
			fprintf(resultFile, "<BucketNum> %d </BucketNum>\n", BucketSize);

			float* centvec = uprofileEventGroupSet[i].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
			fprintf(resultFile, "<TopicCentre>\t");
			for (int k = 0; k < TFIDF_DIM; k++) {
				fprintf(resultFile, "%.8f\t", centvec[k]);
			}
			fprintf(resultFile, "</TopicCentre>\n");

			fprintf(resultFile, "<minAngleCos>\t");
			float minAngleCosV = uprofileEventGroupSet[i].getminAngleCos();
			fprintf(resultFile, "%.8f\t", minAngleCosV);
			fprintf(resultFile, "</minAngleCos>\n");

			ValueRangePair TRPair = uprofileEventGroupSet[i].getTimeRangePair();
			fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", TRPair.maxV, TRPair.minV);

			vector<UserValueRangePair> UVRPair = uprofileEventGroupSet[i].getInfluenceRangeVector();
			int influSize = UVRPair.size();
			fprintf(resultFile, "<influenceRangeVec>\t");
			for (int k = 0; k < influSize; k++) {
				fprintf(resultFile, "%d %.4f %.4f\t", UVRPair[k].userid, UVRPair[k].maxV, UVRPair[k].minV);
				if (k % 10 == 0)
					fprintf(resultFile, "\n");
			}
			fprintf(resultFile, "</influenceRangeVec>\n");

			fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n", uprofileEventGroupSet[i].getMaxNumInfluencedUsers(), uprofileEventGroupSet[i].getMinNumInfluencedUsers());

			//centreP minimalRadius
			SpaceRange sr = uprofileEventGroupSet[i].getSpaceRangecentreP();
			fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", sr.lat, sr.longi, sr.radius);
			float miniRadius = uprofileEventGroupSet[i].GetminimalRadius();
			fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", miniRadius);

			for (int j = 0; j < BucketSize; j++)
			{
				//=======output bucket statistics information================================
				int CurBucketSize = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().size();
				fprintf(resultFile, "<bucketid> %d </bucketid>\n", j);
				fprintf(resultFile, "<BucketSize> %d </BucketSize>\n", CurBucketSize);

				float* bucketcentvec = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
				fprintf(resultFile, "<TopicCentre>\t");
				for (int k = 0; k < TFIDF_DIM; k++) {
					fprintf(resultFile, "%.8f\t", bucketcentvec[k]);
				}
				fprintf(resultFile, "</TopicCentre>\n");

				fprintf(resultFile, "<minAngleCos>\t");
				float bucketminAngleCosV = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getminAngleCos();
				fprintf(resultFile, "%.8f\t", bucketminAngleCosV);
				fprintf(resultFile, "</minAngleCos>\n");

				ValueRangePair bucketTRPair = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getTimeRangePair();
				fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", bucketTRPair.maxV, bucketTRPair.minV);

				vector<UserValueRangePair> bucketUVRPair = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getInfluenceRangeVector();
				int bucketinfluSize = bucketUVRPair.size();
				fprintf(resultFile, "<influenceRangeVec>\t");
				for (int k = 0; k < bucketinfluSize; k++) {
					fprintf(resultFile, "%d %.4f %.4f\t", bucketUVRPair[k].userid, bucketUVRPair[k].maxV, bucketUVRPair[k].minV);
					if (k % 10 == 0)
						fprintf(resultFile, "\n");
				}
				fprintf(resultFile, "</influenceRangeVec>\n");
				fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n",
					uprofileEventGroupSet[i].getUProfileEventGroup()[j].getMaxNumInfluencedUsers(),
					uprofileEventGroupSet[i].getUProfileEventGroup()[j].getMinNumInfluencedUsers());

				//centreP minimalRadius
				SpaceRange sr = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getSpaceRangecentreP();
				fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", sr.lat, sr.longi, sr.radius);
				float bucketminiRadius = uprofileEventGroupSet[i].getUProfileEventGroup()[j].GetminimalRadius();
				fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", bucketminiRadius);
				//finish bucket statistics
			}
			for (int j = 0; j < BucketSize; j++)
			{
				//=======================================
				vector<SubEvent>::iterator iesit = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().begin();
				while (iesit != uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().end()) {
					fprintf(resultFile, "<clusterid> %d </clusterid>\n", (*iesit).GetEventNo());
					/////////////////////////
					fprintf(resultFile, "<msgcontfidf>\t");
					float* conceptvec = (*iesit).GetCluster_ConceptTFIDFVec();
					for (int k = 0; k < TFIDF_DIM; k++) {
						fprintf(resultFile, "%.8f\t", conceptvec[k]);
					}
					fprintf(resultFile, "</msgcontfidf>\n");
					fprintf(resultFile, "<SpaceRange>\t%.8f\t%.8f\t%.8f\t</SpaceRange>\n", (*iesit).GetSpaceRange().lat, (*iesit).GetSpaceRange().longi, (*iesit).GetSpaceRange().radius);
					fprintf(resultFile, "<TimeRange>\t%.8f\t%.8f\t</TimeRange>\n", (*iesit).GetTimeRange().TimeStampCentre, (*iesit).GetTimeRange().range);

					vector<SpaceRange> srset = (*iesit).getmsgSRset();
					if (!srset.empty())
					{
						fprintf(resultFile, "<SpaceRangeSet>\t");
						for (int k = 0; k < srset.size(); k++) {
							fprintf(resultFile, "%.8f %.8f %.8f\t", srset[k].lat, srset[k].longi, srset[k].radius);
						}
						fprintf(resultFile, "</SpaceRangeSet>\n");
					}

					vector<TimeRange> trset = (*iesit).getmsgTRset();
					if (!trset.empty())
					{
						fprintf(resultFile, "<TimeRangeSet>\t");
						for (int k = 0; k < trset.size(); k++) {
							fprintf(resultFile, "%.8f %.8f\t", trset[k].TimeStampCentre, trset[k].range);
						}
						fprintf(resultFile, "</TimeRangeSet>\n");
					}

					fprintf(resultFile, "<useridlist>\t");
					vector<EUserFrePair> eventuserlist = (*iesit).GetEventUserIDs();
					for (int k = 0; k < eventuserlist.size(); k++) {
						fprintf(resultFile, "%d %d\t", eventuserlist[k].userid, eventuserlist[k].frequency);
					}
					fprintf(resultFile, "</useridlist>\n");
					//////////////////////////
					iesit++;
				}
			}
		}
		fclose(resultFile);
	}
	UPEventList.clear();
	//==========================
	char FullSlotFileName[200], SlotFileName[200];
	vector<SubEvent> Eventclusters;
	int DocCount = 0;
	float maxDimVal = 0;
	if ((fopen_s(&dataSetDescriptor, MTimeSlotFlist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", MTimeSlotFlist);
	}
	else 
	{
		while (fscanf_s(dataSetDescriptor, "%s ", SlotFileName, 200) != EOF)
		{
			DocCount++;
			if (DocCount % 2 > 0)
				continue;
			if (DocCount <= 24)  //the first day event is put into user profiles as initial user history activity
				continue;
			//load data
			strcpy_s(FullSlotFileName, 200, path);
			strcat_s(FullSlotFileName, 200, SlotFileName);
			strcat_s(FullSlotFileName, 200, ".UPdata");

			//read the migration event detection results directly for event recommendation
			Eventclusters.clear();
			loadMigrationEventDetectResultSummary(FullSlotFileName, Eventclusters);
			printf("event generation %s\n", SlotFileName);
			///==============	
			eropti.ContinuousUserProfileDataPartitionHP(Eventclusters, numofGroups, uprofileEventGroupSet, seopt);

			char FullSlotPartitionFileName[200];
			strcpy_s(FullSlotPartitionFileName, 200, outpath);
			strcat_s(FullSlotPartitionFileName, 200, SlotFileName);
			strcat_s(FullSlotPartitionFileName, 200, ".UPP");
			int startClusterno = Eventclusters[0].GetEventNo();
			if (fopen_s(&resultFile, FullSlotPartitionFileName, "a+") == 0)
			{
				for (int i = 0; i < uprofileEventGroupSet.size(); i++)
				{
					int BucketSize = uprofileEventGroupSet[i].getUProfileEventGroup().size();
					fprintf(resultFile, "<groupid> %d </groupid>\n", i);
					fprintf(resultFile, "<BucketNum> %d </BucketNum>\n", BucketSize);

					float* centvec = uprofileEventGroupSet[i].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
					fprintf(resultFile, "<TopicCentre>\t");
					for (int k = 0; k < TFIDF_DIM; k++) {
						fprintf(resultFile, "%.8f\t", centvec[k]);
					}
					fprintf(resultFile, "</TopicCentre>\n");

					fprintf(resultFile, "<minAngleCos>\t");
					float minAngleCosV = uprofileEventGroupSet[i].getminAngleCos();
					fprintf(resultFile, "%.8f\t", minAngleCosV);
					fprintf(resultFile, "</minAngleCos>\n");

					ValueRangePair TRPair = uprofileEventGroupSet[i].getTimeRangePair();
					fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", TRPair.maxV, TRPair.minV);

					vector<UserValueRangePair> UVRPair = uprofileEventGroupSet[i].getInfluenceRangeVector();
					int influSize = UVRPair.size();
					fprintf(resultFile, "<influenceRangeVec>\t");
					for (int k = 0; k < influSize; k++) {
						fprintf(resultFile, "%d %.4f %.4f\t", UVRPair[k].userid, UVRPair[k].maxV, UVRPair[k].minV);
						if (k % 10 == 0)
							fprintf(resultFile, "\n");
					}
					fprintf(resultFile, "</influenceRangeVec>\n");

					fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n", uprofileEventGroupSet[i].getMaxNumInfluencedUsers(), uprofileEventGroupSet[i].getMinNumInfluencedUsers());

					//centreP minimalRadius
					SpaceRange sr = uprofileEventGroupSet[i].getSpaceRangecentreP();
					fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", sr.lat, sr.longi, sr.radius);
					float miniRadius = uprofileEventGroupSet[i].GetminimalRadius();
					fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", miniRadius);

					for (int j = 0; j < BucketSize; j++)
					{
						//=======output bucket statistics information================================
						int CurBucketSize = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().size();
						fprintf(resultFile, "<bucketid> %d </bucketid>\n", j);
						fprintf(resultFile, "<BucketSize> %d </BucketSize>\n", CurBucketSize);

						float* bucketcentvec = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
						fprintf(resultFile, "<TopicCentre>\t");
						for (int k = 0; k < TFIDF_DIM; k++) {
							fprintf(resultFile, "%.8f\t", bucketcentvec[k]);
						}
						fprintf(resultFile, "</TopicCentre>\n");

						fprintf(resultFile, "<minAngleCos>\t");
						float bucketminAngleCosV = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getminAngleCos();
						fprintf(resultFile, "%.8f\t", bucketminAngleCosV);
						fprintf(resultFile, "</minAngleCos>\n");

						ValueRangePair bucketTRPair = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getTimeRangePair();
						fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", bucketTRPair.maxV, bucketTRPair.minV);

						vector<UserValueRangePair> bucketUVRPair = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getInfluenceRangeVector();
						int bucketinfluSize = bucketUVRPair.size();
						fprintf(resultFile, "<influenceRangeVec>\t");
						for (int k = 0; k < bucketinfluSize; k++) {
							fprintf(resultFile, "%d %.4f %.4f\t", bucketUVRPair[k].userid, bucketUVRPair[k].maxV, bucketUVRPair[k].minV);
							if (k % 10 == 0)
								fprintf(resultFile, "\n");
						}
						fprintf(resultFile, "</influenceRangeVec>\n");
						fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n",
							uprofileEventGroupSet[i].getUProfileEventGroup()[j].getMaxNumInfluencedUsers(),
							uprofileEventGroupSet[i].getUProfileEventGroup()[j].getMinNumInfluencedUsers());

						//centreP minimalRadius
						SpaceRange sr = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getSpaceRangecentreP();
						fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", sr.lat, sr.longi, sr.radius);
						float bucketminiRadius = uprofileEventGroupSet[i].getUProfileEventGroup()[j].GetminimalRadius();
						fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", bucketminiRadius);
						//finish bucket statistics
					}
				}
					fclose(resultFile);
			}
			Eventclusters.clear();
		}
		fclose(dataSetDescriptor);

		//output the last overall history
		//char FullSlotPartitionFileName[200];
		strcpy_s(FullSlotPartitionFileName, 200, outpath);
		strcat_s(FullSlotPartitionFileName, 200, MTimeSlotFlist);

		strcat_s(FullSlotPartitionFileName, 200, ".UPPWhole");
		//int startClusterno = Eventclusters[0].GetEventNo();
		if (fopen_s(&resultFile, FullSlotPartitionFileName, "a+") == 0)
		{
			for (int i = 0; i < uprofileEventGroupSet.size(); i++)
			{
				printf("i=%d\n", i);
				int BucketSize = uprofileEventGroupSet[i].getUProfileEventGroup().size();
				fprintf(resultFile, "<groupid> %d </groupid>\n", i);
				fprintf(resultFile, "<BucketNum> %d </BucketNum>\n", BucketSize);

				float* centvec = uprofileEventGroupSet[i].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
				fprintf(resultFile, "<TopicCentre>\t");
				for (int k = 0; k < TFIDF_DIM; k++) {
					fprintf(resultFile, "%.8f\t", centvec[k]);
				}
				fprintf(resultFile, "</TopicCentre>\n");

				fprintf(resultFile, "<minAngleCos>\t");
				float minAngleCosV = uprofileEventGroupSet[i].getminAngleCos();
				fprintf(resultFile, "%.8f\t", minAngleCosV);
				fprintf(resultFile, "</minAngleCos>\n");

				ValueRangePair TRPair = uprofileEventGroupSet[i].getTimeRangePair();
				fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", TRPair.maxV, TRPair.minV);

				vector<UserValueRangePair> UVRPair = uprofileEventGroupSet[i].getInfluenceRangeVector();
				int influSize = UVRPair.size();
				fprintf(resultFile, "<influenceRangeVec>\t");
				for (int k = 0; k < influSize; k++) {
					fprintf(resultFile, "%d %.4f %.4f\t", UVRPair[k].userid, UVRPair[k].maxV, UVRPair[k].minV);
					if (k % 10 == 0)
						fprintf(resultFile, "\n");
				}
				fprintf(resultFile, "</influenceRangeVec>\n");

				fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n", uprofileEventGroupSet[i].getMaxNumInfluencedUsers(), uprofileEventGroupSet[i].getMinNumInfluencedUsers());

				//centreP minimalRadius
				SpaceRange sr = uprofileEventGroupSet[i].getSpaceRangecentreP();
				fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", sr.lat, sr.longi, sr.radius);
				float miniRadius = uprofileEventGroupSet[i].GetminimalRadius();
				fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", miniRadius);

				for (int j = 0; j < BucketSize; j++)
				{
					//=======output bucket statistics information================================
					int CurBucketSize = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().size();
					fprintf(resultFile, "<bucketid> %d </bucketid>\n", j);
					fprintf(resultFile, "<BucketSize> %d </BucketSize>\n", CurBucketSize);

					float* bucketcentvec = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
					fprintf(resultFile, "<TopicCentre>\t");
					for (int k = 0; k < TFIDF_DIM; k++) {
						fprintf(resultFile, "%.8f\t", bucketcentvec[k]);
					}
					fprintf(resultFile, "</TopicCentre>\n");

					fprintf(resultFile, "<minAngleCos>\t");
					float bucketminAngleCosV = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getminAngleCos();
					fprintf(resultFile, "%.8f\t", bucketminAngleCosV);
					fprintf(resultFile, "</minAngleCos>\n");

					ValueRangePair bucketTRPair = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getTimeRangePair();
					fprintf(resultFile, "<TimeRangePair> %.8f\t%.8f\t </TimeRangePair>\n", bucketTRPair.maxV, bucketTRPair.minV);

					vector<UserValueRangePair> bucketUVRPair = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getInfluenceRangeVector();
					int bucketinfluSize = bucketUVRPair.size();
					fprintf(resultFile, "<influenceRangeVec>\t");
					for (int k = 0; k < bucketinfluSize; k++) {
						fprintf(resultFile, "%d %.4f %.4f\t", bucketUVRPair[k].userid, bucketUVRPair[k].maxV, bucketUVRPair[k].minV);
						if (k % 10 == 0)
							fprintf(resultFile, "\n");
					}
					fprintf(resultFile, "</influenceRangeVec>\n");
					fprintf(resultFile, "<MaxMinUN>\t %d %d\t </MaxMinUN>\n",
						uprofileEventGroupSet[i].getUProfileEventGroup()[j].getMaxNumInfluencedUsers(),
						uprofileEventGroupSet[i].getUProfileEventGroup()[j].getMinNumInfluencedUsers());

					//centreP minimalRadius
					SpaceRange sr = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getSpaceRangecentreP();
					fprintf(resultFile, "<centreP>\t%.8f\t%.8f\t%.8f\t</centreP>\n", sr.lat, sr.longi, sr.radius);
					float bucketminiRadius = uprofileEventGroupSet[i].getUProfileEventGroup()[j].GetminimalRadius();
					fprintf(resultFile, "<minimalRadius>\t%.8f\t</minimalRadius>\n", bucketminiRadius);
					//finish bucket statistics
				}
				for (int j = 0; j < BucketSize; j++)
				{
					//=======================================
					vector<SubEvent>::iterator iesit = uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().begin();
					while (iesit != uprofileEventGroupSet[i].getUProfileEventGroup()[j].getUProfileEventGroup().end()) {
						fprintf(resultFile, "<clusterid> %d </clusterid>\n", (*iesit).GetEventNo());
						/////////////////////////
						fprintf(resultFile, "<msgcontfidf>\t");
						float* conceptvec = (*iesit).GetCluster_ConceptTFIDFVec();
						for (int k = 0; k < TFIDF_DIM; k++) {
							fprintf(resultFile, "%.8f\t", conceptvec[k]);
						}
						fprintf(resultFile, "</msgcontfidf>\n");
						fprintf(resultFile, "<SpaceRange>\t%.8f\t%.8f\t%.8f\t</SpaceRange>\n", (*iesit).GetSpaceRange().lat, (*iesit).GetSpaceRange().longi, (*iesit).GetSpaceRange().radius);
						fprintf(resultFile, "<TimeRange>\t%.8f\t%.8f\t</TimeRange>\n", (*iesit).GetTimeRange().TimeStampCentre, (*iesit).GetTimeRange().range);

						vector<SpaceRange> srset = (*iesit).getmsgSRset();
						if (!srset.empty())
						{
							fprintf(resultFile, "<SpaceRangeSet>\t");
							for (int k = 0; k < srset.size(); k++) {
								fprintf(resultFile, "%.8f %.8f %.8f\t", srset[k].lat, srset[k].longi, srset[k].radius);
							}
							fprintf(resultFile, "</SpaceRangeSet>\n");
						}

						vector<TimeRange> trset = (*iesit).getmsgTRset();
						if (!trset.empty())
						{
							fprintf(resultFile, "<TimeRangeSet>\t");
							for (int k = 0; k < trset.size(); k++) {
								fprintf(resultFile, "%.8f %.8f\t", trset[k].TimeStampCentre, trset[k].range);
							}
							fprintf(resultFile, "</TimeRangeSet>\n");
						}
						fprintf(resultFile, "<useridlist>\t");
						vector<EUserFrePair> eventuserlist = (*iesit).GetEventUserIDs();
						for (int k = 0; k < eventuserlist.size(); k++) {
							fprintf(resultFile, "%d %d\t", eventuserlist[k].userid, eventuserlist[k].frequency);
						}
						fprintf(resultFile, "</useridlist>\n");
						//////////////////////////
						iesit++;
					}
				}
			}
		}
	}
}

//for format user influence distribution
void ContinuousConstructUID(char* MTimeSlotFlist, char* path, char* outpath, char* ext,	char* UserInfluFilePath)
{
	FILE* dataSetDescriptor = NULL, * resultFile = NULL;
	char FullSlotFileName[300], outFullSlotFileName[300], SlotFileName[300];
		
	//===Event Migration Preloading=============
	EventMigration migrateEvent;
	//loading UserProfileHashMap
	char userinfluenceFile[200];
	//strcpy_s(userinfluenceFile, "UserInfluDictfile.txt");
	strcpy_s(userinfluenceFile, UserInfluFilePath);

	//=============================================
	//for Nepal earthquake dataset
	/*strcat_s(userinfluenceFile, "UserInfluDictfile_Nepal0");
	char WUIPV_str[10];
	_itoa_s(10 * WUIPV, WUIPV_str, _countof(WUIPV_str), 10);
	strcat_s(userinfluenceFile, WUIPV_str);
	strcat_s(userinfluenceFile, "(Training15April-24April).txt");*/

	//for texasFlood dataset
	strcat_s(userinfluenceFile, "UserInfluDictfile_TexasFlood0");
	char WUIPV_str[10];
	_itoa_s(10 * WUIPV, WUIPV_str, _countof(WUIPV_str), 10);
	strcat_s(userinfluenceFile, WUIPV_str);
	strcat_s(userinfluenceFile, "(Training12-21May).txt");/**/
	//=========================================================

	migrateEvent.loadUserProfileHashMap(userinfluenceFile);
	//========================================
	int DocCount = 0;
	if ((fopen_s(&dataSetDescriptor, MTimeSlotFlist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", MTimeSlotFlist);
	}
	else
	{
		while (fscanf_s(dataSetDescriptor, "%s ", SlotFileName, 300) != EOF)
		{   //load data
			strcpy_s(FullSlotFileName, 300, path);
			strcat_s(FullSlotFileName, 300, SlotFileName);
			strcat_s(FullSlotFileName, 300, ext);
			printf("SlotFileName: %s", SlotFileName);

			//===============================
			//update the user influence graph
			//for Nepal earthquake dataset
			/*strcpy_s(userinfluenceFile, UserInfluFilePath);
			strcat_s(userinfluenceFile, "UserInfluDictfile_Nepal0");
			strcat_s(userinfluenceFile, WUIPV_str);
			strcat_s(userinfluenceFile, ".NepalUserProfile(");
			*/

			//for TexasFlood dataset
			strcpy_s(userinfluenceFile, UserInfluFilePath);
			strcat_s(userinfluenceFile, "UserInfluDictfile_TexasFlood0");
			strcat_s(userinfluenceFile, WUIPV_str);
			strcat_s(userinfluenceFile, ".TexasUserProfile(");/**/

			//==========================================

			std::string s(SlotFileName);
			strcat_s(userinfluenceFile, s.substr(13, 13).c_str());
			strcat_s(userinfluenceFile, ").txt");

			migrateEvent.UpdateUserProfileHashMap(userinfluenceFile);
						
			strcpy_s(outFullSlotFileName, 300, outpath);
			strcat_s(outFullSlotFileName, 300, SlotFileName);
			strcat_s(outFullSlotFileName, 300, ".txt");

			ProcessMessageSlot(FullSlotFileName, outFullSlotFileName);		

			DocCount++;
			//if (DocCount > 480)
			//	break;
		}
		fclose(dataSetDescriptor);		
		for (int i = 0; i < UserProfileHashMap.size(); i++) {
			UserProfileHashMap[i].UserInfluenceDistri.clear();
			UserProfileHashMap[i].UserInterestEvents.clear();
			UserProfileHashMap[i].UserResponseNumbers.clear();
		}
		UserProfileHashMap.clear();
	}
}

int ProcessMessageSlot(char* FullSlotFileName, char* outFullSlotFileName)
{
	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	int retweetstatus = 0;

	vector<UPInfluDistriEle> uidvector;
	vector<UPInfluDistriEle>::iterator uidvit, uidvitIn;

	if ((err = fopen_s(&fileDescriptor, FullSlotFileName, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else {
		if ((err = fopen_s(&ResultFileDescriptor, outFullSlotFileName, "a+")) != 0)	{
			printf("ResultFileDescriptor was not open\n");
		}
		else
		{
			while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
				line = buffer;
				strtokenizer strtok(line, " \t\r\n");
				int length = strtok.count_tokens();

				if (length <= 0) {
					printf("Invalid (empty) document!\n");
					fclose(ResultFileDescriptor);
					return 1;
				}

				int i = 0;
				while (i < length){									
					if (strcmp(strtok.token(i).c_str(), "<useridlist>") == 0) 
					{
						fprintf_s(ResultFileDescriptor, "%s ", "<useridlist>"); 
						uidvector.clear();
						
						i++;			
						uidvector.clear(); //clean the uidvector for the current message to use
						float totalInfl = 0;
						while (strcmp(strtok.token(i).c_str(), "</useridlist>") != 0) {
							int userIndex = atoi(strtok.token(i).c_str());
							fprintf_s(ResultFileDescriptor, "%d ", userIndex);

							//construct user influence vector with respect to userIndex
							uidvit = UserProfileHashMap[userIndex].UserInfluenceDistri.begin();
							while (uidvit != UserProfileHashMap[userIndex].UserInfluenceDistri.end()) 
							{
								int user2 = (*uidvit).userid;
								uidvitIn = uidvector.begin();
								int Inserted = 0;
								while (uidvitIn != uidvector.end()) {
									if ((*uidvitIn).userid == user2) {
										(*uidvitIn).userInflu += (*uidvit).userInflu;
										totalInfl += (*uidvit).userInflu;
										Inserted = 1;
										break;
									}
									else if ((*uidvitIn).userid > user2) {
										uidvector.insert(uidvitIn, (*uidvit));
										totalInfl += (*uidvit).userInflu;
										Inserted = 1;
										break;
									}
									else
										uidvitIn++;
								}
								if (!Inserted) {
									uidvector.push_back(*uidvit);
									totalInfl += (*uidvit).userInflu;
								}
																
								uidvit++;
							}
							//===============================
							i++;
						}						
						fprintf_s(ResultFileDescriptor, "%s\t", "</useridlist>");

						//normalize uidvector and output the influence
						uidvitIn = uidvector.begin();
						fprintf_s(ResultFileDescriptor, "%s\t", "<userInfluVec>");
						while (uidvitIn != uidvector.end()) {
							(*uidvitIn).userInflu /= totalInfl;
							fprintf_s(ResultFileDescriptor, "%d %.4f\t", (*uidvitIn).userid,(*uidvitIn).userInflu);
							uidvitIn++;
						}
						fprintf_s(ResultFileDescriptor, "%s\n", "</userInfluVec>");
						uidvector.clear();
						//========================
						i++;
						continue;
					}
					else{
						fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
						i++;
					}
				}				
				////////////////////////////			
			}
			fclose(ResultFileDescriptor);
		}
		fclose(fileDescriptor);
	}

	return 0;
}