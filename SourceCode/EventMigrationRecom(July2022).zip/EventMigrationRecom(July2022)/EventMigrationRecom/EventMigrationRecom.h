#pragma once

#include <iostream>
#include <math.h>
#include <time.h>
#include "SocialMessage.h"
#include "Event.h"
#include "EventMigration.h"
#include "EventRecommendation.h"
#include <string.h> 
#include "strtokenizer.h"
#include <set>
#include "EventRecomOpti.h"

extern void ContinuousEventMigration(char* MTimeSlotFlist, char* path, char* outpath, char* ext, float migrateT, char* UserInfluFilePath);
extern int loadMessageSlotForStreamming(char* FullSlotFileName, vector<SocialMSG>& HashTagedMSGlist,
	vector<SocialMSG>& NonHashTagedMSGlist, int startMSGno);
extern int ReadHashtags(char* HashTags);
extern unsigned hashString(string const& key, unsigned tableSize);

extern void MigrationDetection(vector<SubEvent>& Eventclusters, vector<SubEvent>& Eventcandidates, 
	EventMigration &migrateEvent, float migrateT);

extern void LabelSubclutersWithESimTopK(vector<SubEvent>& Eventclusters, vector<SubEvent>& RelevantEventsPreSlot);
extern void LabelSubclutersWithESimMIGTopK(vector<SubEvent>& Eventclusters, vector<SubEvent>& RelevantEventsPreSlot,
	float migrateT, EventMigration& migrateEvent);
extern void LabelSubclutersWithMIGTopK(vector<SubEvent>& Eventclusters, vector<SubEvent>& RelevantEventsPreSlot,
	float migrateT, EventMigration& migrateEvent);
//for recommendation
extern int loadMigrationEventDetectResult(char* FullSlotFileName, vector<SubEvent> & eventClusters);
extern int loadMigrationEventDetectResultSummary(char* FullSlotFileName, vector<SubEvent>& eventClusters);
extern void ContinuousEventRecommedation(char* MTimeSlotFlist, char* path, char* outpath, char* ext, 
	float migrateT, char* UserInfluFilePath, char* UserInfluFileName, char * userlist, int coupling, char * userProfilePath);

extern int UpdateUPeventList(vector<SubEvent>& incomingEvents, int AddorDel, int DeleteNum); //put the current slot events into the list, remove the expired ones
extern void GenerateVisualUserProfileEventsForRecTestNew(char* MTimeSlotFlist, char* path, char* outpath, char* ext, char* UserInfluFilePath);


//=======for parallel processing
extern void UserProfileAllocation(char* MTimeSlotFlist, char* path, char* outpath, char* userlist, char* userProfilePath, char* UserInfluFilePath, char* UserInfluFileName);
extern void UserProfileAllocationContentUser(char* MTimeSlotFlist, char* path, char* outpath, char* userlist, char* userProfilePath, char* UserInfluFilePath, char* UserInfluFileName);
extern void UserProfileQueryGeneration(char* MTimeSlotFlist, char* HistoryPartition, char* path, char* partitionPath, char* outpath, char* userlist, char* userProfilePath, char* UserInfluFilePath, char* UserInfluFileName);
extern void LoadHistPartitions(char* FullSlotPartitionFileName, std::vector<UPEventPartition>& uprofileEventGroupSet);

extern void UserProfileAllocationHP(char* MTimeSlotFlist, char* path, char* outpath, char* userlist, char* userProfilePath, char* UserInfluFilePath, char* UserInfluFileName);

extern void ContinuousConstructUID(char* MTimeSlotFlist, char* path, char* outpath, char* ext, char* UserInfluFilePath);
extern int ProcessMessageSlot(char* FullSlotFileName, char* outFullSlotFileName);

extern int ReadGTMsg(char* GTmsgs, set<long long int>& GTNonGTset);
extern void NormalizeTFIDF(char* MTimeSlotFlist, char* path, char* outpath);
extern void NormalizeMigrationEventDetectResultSummary(char* inputFileName, char* outputFileName);


