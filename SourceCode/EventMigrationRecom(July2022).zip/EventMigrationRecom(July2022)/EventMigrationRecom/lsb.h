#ifndef __LSB
#define __LSB

#include <memory.h>
#include <stdio.h>
#include <errno.h>
#include "GlobalStructureVar.h"

class LSB
{
public:
	//--=== on disk ===--
	int			t;								/* largest coordinate of a dimension */
	int			d;								/* dimensionality */
	int			n;								/* cardinality */
	int			B;								/* page size in words */
	int			ratio;							/* approximation ratio */

	//--=== debug ==--
	int			quiet;
	bool		emergency;

	//--=== others ===--
	
	char		dsPath[100];					/* folder containing the dataset file */
	char		dsName[100];					/* dataset file name */
	char		forestPath[100];				/* folder containing the forest */

	int			f;
	int			pz;								/* number of pages to store the Z-value of a point */
	int			L;								/* number of lsb-trees */
	int			m;								/* dimensionality of the hash space */
	int			qNumTrees;						/* number of lsb-trees used to answer a query */
	int			u;								/* log_2 (U/w) */

	float		* a_array;												
	float		* b_array;						/* each lsb-tree requires m hash functions, and each has function
												   requires a d-dimensional vector a and a 1d value b. so a_array contains 
												   l * m * d values totally and b_array contains l *m values */

	float		U;								/* each dimension of the hash space has domain [-U/2, U/2] */
	float		w;
		
//	LSBtreePtr *trees;							/* lsbtrees */

	//--=== Functions ===--
	LSB();
	~LSB();

	//--=== internal ===--
	virtual void	freadNextEntry		(FILE *_fp, int * _son, int * _key);		
	virtual void	gen_vectors			();									
	virtual void	getHashVector		(int _tableID, float *_key, float *_g);
	virtual void	getHashPara			(int _u, int _v, float **_a_vector, float *_b);
	virtual float	get1HashV			(int _u, int _v, float *_key);
	virtual float	get1HashV2Influ(int _u, int _v, vector<UPInfluDistriEle> _key);
	virtual int		getZ				(float *_g, int *_z);
	virtual	int		getLowestCommonLevel(int *_z1, int *_z2);
	virtual int		get_m				(int _r, float _w, int _n, int _B, int _d);
	virtual double	get_rho				(int _r, float _w);					
	virtual int		get_obj_size		(int _dim);							
	virtual int		get_u				();										
	virtual int		insert				(int _treeID, int _son, float * _key);
	virtual int		readParaFile		(char *_fname);
	virtual int		writeParaFile		(char *_fname);

	//--=== external ===--
	virtual int		buildFromFile		(char *_dsPath, char *_forestPath);
	virtual int		bulkload			(char *_dspath, char *_forestPath);
	virtual void	init				(int _t, int _d, int _n, int _B, int _L, int _ratio);	
};

struct LSBqsortElem
{
	int	* ds;
	int	pos;		/* position of the object in array ds */
	int	pz;			/* size of the z array below */
	int * z;
};



#endif