﻿#pragma once

#include "GlobalStructureVar.h"

class SocialMSG {
private:
	unsigned long long int retweetedStatus; // if this message is retweeted one, retweetedStatus is its source msgID. Otherwise, it is 0.
	unsigned long long int msgID;
	TimeRange TR;
	SpaceRange SR;  

	float ConceptTFIDFVec[TFIDF_DIM];
	vector<EUserFrePair> EventUserIDsFre;  // a number of user-event interaction recorders, here users are those attached with this message
	
public:
	int hashtaged;  //for keep record on if it is hashtag
	vector<string> HashtagList;  //a number of hashtags attached with this message

	SocialMSG() {		
	}
	
	SocialMSG(unsigned long long int retweetedNo, float* vec, TimeRange tr, SpaceRange sr, std::vector<EUserFrePair> euids) {
		for (int i = 0; i < TFIDF_DIM; i++) {
			ConceptTFIDFVec[i] = vec[i];
		}
		retweetedStatus = retweetedNo;
		TR.TimeStampCentre = tr.TimeStampCentre;
		TR.range = tr.range;
		SR.lat = sr.lat;
		SR.longi = sr.longi;
		SR.radius = sr.radius;
		hashtaged = 0;
		msgID = 0;

		std::vector<EUserFrePair>::iterator eit = euids.begin();
		while (eit != euids.end()) {
			EventUserIDsFre.push_back(*eit);
			eit++;			
		}
	}

	void setMSGID(unsigned long long int mid) {
		msgID = mid;
	}
	unsigned long long int getMSGID() {
		return msgID;
	}
	unsigned long long int getRetweetStatus() {
		return retweetedStatus;
	}
	vector<EUserFrePair>& getEventUserIDsFre() {
		return EventUserIDsFre;
	}
	
	float* getConceptTFIDFVec() { return ConceptTFIDFVec; }

	TimeRange getTimeRange() { return TR; }
	SpaceRange getSpaceRange() { return SR; }

	float CVModule() {
		float ret = 0;
		for (int i = 0; i < TFIDF_DIM; i++) {
			ret += this->ConceptTFIDFVec[i] * this->ConceptTFIDFVec[i];
		}
		return sqrt(ret);
	}

	void cleanMSG() {
		EventUserIDsFre.clear();
		HashtagList.clear();
	}
	
	float GetConceptSimilarity(SocialMSG* smsg) {
		float simi = 0;
		for (int i = 0; i < TFIDF_DIM; i++) {
			simi += smsg->ConceptTFIDFVec[i] * ConceptTFIDFVec[i];
		}
		float thisModule = this->CVModule();
		float smsgModule = smsg->CVModule();
		simi /= thisModule;
		simi /= smsgModule;

		return simi;
	}

	float GetTimeSimilarity(SocialMSG* smsg) {
		float Tsim;

		SocialMSG* maxPtr, * minPtr;
		if (this->TR.TimeStampCentre >= smsg->TR.TimeStampCentre) {
			maxPtr = this;
			minPtr = smsg;
		}
		else
		{
			maxPtr = smsg;
			minPtr = this;
		}

		if (maxPtr->TR.TimeStampCentre - minPtr->TR.TimeStampCentre >= 2 * maxPtr->TR.range)
			Tsim = 0;
		else {
			float intersectT = (minPtr->TR.TimeStampCentre + minPtr->TR.range) - (maxPtr->TR.TimeStampCentre - maxPtr->TR.range);
			float unionT = (maxPtr->TR.TimeStampCentre + maxPtr->TR.range) - (minPtr->TR.TimeStampCentre - minPtr->TR.range);
			Tsim = intersectT / unionT;
		}

		return Tsim;
	}

	float GetSpaceSimilarity(SocialMSG* smsg) {
		float Ssim;	

		double GreatCircleDist = get_distance(this->SR.lat, this->SR.longi, smsg->SR.lat, smsg->SR.longi);
		Ssim = 1 - GreatCircleDist / 500;  //put 500 first, default, it can be the maximal Great Circle distance between two locations in dataset

		if (Ssim < 0)
			Ssim = 0;

		return Ssim;
	}

	float GetGlobalSimilarity(SocialMSG* smsg) {
		float Gsim = 0;

		switch (MethodChoice) {
		case 1:
			Gsim = GetConceptSimilarity(smsg);
			break;
		case 2:
			Gsim = GetTimeSimilarity(smsg);
			break;
		case 3:
			Gsim = GetSpaceSimilarity(smsg);
			break;
		case 4:
			Gsim = GetConceptSimilarity(smsg) * GetTimeSimilarity(smsg);
			break;
		case 5:
			Gsim = GetConceptSimilarity(smsg) * GetSpaceSimilarity(smsg);
			break;
		case 6:
			Gsim = omeg1*GetConceptSimilarity(smsg) + omeg2* GetTimeSimilarity(smsg)+(1-omeg1-omeg2)* GetSpaceSimilarity(smsg);
			break;
		default:
			Gsim = GetConceptSimilarity(smsg) * GetTimeSimilarity(smsg) * GetSpaceSimilarity(smsg);
		}

		return Gsim;
	}
	//===Great-circle distance==========
	double rad(float d) {
		return d * PI / 180.0;
	}
	
	double round(double d) {
		return floor(d + 0.5);
	}

	double get_distance(double lat1, double lng1, double lat2, double lng2)
	{
		double radLat1 = rad(lat1);
		double radLat2 = rad(lat2);
		double a = radLat1 - radLat2;
		double b = rad(lng1) - rad(lng2);
		double s = 2 * asin(sqrt(pow(sin(a / 2), 2) + cos(radLat1) * cos(radLat2) * pow(sin(b / 2), 2)));
		s = s * EARTH_RADIUS;
		s = round(s * 10000) / 10000;
		return s;
	}

	//for EventRecomOpti.cpp
	float GetConceptVectorSimilarity(float* con1, float* con2) {
		float simi = 0;
		for (int i = 0; i < TFIDF_DIM; i++) {
			simi += con1[i] * con2[i];
		}
		float thisModule = 0;
		for (int i = 0; i < TFIDF_DIM; i++) {
			thisModule += con1[i] * con1[i];
		}
		thisModule = sqrt(thisModule);

		float smsgModule = 0;
		for (int i = 0; i < TFIDF_DIM; i++) {
			smsgModule += con2[i] * con2[i];
		}
		smsgModule = sqrt(smsgModule);

		simi /= thisModule;
		simi /= smsgModule;

		return simi;
	}
	
	///////////////////////////////

	~SocialMSG()
	{		
		EventUserIDsFre.clear();
		HashtagList.clear();
	}
};