﻿#pragma once
#include <vector>
#include <iterator>
#include <algorithm> 
#include <set>
#include <iostream>
#include <math.h> 
#include <string>
#include <ctime>
using namespace std;

#define PI 3.14159265358979
#define EARTH_RADIUS 6378.137 //地球半径
#define EARTH_Half_CIRCUMFERENCE 20037.5 //地球半周长
#define BUFFERSIZE 60000//50000
#define USERLEN 100
#define MSGLEN 200
//#define MVALUE 10//5 //the number of hash functions, 5 for TFIDF vectors, 5 for user influence vectors
#define MVALUE 12//the number of hash functions, 6 for TFIDF vectors, 6 for user influence vectors

#define MAXFLOAT FLT_MAX//5256000 //minutes for one year
#define MINFLOAT FLT_MIN
#define MAXINT INT_MAX
#define MININT INT_MIN
//#define ELIPSE 0.8  //social message similarity threshold, can be variable.
#define INFLUENCETHRE 0.300000001 //user influence threshold
#define ROWSV 400//670  //for c[ROWSV+1][ROWSV+1]
#define CONVEC_DIM 2  //location cluster number for partition
#define NUMOfGROUPS 10 //6// group cluster number for partition

#define TUNUM 135783//14978//20//10000 //total number of users in nepal training dataset
//#define TUNUM 64240 //total number of users in Texas Flood training dataset
//#define WUIPV 0.7   
#define HTSize 5000//1000//50000
#define FNAMEBUFSIZE 400

const int TFIDF_DIM = 50;//160; //30000;//Top TFIDF_DIM 4-grams will be selected for one time slot
const int TPNUM = 720; //one month, 720 1-hour periods
const int TFIDF_KEYDIM = 5;
//const int KeyDim[25] = { 3, 12, 2, 0, 5, 11, 44, 15, 6, 7, 1,8,9,40,38,21,30,26,39,46,16,19,42,18,31};
const int KeyDim[TFIDF_KEYDIM] = { 0, 2,  1,  7, 30};

extern float SPACERADIUST;// = 20;
extern float TIMERADIUST;// = 30;
extern float ELIPSE;  //social message similarity threshold, can be variable. Get value from main parameter list
extern float omeg1; //concept net weight
extern float omeg2; //time weight, then the weight of location is 1-omeg1-omeg2
extern int MethodChoice;
extern float WUIPV;
extern int TOPK;
extern vector<int> TimePeriodLastClusterNoList;
struct strFre {
	string token;
	int frequency;
};

struct EUserFrePair
{
	int userid;

	/*the number of comments, ...for a user interacting with a sub-event or a message 
	in his history user profile--use training data to get this*/
	int frequency; 					
};

struct TimeRange
{
	float TimeStampCentre;   //time stamp: change date-time into int, we use float to fit the composite time point
	float range;  //the uncertainty threshold range \tau with time stamp 
};

struct SpaceRange
{
	float lat;
	float longi;
	float radius;
};

struct EventUserSimi {
	int userid;
	float simi;
};


struct UPInfluDistriEle
{
	int userid;
	float userInflu; //the ratio of comments, ...for a user interacting with other users--use training data to get this
};

struct UPRespnseEle
{
	int userid;
	int userResponse; //the number of response, ...for a user interacting with other users--use training data to get this
				   //ith element is the number of userID's messages followed by ith user in the training dataset.
};

struct NewURespnEle
{
	int startUid;
	int endUid;
	int userResponse;
};

struct EventNoSimiPair {
	int eventNo;
	int migEno;
	float simi;
};

struct EventPoint {
	float point[TFIDF_DIM];
	float DomiVar;
};
struct DimHashKeyPair {
	int dim;
	int HashKey;
};