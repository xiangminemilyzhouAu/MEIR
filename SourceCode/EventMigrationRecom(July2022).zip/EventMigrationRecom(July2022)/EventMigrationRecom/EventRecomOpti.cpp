﻿
#include "EventRecomOpti.h"

void EventRecomOpti::UserProfileDataPartitionContentUser(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
	std::vector<UPEventPartition>& UProfileEventGroupSets, LSB& lsb, LSB & lsbuser, SocialEventOperation& seoper)
{
	MapEvent2VecContentUser(UProfileEventSet, lsb,lsbuser);

	std::vector<UPEventBucket> UProfileEventBuckets;

	ConflictEvents2Buckets(UProfileEventSet, UProfileEventBuckets, lsb, seoper);

	AllocateBucketsofGroups2Processors(UProfileEventBuckets, NumOfGroups, UProfileEventGroupSets, lsb, seoper);

	for (int i = 0; i < UProfileEventGroupSets.size(); i++)
		ProduceDataPartitionSummary(UProfileEventGroupSets[i]);

	UProfileEventBuckets.clear();
}

void EventRecomOpti::UserProfileDataPartition(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
	std::vector<UPEventPartition>& UProfileEventGroupSets, LSB &lsb, SocialEventOperation &seoper)
{
	MapEvent2Vec(UProfileEventSet,lsb);	

	std::vector<UPEventBucket> UProfileEventBuckets;
	
	ConflictEvents2Buckets(UProfileEventSet, UProfileEventBuckets,lsb,seoper);

	//===========
	vector<SubEvent> TFIDFCenters, tmpTFIDFCenters;
	float TopicVectoCentre[TFIDF_DIM];
	int bucketNum = UProfileEventBuckets.size();
	tmpTFIDFCenters.resize(bucketNum);
	
	for (int i = 0; i < bucketNum; i++) {
		ComputeTopicCentre(UProfileEventBuckets[i], TopicVectoCentre);
		tmpTFIDFCenters[i].setConceptTFIDFVec(TopicVectoCentre);
		UProfileEventBuckets[i].setTFIDFCenter(tmpTFIDFCenters[i]);
		ProduceEventBucketSummary(UProfileEventBuckets[i]);
		float minangleCos = ComputeMinAngleCos(UProfileEventBuckets[i], tmpTFIDFCenters[i]);
		UProfileEventBuckets[i].setminAngleCos(minangleCos);
	}

	vector<UPEventBucket> subsets;
	float SimiT = 0.8;
	vector<UPEventBucket>::iterator bit = UProfileEventBuckets.begin();	
	int offset = 0;
	while (bit != UProfileEventBuckets.end()) {
		float minangleCos = (*bit).getminAngleCos();
		if (minangleCos < 0.8) {//split bucket
			subsets.clear();
			onePassClustering((*bit).getUProfileEventGroup(), SimiT, subsets);
			if (subsets.size() > 1) {
				for (int i = 0; i < subsets.size(); i++) {
					ComputeTopicCentre(subsets[i], TopicVectoCentre);
					tmpTFIDFCenters[i].setConceptTFIDFVec(TopicVectoCentre);
					subsets[i].setTFIDFCenter(tmpTFIDFCenters[i]);
					ProduceEventBucketSummary(subsets[i]);
					float minangleCos = ComputeMinAngleCos(subsets[i], tmpTFIDFCenters[i]);
					subsets[i].setminAngleCos(minangleCos);
					UProfileEventBuckets.push_back(*(subsets.begin() + i));
				}

				subsets.clear();
				bit = UProfileEventBuckets.begin() + offset;
				UProfileEventBuckets.erase(bit);
				bit = UProfileEventBuckets.begin() + offset;
				continue;
			}
		}
		bit++;
		offset++;
		//cout << offset << endl;
	}
	//=============
	UnionLSHBucketsBySimilarity(UProfileEventBuckets, SimiT);
	AllocateBucketsofGroups2Processors(UProfileEventBuckets, NumOfGroups, UProfileEventGroupSets, lsb, seoper);  
	//====================	
	TFIDFCenters.resize(NumOfGroups);
	for (int i = 0; i < NumOfGroups; i++) {
		ComputeTopicCentrePartition(UProfileEventGroupSets[i].getUProfileEventGroup(), TopicVectoCentre);
		TFIDFCenters[i].setConceptTFIDFVec(TopicVectoCentre);
		UProfileEventGroupSets[i].setTFIDFCenter(TFIDFCenters[i]);
		ProduceDataPartitionSummary(UProfileEventGroupSets[i]);
		float minangleCos = ComputePartitionMinAngleCos(UProfileEventGroupSets[i], TFIDFCenters[i]);
		UProfileEventGroupSets[i].setminAngleCos(minangleCos);		
	}	
	TFIDFCenters.clear();
	tmpTFIDFCenters.clear();
	subsets.clear();
	/*for(int i=0;i<UProfileEventGroupSets.size();i++)
		ProduceDataPartitionSummary(UProfileEventGroupSets[i]);
		*/
	UProfileEventBuckets.clear();
}
void EventRecomOpti::UnionLSHBucketsBySimilarity(std::vector<UPEventBucket>& UPEBuckets, float simiThreshold)
{
	//select the first bucket for the first processor 
	std::vector<UPEventBucket>::iterator upebit, upebitInner, FirstProBit, SecondProBit;
	float maxSimi = 0;
	
	int loop = 1;
	int offsetOut = 0;
	int offsetIn = 0;
	float earlyStopThre = 0.95;
	while (loop) {
		//output for monitoring
		//find the closest buckets with commKeyNum>conflictKeyNumThre
		maxSimi = 0;
		upebit = UPEBuckets.begin();
		offsetOut = 0;
		while (upebit != UPEBuckets.end()) {
			upebitInner = upebit;
			offsetIn = offsetOut + 1;
			upebitInner++;
			while (upebitInner != UPEBuckets.end()) {
				float minanlgleCosV = ComputeBucketUnionMinAngleCos((*upebit), (*upebitInner));
				if (minanlgleCosV > maxSimi) {
					maxSimi = minanlgleCosV;
					FirstProBit = upebit;
					SecondProBit = upebitInner;
				}
				//stop early to save the cost
				if (maxSimi >= earlyStopThre) {
					int sizeSPB = (*SecondProBit).getUProfileEventGroup().size();
					for (int i = 0; i < sizeSPB; i++)
						(*FirstProBit).setUProfileEventGroup((*SecondProBit).getUProfileEventGroup()[i]);
										
					UPEBuckets.erase(SecondProBit);
					float TopicVectoCentre[TFIDF_DIM];
					SubEvent tmpTFIDFCenters;
					ComputeTopicCentre((*FirstProBit), TopicVectoCentre);
					tmpTFIDFCenters.setConceptTFIDFVec(TopicVectoCentre);
					(*FirstProBit).setTFIDFCenter(tmpTFIDFCenters);
					ProduceEventBucketSummary(*FirstProBit);
					float minangleCos = ComputeMinAngleCos(*FirstProBit, tmpTFIDFCenters);
					(*FirstProBit).setminAngleCos(minangleCos);
					//reset
					upebitInner = UPEBuckets.begin() + offsetIn;
					maxSimi = 0;
					SecondProBit = upebitInner;
					continue;
				}
				upebitInner++;
				offsetIn++;
			}
			offsetOut++;
			upebit++;
		}
		if (maxSimi < simiThreshold)
			loop = 0;
		else {
			int sizeSPB = (*SecondProBit).getUProfileEventGroup().size();
			for (int i = 0; i < sizeSPB; i++)
				(*FirstProBit).setUProfileEventGroup((*SecondProBit).getUProfileEventGroup()[i]);

			UPEBuckets.erase(SecondProBit);
			float TopicVectoCentre[TFIDF_DIM];
			SubEvent tmpTFIDFCenters;
			ComputeTopicCentre((*FirstProBit), TopicVectoCentre);
			tmpTFIDFCenters.setConceptTFIDFVec(TopicVectoCentre);
			(*FirstProBit).setTFIDFCenter(tmpTFIDFCenters);
			ProduceEventBucketSummary(*FirstProBit);
			float minangleCos = ComputeMinAngleCos(*FirstProBit, tmpTFIDFCenters);
			(*FirstProBit).setminAngleCos(minangleCos);
			if (earlyStopThre > simiThreshold + 0.05)
				earlyStopThre = earlyStopThre - 0.05;
			else
				earlyStopThre = simiThreshold;
		}
	}
}
void EventRecomOpti::ContinuousUserProfileDataPartition(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
	std::vector<UPEventPartition>& UProfileEventGroupSets, LSB& lsb, SocialEventOperation& seoper)
{
	MapEvent2Vec(UProfileEventSet, lsb);

	std::vector<UPEventBucket> UProfileEventBuckets;

	ConflictEvents2Buckets(UProfileEventSet, UProfileEventBuckets, lsb, seoper);
	//===========
	vector<SubEvent> TFIDFCenters, tmpTFIDFCenters;
	float TopicVectoCentre[TFIDF_DIM];
	int bucketNum = UProfileEventBuckets.size();
	tmpTFIDFCenters.resize(bucketNum);
	for (int i = 0; i < bucketNum; i++) {
		ComputeTopicCentre(UProfileEventBuckets[i], TopicVectoCentre);
		tmpTFIDFCenters[i].setConceptTFIDFVec(TopicVectoCentre);
		UProfileEventBuckets[i].setTFIDFCenter(tmpTFIDFCenters[i]);
		ProduceEventBucketSummary(UProfileEventBuckets[i]);
		float minangleCos = ComputeMinAngleCos(UProfileEventBuckets[i], tmpTFIDFCenters[i]);
		UProfileEventBuckets[i].setminAngleCos(minangleCos);
		/*if (minangleCos < 0.8)
			cout << "bucket " << i << ": " << minangleCos << "Size: " << UProfileEventBuckets[i].getUProfileEventGroup().size()
			<< "\t commonDim: " << UProfileEventBuckets[i].commonHashDimSet.size() << endl;*/
	}
	//=============
	vector<UPEventBucket> subsets;
	float SimiT = 0.8;
	vector<UPEventBucket>::iterator bit = UProfileEventBuckets.begin();
	int offset = 0;
	while (bit != UProfileEventBuckets.end()) {
		float minangleCos = (*bit).getminAngleCos();
		if (minangleCos < 0.8) {//split bucket
			subsets.clear();
			onePassClustering((*bit).getUProfileEventGroup(), SimiT, subsets);
			if (subsets.size() > 1) {
				for (int i = 0; i < subsets.size(); i++) {
					ComputeTopicCentre(subsets[i], TopicVectoCentre);
					tmpTFIDFCenters[i].setConceptTFIDFVec(TopicVectoCentre);
					subsets[i].setTFIDFCenter(tmpTFIDFCenters[i]);
					ProduceEventBucketSummary(subsets[i]);
					float minangleCos = ComputeMinAngleCos(subsets[i], tmpTFIDFCenters[i]);
					subsets[i].setminAngleCos(minangleCos);
					UProfileEventBuckets.push_back(*(subsets.begin() + i));
				}
				subsets.clear();
				bit = UProfileEventBuckets.begin() + offset;
				UProfileEventBuckets.erase(bit);
				bit = UProfileEventBuckets.begin() + offset;
				continue;
			}
		}
		bit++;
		offset++;
	}
	//=============
	UnionLSHBucketsBySimilarity(UProfileEventBuckets, SimiT);
	ContinuousAllocateBucketsofGroups2Processors(UProfileEventBuckets, NumOfGroups, UProfileEventGroupSets, lsb, seoper);

	//====================	
	TFIDFCenters.resize(NumOfGroups);
	for (int i = 0; i < NumOfGroups; i++) {
		ComputeTopicCentrePartition(UProfileEventGroupSets[i].getUProfileEventGroup(), TopicVectoCentre);
		TFIDFCenters[i].setConceptTFIDFVec(TopicVectoCentre);
		UProfileEventGroupSets[i].setTFIDFCenter(TFIDFCenters[i]);
		ProduceDataPartitionSummary(UProfileEventGroupSets[i]);
		float minangleCos = ComputePartitionMinAngleCos(UProfileEventGroupSets[i], TFIDFCenters[i]);
		UProfileEventGroupSets[i].setminAngleCos(minangleCos);
	}
	TFIDFCenters.clear();
	tmpTFIDFCenters.clear();
	subsets.clear();
	/*for (int i = 0; i < UProfileEventGroupSets.size(); i++)
		ProduceDataPartitionSummary(UProfileEventGroupSets[i]);*/
	UProfileEventBuckets.clear();
}

float EventRecomOpti::ComputeMinAngleCos(UPEventBucket& UProfileEventBucket, SubEvent &TFIDFCenters) {
	float minangleCos = 1.0;
	vector<SubEvent>::iterator ssit = UProfileEventBucket.getUProfileEventGroup().begin();
	while (ssit != UProfileEventBucket.getUProfileEventGroup().end()) {
		float cosVal = (*ssit).GetConceptSimilarity(&TFIDFCenters);
		if (cosVal < minangleCos)
			minangleCos = cosVal;
		//=============
		ssit++;
	}
	return minangleCos;
}

float EventRecomOpti::ComputePartitionMinAngleCos(UPEventPartition& UProfileEventPartition, SubEvent& TFIDFCenters) {
	float minangleCos = 1.0;
	int bucketNum = UProfileEventPartition.getUProfileEventGroup().size();
	for (int i = 0; i < bucketNum; i++) {
		vector<SubEvent>::iterator ssit = UProfileEventPartition.getUProfileEventGroup()[i].getUProfileEventGroup().begin();
		vector<SubEvent>::iterator ssitEnd = UProfileEventPartition.getUProfileEventGroup()[i].getUProfileEventGroup().end();
		while (ssit != ssitEnd) {
			float cosVal = (*ssit).GetConceptSimilarity(&TFIDFCenters);
			if (cosVal < minangleCos)
				minangleCos = cosVal;
			//=============
			ssit++;
		}
	}
	return minangleCos;
}
void EventRecomOpti::ComputeAngleVector(SubEvent& eventV, float TopicVectorAngle[]) {
	float* convec = eventV.GetCluster_ConceptTFIDFVec();
	for (int i = 0; i < TFIDF_DIM - 1; i++) {
		float phi_i = 0;
		if (convec[i] == 0) {
			phi_i = PI * 0.5;//PI*90/180;
		}
		else {
			float tanPhi_i = 0;
			for (int j = i + 1; j < TFIDF_DIM - 1; j++)
				tanPhi_i += pow(convec[j], 2);
			tanPhi_i = sqrt(tanPhi_i) / convec[i];
			phi_i = atan(tanPhi_i);
		}
		TopicVectorAngle[i] = phi_i;
	}
}

void EventRecomOpti::ReadMaxMinDimValues(char* FileName, float MaxValues[], float MinValues[]) {
	FILE* fileDescriptor = NULL;
	char buffer[BUFFERSIZE];
		
	string line;
	int dimNo = 0;
	if ((fopen_s(&fileDescriptor, FileName, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FileName);
	}
	else
	{
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) line!\n");
				return;
			}

			MaxValues[dimNo] = atof(strtok.token(1).c_str());
			MinValues[dimNo] = atof(strtok.token(3).c_str());
			dimNo++;
		}
		fclose(fileDescriptor);
	}
}

void EventRecomOpti::ConflictEvents2BucketsDimHash(std::vector<SubEvent>& UProfileEventSet,
	std::vector<UPEventBucket>& UPEventBuckets, int conflictKeyNum)
{
	std::vector<SubEvent>::iterator upesit = UProfileEventSet.begin();
	while (upesit != UProfileEventSet.end()) {
		int offset = 0;
		int maxConflictNum = 0;
		int count = 0;
		std::vector<UPEventBucket>::iterator upebit = UPEventBuckets.begin();
		while (upebit != UPEventBuckets.end()) {//count the conflict number
			int commKeyNum = (*upebit).commonHashDimSet.size();
			int minConflictNum = commKeyNum;
			for (int i = 0; i < commKeyNum; i++) {
				if ((*upebit).commonHashDimSet[i].HashKey != (*upesit).EDIMHashV[(*upebit).commonHashDimSet[i].dim].HashKey)//found
					minConflictNum--;
			}	
			if (minConflictNum > maxConflictNum) {
				maxConflictNum = minConflictNum;
				offset = count;
			}
			count++;
			upebit++;
		}
		if (maxConflictNum >= conflictKeyNum){ // find the conflict bucket, put the event into the bucket		
			upebit = UPEventBuckets.begin() + offset;
			(*upebit).setUProfileEventGroup(*upesit);
			//remove the uncommon hash dim pair from (*upebit).commonHashDimSet
			vector<DimHashKeyPair>::iterator dkit = (*upebit).commonHashDimSet.begin();
			int offset1 = 0;
			while (dkit != (*upebit).commonHashDimSet.end()) {
				if ((*dkit).HashKey != (*upesit).EDIMHashV[(*dkit).dim].HashKey) {
					(*upebit).commonHashDimSet.erase(dkit);
					dkit = (*upebit).commonHashDimSet.begin() + offset1;
					continue;
				}
				dkit++;
				offset1++;
			}			
		}
		else{
			UPEventBucket curEPar;
			curEPar.setUProfileEventGroup(*upesit);	
			for (int i = 0; i < TFIDF_DIM; i++)
				curEPar.commonHashDimSet[i].HashKey = (*upesit).EDIMHashV[i].HashKey;
			UPEventBuckets.push_back(curEPar);			
		}
		upesit++;
	}
}


float EventRecomOpti::ComputeUnionMinAngleCos(UPEventBucket& UProfileEventBucketF, vector<UPEventBucket>& UProfileEventBucketS) {
	float minangleCos = 1.0;
	SubEvent TFIDFCenters;
	float TopicVectoCentre[TFIDF_DIM] = { 0 };

	float* vecF = UProfileEventBucketF.getTFIDFCenter().GetCluster_ConceptTFIDFVec();
	int sizeF= UProfileEventBucketF.getUProfileEventGroup().size();
	int sizeS= 0;
	for (int i = 0; i < TFIDF_DIM; i++) {
		//TopicVectoCentre[i] = (vecF[i] * sizeF + vecS[i] * sizeS) / (sizeF + sizeS);
		TopicVectoCentre[i] = vecF[i] * sizeF;
	}
	int BucketNum = UProfileEventBucketS.size();
	for (int i = 0; i < BucketNum; i++) {
		float* vecS = UProfileEventBucketS[i].getTFIDFCenter().GetCluster_ConceptTFIDFVec();
		int CurSizeS=UProfileEventBucketS[i].getUProfileEventGroup().size();
		sizeS += CurSizeS;
		for (int j = 0; j < TFIDF_DIM; j++) {
			TopicVectoCentre[j] += vecS[j] * CurSizeS;
		}
	}
	for (int i = 0; i < TFIDF_DIM; i++) {
		TopicVectoCentre[i] /= (sizeF + sizeS);
	}

	TFIDFCenters.setConceptTFIDFVec(TopicVectoCentre);

	vector<SubEvent>::iterator ssit = UProfileEventBucketF.getUProfileEventGroup().begin();
	while (ssit != UProfileEventBucketF.getUProfileEventGroup().end()) {
		float cosVal = (*ssit).GetConceptSimilarity(&TFIDFCenters);
		if (cosVal < minangleCos)
			minangleCos = cosVal;
		//=============
		ssit++;
	}
	for (int i = 0; i < BucketNum; i++) {
		ssit = UProfileEventBucketS[i].getUProfileEventGroup().begin();
		while (ssit != UProfileEventBucketS[i].getUProfileEventGroup().end()) {
			float cosVal = (*ssit).GetConceptSimilarity(&TFIDFCenters);
			if (cosVal < minangleCos)
				minangleCos = cosVal;
			//=============
			ssit++;
		}
	}
	return minangleCos;
}

float EventRecomOpti::ComputeBucketUnionMinAngleCos(UPEventBucket& UProfileEventBucketF, UPEventBucket& UProfileEventBucketS) {
	float minangleCos = 1.0;
	SubEvent TFIDFCenters;
	float TopicVectoCentre[TFIDF_DIM] = { 0 };

	float* vecF = UProfileEventBucketF.getTFIDFCenter().GetCluster_ConceptTFIDFVec();
	float* vecS= UProfileEventBucketS.getTFIDFCenter().GetCluster_ConceptTFIDFVec();
	int sizeF = UProfileEventBucketF.getUProfileEventGroup().size();
	int sizeS = UProfileEventBucketS.getUProfileEventGroup().size();
	for (int i = 0; i < TFIDF_DIM; i++) 
		TopicVectoCentre[i] = (vecF[i] * sizeF + vecS[i] * sizeS) / (sizeF + sizeS);
	
	TFIDFCenters.setConceptTFIDFVec(TopicVectoCentre);

	vector<SubEvent>::iterator ssit = UProfileEventBucketF.getUProfileEventGroup().begin();
	while (ssit != UProfileEventBucketF.getUProfileEventGroup().end()) {
		float cosVal = (*ssit).GetConceptSimilarity(&TFIDFCenters);
		if (cosVal < minangleCos)
			minangleCos = cosVal;
		//=============
		ssit++;
	}
	
	ssit = UProfileEventBucketS.getUProfileEventGroup().begin();
	while (ssit != UProfileEventBucketS.getUProfileEventGroup().end()) {
		float cosVal = (*ssit).GetConceptSimilarity(&TFIDFCenters);
		if (cosVal < minangleCos)
			minangleCos = cosVal;
		//=============
		ssit++;
	}
	
	return minangleCos;
}

int EventRecomOpti::ComputeCommonHashKeyDim(UPEventBucket& UProfileEventBucketF, UPEventBucket& UProfileEventBucketS) {
	int commHashKeyNum = 0;
	
	vector<DimHashKeyPair>::iterator ssit = UProfileEventBucketF.commonHashDimSet.begin();
	vector<DimHashKeyPair>::iterator ssitIn = UProfileEventBucketS.commonHashDimSet.begin();
	while (ssit != UProfileEventBucketF.commonHashDimSet.end()&& ssitIn != UProfileEventBucketS.commonHashDimSet.end()) {
		if ((*ssit).dim == (*ssitIn).dim) {
			if ((*ssit).HashKey == (*ssitIn).HashKey) 
				commHashKeyNum++;					
			ssit++;
			ssitIn++;
		}
		else if ((*ssit).dim > (*ssitIn).dim)
			ssitIn++;
		else
			ssit++;
	}
	
	return commHashKeyNum;
}

void EventRecomOpti::UnionIncomingBucketsToParitionsBySimilarity(std::vector<UPEventPartition>& UProfileEventGroupSets, std::vector<UPEventBucket>& UPEBuckets, float simiThreshold, int conflictKeyNumThre)
{
	std::vector<UPEventBucket>::iterator upebit, FirstProBit, SecondProBit;
	upebit = UPEBuckets.begin();
	int UPEventGroupSetSize = UProfileEventGroupSets.size();
	
	int offset = 0;
	while (upebit != UPEBuckets.end()) {
		int bestBucketNo = -1;  //to note the bucket no can fit directly
		int bestPartitionNo = -1;

		int secondBestBucketNo = -1; //to note the bucket no cannot fit directly, but within the similarity threshold
		int secondBestPartitionNo = -1;
		for (int i = 0; i < UPEventGroupSetSize; i++)
		{
			int bucketNum = UProfileEventGroupSets[i].getUProfileEventGroup().size();
			//find the closest buckets with commKeyNum>conflictKeyNumThre
			for (int j = 0; j < bucketNum; j++) {
				//if(offset==1&&i==9&&j==56)
				//	printf("offset=%d i=%d j=%d\n", offset, i, j);
				int commHashKeyNum = ComputeCommonHashKeyDim((*upebit), UProfileEventGroupSets[i].getUProfileEventGroup()[j]);
				if (commHashKeyNum >= conflictKeyNumThre) {
					float minangleCosV = ComputeBucketUnionMinAngleCos((*upebit), UProfileEventGroupSets[i].getUProfileEventGroup()[j]);
					if (minangleCosV < UProfileEventGroupSets[i].getUProfileEventGroup()[j].getminAngleCos()) {//cannot fit
						if (minangleCosV >= simiThreshold)
						{
							if (secondBestBucketNo == -1) {
								secondBestPartitionNo = i;
								secondBestBucketNo = j;
							}
							else {
								if (UProfileEventGroupSets[i].getUProfileEventGroup()[j].getUProfileEventGroup().size() <
									UProfileEventGroupSets[secondBestPartitionNo].getUProfileEventGroup()[secondBestBucketNo].getUProfileEventGroup().size()) { //smallest bucket has highest priority
									secondBestPartitionNo = i;
									secondBestBucketNo = j;
								}
							}
						}
					}
					else {
						if (bestBucketNo == -1) {
							bestPartitionNo = i;
							bestBucketNo = j;
						}
						else {
							if (UProfileEventGroupSets[i].getUProfileEventGroup()[j].getUProfileEventGroup().size() <
								UProfileEventGroupSets[bestPartitionNo].getUProfileEventGroup()[bestBucketNo].getUProfileEventGroup().size()) { //smallest bucket has highest priority
								bestPartitionNo = i;
								bestBucketNo = j;
							}
						}
					}
				}
			}
		}
		if (bestBucketNo != -1) {
			vector<SubEvent>::iterator ProBit= UProfileEventGroupSets[bestPartitionNo].getUProfileEventGroup()[bestBucketNo].getUProfileEventGroup().begin();

			UProfileEventGroupSets[bestPartitionNo].getUProfileEventGroup()[bestBucketNo].getUProfileEventGroup().insert
			(ProBit, (*upebit).getUProfileEventGroup().begin(), (*upebit).getUProfileEventGroup().end());
			//reset
			UPEBuckets.erase(upebit);
			upebit = UPEBuckets.begin() + offset;
			ProduceEventBucketSummary(UProfileEventGroupSets[bestPartitionNo].getUProfileEventGroup()[bestBucketNo]);
			continue;
		}
		else if (secondBestBucketNo != -1) {
			vector<SubEvent>::iterator ProBit = UProfileEventGroupSets[secondBestPartitionNo].getUProfileEventGroup()[secondBestBucketNo].getUProfileEventGroup().begin();

			UProfileEventGroupSets[secondBestPartitionNo].getUProfileEventGroup()[secondBestBucketNo].getUProfileEventGroup().insert
			(ProBit, (*upebit).getUProfileEventGroup().begin(), (*upebit).getUProfileEventGroup().end());
			
			//=====update 
			float TopicVectoCentre[TFIDF_DIM];
			SubEvent tmpTFIDFCenters;
			ComputeTopicCentre(UProfileEventGroupSets[secondBestPartitionNo].getUProfileEventGroup()[secondBestBucketNo], TopicVectoCentre);
			tmpTFIDFCenters.setConceptTFIDFVec(TopicVectoCentre);
			UProfileEventGroupSets[secondBestPartitionNo].getUProfileEventGroup()[secondBestBucketNo].setTFIDFCenter(tmpTFIDFCenters);
			ProduceEventBucketSummary(UProfileEventGroupSets[secondBestPartitionNo].getUProfileEventGroup()[secondBestBucketNo]);
			float minangleCos = ComputeMinAngleCos(UProfileEventGroupSets[secondBestPartitionNo].getUProfileEventGroup()[secondBestBucketNo], tmpTFIDFCenters);
			UProfileEventGroupSets[secondBestPartitionNo].getUProfileEventGroup()[secondBestBucketNo].setminAngleCos(minangleCos);
			//reset
			UPEBuckets.erase(upebit);
			upebit = UPEBuckets.begin() + offset;
			continue;
		}
		upebit++;
		offset++;
	}	
}

void EventRecomOpti::UnionBucketsBySimilarity(std::vector<UPEventBucket>& UPEBuckets, float simiThreshold, int conflictKeyNumThre)
{
	//select the first bucket for the first processor 
	std::vector<UPEventBucket>::iterator upebit, upebitInner, FirstProBit, SecondProBit;
	float maxSimi = 0;
	int commKeyNum = 1;

	int loop = 1;
	int offsetOut = 0;
	int offsetIn = 0;
	float earlyStopThre = 0.95;
	while (loop) {
		//output for monitoring
		cout << "UPEBuckets Size: " << UPEBuckets.size() << endl;
		//find the closest buckets with commKeyNum>conflictKeyNumThre
		maxSimi = 0;
		upebit = UPEBuckets.begin();
		offsetOut = 0;
		while (upebit != UPEBuckets.end()) {
			upebitInner = upebit;
			offsetIn = offsetOut+1;
			upebitInner++;
			while (upebitInner != UPEBuckets.end()) {
				int commHashKeyNum= ComputeCommonHashKeyDim((*upebit), (*upebitInner));
				if (commHashKeyNum >= conflictKeyNumThre) {
					float minanlgleCosV = ComputeBucketUnionMinAngleCos((*upebit), (*upebitInner));
					if (minanlgleCosV > maxSimi) {
						maxSimi = minanlgleCosV;
						FirstProBit = upebit;
						SecondProBit = upebitInner;
					}
					//stop early to save the cost
					if (maxSimi >= earlyStopThre) {
						int sizeSPB = (*SecondProBit).getUProfileEventGroup().size();
						for (int i = 0; i < sizeSPB; i++)
							(*FirstProBit).setUProfileEventGroup((*SecondProBit).getUProfileEventGroup()[i]);
						int offsetFir=0;
						int offsetSec = 0;
						vector<DimHashKeyPair>::iterator Firit = (*FirstProBit).commonHashDimSet.begin();
						vector<DimHashKeyPair>::iterator Secit = (*SecondProBit).commonHashDimSet.begin();
						while (Firit != (*FirstProBit).commonHashDimSet.end()&& Secit != (*SecondProBit).commonHashDimSet.end()) {
							if ((*Firit).dim < (*Secit).dim) {  //not in SecondProBit
								(*FirstProBit).commonHashDimSet.erase(Firit);
								Firit = (*FirstProBit).commonHashDimSet.begin() + offsetFir;
							}
							else if ((*Firit).dim > (*Secit).dim)
							{
								(*SecondProBit).commonHashDimSet.erase(Secit);
								Secit = (*SecondProBit).commonHashDimSet.begin()+offsetSec;
							}
							else if ((*Firit).dim == (*Secit).dim) {
								if ((*Firit).HashKey != (*Secit).HashKey)
								{
									(*FirstProBit).commonHashDimSet.erase(Firit);
									Firit = (*FirstProBit).commonHashDimSet.begin() + offsetFir;	
									(*SecondProBit).commonHashDimSet.erase(Secit);
									Secit = (*SecondProBit).commonHashDimSet.begin() + offsetSec;
								}
								else{
									offsetFir++;
									offsetSec++;
									Firit++;
									Secit++;
								}
							}
						}
						

						UPEBuckets.erase(SecondProBit);
						float TopicVectoCentre[TFIDF_DIM];
						SubEvent tmpTFIDFCenters;
						ComputeTopicCentre((*FirstProBit), TopicVectoCentre);
						tmpTFIDFCenters.setConceptTFIDFVec(TopicVectoCentre);
						(*FirstProBit).setTFIDFCenter(tmpTFIDFCenters);
						ProduceEventBucketSummary(*FirstProBit);
						float minangleCos = ComputeMinAngleCos(*FirstProBit, tmpTFIDFCenters);
						(*FirstProBit).setminAngleCos(minangleCos);
						//reset
						upebitInner = UPEBuckets.begin() + offsetIn;
						maxSimi = 0;
						SecondProBit = upebitInner;
						continue; 
					}
					//==================
				}
				upebitInner++;
				offsetIn++;
				//cout << "offsetIn: " << offsetIn << "\t offsetOut: " << offsetOut << endl;
			}
			offsetOut++;
			upebit++;
		}
		if (maxSimi < simiThreshold)
			loop = 0;
		else{
			int sizeSPB = (*SecondProBit).getUProfileEventGroup().size();
			for (int i = 0; i < sizeSPB; i++)
				(*FirstProBit).setUProfileEventGroup((*SecondProBit).getUProfileEventGroup()[i]);
			int offsetFir = 0;
			int offsetSec = 0;
			vector<DimHashKeyPair>::iterator Firit = (*FirstProBit).commonHashDimSet.begin();
			vector<DimHashKeyPair>::iterator Secit = (*SecondProBit).commonHashDimSet.begin();
			while (Firit != (*FirstProBit).commonHashDimSet.end() && Secit != (*SecondProBit).commonHashDimSet.end()) {
				if ((*Firit).dim < (*Secit).dim) {  //not in SecondProBit
					(*FirstProBit).commonHashDimSet.erase(Firit);
					Firit = (*FirstProBit).commonHashDimSet.begin() + offsetFir;
				}
				else if ((*Firit).dim > (*Secit).dim)
				{
					(*SecondProBit).commonHashDimSet.erase(Secit);
					Secit = (*SecondProBit).commonHashDimSet.begin() + offsetSec;
				}
				else if ((*Firit).dim == (*Secit).dim) {
					if ((*Firit).HashKey != (*Secit).HashKey)
					{
						(*FirstProBit).commonHashDimSet.erase(Firit);
						Firit = (*FirstProBit).commonHashDimSet.begin() + offsetFir;
						(*SecondProBit).commonHashDimSet.erase(Secit);
						Secit = (*SecondProBit).commonHashDimSet.begin() + offsetSec;
					}
					else {
						offsetFir++;
						offsetSec++;
						Firit++;
						Secit++;
					}
				}
			}

			UPEBuckets.erase(SecondProBit);
			float TopicVectoCentre[TFIDF_DIM];
			SubEvent tmpTFIDFCenters;
			ComputeTopicCentre((*FirstProBit), TopicVectoCentre);
			tmpTFIDFCenters.setConceptTFIDFVec(TopicVectoCentre);
			(*FirstProBit).setTFIDFCenter(tmpTFIDFCenters);
			ProduceEventBucketSummary(*FirstProBit);
			float minangleCos = ComputeMinAngleCos(*FirstProBit, tmpTFIDFCenters);
			(*FirstProBit).setminAngleCos(minangleCos);
			if (earlyStopThre > simiThreshold + 0.05)
				earlyStopThre = earlyStopThre - 0.05;
			else
				earlyStopThre = simiThreshold;
		}
	}
}

int EventRecomOpti::ComputeTopicCentre(UPEventBucket& UProfileEventBucket, float TopicVectoCentre[]) {
	int bucketsize = 0;
	bucketsize = UProfileEventBucket.getUProfileEventGroup().size();
	if (bucketsize == 0)
		return bucketsize;

	vector<SubEvent>::iterator ssit = UProfileEventBucket.getUProfileEventGroup().begin();
	vector<SubEvent>::iterator ssEndit = UProfileEventBucket.getUProfileEventGroup().end();
	for (int j = 0; j < TFIDF_DIM; j++) {
		TopicVectoCentre[j] = 0;
	}
	while (ssit != ssEndit) {
		float* vec = (*ssit).GetCluster_ConceptTFIDFVec();
		for (int j = 0; j < TFIDF_DIM; j++) {
			TopicVectoCentre[j] += vec[j];
		}
		ssit++;
	}
	for (int j = 0; j < TFIDF_DIM; j++) 
		TopicVectoCentre[j] /= bucketsize;
	
	return bucketsize;
}

int EventRecomOpti::ComputeTopicCentrePartition(vector<UPEventBucket>& UProfileEventBucket, float TopicVectoCentre[]) {
	int bucketsize = 0;
	for(int i=0;i<UProfileEventBucket.size();i++)
		bucketsize += UProfileEventBucket[i].getUProfileEventGroup().size();
	if (bucketsize == 0)
		return bucketsize;

	for (int j = 0; j < TFIDF_DIM; j++) {
		TopicVectoCentre[j] = 0;
	}
	for (int i = 0; i < UProfileEventBucket.size(); i++) {
		vector<SubEvent>::iterator ssit = UProfileEventBucket[i].getUProfileEventGroup().begin();
		vector<SubEvent>::iterator ssEndit = UProfileEventBucket[i].getUProfileEventGroup().end();
		while (ssit != ssEndit) {
			float* vec = (*ssit).GetCluster_ConceptTFIDFVec();
			for (int j = 0; j < TFIDF_DIM; j++) {
				TopicVectoCentre[j] += vec[j];
			}
			ssit++;
		}
	}
	for (int j = 0; j < TFIDF_DIM; j++)
		TopicVectoCentre[j] /= bucketsize;

	return bucketsize;
}

void EventRecomOpti::AllocateIncomingBucketsofGroups2ProcessorsUnion(std::vector<UPEventBucket>& UPEBuckets, int NumOfGroups,
	std::vector<UPEventPartition>& UProfileEventGroupProcessors)
{
	std::vector<UPEventBucket>::iterator upebit, FirstProBit;
	//allocate the rest of buckets to NumOfGroups processors
	while (!UPEBuckets.empty()) {
		int proToAllocate = findSmallestGroup(UProfileEventGroupProcessors, NumOfGroups);
		upebit = UPEBuckets.begin();
		float maxSimi = -1.0;
		FirstProBit = upebit;
		while (upebit != UPEBuckets.end()) {
			float curSimi = ComputeUnionMinAngleCos((*upebit), UProfileEventGroupProcessors[proToAllocate].getUProfileEventGroup());
			if (curSimi > maxSimi) {
				maxSimi = curSimi;
				FirstProBit = upebit;
			}
			upebit++;
		}
		if (FirstProBit != UPEBuckets.end()) {
			UProfileEventGroupProcessors[proToAllocate].setUProfileEventGroup(*FirstProBit);  //allocate the rest bucket for the processor proToAllocate
			UPEBuckets.erase(FirstProBit);  //remove the bucket
		}
	}
}

void EventRecomOpti::AllocateBucketsofGroups2ProcessorsUnion(std::vector<UPEventBucket>& UPEBuckets, int NumOfGroups,
	std::vector<UPEventPartition>& UProfileEventGroupProcessors)
{
	//select the first bucket for the first processor 
	std::vector<UPEventBucket>::iterator upebit, upebitInner, FirstProBit;
	int allocatedProcessorNum = 0;
	if (!UPEBuckets.empty())
	{		
		upebit = UPEBuckets.begin();
		float minSimi = 1;
		FirstProBit = upebit;
		while (upebit != UPEBuckets.end()) {
			upebitInner = UPEBuckets.begin();
			float curSimi = 0;
			while (upebitInner != UPEBuckets.end()) {
				curSimi += ComputeBucketUnionMinAngleCos((*upebit),(*upebitInner));
				upebitInner++;
			}
			if (curSimi < minSimi) {
				FirstProBit = upebit;
				minSimi = curSimi;
			}
			upebit++;
		}
		UProfileEventGroupProcessors[0].setUProfileEventGroup(*FirstProBit);  //allocate the first bucket for the first processor
		UPEBuckets.erase(FirstProBit);  //remove the bucket
		allocatedProcessorNum++;
	}
	
	//select the first bucket for each of the rest of processors
	for (int i = allocatedProcessorNum; i < NumOfGroups; i++) {
		if (UPEBuckets.empty())
			break;

		//find the first bucket for processor i
		upebit = UPEBuckets.begin();
		float minSimi = 1;
		FirstProBit = upebit;
		while (upebit != UPEBuckets.end()) {
			float curSimi = 0;
			for (int j = 0; j < allocatedProcessorNum; j++) {
				curSimi += ComputeUnionMinAngleCos((*upebit), UProfileEventGroupProcessors[j].getUProfileEventGroup());
			}
			if (curSimi < minSimi) {
				minSimi = curSimi;
				FirstProBit = upebit;
			}
			upebit++;
		}
		UProfileEventGroupProcessors[i].setUProfileEventGroup(*FirstProBit);  //allocate the first bucket for the ith processor
		UPEBuckets.erase(FirstProBit);  //remove the bucket
		allocatedProcessorNum++;
	}

	//allocate the rest of buckets to NumOfGroups processors
	while (!UPEBuckets.empty()){
		int proToAllocate = findSmallestGroup(UProfileEventGroupProcessors, NumOfGroups);
		upebit = UPEBuckets.begin();
		float maxSimi = -1.0;
		FirstProBit = upebit;
		while (upebit != UPEBuckets.end()){
			float curSimi = ComputeUnionMinAngleCos((*upebit), UProfileEventGroupProcessors[proToAllocate].getUProfileEventGroup());
			if (curSimi > maxSimi) {
				maxSimi = curSimi;
				FirstProBit = upebit;
			}
			upebit++;
		}
		if (FirstProBit != UPEBuckets.end()) {
			UProfileEventGroupProcessors[proToAllocate].setUProfileEventGroup(*FirstProBit);  //allocate the rest bucket for the processor proToAllocate
			UPEBuckets.erase(FirstProBit);  //remove the bucket
		}
	}
}

void EventRecomOpti::ContinuousUserProfileDataPartitionAngleHashMixedHashKMeans(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
	std::vector<UPEventPartition>& UProfileEventGroupSets) {
	vector<SubEvent>::iterator lit;
	//=======compute hash values for each dimension of the topic===========
	//====read maxMinValue for each dimension.
	float dimMax[TFIDF_DIM] = { 0 };
	float dimMin[TFIDF_DIM] = { 0 };
	char StatisticsFile[200];
	strcpy_s(StatisticsFile, "statistics7DaysNepalData.txt");
	ReadMaxMinDimValues(StatisticsFile, dimMax, dimMin);
	lit = UProfileEventSet.begin();
	while (lit != UProfileEventSet.end()) {
		float* vec = (*lit).GetCluster_ConceptTFIDFVec();
		for (int i = 0; i < TFIDF_DIM; i++) {
			(*lit).EDIMHashV[i].dim = i;
			if (vec[i] == 0)
				(*lit).EDIMHashV[i].HashKey = 3;
			else if (vec[i] < 0)
				(*lit).EDIMHashV[i].HashKey = 3 * (dimMin[i] - vec[i]) / dimMin[i];
			else if (vec[i] > 0)
				(*lit).EDIMHashV[i].HashKey = 3 + ceil(3 * vec[i] / dimMax[i]);
		}
		lit++;
	}

	//===put events into buckets based on hash conflicts;
	int conflictKeyNum = 45;  //i.e. each pair of events has at least conflictKeyNum conflict hash key values.
	std::vector<UPEventBucket> UProfileEventBuckets;
	ConflictEvents2BucketsDimHash(UProfileEventSet, UProfileEventBuckets, conflictKeyNum);

	//===========
	vector<SubEvent> TFIDFCenters;
	vector<SubEvent> tmpTFIDFCenters;
	float TopicVectoCentre[TFIDF_DIM];
	int bucketNum = UProfileEventBuckets.size();
	tmpTFIDFCenters.resize(bucketNum);
	for (int i = 0; i < bucketNum; i++) {
		ComputeTopicCentre(UProfileEventBuckets[i], TopicVectoCentre);
		tmpTFIDFCenters[i].setConceptTFIDFVec(TopicVectoCentre);
		UProfileEventBuckets[i].setTFIDFCenter(tmpTFIDFCenters[i]);
		ProduceEventBucketSummary(UProfileEventBuckets[i]);
		float minangleCos = ComputeMinAngleCos(UProfileEventBuckets[i], tmpTFIDFCenters[i]);
		UProfileEventBuckets[i].setminAngleCos(minangleCos);
		if (minangleCos < 0.8)
			cout << "bucket " << i << ": " << minangleCos << "Size: " << UProfileEventBuckets[i].getUProfileEventGroup().size()
			<< "\t commonDim: " << UProfileEventBuckets[i].commonHashDimSet.size() << endl;
	}
	//===========
	float simiThreshold = 0.8;
	int conflictKeyNumThre = 20;
	//find a smallest bucket that can cover an incoming bucket in UProfileEventBuckets by similarity. i.e. UnionBucketsBySimilarity.

	UnionIncomingBucketsToParitionsBySimilarity(UProfileEventGroupSets, UProfileEventBuckets, simiThreshold, conflictKeyNumThre);
	
	printf("complete UnionIncomingBucketsToParitionsBySimilarity\n");
	//for an incoming bucket, if no any existing bucket covers it, find the cloest and smallest bucket to union them.
	if(!UProfileEventBuckets.empty())
		AllocateIncomingBucketsofGroups2ProcessorsUnion(UProfileEventBuckets, NumOfGroups, UProfileEventGroupSets);
	
	printf("complete AllocateIncomingBucketsofGroups2ProcessorsUnion\n");
	TFIDFCenters.resize(NumOfGroups);
	for (int i = 0; i < NumOfGroups; i++) {
		ComputeTopicCentrePartition(UProfileEventGroupSets[i].getUProfileEventGroup(), TopicVectoCentre);
		TFIDFCenters[i].setConceptTFIDFVec(TopicVectoCentre);
		UProfileEventGroupSets[i].setTFIDFCenter(TFIDFCenters[i]);

		ProduceDataPartitionSummary(UProfileEventGroupSets[i]);
		float minangleCos = ComputePartitionMinAngleCos(UProfileEventGroupSets[i], TFIDFCenters[i]);
		UProfileEventGroupSets[i].setminAngleCos(minangleCos);		
	}
	UProfileEventBuckets.clear();
	TFIDFCenters.clear();
	tmpTFIDFCenters.clear();
}
void EventRecomOpti::UserProfileDataPartitionAngleHashMixedHashKMeans(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
	std::vector<UPEventPartition>& UProfileEventGroupSets, SocialEventOperation& seoper)
{
	//====================
	vector<SubEvent> TFIDFCenters;
	vector<SubEvent> tmpTFIDFCenters;

	//======compute angle
	float TopicVectorAngle[TFIDF_DIM];
	for (int i = 0; i < TFIDF_DIM; i++) {
		TopicVectorAngle[i] = 0;
	}
	vector<SubEvent>::iterator lit = UProfileEventSet.begin();
	while (lit != UProfileEventSet.end()) {
		ComputeAngleVector((*lit), TopicVectorAngle);
		(*lit).setTFIDFVecAngleSphericalCorSys(TopicVectorAngle);
		lit++;
	}
	
	//=======compute hash values for each dimension of the topic===========
	//====read maxMinValue for each dimension.
	float dimMax[TFIDF_DIM] = { 0 };
	float dimMin[TFIDF_DIM] = { 0 };	
	char StatisticsFile[200];
	strcpy_s(StatisticsFile, "statistics7DaysNepalData.txt");
	ReadMaxMinDimValues(StatisticsFile, dimMax, dimMin);
	lit = UProfileEventSet.begin();
	while (lit != UProfileEventSet.end()) {
		float* vec = (*lit).GetCluster_ConceptTFIDFVec();
		for (int i = 0; i < TFIDF_DIM; i++) {
			(*lit).EDIMHashV[i].dim = i;
			if (vec[i] == 0)
				(*lit).EDIMHashV[i].HashKey = 3;
			else if(vec[i]<0)
				(*lit).EDIMHashV[i].HashKey = 3 * (dimMin[i] - vec[i]) / dimMin[i];
			else if(vec[i]>0)
				(*lit).EDIMHashV[i].HashKey =3+ ceil(3 * vec[i]/ dimMax[i]);
		}
		lit++;
	}	
	//===put events into buckets based on hash conflicts;
	int conflictKeyNum = 45;  //i.e. each pair of events has at least conflictKeyNum conflict hash key values.
	std::vector<UPEventBucket> UProfileEventBuckets;
	ConflictEvents2BucketsDimHash(UProfileEventSet, UProfileEventBuckets, conflictKeyNum);

	//===K-mean clustering over UProfileEventBuckets
	float TopicVectoCentre[TFIDF_DIM];	
	int bucketNum = UProfileEventBuckets.size();
	tmpTFIDFCenters.resize(bucketNum);
	for (int i = 0; i < bucketNum; i++) {
		ComputeTopicCentre(UProfileEventBuckets[i], TopicVectoCentre);
		tmpTFIDFCenters[i].setConceptTFIDFVec(TopicVectoCentre);
		UProfileEventBuckets[i].setTFIDFCenter(tmpTFIDFCenters[i]);
		ProduceEventBucketSummary(UProfileEventBuckets[i]);
		float minangleCos = ComputeMinAngleCos(UProfileEventBuckets[i], tmpTFIDFCenters[i]);
		UProfileEventBuckets[i].setminAngleCos(minangleCos);
		if(minangleCos<0.8)
			cout << "bucket " << i << ": " << minangleCos << "Size: "<<UProfileEventBuckets[i].getUProfileEventGroup().size()
				<<"\t commonDim: "<< UProfileEventBuckets[i].commonHashDimSet.size()<<endl;
	}

	float simiThreshold = 0.8;
	int conflictKeyNumThre = 20;
	UnionBucketsBySimilarity(UProfileEventBuckets, simiThreshold, conflictKeyNumThre);

	AllocateBucketsofGroups2ProcessorsUnion(UProfileEventBuckets, NumOfGroups, UProfileEventGroupSets);
	TFIDFCenters.resize(NumOfGroups);
	for (int i = 0; i < NumOfGroups; i++) {
		ComputeTopicCentrePartition(UProfileEventGroupSets[i].getUProfileEventGroup(), TopicVectoCentre);
		TFIDFCenters[i].setConceptTFIDFVec(TopicVectoCentre);
		UProfileEventGroupSets[i].setTFIDFCenter(TFIDFCenters[i]);
		ProduceDataPartitionSummary(UProfileEventGroupSets[i]);
		float minangleCos = ComputePartitionMinAngleCos(UProfileEventGroupSets[i], TFIDFCenters[i]);
		UProfileEventGroupSets[i].setminAngleCos(minangleCos);
	}
	UProfileEventBuckets.clear();
	TFIDFCenters.clear();
	tmpTFIDFCenters.clear();
}

void EventRecomOpti::ConflictEvents2BucketsCosinAngle(std::vector<SubEvent>& UProfileEventSet,
	std::vector<UPEventBucket>& UPEventBuckets)
{
	std::vector<SubEvent>::iterator upesit = UProfileEventSet.begin();
	while (upesit != UProfileEventSet.end()) {
		std::vector<UPEventBucket>::iterator upebit = UPEventBuckets.begin();
		while (upebit != UPEventBuckets.end()) {
			float cursimi = (*upebit).getUProfileEventGroup()[0].GetConceptSimilarity(&(*upesit));
			if (cursimi >= 0.9999) //close to 1, find the conflict bucket, put the event into the bucket
			{
				(*upebit).setUProfileEventGroup(*upesit);
				break;
			}
			upebit++;
		}
		if (upebit == UPEventBuckets.end()) //not find conflict, put a new bucket
		{
			UPEventBucket curEPar;
			curEPar.setUProfileEventGroup(*upesit);
			UPEventBuckets.push_back(curEPar);
		}
		upesit++;
	}
}

void EventRecomOpti::ContinuousUserProfileDataPartitionAngleHash(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
	std::vector<UPEventPartition>& UProfileEventGroupSets)
{
	std::vector<UPEventBucket> UProfileEventBuckets;
	ConflictEvents2BucketsCosinAngle(UProfileEventSet, UProfileEventBuckets);

	std::vector<UPEventBucket>::iterator upebit, FirstProBit;
	//allocate the rest of SubEvent to NumOfGroups processors
	//allocate without area angle increase	
	int proToAllocate = -1;
	upebit = UProfileEventBuckets.begin();
	int offset = 0;
	while (upebit != UProfileEventBuckets.end())
	{
		proToAllocate = -1;
		for (int i = 0; i < NumOfGroups; i++) {
			float cursimi = UProfileEventGroupSets[i].getUProfileEventGroup()[0].
				getTFIDFCenter().GetConceptSimilarity(&(*upebit).getUProfileEventGroup()[0]);
			if (cursimi > UProfileEventGroupSets[i].getUProfileEventGroup()[0].getminAngleCos()) { //no increase area
				if (proToAllocate == -1)
					proToAllocate = i;
				else {//check the size of groupsets				
					if (UProfileEventGroupSets[i].getUProfileEventGroup()[0].getUProfileEventGroup().size()
						< UProfileEventGroupSets[proToAllocate].getUProfileEventGroup()[0].getUProfileEventGroup().size())  //all clusters are kept in the first UProfileGroup
						proToAllocate = i;
				}
			}
		}
		if (proToAllocate != -1){  //proToAllocate is found			
			FirstProBit = upebit;			
			UProfileEventGroupSets[proToAllocate].setUProfileEventGroup(*FirstProBit);
			UProfileEventBuckets.erase(FirstProBit);  //remove the event
			upebit=UProfileEventBuckets.begin()+offset;
		}
		else {
			upebit++;
			offset++;
		}
	}
	//allocate the rest of events to the nearest groupset 	
	offset = 0;
	upebit = UProfileEventBuckets.begin();
	while (upebit != UProfileEventBuckets.end())
	{
		proToAllocate = -1;
		float MaxSimi = -10;
		for (int i = 0; i < NumOfGroups; i++) {
			float cursimi = UProfileEventGroupSets[i].getUProfileEventGroup()[0].
				getTFIDFCenter().GetConceptSimilarity(&(*upebit).getUProfileEventGroup()[0]);
			if (cursimi > MaxSimi) { 
				MaxSimi = cursimi;
				proToAllocate = i;
			}
		}

		//==============
		FirstProBit = upebit;
		UProfileEventGroupSets[proToAllocate].setUProfileEventGroup(*FirstProBit);  //allocate the rest event for the processor proToAllocate
		UProfileEventGroupSets[proToAllocate].getUProfileEventGroup()[0].setminAngleCos(MaxSimi);		
		UProfileEventBuckets.erase(FirstProBit);  //remove the event
		upebit=UProfileEventBuckets.begin();
		//===============		
	}
	/*while (!UProfileEventBuckets.empty()) {
		int proToAllocate = findSmallestGroup(UProfileEventGroupSets, NumOfGroups);
		upebit = UProfileEventBuckets.begin();
		float maxsimi = UProfileEventGroupSets[proToAllocate].getUProfileEventGroup()[0].getminAngleCos();//0.3;
		FirstProBit = upebit;
		while (upebit != UProfileEventBuckets.end())
		{
			float cursimi = UProfileEventGroupSets[proToAllocate].getUProfileEventGroup()[0].
				getTFIDFCenter().GetConceptSimilarity(&(*upebit).getUProfileEventGroup()[0]);
			//float cursimi = UProfileEventGroupSets[proToAllocate].getUProfileEventGroup()[0].
			//	getTFIDFCenter().GetConceptSimilaritySubspace(&(*upebit).getUProfileEventGroup()[0]);
			if (cursimi > maxsimi) {
				maxsimi = cursimi;
				FirstProBit = upebit;
			}
			upebit++;
		}

		if (FirstProBit != UProfileEventBuckets.end()) {
			UProfileEventGroupSets[proToAllocate].setUProfileEventGroup(*FirstProBit);  //allocate the rest event for the processor proToAllocate
			float cosVal = (*FirstProBit).getUProfileEventGroup()[0].GetConceptSimilarity(&UProfileEventGroupSets[proToAllocate]
				.getUProfileEventGroup()[0].getTFIDFCenter());
			//float cosVal = (*FirstProBit).getUProfileEventGroup()[0].GetConceptSimilaritySubspace(&UProfileEventGroupSets[proToAllocate]
			//	.getUProfileEventGroup()[0].getTFIDFCenter());
			if (cosVal < UProfileEventGroupSets[proToAllocate].getUProfileEventGroup()[0].getminAngleCos())
				UProfileEventGroupSets[proToAllocate].getUProfileEventGroup()[0].setminAngleCos(cosVal);
			UProfileEventBuckets.erase(FirstProBit);  //remove the event
		}
	}*/
	for (int i = 0; i < UProfileEventGroupSets.size(); i++)
		ProduceDataPartitionSummary(UProfileEventGroupSets[i]);
	UProfileEventBuckets.clear();
}


void EventRecomOpti::kmeansClusters(vector<SubEvent>& inputEventlist, int NumOfGroups, vector<SubEvent> outeventGroups[], vector<SubEvent>& TFIDFCenters) {
	vector<SubEvent>::iterator lit;
	lit = inputEventlist.begin();
	while (lit != inputEventlist.end()) {
		//decide where to allocate the lit
		double maxTFIDFCos = -10;
		double curFTIDFCos = -10;
		int maxIndex = 0;
		for (int i = 0; i < NumOfGroups; i++) {
			curFTIDFCos = (*lit).GetConceptSimilarity(&TFIDFCenters[i]);
			//curFTIDFCos = (*lit).GetConceptSimilaritySubspace(&TFIDFCenters[i]);
			if (curFTIDFCos > maxTFIDFCos) {
				maxTFIDFCos = curFTIDFCos;
				maxIndex = i;
			}
		}
		outeventGroups[maxIndex].push_back(*lit);
		lit++;
	}
}
void EventRecomOpti::getkmeansCentres(vector<SubEvent>& inputEventlist, int NumOfGroups, vector<SubEvent> outeventGroups[], vector<SubEvent>& TFIDFCenters) {
	vector<SubEvent>::iterator lit, litmp;
	vector<SubEvent> tmpCenters;

	if (inputEventlist.size() <= NumOfGroups) {
		lit = inputEventlist.begin();
		int i = 0;
		while (lit != inputEventlist.end()) {
			outeventGroups[i].push_back(*lit);
			i++;
			lit++;
		}
	}
	else {
		//choose NumOfGroups events furthest from each other.
		//choose the first one
		/*for (int i = 1; i < NumOfGroups; i++) 
			TFIDFCenters.push_back(inputEventlist[i]);*/
		//================
		TFIDFCenters.push_back(inputEventlist[0]);
		for (int i = 1; i < NumOfGroups; i++) {
			//choose the ith reference point
			int offset = 0;
			float minCos = 1;
			int count = 0;
			litmp = inputEventlist.begin();
			while (litmp != inputEventlist.end()) {
				int centerNum = TFIDFCenters.size();
				int j = 0;
				float maxCos = -1;			
				for (j = 0; j < centerNum; j++) {
					float curCos = TFIDFCenters[j].GetConceptSimilarity(&(*litmp));
					if (curCos>maxCos)//cannot be too close to any centers.
						maxCos=curCos;
				}
				if (maxCos < minCos) {
					offset = count;
					minCos = maxCos;
				}
				litmp++;
				count++;
			}
			TFIDFCenters.push_back(inputEventlist[offset]);
		}
		//================

		tmpCenters.resize(NumOfGroups);
		int loop = 1;
		while (loop)
		{
			for (int i = 0; i < NumOfGroups; i++)
				outeventGroups[i].clear();

			//allocate inputlocationlist elements to outlocationGroups
			lit = inputEventlist.begin();
			while (lit != inputEventlist.end()) {
				//decide where to allocate the lit
				float maxTFIDFCos = -10;
				float curFTIDFCos = -10;
				int maxIndex = 0;
				for (int i = 0; i < NumOfGroups; i++) {
					curFTIDFCos = TFIDFCenters[i].GetConceptSimilarity(&(*lit));
					//curFTIDFCos = TFIDFCenters[i].GetConceptSimilaritySubspace(&(*lit));
					if (curFTIDFCos > maxTFIDFCos) {
						maxTFIDFCos = curFTIDFCos;
						maxIndex = i;
					}
				}
				outeventGroups[maxIndex].push_back(*lit);
				lit++;
			}
			//======make sure every outeventGroupso[i] has events======================
			for (int i = 0; i < NumOfGroups; i++) {
				if (!outeventGroups[i].empty())
					continue;
				lit = inputEventlist.begin();
				while (lit != inputEventlist.end()) {
					//decide where to allocate the lit
					float maxTFIDFCos = -10;
					float curFTIDFCos = -10;
					int maxIndex = 0;
					for (int j = 0; j < NumOfGroups; j++) {
						curFTIDFCos = TFIDFCenters[j].GetConceptSimilarity(&(*lit));
						if (curFTIDFCos > maxTFIDFCos) {
							maxTFIDFCos = curFTIDFCos;
							maxIndex = i;
						}
					}
					outeventGroups[maxIndex].push_back(*lit);
					lit++;
				}
			}
			//==========================
			for (int i = 0; i < NumOfGroups; i++) {
				//calculate the coordinates of tmpCentres
				float tmpeventCentreCor[TFIDF_DIM] = { 0 };
				for (int j = 0; j < TFIDF_DIM; j++)
					tmpeventCentreCor[j] = 0;
				/*float tmpeventCentreCorMax[TFIDF_DIM] = { 0 };
				float tmpeventCentreCorMin[TFIDF_DIM] = { 0 };
				for (int j = 0; j < TFIDF_DIM; j++) {
					tmpeventCentreCorMax[j] = -1;
					tmpeventCentreCorMin[j] = 1;
				}*/

				tmpCenters[i].setConceptTFIDFVec(tmpeventCentreCor);
				lit = outeventGroups[i].begin();
				while (lit != outeventGroups[i].end()) {
					float *convec=(*lit).GetCluster_ConceptTFIDFVec();
					for (int j = 0; j < TFIDF_DIM; j++) {
						tmpeventCentreCor[j] += convec[j];
						/*if(convec[j]> tmpeventCentreCorMax[j])
							tmpeventCentreCorMax[j] = convec[j];
						if (convec[j] < tmpeventCentreCorMin[j])
							tmpeventCentreCorMin[j] = convec[j];*/
					}
					lit++;
				}
				for (int j = 0; j < TFIDF_DIM; j++) {
					tmpeventCentreCor[j] /= outeventGroups[i].size();
					/*tmpeventCentreCor[j] = (tmpeventCentreCorMax[j] + tmpeventCentreCorMin[j]) / 2;*/
					tmpCenters[i].setConceptTFIDFVec(tmpeventCentreCor);
				}
			}
			//================================================
			int i = 0;
			for (i = 0; i < NumOfGroups; i++) {
				float simiCurr=tmpCenters[i].GetConceptSimilarity(&TFIDFCenters[i]);
				//float simiCurr = tmpCenters[i].GetConceptSimilaritySubspace(&TFIDFCenters[i]);
				if (simiCurr<0.99)
					break; //needs to loop
			}
			if (i == NumOfGroups) //locCentres stable, stop loop
				loop = 0;

			for (i = 0; i < NumOfGroups; i++) 
				TFIDFCenters[i].setConceptTFIDFVec(tmpCenters[i].GetCluster_ConceptTFIDFVec());
		}
	}

	tmpCenters.clear();
}

void EventRecomOpti::ContinuousUserProfileDataPartitionContentUser(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
	std::vector<UPEventPartition>& UProfileEventGroupSets, LSB& lsb, LSB& lsbuser, SocialEventOperation& seoper)
{
	MapEvent2VecContentUser(UProfileEventSet, lsb, lsbuser);

	std::vector<UPEventBucket> UProfileEventBuckets;

	ConflictEvents2Buckets(UProfileEventSet, UProfileEventBuckets, lsb, seoper);

	ContinuousAllocateBucketsofGroups2Processors(UProfileEventBuckets, NumOfGroups, UProfileEventGroupSets, lsb, seoper);

	for (int i = 0; i < UProfileEventGroupSets.size(); i++)
		ProduceDataPartitionSummary(UProfileEventGroupSets[i]);
	UProfileEventBuckets.clear();
}

void EventRecomOpti::UserProfileDataPartitionHP(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
	std::vector<UPEventPartition>& UProfileEventGroupSets, SocialEventOperation& seoper)
{
	//one pass clustering
	float SimiT = 0.3;
	vector<UPEventBucket> subsets;
	onePassClustering(UProfileEventSet, SimiT, subsets);
	//uniform partition
	UProfileEventGroupSets.resize(NumOfGroups);
	int subsetSize = subsets.size();
	for (int i = 0; i < subsetSize; i++) {
		vector<SubEvent> sseti = subsets[i].getUProfileEventGroup();
		vector<SubEvent>::iterator ssit = sseti.begin();
		int curP = 0;
		while (ssit != sseti.end()) {
			UProfileEventGroupSets[curP].setUProfileEvent((*ssit), 0);
			curP++;
			if (curP == NumOfGroups)
				curP = 0;
			ssit++;
		}
	}	
	//======================Jan. 2022	
	float TopicVectoCentre[TFIDF_DIM];
	vector<SubEvent> TFIDFCenters;
	float minangleCos = 1.0;

	TFIDFCenters.resize(NumOfGroups);
	for (int i = 0; i < NumOfGroups; i++) {
		ComputeTopicCentrePartition(UProfileEventGroupSets[i].getUProfileEventGroup(), TopicVectoCentre);
		TFIDFCenters[i].setConceptTFIDFVec(TopicVectoCentre);
		UProfileEventGroupSets[i].setTFIDFCenter(TFIDFCenters[i]);
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setTFIDFCenter(TFIDFCenters[i]);
		ProduceDataPartitionSummary(UProfileEventGroupSets[i]);
		//ProduceEventBucketSummary(UProfileEventGroupSets[i].getUProfileEventGroup()[0]);
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setTimeRangePair(UProfileEventGroupSets[i].getTimeRangePair());
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setInfluenceRangeVector(UProfileEventGroupSets[i].getInfluenceRangeVector());
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setMaxNumInfluencedUsers(UProfileEventGroupSets[i].getMaxNumInfluencedUsers());
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setMinNumInfluencedUsers(UProfileEventGroupSets[i].getMinNumInfluencedUsers());
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setminimalRadius(UProfileEventGroupSets[i].GetminimalRadius());
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setSpaceRangecentreP(UProfileEventGroupSets[i].getSpaceRangecentreP());
		
		float minangleCos = ComputePartitionMinAngleCos(UProfileEventGroupSets[i], TFIDFCenters[i]);
		UProfileEventGroupSets[i].setminAngleCos(minangleCos);
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setminAngleCos(minangleCos);

	}

	cout << "finished data partition" << endl;
	TFIDFCenters.clear();
	//============================
	//for (int i = 0; i < UProfileEventGroupSets.size(); i++)
	//	ProduceDataPartitionSummary(UProfileEventGroupSets[i]);

	subsets.clear();
}

void EventRecomOpti::onePassClustering(std::vector<SubEvent>& dataset, float SimiT, std::vector<UPEventBucket>& subsets)//SimiT is the distance threshold in a cluster, subsets keetps the subevent clusters, the initial input should be empty
{
	std::vector<SubEvent>::iterator dit = dataset.begin();
	std::vector<UPEventBucket>::iterator CurSit, CloSit; //CurSit points to the current CCIGSet, CloSit points to the CCIGSet closest to the checked CCIG 

	//printf("dataset size:\t %d\n", dataset.size());
	
	while (dit != dataset.end()) {
		//(1) the object descriptions are processed serially; 
		//(2) the first object becomes the cluster representative of the first cluster; 
		if (subsets.size() == 0) {
			UPEventBucket curSubSet;
			curSubSet.setUProfileEventGroup(*dit);
			subsets.push_back(curSubSet);
			dit++;
			continue;
		}

		//(3) each subsequent object is matched against all cluster representatives existing at its processing time; 
		CurSit = subsets.begin();
		CloSit = subsets.begin();
		float minDist = -1; //MAXFLOAT; //the initial value is set to minimal similarity value;	

		while (CurSit != subsets.end())
		{
			//skip the clusters with elements up to NUMOfGROUPS
			if ((*CurSit).getUProfileEventGroup().size() >= NUMOfGROUPS)
			{
				CurSit++;
				continue;
			}
			std::vector<SubEvent>::iterator SubSit = (*CurSit).getUProfileEventGroup().begin();  //SubSit points to the subset to a Event set
			float curDist = 0;
			while (SubSit != (*CurSit).getUProfileEventGroup().end())
			{				
				//float tmpDist = (*SubSit).GetGlobalSimilarity(&(*dit));// CCIGDist((*dit), (*CurSit));
				float tmpDist = (*SubSit).GetConceptSimilarity(&(*dit));// CCIGDist((*dit), (*CurSit));
				curDist += tmpDist;
				SubSit++;
			}
			curDist /= (*CurSit).getUProfileEventGroup().size();
			if (curDist > minDist)
			{
				minDist = curDist;
				CloSit = CurSit;
			}
			CurSit++;
		}
		if (minDist > SimiT)
		{
			//(4) a given object is assigned to one cluster (or more if overlap is allowed) according to some condition on the matching function; 
			(*CloSit).setUProfileEventGroup(*dit);
			//(5) when an object is assigned to a cluster the representative for that cluster is recomputed; since we calculate the average distance to all CCIGs in one cluster, we donot recompute the representative of a cluster
		}
		else {
			//(6) if an object fails a certain test it becomes the cluster representative of a new cluster
			UPEventBucket curSubSet1;
			curSubSet1.setUProfileEventGroup(*dit);
			subsets.push_back(curSubSet1);
		}
		dit++;		
	}
	//By now, you finish the one-pass clustering process. you can output the data in each cluster
	//printf("finish one-pass clustering \n");
}

void EventRecomOpti::ContinuousUserProfileDataPartitionHP(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
	std::vector<UPEventPartition>& UProfileEventGroupSets, SocialEventOperation& seoper)
{	
	//one pass clustering
	float SimiT = 0.3; //0.05;
	vector<UPEventBucket> subsets;
	onePassClustering(UProfileEventSet, SimiT, subsets);
	//uniform partition
	if(UProfileEventGroupSets.empty())
		UProfileEventGroupSets.resize(NumOfGroups);
	int subsetSize = subsets.size();
	for (int i = 0; i < subsetSize; i++) {
		vector<SubEvent> sseti = subsets[i].getUProfileEventGroup();
		vector<SubEvent>::iterator ssit = sseti.begin();
		int curP = 0;
		while (ssit != sseti.end()) {
			UProfileEventGroupSets[curP].setUProfileEvent((*ssit), 0);
			curP++;
			if (curP == NumOfGroups)
				curP = 0;
			ssit++;
		}
	}
	//======================Jan. 2022	
	float TopicVectoCentre[TFIDF_DIM];
	vector<SubEvent> TFIDFCenters;	
	float minangleCos = 1.0;

	TFIDFCenters.resize(NumOfGroups);
	for (int i = 0; i < NumOfGroups; i++) {
		ComputeTopicCentrePartition(UProfileEventGroupSets[i].getUProfileEventGroup(), TopicVectoCentre);
		TFIDFCenters[i].setConceptTFIDFVec(TopicVectoCentre);
		UProfileEventGroupSets[i].setTFIDFCenter(TFIDFCenters[i]);
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setTFIDFCenter(TFIDFCenters[i]);
		ProduceDataPartitionSummary(UProfileEventGroupSets[i]);
		//ProduceEventBucketSummary(UProfileEventGroupSets[i].getUProfileEventGroup()[0]);
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setTimeRangePair(UProfileEventGroupSets[i].getTimeRangePair());
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setInfluenceRangeVector(UProfileEventGroupSets[i].getInfluenceRangeVector());
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setMaxNumInfluencedUsers(UProfileEventGroupSets[i].getMaxNumInfluencedUsers());
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setMinNumInfluencedUsers(UProfileEventGroupSets[i].getMinNumInfluencedUsers());
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setminimalRadius(UProfileEventGroupSets[i].GetminimalRadius());
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setSpaceRangecentreP(UProfileEventGroupSets[i].getSpaceRangecentreP());

		float minangleCos = ComputePartitionMinAngleCos(UProfileEventGroupSets[i], TFIDFCenters[i]);
		UProfileEventGroupSets[i].setminAngleCos(minangleCos);
		UProfileEventGroupSets[i].getUProfileEventGroup()[0].setminAngleCos(minangleCos);
	}

	cout << "finished data partition" << endl;
	TFIDFCenters.clear();
	//============================
/*	for (int i = 0; i < UProfileEventGroupSets.size(); i++)
		ProduceDataPartitionSummary(UProfileEventGroupSets[i]);*/

	subsets.clear();	
}


//produce hash vectors for Social Events in UProfileEventSet over TFIDF vector and user influence vector
void EventRecomOpti::MapEvent2VecContentUser(std::vector<SubEvent>& UProfileEventSet, LSB& lsb, LSB& lsbuser) {
	std::vector<SubEvent>::iterator eit = UProfileEventSet.begin();
	float* _g = NULL;
	_g = new float[lsb.m];
	int* hashV = NULL;
	hashV = new int[lsb.m];
	while (eit != UProfileEventSet.end())
	{
		getEventHashVector(0, (*eit).GetCluster_ConceptTFIDFVec(), _g, lsb);  //need to be fixed to put influence vector as one of input. Commented by Emily
		for (int i = 0; i < lsb.m; i++)
			hashV[i] = 0;
		lsb.getZ(_g, hashV);

		int halfMVALUE = MVALUE / 2;
		for (int i = 0; i < halfMVALUE; i++)
			(*eit).EHashV[i] = hashV[i];

		getEventHashVector(0, (*eit).GetCluster_UserInfluVec(), _g, lsbuser);  //to put influence vector as one of input. Commented by Emily
		for (int i = 0; i < lsb.m; i++)
			hashV[i] = 0;
		lsbuser.getZ(_g, hashV);

		
		for (int i = halfMVALUE; i < MVALUE; i++)
			(*eit).EHashV[i] = hashV[i- halfMVALUE];

		eit++;
	}
	if (_g != NULL)
		delete _g;
	if (hashV != NULL)
		delete hashV;
}
//produce hash vectors for Social Events in UProfileEventSet
void EventRecomOpti::MapEvent2Vec(std::vector<SubEvent>& UProfileEventSet, LSB &lsb)
{
	std::vector<SubEvent>::iterator eit = UProfileEventSet.begin();
	float * _g = NULL;
	_g = new float[lsb.m];
	int* hashV = NULL;
	hashV=new int[lsb.m];
	while (eit != UProfileEventSet.end())
	{
		getEventHashVector(0, (*eit).GetCluster_ConceptTFIDFVec(), _g,lsb);  //need to be fixed to put influence vector as one of input. Commented by Emily

		for (int i = 0; i < lsb.m; i++)
			hashV[i] = 0;

		lsb.getZ(_g, hashV);

		for (int i = 0; i < MVALUE; i++)
			(*eit).EHashV[i] = hashV[i];
		
		
		eit++;
	}
	if (_g != NULL)
		delete _g;
	if (hashV != NULL)
		delete hashV;
}

void EventRecomOpti::getEventHashVector(int _tableID, float* _key, float* _g, LSB& lsb)
{
	int i;

	int m1 = lsb.m;
	//int m1 = lsb.m * alpha;
	//int m2 = lsb.m - m1;

	for (i = 0; i < m1; i++)
	{
		_g[i] = lsb.get1HashV(_tableID, i, _key);
	}

	/*for (i = m1; i < lsb.m; i++)
	{
		_g[i] = lsb.get1HashV2Influ(_tableID, i, influencekey);
	}*/
}

void EventRecomOpti::ConflictEvents2Buckets(std::vector<SubEvent>& UProfileEventSet,
	std::vector<UPEventBucket>&UPEventBuckets, LSB &lsb, SocialEventOperation &seoper)
{
	std::vector<SubEvent>::iterator upesit = UProfileEventSet.begin();
		
	while (upesit != UProfileEventSet.end()) {
		std::vector<UPEventBucket>::iterator upebit = UPEventBuckets.begin();
		while (upebit != UPEventBuckets.end()) {
			float curdist =  seoper.l2_dist_int((*upebit).getUProfileEventGroup()[0].EHashV, (*upesit).EHashV, MVALUE);
			if (curdist <= 0.00001) //close to 0, find the conflict bucket, put the event into the bucket
			{
				(*upebit).setUProfileEventGroup(*upesit);
				break;
			}				
			upebit++;
		}
		if (upebit == UPEventBuckets.end()) //not find conflict, put a new bucket
		{
			UPEventBucket curEPar;
			curEPar.setUProfileEventGroup(*upesit);
			UPEventBuckets.push_back(curEPar);
		}
		upesit++;
	}
}

void EventRecomOpti::AllocateBucketsofGroups2Processors(std::vector<UPEventBucket> &UPEBuckets,	int NumOfGroups, 
	std::vector<UPEventPartition> &UProfileEventGroupProcessors, LSB &lsb, SocialEventOperation &seoper)
{
	//select the first bucket for the first processor 
	std::vector<UPEventBucket>::iterator upebit, upebitInner, FirstProBit;
	int allocatedProcessorNum = 0;
	if (!UPEBuckets.empty()) 
	{
		upebit = UPEBuckets.begin();
		float maxdist = 0;
		FirstProBit = upebit;
		while (upebit != UPEBuckets.end()) {
			upebitInner = UPEBuckets.begin();
			float curdist = 0;
			while (upebitInner != UPEBuckets.end()) {
				curdist += seoper.l2_dist_int((*upebit).getUProfileEventGroup()[0].EHashV, (*upebitInner).getUProfileEventGroup()[0].EHashV, MVALUE);
				upebitInner++;
			}
			if (curdist > maxdist){
				FirstProBit = upebit;
				maxdist = curdist;
			}
			upebit++;
		}
		UProfileEventGroupProcessors[0].setUProfileEventGroup(*FirstProBit);  //allocate the first bucket for the first processor
		UPEBuckets.erase(FirstProBit);  //remove the bucket
		allocatedProcessorNum++;
	}
	//select the first bucket for each of the rest of processors
	for (int i = allocatedProcessorNum; i < NumOfGroups; i++) {
		if (UPEBuckets.empty())
			break;

		//find the first bucket for processor i
		upebit = UPEBuckets.begin();
		float maxdist = 0;
		FirstProBit = upebit;
		while (upebit != UPEBuckets.end()) {
			float curdist = 0;
			for (int j = 0; j < allocatedProcessorNum; j++) {
				curdist += seoper.l2_dist_int((*upebit).getUProfileEventGroup()[0].EHashV,
					UProfileEventGroupProcessors[j].getUProfileEventGroup()[0].getUProfileEventGroup()[0].EHashV, MVALUE);
			}
			if (curdist > maxdist) {
				maxdist = curdist;
				FirstProBit = upebit;
			}
			upebit++;
		}
		UProfileEventGroupProcessors[i].setUProfileEventGroup(*FirstProBit);  //allocate the first bucket for the ith processor
		UPEBuckets.erase(FirstProBit);  //remove the bucket
		allocatedProcessorNum++;
	}

	//allocate the rest of buckets to NumOfGroups processors
	while (!UPEBuckets.empty()) 
	{
		int proToAllocate = findSmallestGroup(UProfileEventGroupProcessors, NumOfGroups);
		upebit = UPEBuckets.begin();
		float mindist=MAXFLOAT;
		FirstProBit = upebit;
		while (upebit!=UPEBuckets.end())
		{
			float curdist= seoper.l2_dist_int((*upebit).getUProfileEventGroup()[0].EHashV,
				UProfileEventGroupProcessors[proToAllocate].getUProfileEventGroup()[0].getUProfileEventGroup()[0].EHashV, MVALUE);
			if (curdist < mindist) {
				mindist = curdist;
				FirstProBit = upebit;
			}
			upebit++;
		}
		if (FirstProBit != UPEBuckets.end()) {
			UProfileEventGroupProcessors[proToAllocate].setUProfileEventGroup(*FirstProBit);  //allocate the rest bucket for the processor proToAllocate
			UPEBuckets.erase(FirstProBit);  //remove the bucket
		}
	}
}

void EventRecomOpti::ContinuousAllocateBucketsofGroups2Processors(std::vector<UPEventBucket>& UPEBuckets, int NumOfGroups,
	std::vector<UPEventPartition>& UProfileEventGroupProcessors, LSB& lsb, SocialEventOperation& seoper)
{
	std::vector<UPEventBucket>::iterator upebit, FirstProBit;
	//allocate the rest of buckets to NumOfGroups processors
	while (!UPEBuckets.empty()) {
		int proToAllocate = findSmallestGroup(UProfileEventGroupProcessors, NumOfGroups);
		upebit = UPEBuckets.begin();
		float mindist = MAXFLOAT;
		FirstProBit = upebit;
		while (upebit != UPEBuckets.end())
		{
			float curdist = seoper.l2_dist_int((*upebit).getUProfileEventGroup()[0].EHashV,
				UProfileEventGroupProcessors[proToAllocate].getUProfileEventGroup()[0].getUProfileEventGroup()[0].EHashV, MVALUE);
			if (curdist < mindist) {
				mindist = curdist;
				FirstProBit = upebit;
			}
			upebit++;
		}
		if (FirstProBit != UPEBuckets.end()) {
			UProfileEventGroupProcessors[proToAllocate].setUProfileEventGroup(*FirstProBit);  //allocate the rest bucket for the processor proToAllocate
			UPEBuckets.erase(FirstProBit);  //remove the bucket
		}
	}
}


int EventRecomOpti::findSmallestGroup(std::vector<UPEventPartition>& UProfileEventGroupProcessors, int NumOfGroups) {
	int processorNumber = 0;
	int SmallestclusterNum = MAXINT;
	for (int i = 0; i < NumOfGroups; i++) {
		int CurClusterNum = 0;
		for (int j = 0; j < UProfileEventGroupProcessors[i].getUProfileEventGroup().size(); j++) {
			CurClusterNum += UProfileEventGroupProcessors[i].getUProfileEventGroup()[j].getUProfileEventGroup().size();
		}
		if (CurClusterNum < SmallestclusterNum) {
			processorNumber = i;
			SmallestclusterNum = CurClusterNum;
		}
	}
	return processorNumber;
}


void EventRecomOpti::ProduceEventBucketSummary(UPEventBucket& UProfileEventBucket)
{
	float minCluster_ConceptTFIDFVec[TFIDF_DIM] = { MAXFLOAT };
	float maxCluster_ConceptTFIDFVec[TFIDF_DIM] = { -1000.0 };
	float minTopicVectorAngleRanges[TFIDF_DIM] = { MAXFLOAT };
	float maxTopicVectorAngleRanges[TFIDF_DIM] = { -1000.0 };

	for (int i = 0; i < TFIDF_DIM; i++)	{
		minCluster_ConceptTFIDFVec[i] = MAXFLOAT;
		maxCluster_ConceptTFIDFVec[i] = MAXFLOAT*(-1);
		minTopicVectorAngleRanges[i] = MAXFLOAT;
		maxTopicVectorAngleRanges[i] = MAXFLOAT * (-1);
	}

	vector<UPInfluDistriEle> minUserInfluenceDistri, maxUserInfluenceDistri;
	vector<UPInfluDistriEle>::iterator minUIDit, maxUIDit;
	int minUN = MAXINT;
	int maxUN = -1000;

	float minTime = MAXFLOAT;
	float maxTime = MINFLOAT;

	float minLat = MAXFLOAT;
	float maxLat = MAXFLOAT * (-1);

	float minLongi = MAXFLOAT;
	float maxLongi = MAXFLOAT * (-1);

	SpaceRange centP;
	centP.lat = 0;
	centP.longi = 0;
	centP.radius = 0;
	int LocationNum = 0;
	float miniR = MAXFLOAT;
	std::vector<SubEvent>::iterator seit = UProfileEventBucket.getUProfileEventGroup().begin();
	while (seit != UProfileEventBucket.getUProfileEventGroup().end()){
		//for conceptTFIDFVec summary
		float* convec = (*seit).GetCluster_ConceptTFIDFVec();
		for (int i = 0; i < TFIDF_DIM; i++) {
			if (convec[i] > maxCluster_ConceptTFIDFVec[i])
				maxCluster_ConceptTFIDFVec[i] = convec[i];
			if (convec[i] < minCluster_ConceptTFIDFVec[i])
				minCluster_ConceptTFIDFVec[i] = convec[i];
		}
		//for TopicVectorAngleTanRanges summary. added by emily in Dec. 2021.
		float *phi_i = (*seit).GetTFIDFVecAngleSphericalCorSys();
		for (int i = 0; i < TFIDF_DIM - 1; i++) {
			/*if (convec[i] == 0) {
				phi_i = PI * 0.5;//PI*90/180;
			}
			else {
				float tanPhi_i = 0;
				for (int j = i + 1; j < TFIDF_DIM - 1; j++)
					tanPhi_i += pow(convec[j], 2);
				tanPhi_i = sqrt(tanPhi_i) / convec[i];
				phi_i = atan(tanPhi_i);
				if (phi_i < minTopicVectorAngleRanges[i])
					minTopicVectorAngleRanges[i] = phi_i;
				if (phi_i > maxTopicVectorAngleRanges[i])
					maxTopicVectorAngleRanges[i] = phi_i;
			}*/
			if (phi_i[i] < minTopicVectorAngleRanges[i])
				minTopicVectorAngleRanges[i] = phi_i[i];
			if (phi_i[i] > maxTopicVectorAngleRanges[i])
				maxTopicVectorAngleRanges[i] = phi_i[i];
		}
		//for time summary
		TimeRange tr = (*seit).GetTimeRange();
		if (tr.TimeStampCentre > maxTime)
			maxTime = tr.TimeStampCentre;
		if (tr.TimeStampCentre < minTime)
			minTime = tr.TimeStampCentre;
		//for location summary
		SpaceRange sr = (*seit).GetSpaceRange();
		if (sr.lat > maxLat)
			maxLat = sr.lat;
		if (sr.lat < minLat)
			minLat = sr.lat;
		if (sr.longi > maxLongi)
			maxLongi = sr.longi;
		if (sr.longi < minLongi)
			minLongi = sr.longi;
		//////////////////////
		//search clusterCentreSet, and see if sr is in clusterCentreSet already
		vector<SpaceRange>::iterator ccsit = UProfileEventBucket.clusterCentreSet.begin();
		int Inserted = 0;
		while (ccsit != UProfileEventBucket.clusterCentreSet.end()) {
			if ((*ccsit).lat == sr.lat && (*ccsit).longi == sr.longi)	{
				(*ccsit).radius = max((*ccsit).radius, sr.radius);
				Inserted = 1;
				break;
			}
			ccsit++;
		}
		if (!Inserted)
			UProfileEventBucket.clusterCentreSet.push_back(sr);
		//for float minimalRadius; //the minimal radius of subevents in this partion
		if (sr.radius < miniR)
			miniR = sr.radius;

		//for user influences			
		int EventUserNum = (*seit).GetEventUserIDs().size();
		for (int i = 0; i < EventUserNum; i++)	{
			//////////////////////////////////	
			int seitUid = (*seit).GetEventUserIDs()[i].userid;
			std::vector<UPInfluDistriEle>::iterator uidp = UserProfileHashMap[seitUid].UserInfluenceDistri.begin();
			while (uidp != UserProfileHashMap[seitUid].UserInfluenceDistri.end()){
				minUIDit = minUserInfluenceDistri.begin();
				maxUIDit = maxUserInfluenceDistri.begin();
				int insertFlag = 0;
				while (maxUIDit != maxUserInfluenceDistri.end()) {
					if ((*maxUIDit).userid == (*uidp).userid) {
						if ((*uidp).userInflu > (*maxUIDit).userInflu)
							(*maxUIDit).userInflu = (*uidp).userInflu;
						if ((*uidp).userInflu < (*minUIDit).userInflu)
							(*minUIDit).userInflu = (*uidp).userInflu;
						insertFlag = 1;
						break;
					}
					else if ((*maxUIDit).userid > (*uidp).userid) {
						maxUserInfluenceDistri.insert(maxUIDit, (*uidp));
						minUserInfluenceDistri.insert(minUIDit, (*uidp));
						insertFlag = 1;
						break;
					}
					maxUIDit++;
					minUIDit++;
				}
				if (!insertFlag) {
					maxUserInfluenceDistri.push_back(*uidp);
					minUserInfluenceDistri.push_back(*uidp);
				}
				uidp++;
			}
		}
		if (EventUserNum > maxUN)
			maxUN = EventUserNum;
		if (EventUserNum < minUN)
			minUN = EventUserNum;
		seit++;
	}
	
	//for float minimalRadius; //the minimal radius of subevents in this partion
	vector<SpaceRange>::iterator ccsit = UProfileEventBucket.clusterCentreSet.begin();
	centP.lat = 0;
	centP.longi = 0;
	while (ccsit != UProfileEventBucket.clusterCentreSet.end()) {
		centP.lat += (*ccsit).lat;
		centP.longi += (*ccsit).longi;
		ccsit++;
	}
	LocationNum = UProfileEventBucket.clusterCentreSet.size();
	centP.lat /= LocationNum;
	centP.longi /= LocationNum;
	//compute the centreP.radius
	seit = UProfileEventBucket.getUProfileEventGroup().begin();
	while (seit != UProfileEventBucket.getUProfileEventGroup().end()){
		SpaceRange sr = (*seit).GetSpaceRange();
		SubEvent subevt;
		float GreatCircleDist = subevt.get_distance(centP.lat, centP.longi, sr.lat, sr.longi);
		float tmpRadius = GreatCircleDist + sr.radius;
		if (tmpRadius > centP.radius)
			centP.radius = tmpRadius;
		seit++;
	}
	UProfileEventBucket.setSpaceRangecentreP(centP);
	UProfileEventBucket.setminimalRadius(miniR);

	ValueRangePair TopicRangeVec[TFIDF_DIM];
	for (int i = 0; i < TFIDF_DIM; i++) {
		TopicRangeVec[i].minV = minCluster_ConceptTFIDFVec[i];
		TopicRangeVec[i].maxV = maxCluster_ConceptTFIDFVec[i];
	}
	UProfileEventBucket.setTopicRangeVector(TopicRangeVec);

	//================
	ValueRangePair TopicVecAngleRange[TFIDF_DIM];
	for (int i = 0; i < TFIDF_DIM; i++) {
		TopicVecAngleRange[i].minV = minTopicVectorAngleRanges[i];
		TopicVecAngleRange[i].maxV = maxTopicVectorAngleRanges[i];
	}
	UProfileEventBucket.setTopicVectorAngleTanRanges(TopicVecAngleRange);
	//=======================
	ValueRangePair TimeRangePair;
	TimeRangePair.maxV = maxTime;
	TimeRangePair.minV = minTime;
	UProfileEventBucket.setTimeRangePair(TimeRangePair);

	ValueRangePair SpaceRangePairs[2];
	SpaceRangePairs[0].maxV = maxLat;
	SpaceRangePairs[0].minV = minLat;
	SpaceRangePairs[1].maxV = maxLongi;
	SpaceRangePairs[1].minV = minLongi;
	UProfileEventBucket.setSpaceRangePair(SpaceRangePairs);

	vector<UserValueRangePair> influenceRangeVec;
	UserValueRangePair UVRP;
	for (int i = 0; i < minUserInfluenceDistri.size(); i++) {
		UVRP.userid = minUserInfluenceDistri[i].userid;
		UVRP.minV = minUserInfluenceDistri[i].userInflu;
		UVRP.maxV = maxUserInfluenceDistri[i].userInflu;
		influenceRangeVec.push_back(UVRP);
	}
	//UProfileEventBucket.getInfluenceRangeVector().clear();
	UProfileEventBucket.setInfluenceRangeVector(influenceRangeVec);
	UProfileEventBucket.setMaxNumInfluencedUsers(maxUN);
	UProfileEventBucket.setMinNumInfluencedUsers(minUN);


	minUserInfluenceDistri.clear();
	maxUserInfluenceDistri.clear();
	influenceRangeVec.clear();/**/
}
void EventRecomOpti::ProduceDataPartitionSummary(UPEventPartition & UProfileEventGroup)
{	
	float minCluster_ConceptTFIDFVec[TFIDF_DIM] = { MAXFLOAT };
	float maxCluster_ConceptTFIDFVec[TFIDF_DIM] = { -1000.0 };

	float minTopicVectorAngleRanges[TFIDF_DIM] = { MAXFLOAT };
	float maxTopicVectorAngleRanges[TFIDF_DIM] = { -1000.0 };

	for (int i = 0; i < TFIDF_DIM; i++)
	{
		minCluster_ConceptTFIDFVec[i] = MAXFLOAT;
		maxCluster_ConceptTFIDFVec[i] = MAXFLOAT * (-1);
		minTopicVectorAngleRanges[i] = MAXFLOAT;
		maxTopicVectorAngleRanges[i] = MAXFLOAT * (-1);
	}

	vector<UPInfluDistriEle> minUserInfluenceDistri, maxUserInfluenceDistri;
	vector<UPInfluDistriEle>::iterator minUIDit, maxUIDit;
	int minUN = MAXINT;
	int maxUN = -1000;
	
	float minTime = MAXFLOAT;
	float maxTime = -1000.0;

	float minLat = MAXFLOAT;
	float maxLat = MAXFLOAT * (-1);

	float minLongi = MAXFLOAT;
	float maxLongi = MAXFLOAT * (-1);
	
	SpaceRange centP;
	centP.lat = 0;
	centP.longi = 0;
	centP.radius = 0;
	int LocationNum = 0;

	
	float miniR = MAXFLOAT;

	std::vector<UPEventBucket>::iterator upegit = UProfileEventGroup.getUProfileEventGroup().begin();
	while (upegit != UProfileEventGroup.getUProfileEventGroup().end()) 
	{
		std::vector<SubEvent>::iterator seit = (*upegit).getUProfileEventGroup().begin();
		while (seit != (*upegit).getUProfileEventGroup().end()) 
		{
			//for conceptTFIDFVec summary
			float* convec = (*seit).GetCluster_ConceptTFIDFVec();
			for (int i = 0; i < TFIDF_DIM; i++)	{
				if (convec[i] > maxCluster_ConceptTFIDFVec[i])
					maxCluster_ConceptTFIDFVec[i] = convec[i];
				if (convec[i] < minCluster_ConceptTFIDFVec[i])
					minCluster_ConceptTFIDFVec[i] = convec[i];
			}
			//for TopicVectorAngleTanRanges summary. added by emily in Dec. 2021.
				float *phi_i = (*seit).GetTFIDFVecAngleSphericalCorSys();
				for (int i = 0; i < TFIDF_DIM-1; i++) {				
				/*if (convec[i] == 0) {
					phi_i = PI * 0.5;//PI*90/180;
				}
				else {					
					float tanPhi_i = 0;
					for (int j = i + 1; j < TFIDF_DIM-1; j++)
						tanPhi_i += pow(convec[j], 2);
					tanPhi_i = sqrt(tanPhi_i)/convec[i];
					phi_i = atan(tanPhi_i);

					if (phi_i < minTopicVectorAngleRanges[i])
						minTopicVectorAngleRanges[i] = phi_i;
					if (phi_i > maxTopicVectorAngleRanges[i])
						maxTopicVectorAngleRanges[i] = phi_i;
				}*/
				if (phi_i[i] < minTopicVectorAngleRanges[i])
					minTopicVectorAngleRanges[i] = phi_i[i];
				if (phi_i[i] > maxTopicVectorAngleRanges[i])
					maxTopicVectorAngleRanges[i] = phi_i[i];
			}
			//for time summary
			TimeRange tr = (*seit).GetTimeRange();
			if (tr.TimeStampCentre > maxTime)
				maxTime = tr.TimeStampCentre;
			if (tr.TimeStampCentre < minTime)
				minTime = tr.TimeStampCentre;
			//for location summary
			SpaceRange sr = (*seit).GetSpaceRange();
			if (sr.lat > maxLat)
				maxLat = sr.lat;
			if (sr.lat < minLat)
				minLat = sr.lat;
			if (sr.longi > maxLongi)
				maxLongi = sr.longi;
			if (sr.longi < minLongi)
				minLongi = sr.longi;
			//////////////////////
			//for SpaceRange centreP; //the centre location point of all the subevents 
			//centP.lat += sr.lat;
			//centP.longi += sr.longi;
			//LocationNum++;
			//search clusterCentreSet, and see if sr is in clusterCentreSet already
			vector<SpaceRange>::iterator ccsit = UProfileEventGroup.clusterCentreSet.begin();
			int Inserted = 0;
			while (ccsit != UProfileEventGroup.clusterCentreSet.end()) {
				if ((*ccsit).lat == sr.lat && (*ccsit).longi == sr.longi)
				{
					(*ccsit).radius = max((*ccsit).radius, sr.radius);
					Inserted = 1;
					break;
				}
				ccsit++;
			}
			if (!Inserted)
				UProfileEventGroup.clusterCentreSet.push_back(sr);
			//for float minimalRadius; //the minimal radius of subevents in this partion
			if(sr.radius<miniR)
				miniR=sr.radius;
			
			//for user influences			
			int EventUserNum = (*seit).GetEventUserIDs().size();
			for (int i = 0; i < EventUserNum; i++) 
			{
				//////////////////////////////////	
				int seitUid = (*seit).GetEventUserIDs()[i].userid;
				std::vector<UPInfluDistriEle>::iterator uidp = UserProfileHashMap[seitUid].UserInfluenceDistri.begin();
				while (uidp != UserProfileHashMap[seitUid].UserInfluenceDistri.end())
				{
					minUIDit = minUserInfluenceDistri.begin();
					maxUIDit = maxUserInfluenceDistri.begin();
					int insertFlag = 0;
					while (maxUIDit != maxUserInfluenceDistri.end()) {
						if ((*maxUIDit).userid == (*uidp).userid) {
							if ((*uidp).userInflu > (*maxUIDit).userInflu) 
								(*maxUIDit).userInflu = (*uidp).userInflu;
							if ((*uidp).userInflu < (*minUIDit).userInflu)
								(*minUIDit).userInflu = (*uidp).userInflu;
							insertFlag = 1;
							break;
						}
						else if ((*maxUIDit).userid > (*uidp).userid){
							maxUserInfluenceDistri.insert(maxUIDit, (*uidp));
							minUserInfluenceDistri.insert(minUIDit, (*uidp));
							insertFlag = 1;
							break;
						}
						maxUIDit++;
						minUIDit++;
					}
					if (!insertFlag){
						maxUserInfluenceDistri.push_back(*uidp);
						minUserInfluenceDistri.push_back(*uidp);
					}
					uidp++;
				}				
			}
			
			//for UN
			/*int influencedUserNum = 0;
			for (int i = 0; i < maxUserInfluenceDistri.size(); i++) {
				influencedUserNum++;
			}*/
			if (EventUserNum > maxUN)
				maxUN = EventUserNum;
			if (EventUserNum < minUN)
				minUN = EventUserNum;
			

			seit++;
		}		
		upegit++;
	}

	//for float minimalRadius; //the minimal radius of subevents in this partion
	vector<SpaceRange>::iterator ccsit = UProfileEventGroup.clusterCentreSet.begin();
	centP.lat = 0;
	centP.longi = 0;
	while (ccsit != UProfileEventGroup.clusterCentreSet.end()) {
		centP.lat += (*ccsit).lat;
		centP.longi += (*ccsit).longi;
		ccsit++;
	}
	LocationNum = UProfileEventGroup.clusterCentreSet.size();
	centP.lat /= LocationNum;
	centP.longi/= LocationNum;
	//compute the centreP.radius
	upegit = UProfileEventGroup.getUProfileEventGroup().begin();
	while (upegit != UProfileEventGroup.getUProfileEventGroup().end())
	{
		std::vector<SubEvent>::iterator seit = (*upegit).getUProfileEventGroup().begin();
		while (seit != (*upegit).getUProfileEventGroup().end())
		{
			SpaceRange sr = (*seit).GetSpaceRange();
			SubEvent subevt;
			float GreatCircleDist = subevt.get_distance(centP.lat, centP.longi, sr.lat, sr.longi);
			float tmpRadius = GreatCircleDist + sr.radius;
			if (tmpRadius > centP.radius)
				centP.radius = tmpRadius;

			seit++;
		}
		upegit++;
	}
	
	UProfileEventGroup.setSpaceRangecentreP(centP);	
	UProfileEventGroup.setminimalRadius(miniR);
			
	ValueRangePair TopicRangeVec[TFIDF_DIM];
	for (int i = 0; i < TFIDF_DIM; i++) {
		TopicRangeVec[i].minV = minCluster_ConceptTFIDFVec[i];
		TopicRangeVec[i].maxV = maxCluster_ConceptTFIDFVec[i];
	}
	UProfileEventGroup.setTopicRangeVector(TopicRangeVec);

	//================
	ValueRangePair TopicVecAngleRange[TFIDF_DIM];
	for (int i = 0; i < TFIDF_DIM; i++) {
		TopicVecAngleRange[i].minV = minTopicVectorAngleRanges[i];
		TopicVecAngleRange[i].maxV = maxTopicVectorAngleRanges[i];
	}
	UProfileEventGroup.setTopicVectorAngleTanRanges(TopicVecAngleRange);
	//=======================
	ValueRangePair TimeRangePair;
	TimeRangePair.maxV = maxTime;
	TimeRangePair.minV = minTime;
	UProfileEventGroup.setTimeRangePair(TimeRangePair);

	ValueRangePair SpaceRangePairs[2];
	SpaceRangePairs[0].maxV = maxLat;
	SpaceRangePairs[0].minV = minLat;
	SpaceRangePairs[1].maxV = maxLongi;
	SpaceRangePairs[1].minV = minLongi;
	UProfileEventGroup.setSpaceRangePair(SpaceRangePairs);

	vector<UserValueRangePair> influenceRangeVec;
	UserValueRangePair UVRP;
	for (int i = 0; i < minUserInfluenceDistri.size(); i++) {
		UVRP.userid = minUserInfluenceDistri[i].userid;
		UVRP.minV = minUserInfluenceDistri[i].userInflu;
		UVRP.maxV = maxUserInfluenceDistri[i].userInflu;
		
		influenceRangeVec.push_back(UVRP);
	}
	//UProfileEventGroup.getInfluenceRangeVector().clear();
	UProfileEventGroup.setInfluenceRangeVector(influenceRangeVec);
	UProfileEventGroup.setMaxNumInfluencedUsers(maxUN);
	UProfileEventGroup.setMinNumInfluencedUsers(minUN);	
	
	minUserInfluenceDistri.clear();
	maxUserInfluenceDistri.clear();
	influenceRangeVec.clear();
}

void EventRecomOpti::IncomingEventSubsetIdentification(std::vector<SubEvent>&IncomingEventSet, std::vector<SubEvent>&IncomingEventSubset,
	UPEventPartition &UPEPar, float SimiThreshold, float alpha)
{
	std::vector<SubEvent>::iterator IESit = IncomingEventSet.begin();
	while (IESit != IncomingEventSet.end()) {	
		float upmax = ComputeUPmax(UPEPar, (*IESit),alpha, SimiThreshold);
		if (upmax >= SimiThreshold)
			IncomingEventSubset.push_back(*IESit);
		IESit++;
	}
}

//==================modified by Emily on 27 Feb.2021
float EventRecomOpti::ComputeUPmax(UPEventPartition& UserProfileEventPartition, SubEvent& IncomingEvent, float alpha, float SimiThreshold)
{
	float UPmax = -1;
	int i = 0;
	//====filter based on the partition level first, if can be filtered, return directly========================
	ValueRangePair vrp = UserProfileEventPartition.getTimeRangePair();
	SpaceRange vrpSpaceRange = UserProfileEventPartition.getSpaceRangecentreP();
	float miniRadius = UserProfileEventPartition.GetminimalRadius();
	/*float UPmaxLocation = ComputeUPmaxLocationNew(vrpSpaceRange, miniRadius, IncomingEvent) * (1 - omeg1 - omeg2) * (1 - alpha);
	float UPmaxTime = ComputeUPmaxTime(vrp, IncomingEvent) * omeg2 * (1 - alpha);*/
	float UPmaxLocation = (1 - omeg1 - omeg2) * (1 - alpha);
	float UPmaxTime = omeg2 * (1 - alpha);

	float UPmaxT = ComputeUPmaxT(UserProfileEventPartition, IncomingEvent, -1) * omeg1 * (1 - alpha);  //based on super-cone only
	float UPmaxI = ComputeProb_EvEn(UserProfileEventPartition, IncomingEvent, -1) * alpha;
	
	UPmax = UPmaxT + UPmaxI + UPmaxLocation + UPmaxTime;
	if (UPmax < SimiThreshold) {
		cout << "filtered by partition" << endl;
		return UPmax;
	}

	//============================
	UPmax = -1;
	int bucketnum = UserProfileEventPartition.getUProfileEventGroup().size();
	for (int i = 0; i < bucketnum; i++) {
		vrp = UserProfileEventPartition.getUProfileEventGroup()[i].getTimeRangePair();
		vrpSpaceRange = UserProfileEventPartition.getUProfileEventGroup()[i].getSpaceRangecentreP();
		miniRadius = UserProfileEventPartition.getUProfileEventGroup()[i].GetminimalRadius();
		UPmaxLocation = ComputeUPmaxLocationNew(vrpSpaceRange, miniRadius, IncomingEvent) * (1 - omeg1 - omeg2) * (1 - alpha);
		UPmaxTime = ComputeUPmaxTime(vrp, IncomingEvent) * omeg2 * (1 - alpha);/**/		

		UPmaxT = ComputeUPmaxT(UserProfileEventPartition, IncomingEvent, i) * omeg1 * (1 - alpha);
		
		UPmaxI = ComputeProb_EvEn(UserProfileEventPartition, IncomingEvent,i) * alpha;

		float UPmaxTmp = UPmaxT + UPmaxI + UPmaxLocation + UPmaxTime;
		if (UPmaxTmp > UPmax) 
			UPmax = UPmaxTmp;
		if (UPmax >= SimiThreshold) //cannot be filtered, stop early
			return UPmax;
	}
	//if(i==bucketnum)
		cout << "filtered by bucket" << endl;

	return UPmax;
}

int EventRecomOpti::GetCrossCircleLineCrossPoint(SpaceRange& sr, SubEvent& IncomingEvent, SpaceRange& crossPoint) {
	int ret = 0; //the point is outside of circle
	//compute distance on earth
	float distSRInEvent;
	SpaceRange inEcentre = IncomingEvent.GetSpaceRange();
	distSRInEvent = IncomingEvent.get_distance(sr.lat, sr.longi, inEcentre.lat, inEcentre.longi);

	float crossPtoInE = distSRInEvent - sr.radius; //distance between crossPoint and Incoming event centre
	if (crossPtoInE <= 0) //insideo of the circle
		return ret;
	
	//calculate crosspoint based on CircleCentretoCrossPAngle, sr and the position of incomingEvent
	crossPoint.lat = (sr.lat * crossPtoInE + inEcentre.lat * sr.radius) / (crossPtoInE + sr.radius);
	crossPoint.longi= (sr.longi * crossPtoInE + inEcentre.longi * sr.radius) / (crossPtoInE + sr.radius);
	ret = 1;

	return ret;
}
float EventRecomOpti::ComputeUPmaxLocationNew(SpaceRange& sr, float & minimalRange, SubEvent& IncomingEvent) {
	float UPmaxLocation = 1;  //inside the circle
	SubEvent virtualEvent;
	SpaceRange crossPoint;
	crossPoint.radius = minimalRange;
	int ret=GetCrossCircleLineCrossPoint(sr, IncomingEvent, crossPoint);
	if (ret == 0)  //inside of the circle
		return UPmaxLocation;

	virtualEvent.setSpaceRange(crossPoint);
	virtualEvent.uploadmsgSRset(crossPoint);

	UPmaxLocation=virtualEvent.GetSpaceSimilarity(&IncomingEvent);
	
	return UPmaxLocation;
}

float EventRecomOpti::ComputeCircleSlopeCoefficient(SpaceRange* sr) {//K--Tan angle
	float K, angle;
	angle = (180 - sr->longi) / 2;
	K = tan(angle);
	return K;
}

//=finished ==================modification by Emily on 27 Feb.2021===========================================================

float EventRecomOpti::ComputeUPmaxTime(ValueRangePair& vrp, SubEvent& IncomingEvent) {
	float UPmaxTime = 0;

	SubEvent virtualEvent;
	TimeRange tr;
	tr.TimeStampCentre = vrp.maxV;
	tr.range = TIMERADIUST;
	virtualEvent.setTimeRange(tr);

	UPmaxTime = virtualEvent.GetTimeSimilarity(&IncomingEvent);

	return UPmaxTime;
}

float EventRecomOpti::ComputeUPmaxT(UPEventPartition& UserProfileEventPartition, SubEvent& IncomingEvent, int bucketNo)
{
	float UPmaxT = -1.0;

	/*SocialMSG smg;
	float virtualConceptVec[TFIDF_DIM] = { 0 };
	for (int j = 0; j < TFIDF_DIM; j++)
		virtualConceptVec[j] = 0;
	float* incomingConceptVec = IncomingEvent.GetCluster_ConceptTFIDFVec();
	
	ValueRangePair* upepAngle = UserProfileEventPartition.getTopicVectorAngleTanRanges();
	GetTBoundAngleValueofDim(upepAngle, incomingConceptVec, virtualConceptVec);

	UPmaxT = smg.GetConceptVectorSimilarity(virtualConceptVec, IncomingEvent.GetCluster_ConceptTFIDFVec());*/
	/*vector<int> DominantDim;
	ValueRangePair* vpr = UserProfileEventPartition.getTopicRangeVector();
	float* eventvrp = IncomingEvent.GetCluster_ConceptTFIDFVec();
	if (IncomingEvent.GetEventNo() == 5280)
		cout << "dbug" << endl;
	int DomiSize=SelectDimOutRect(vpr, eventvrp, DominantDim,UPmaxT);
	if(DomiSize>2) //if only have two dominant dimensions or have no dominant dimension. UPmaxT is calculated in SelectDimOutRect already, no need function call
		UPmaxT=GetTBoundCosofDominantDim(vpr, eventvrp, DominantDim);

	DominantDim.clear();*/

	float alphacosin = 0;
	float Betacosin = 0;

	if (bucketNo == -1)  //compute based on the whole partition 
	{
		alphacosin = IncomingEvent.GetConceptSimilarity(&UserProfileEventPartition.getTFIDFCenter());
		Betacosin = UserProfileEventPartition.getminAngleCos();
	}
	else {  //compute based on bucket with buckNo
		alphacosin = IncomingEvent.GetConceptSimilarity(&UserProfileEventPartition.getUProfileEventGroup()[bucketNo].getTFIDFCenter());
		Betacosin = UserProfileEventPartition.getUProfileEventGroup()[bucketNo].getminAngleCos();
	}
	if (alphacosin > Betacosin)  //inside the hyper-cone
		UPmaxT = 1;
	else {
		float tmpUPmaxT = alphacosin * Betacosin + sqrt(1 - alphacosin * alphacosin) * sqrt(1 - Betacosin * Betacosin);/**/
		//test if it is bounded		
		vector<SubEvent>::iterator lit, enlit;	
		if (bucketNo != -1)	{		
			lit = UserProfileEventPartition.getUProfileEventGroup()[bucketNo].getUProfileEventGroup().begin();
			enlit = UserProfileEventPartition.getUProfileEventGroup()[bucketNo].getUProfileEventGroup().end();
		
			while (lit != enlit) {
				float alp = IncomingEvent.GetConceptSimilarity(&(*lit));
				if (alp > tmpUPmaxT)
					cout << "BucketNum: " << bucketNo << "not bounded" << "alp=" << alp << "\t tmpUPmaxT=" << tmpUPmaxT << endl;
				lit++;
			}
		}
		else {
			int bucketNum=UserProfileEventPartition.getUProfileEventGroup().size();
			for (int i = 0; i < bucketNum; i++) {
				lit = UserProfileEventPartition.getUProfileEventGroup()[i].getUProfileEventGroup().begin();
				enlit = UserProfileEventPartition.getUProfileEventGroup()[i].getUProfileEventGroup().end();

				while (lit != enlit) {
					float alp = IncomingEvent.GetConceptSimilarity(&(*lit));
					if (alp > tmpUPmaxT)
						cout << "BucketNum: " << bucketNo << "not bounded" << "alp=" << alp << "\t tmpUPmaxT=" << tmpUPmaxT << endl;
					lit++;
				}
			}
		}/**/
		//========================
		if (tmpUPmaxT > UPmaxT)
			UPmaxT = tmpUPmaxT;
	}
	
	return UPmaxT;
}


//added by Emily in Jan. 2022
float EventRecomOpti::GetTBoundValue(ValueRangePair* UserParVPRect, float* EventVRP, float* VirtualEventTopic, 
	vector<DimHashKeyPair>& commondims, float &ModuleVirETopicSquare, float &ModuleEVRPSquare, UPEventBucket & upebut, SubEvent& IncomingEvent)
{
	float BoundValue = 0;  //the maximal cosine value between UserParVPRect and EventVRP. i.e. between EventVRP and VirtualEventTopic
	int StartDim = -1;
	int EndDim = -1;
	int ComDimSize = commondims.size();
	for (int i = 0; i < ComDimSize; i++){
		//choose StartDim;
		if (StartDim == -1){  //StartDim has not been selected		
			//check if commondims[i] meet requirement
			if (UserParVPRect[commondims[i].dim].maxV == 0 || UserParVPRect[commondims[i].dim].minV == 0
				|| EventVRP[commondims[i].dim] == 0)  //not ok
				continue;
			else
				StartDim = commondims[i].dim;
		}
		else {
			if (UserParVPRect[commondims[i].dim].maxV == 0 || UserParVPRect[commondims[i].dim].minV == 0
				|| EventVRP[commondims[i].dim] == 0)  //not ok
				continue;
			else {
				EndDim = commondims[i].dim;
				break;
			}
		}
	}

	//choose the first 2 dimension bound values. 
	//based on data partition, mini and maxi or minj and maxj in commondims can only be in the same quadrant. 
    //So the rectangle can cover quadrant 1, 2, 3, 4 only. Cannot cover two quadrants
	float StartEndPoints[2][2];
	int i = StartDim;
	int j = EndDim;
	if (UserParVPRect[i].minV > 0 && UserParVPRect[j].minV > 0){//quadrant 1
		StartEndPoints[0][0] = UserParVPRect[i].maxV;
		StartEndPoints[0][1] = UserParVPRect[j].minV;
		StartEndPoints[1][0] = UserParVPRect[i].minV;
		StartEndPoints[1][1] = UserParVPRect[j].maxV;
	}
	else if (UserParVPRect[i].maxV < 0 && UserParVPRect[j].minV > 0) { //qadrant 2
		StartEndPoints[0][0] = UserParVPRect[i].maxV;
		StartEndPoints[0][1] = UserParVPRect[j].maxV;
		StartEndPoints[1][0] = UserParVPRect[i].minV;
		StartEndPoints[1][1] = UserParVPRect[j].minV;
	}
	else if (UserParVPRect[i].maxV < 0 && UserParVPRect[j].maxV < 0) { //qadrant 3
		StartEndPoints[0][0] = UserParVPRect[i].minV;
		StartEndPoints[0][1] = UserParVPRect[j].maxV;
		StartEndPoints[1][0] = UserParVPRect[i].maxV;
		StartEndPoints[1][1] = UserParVPRect[j].minV;
	}
	else if (UserParVPRect[i].minV > 0 && UserParVPRect[j].maxV < 0) {//qadrant 4
		StartEndPoints[0][0] = UserParVPRect[i].minV;
		StartEndPoints[0][1] = UserParVPRect[j].minV;
		StartEndPoints[1][0] = UserParVPRect[i].maxV;
		StartEndPoints[1][1] = UserParVPRect[j].maxV;
	}
	
	float StartPointVecCos = StartEndPoints[0][0]/sqrt(pow(StartEndPoints[0][0],2)+pow(StartEndPoints[0][1],2));
	float EndPointVecCos = StartEndPoints[1][0] / sqrt(pow(StartEndPoints[1][0], 2) + pow(StartEndPoints[1][1], 2));
	float EventCos = EventVRP[i] / sqrt(pow(EventVRP[i], 2) + pow(EventVRP[j], 2));
	
	if (UserParVPRect[j].minV > 0) {//for qadrant 1 and 2, cosine decreases with angle increasing
		if (EventVRP[j] > 0){  //qadrant 1,2 for EventVRP.		
			if (EventCos < EndPointVecCos) { //for the case like T3 in the figure 6 of the paper
				VirtualEventTopic[i] = StartEndPoints[1][0];
				VirtualEventTopic[j] = StartEndPoints[1][1];
				BoundValue = 1;
			}
			else if(EventCos>StartPointVecCos){  //for the case like T2 in the figure 6 of the paper			
				VirtualEventTopic[i] = StartEndPoints[0][0];
				VirtualEventTopic[j] = StartEndPoints[0][1];
				BoundValue = 1;
			}
			else {////for the case like T1 in the figure 6 of the paper			
				VirtualEventTopic[0] = EventVRP[0];
				VirtualEventTopic[1] = EventVRP[1];
			}
		}
		else {//qadrant 3,4 for EventVRP. always outside of the supercoin
			float startEventAngleCosine=(StartEndPoints[0][0]*EventVRP[i]+StartEndPoints[0][1]*EventVRP[j])/ 
				(sqrt(pow(StartEndPoints[0][0], 2) + pow(StartEndPoints[0][1], 2))* sqrt(pow(EventVRP[i], 2) + pow(EventVRP[j], 2)));

			float endEventAngleCosine = (StartEndPoints[1][0] * EventVRP[i] + StartEndPoints[1][1] * EventVRP[j]) /
				(sqrt(pow(StartEndPoints[1][0], 2) + pow(StartEndPoints[1][1], 2)) * sqrt(pow(EventVRP[i], 2) + pow(EventVRP[j], 2)));

			if (startEventAngleCosine > endEventAngleCosine){
				VirtualEventTopic[i] = StartEndPoints[0][0];
				VirtualEventTopic[j] = StartEndPoints[0][1];
				BoundValue = 1;
			}
			else {
				VirtualEventTopic[i] = StartEndPoints[1][0];
				VirtualEventTopic[j] = StartEndPoints[1][1];
				BoundValue = 1;
			}
		}
	}
	else if (UserParVPRect[j].maxV < 0) {//for qadrant 3 and 4, cosine increases with angle increasing
		if (EventVRP[j] < 0) {  //qadrant 3,4 for EventVRP.		
			if (EventCos > EndPointVecCos) { //for the case like T3 in the figure 6 of the paper
				VirtualEventTopic[i] = StartEndPoints[1][0];
				VirtualEventTopic[j] = StartEndPoints[1][1];
				BoundValue = 1;
			}
			else if (EventCos < StartPointVecCos) {  //for the case like T2 in the figure 6 of the paper			
				VirtualEventTopic[i] = StartEndPoints[0][0];
				VirtualEventTopic[j] = StartEndPoints[0][1];
				BoundValue = 1;
			}
			else {////for the case like T1 in the figure 6 of the paper			
				VirtualEventTopic[0] = EventVRP[0];
				VirtualEventTopic[1] = EventVRP[1];
			}
		}
		else {//qadrant 1,2 for EventVRP. always outside of the supercoin
			float startEventAngleCosine = (StartEndPoints[0][0] * EventVRP[i] + StartEndPoints[0][1] * EventVRP[j]) /
				(sqrt(pow(StartEndPoints[0][0], 2) + pow(StartEndPoints[0][1], 2)) * sqrt(pow(EventVRP[i], 2) + pow(EventVRP[j], 2)));

			float endEventAngleCosine = (StartEndPoints[1][0] * EventVRP[i] + StartEndPoints[1][1] * EventVRP[j]) /
				(sqrt(pow(StartEndPoints[1][0], 2) + pow(StartEndPoints[1][1], 2)) * sqrt(pow(EventVRP[i], 2) + pow(EventVRP[j], 2)));

			if (startEventAngleCosine > endEventAngleCosine) {
				VirtualEventTopic[i] = StartEndPoints[0][0];
				VirtualEventTopic[j] = StartEndPoints[0][1];
				BoundValue = 1;
			}
			else {
				VirtualEventTopic[i] = StartEndPoints[1][0];
				VirtualEventTopic[j] = StartEndPoints[1][1];
				BoundValue = 1;
			}
		}
	}

	
	//after select dim 1, 2 values, select the following values one by one with the condition of previous values
	float DimValMultiply = VirtualEventTopic[i] * EventVRP[i] + VirtualEventTopic[j] * EventVRP[j];
	float ModuleVirtualEventTopicSquare = pow(VirtualEventTopic[i], 2) + pow(VirtualEventTopic[j], 2);
	float ModuleEventVRPSquare= pow(EventVRP[i], 2) + pow(EventVRP[j], 2);	
	//===========
	//test if it is bounded
	BoundValue = DimValMultiply / (sqrt(ModuleVirtualEventTopicSquare) * sqrt(ModuleEventVRPSquare));
	vector<SubEvent>::iterator lit = upebut.getUProfileEventGroup().begin();
	vector<SubEvent>::iterator enlit = upebut.getUProfileEventGroup().end();
	float IncomingNoComModuleSquare, BucketVirENoComModuleSquare;
	vector<DimHashKeyPair> TmpcommHashDims;
	TmpcommHashDims.push_back(commondims[i]);
	TmpcommHashDims.push_back(commondims[j]);
	while (lit != enlit) {
		float alp = IncomingEvent.GetConceptSimilarityDimSubset(&(*lit), upebut.commonHashDimSet, IncomingNoComModuleSquare, BucketVirENoComModuleSquare);
		if (alp > BoundValue)
			cout << "Hash not bounded \t" << "alp=" << alp << "\t BoundValue=" << BoundValue << endl;
		lit++;
	}
	//==================
	//=============
		
	for (int k = 0; k < ComDimSize; k++) {
		if (commondims[k].dim == StartDim || commondims[k].dim == EndDim)  //skip the first two selected dimensions
			continue;
		//select the next dim value for VirtualEventTopic, i.e.VirtualEventTopic[commondims[k].dim]
		//check UserParVPRect[commondims[k].dim].minV and UserParVPRect[commondims[k].dim].maxV, and EventVRP[commondims[k].dim]
		int dno = commondims[k].dim;
		float Event2MaxV = EventVRP[dno] * UserParVPRect[dno].maxV;
		float Event2MinV = EventVRP[dno] * UserParVPRect[dno].minV;
		float maxDimValMultiply = DimValMultiply + EventVRP[dno] * max(Event2MaxV, Event2MinV);
		float minDimValMultiply = DimValMultiply + EventVRP[dno] * min(Event2MaxV, Event2MinV);		
		
		if (minDimValMultiply >= 0) {//DimValMultiply is positive only in the one dimension higher subspace
			//compute x_3=(y_3 (x_1^2+x_2^2))/(x_1 y_1+x_2 y_2 )
			VirtualEventTopic[dno]=EventVRP[dno]* ModuleVirtualEventTopicSquare/DimValMultiply;
			if (VirtualEventTopic[dno] > UserParVPRect[dno].maxV) {
				VirtualEventTopic[dno] = UserParVPRect[dno].maxV;
				DimValMultiply += Event2MaxV;
				ModuleVirtualEventTopicSquare += pow(UserParVPRect[dno].maxV, 2);
			}
			else if (VirtualEventTopic[dno] < UserParVPRect[dno].minV) {
				VirtualEventTopic[dno] = UserParVPRect[dno].minV;
				DimValMultiply += Event2MinV;
				ModuleVirtualEventTopicSquare += pow(UserParVPRect[dno].minV, 2);
			}
			else { //for the peak point			
				DimValMultiply += VirtualEventTopic[dno];
				ModuleVirtualEventTopicSquare += pow(VirtualEventTopic[dno], 2);
			}
		}
		else if (maxDimValMultiply <= 0) {//DimValMultiply is negative only in the one dimension higher subspace
			//compute f(x_3 )=(〖(x〗_1 y_1+x_2 y_2+x_3 y_3))/〖〖(y_1^2+y_2^2+y_3^2)〗^(1/2)  (x_1^2+x_2^2+x_3^2 )〗^((1/2)) 
			float CurModuleVirtualEventSquareMax = ModuleVirtualEventTopicSquare + pow(UserParVPRect[dno].maxV, 2);
			float CurModuleVirtualEventSquareMin = ModuleVirtualEventTopicSquare + pow(UserParVPRect[dno].minV, 2);
			float TmaxDimValMultiply = DimValMultiply + UserParVPRect[dno].maxV * EventVRP[dno];
			float TminDimValMultiply = DimValMultiply + UserParVPRect[dno].minV * EventVRP[dno];
			float maxf = TmaxDimValMultiply / CurModuleVirtualEventSquareMax;
			float minf = TminDimValMultiply / CurModuleVirtualEventSquareMin;
			if (maxf > minf) {
				VirtualEventTopic[dno] = UserParVPRect[dno].maxV;
				DimValMultiply = TmaxDimValMultiply;
				ModuleVirtualEventTopicSquare = CurModuleVirtualEventSquareMax;
			}
			else {
				VirtualEventTopic[dno] = UserParVPRect[dno].minV;
				DimValMultiply = TminDimValMultiply;
				ModuleVirtualEventTopicSquare = CurModuleVirtualEventSquareMin;
			}
		}
		else {  //DimValMultiply can be positive or negative in the one dimension higher subspace, the value can only be minV, maxV or peakpoint
			float CurModuleVirtualEventSquareMax = ModuleVirtualEventTopicSquare + pow(UserParVPRect[dno].maxV, 2);
			float CurModuleVirtualEventSquareMin = ModuleVirtualEventTopicSquare + pow(UserParVPRect[dno].minV, 2);
			float TmaxDimValMultiply = DimValMultiply + UserParVPRect[dno].maxV * EventVRP[dno];
			float TminDimValMultiply = DimValMultiply + UserParVPRect[dno].minV * EventVRP[dno];
			float maxf = TmaxDimValMultiply / CurModuleVirtualEventSquareMax;
			float minf = TminDimValMultiply / CurModuleVirtualEventSquareMin;
			float peakpoint= EventVRP[dno] * ModuleVirtualEventTopicSquare / DimValMultiply;
			float peakDimValMultiply = DimValMultiply + peakpoint * EventVRP[dno];
			float CurModuleVirtualEventSquarePeak = ModuleVirtualEventTopicSquare + pow(peakpoint, 2);
			float peakf = peakDimValMultiply / CurModuleVirtualEventSquarePeak;

			if (maxf > minf&& maxf > peakf) {
				VirtualEventTopic[dno] = UserParVPRect[dno].maxV;
				DimValMultiply = TmaxDimValMultiply;
				ModuleVirtualEventTopicSquare = CurModuleVirtualEventSquareMax;
			}
			else if (minf > maxf&& minf > peakf) {
				VirtualEventTopic[dno] = UserParVPRect[dno].minV;
				DimValMultiply = TminDimValMultiply;
				ModuleVirtualEventTopicSquare = CurModuleVirtualEventSquareMin;
			}
			else {
				VirtualEventTopic[dno] = peakpoint;
				DimValMultiply = peakDimValMultiply;
				ModuleVirtualEventTopicSquare = CurModuleVirtualEventSquarePeak;
			}
		}
		ModuleEventVRPSquare += pow(EventVRP[dno], 2);

		//======================
			//===========
		//test if it is bounded
		BoundValue = DimValMultiply / (sqrt(ModuleVirtualEventTopicSquare) * sqrt(ModuleEventVRPSquare));
		lit = upebut.getUProfileEventGroup().begin();
		enlit = upebut.getUProfileEventGroup().end();
		TmpcommHashDims.push_back(commondims[k]);		
		while (lit != enlit) {
			float alp = IncomingEvent.GetConceptSimilarityDimSubset(&(*lit), upebut.commonHashDimSet, IncomingNoComModuleSquare, BucketVirENoComModuleSquare);
			if (alp > BoundValue)
				cout << "Hash not bounded \t" << "alp=" << alp << "\t BoundValue=" << BoundValue << endl;
			lit++;
		}
		//==================
		//=============
		//====================
	}

	ModuleVirETopicSquare = ModuleVirtualEventTopicSquare;
	ModuleEVRPSquare = ModuleEventVRPSquare;
	
	BoundValue= DimValMultiply / (sqrt(ModuleVirtualEventTopicSquare) * sqrt(ModuleEventVRPSquare));
	
	return BoundValue;
}
//added by Emily on 27June, 2021; revised Dec. 2021
int EventRecomOpti::SelectDimOutRect(ValueRangePair* UserParVPRect, float* EventVRP, vector<int>& DominantDim, 
	float &Top2DomDmincost)
{
	int ret = 0;
	vector<int> tmpDominantDimList;
	float minCos[TFIDF_DIM][TFIDF_DIM];
	Top2DomDmincost = 1;
	int Top1Dim[2];
	
	//initialize minCos
	for (int i = 0; i < TFIDF_DIM; i++) {
		minCos[i][i] = 1;
		for (int j = i + 1; j < TFIDF_DIM; j++)	{
			minCos[i][j] = 1;
			minCos[j][i] = 1;
		}
	}
	//check every 2 dimensions. see if eventVRP is in the range. only check the keydim
	for (int i = 0; i < TFIDF_KEYDIM; i++) {
		for (int j = i + 1; j < TFIDF_KEYDIM; j++) {
			//============
			if (EventVRP[KeyDim[i]] == 0 && EventVRP[KeyDim[j]] == 0) {
				tmpDominantDimList.push_back(KeyDim[i]);
				tmpDominantDimList.push_back(KeyDim[j]);
				continue;
			}
			if (UserParVPRect[KeyDim[i]].minV < 0 && UserParVPRect[KeyDim[j]].minV < 0 &&
				UserParVPRect[KeyDim[i]].maxV > 0 && UserParVPRect[KeyDim[j]].maxV > 0) //if the UserParVPRect covers 4 quadrants space, not dominantDim
				continue;
			//dimension i and j space
			//four points <mini,minj><mini,maxj><maxi,minj><maxi,maxj>
			if ((UserParVPRect[KeyDim[i]].minV == 0 && UserParVPRect[KeyDim[j]].minV == 0)||
				(UserParVPRect[KeyDim[i]].minV == 0 && UserParVPRect[KeyDim[j]].maxV == 0)||
				(UserParVPRect[KeyDim[i]].maxV == 0 && UserParVPRect[KeyDim[j]].minV == 0)||
				(UserParVPRect[KeyDim[i]].maxV == 0 && UserParVPRect[KeyDim[j]].maxV == 0)) {//any one of point is at original point
				if(std::find(tmpDominantDimList.begin(), tmpDominantDimList.end(), KeyDim[i]) != tmpDominantDimList.end())
					tmpDominantDimList.push_back(KeyDim[i]);
				if (std::find(tmpDominantDimList.begin(), tmpDominantDimList.end(), KeyDim[j]) != tmpDominantDimList.end())
					tmpDominantDimList.push_back(KeyDim[j]);
				continue;
			}
			
			//based on data, maxi and maxj are no smaller than 0. So the rectangle can cover quadrant 1, 2, 1-2, 4, or 4-1
			float StartEndPoints[2][2];
			if (UserParVPRect[KeyDim[i]].minV >= 0 && UserParVPRect[KeyDim[j]].minV >= 0) //quadrant 1
			{
				StartEndPoints[0][0] = UserParVPRect[KeyDim[i]].maxV;
				StartEndPoints[0][1] = UserParVPRect[KeyDim[j]].minV;
				StartEndPoints[1][0] = UserParVPRect[KeyDim[i]].minV;
				StartEndPoints[1][1] = UserParVPRect[KeyDim[j]].maxV;
			}
			else if (UserParVPRect[i].minV < 0) {  //UserParVPRect[j].minV >= 0, UserParVPRect[i].maxV >= 0, for qadrant 2, 1-2
				StartEndPoints[0][0] = UserParVPRect[KeyDim[i]].maxV;
				StartEndPoints[0][1] = UserParVPRect[KeyDim[j]].minV;
				StartEndPoints[1][0] = UserParVPRect[KeyDim[i]].minV;
				StartEndPoints[1][1] = UserParVPRect[KeyDim[j]].minV;
			}
			else if (UserParVPRect[j].minV < 0) {//UserParVPRect[i].minV >= 0, UserParVPRect[j].maxV >= 0, for qadrant 4, 4 - 1
				StartEndPoints[0][0] = UserParVPRect[KeyDim[i]].minV;
				StartEndPoints[0][1] = UserParVPRect[KeyDim[j]].minV;
				StartEndPoints[1][0] = UserParVPRect[KeyDim[i]].minV;
				StartEndPoints[1][1] = UserParVPRect[KeyDim[j]].maxV;
			}
			//for test
			float StartEndcosin = (StartEndPoints[0][0] * StartEndPoints[1][0] + StartEndPoints[0][1] * StartEndPoints[1][1]) /
				(sqrt(pow(StartEndPoints[0][0], 2) + pow(StartEndPoints[0][1], 2)) * sqrt(pow(StartEndPoints[1][0], 2) + pow(StartEndPoints[1][1], 2)));

			cout << "Before normalize: StartEndCosin: " << StartEndcosin << endl;

			//normalized these two points
			for (int k = 0; k < 2; k++) {
				float DomiVar = sqrt(pow(StartEndPoints[k][0], 2) + pow(StartEndPoints[k][1], 2));
				StartEndPoints[k][0] /= DomiVar;
				StartEndPoints[k][1] /= DomiVar;
			}
			StartEndcosin = (StartEndPoints[0][0] * StartEndPoints[1][0] + StartEndPoints[0][1] * StartEndPoints[1][1]) /
				(sqrt(pow(StartEndPoints[0][0], 2) + pow(StartEndPoints[0][1], 2)) * sqrt(pow(StartEndPoints[1][0], 2) + pow(StartEndPoints[1][1], 2)));

			cout << "After normalize: StartEndCosin: " << StartEndcosin << endl;

			float BisectorUnitVec[2];
			float var;
			float alphacosin; //angle between a point to BisectorUnitVec;
			float Betacosin, BetacosinStart;  //angle between an edge vector to BisectorUnitVec
			BisectorUnitVec[0] = StartEndPoints[0][0] + StartEndPoints[1][0];
			BisectorUnitVec[1] = StartEndPoints[0][1] + StartEndPoints[1][1];
			var = sqrt(pow(BisectorUnitVec[0], 2) + pow(BisectorUnitVec[1], 2));
			BisectorUnitVec[0] /= var;
			BisectorUnitVec[1] /= var;
			Betacosin = BisectorUnitVec[0] * StartEndPoints[1][0] + BisectorUnitVec[1] * StartEndPoints[1][1];
			BetacosinStart = BisectorUnitVec[0] * StartEndPoints[0][0] + BisectorUnitVec[1] * StartEndPoints[0][1];//for remove deviation
			if (BetacosinStart < Betacosin) //these two values should be equal.
				Betacosin = BetacosinStart;

			//=====================
			float EventVRPoint[2];
			EventVRPoint[0] = EventVRP[KeyDim[i]];
			EventVRPoint[1] = EventVRP[KeyDim[j]];
			float DomiVar = sqrt(pow(EventVRPoint[0], 2) + pow(EventVRPoint[1], 2));
			alphacosin = (BisectorUnitVec[0] * EventVRPoint[0] + BisectorUnitVec[1] * EventVRPoint[1]) / DomiVar;

			if (alphacosin < Betacosin) { //not in the area			
				//compute the minAngle cosine
				minCos[KeyDim[i]][KeyDim[j]] = alphacosin * Betacosin + sqrt(1 - pow(alphacosin, 2)) * sqrt(1 - pow(Betacosin, 2));
				minCos[KeyDim[j]][KeyDim[i]] = minCos[KeyDim[i]][KeyDim[j]];
				if (Top2DomDmincost > minCos[KeyDim[i]][KeyDim[j]]) {
					Top1Dim[0] = KeyDim[i];
					Top1Dim[1] = KeyDim[j];
					Top2DomDmincost = minCos[KeyDim[i]][KeyDim[j]];
				}
			}
	//check every 2 dimensions. see if eventVRP is in the range. find the first two dominant dimensions.
	/*for (int i = 0; i < TFIDF_DIM; i++) {		
		for (int j = i+1; j < TFIDF_DIM; j++) {			
			//============
			if (i == 0 && j == 3)
				cout << "dbug i, j" << endl;
			if (EventVRP[i] == 0 && EventVRP[j] == 0)
				 continue;
			if (UserParVPRect[i].minV < 0 && UserParVPRect[j].minV < 0 && 
				UserParVPRect[i].maxV>=0 && UserParVPRect[j].maxV>=0) //if the UserParVPRect covers 4 quadrants space, not dominantDim
				continue;
			//dimension i and j space
			//four points <mini,minj><mini,maxj><maxi,minj><maxi,maxj>
			if (UserParVPRect[i].minV == 0 && UserParVPRect[j].minV==0)//any one of point is at original point
				continue;
			else if (UserParVPRect[i].minV == 0 && UserParVPRect[j].maxV == 0)
				continue;
			else if (UserParVPRect[i].maxV == 0 && UserParVPRect[j].minV == 0)
				continue;
			else if (UserParVPRect[i].maxV == 0 && UserParVPRect[j].maxV == 0)
				continue;

			//based on data, maxi and maxj are no smaller than 0. So the rectangle can cover quadrant 1, 2, 1-2, 4, or 4-1
			float StartEndPoints[2][2];
			if (UserParVPRect[i].minV >= 0 && UserParVPRect[j].minV >= 0) //quadrant 1
			{
				StartEndPoints[0][0] = UserParVPRect[i].maxV;
				StartEndPoints[0][1] = UserParVPRect[j].minV;
				StartEndPoints[1][0] = UserParVPRect[i].minV;
				StartEndPoints[1][1] = UserParVPRect[j].maxV;
			}
			else if (UserParVPRect[i].minV < 0) {  //UserParVPRect[j].minV >= 0, UserParVPRect[i].maxV >= 0, for qadrant 2, 1-2
				StartEndPoints[0][0] = UserParVPRect[i].maxV;
				StartEndPoints[0][1] = UserParVPRect[j].minV;
				StartEndPoints[1][0] = UserParVPRect[i].minV;
				StartEndPoints[1][1] = UserParVPRect[j].minV;
			}
			else if (UserParVPRect[j].minV < 0) {//UserParVPRect[i].minV >= 0, UserParVPRect[j].maxV >= 0, for qadrant 4, 4 - 1
				StartEndPoints[0][0] = UserParVPRect[i].minV;
				StartEndPoints[0][1] = UserParVPRect[j].minV;
				StartEndPoints[1][0] = UserParVPRect[i].minV;
				StartEndPoints[1][1] = UserParVPRect[j].maxV;
			}
			//for test
			float StartEndcosin = (StartEndPoints[0][0] * StartEndPoints[1][0] + StartEndPoints[0][1] * StartEndPoints[1][1])/
				(sqrt(pow(StartEndPoints[0][0],2)+pow(StartEndPoints[0][1],2))* sqrt(pow(StartEndPoints[1][0], 2) + pow(StartEndPoints[1][1], 2)));

			cout << "Before normalize: StartEndCosin: " << StartEndcosin << endl;

			//normalized these two points
			for (int k = 0; k < 2; k++) {
				float DomiVar = sqrt(pow(StartEndPoints[k][0], 2) + pow(StartEndPoints[k][1], 2));
				StartEndPoints[k][0] /= DomiVar;
				StartEndPoints[k][1] /= DomiVar;
			}
			StartEndcosin = (StartEndPoints[0][0] * StartEndPoints[1][0] + StartEndPoints[0][1] * StartEndPoints[1][1]) /
				(sqrt(pow(StartEndPoints[0][0], 2) + pow(StartEndPoints[0][1], 2)) * sqrt(pow(StartEndPoints[1][0], 2) + pow(StartEndPoints[1][1], 2)));

			cout << "After normalize: StartEndCosin: " << StartEndcosin << endl;

			float BisectorUnitVec[2];
			float var;			
			float alphacosin; //angle between a point to BisectorUnitVec;
			float Betacosin, BetacosinStart;  //angle between an edge vector to BisectorUnitVec
			BisectorUnitVec[0] = StartEndPoints[0][0] + StartEndPoints[1][0];
			BisectorUnitVec[1] = StartEndPoints[0][1] + StartEndPoints[1][1];
			var = sqrt(pow(BisectorUnitVec[0], 2) + pow(BisectorUnitVec[1], 2));
			BisectorUnitVec[0] /= var;
			BisectorUnitVec[1] /= var;
			Betacosin = BisectorUnitVec[0] * StartEndPoints[1][0] + BisectorUnitVec[1] * StartEndPoints[1][1];
			BetacosinStart = BisectorUnitVec[0] * StartEndPoints[0][0] + BisectorUnitVec[1] * StartEndPoints[0][1];//for remove deviation
			if (BetacosinStart < Betacosin) //these two values should be equal.
				Betacosin = BetacosinStart;

			//=====================
			float EventVRPoint[2];
			EventVRPoint[0] = EventVRP[i];
			EventVRPoint[1] = EventVRP[j];
			float DomiVar = sqrt(pow(EventVRPoint[0], 2) + pow(EventVRPoint[1], 2));
			alphacosin = (BisectorUnitVec[0] * EventVRPoint[0] + BisectorUnitVec[1] * EventVRPoint[1])/DomiVar;

			if (alphacosin < Betacosin) { //not in the area			
				//compute the minAngle cosine
				minCos[i][j] = alphacosin * Betacosin + sqrt(1 - pow(alphacosin, 2)) * sqrt(1 - pow(Betacosin, 2));
				minCos[j][i] = minCos[i][j];
				if (Top2DomDmincost > minCos[i][j]) {
					Top1Dim[0] = i;
					Top1Dim[1] = j;
					Top2DomDmincost = minCos[i][j];
				}
			}*/
			//==================================
			/*float points[4][2];
			for (int k = 0; k < 2; k++) {
				points[k][0] = UserParVPRect[i].minV;
				points[k + 2][0] = UserParVPRect[i].maxV;
			}
			for (int k = 0; k < 4; k++) {
				if(k%2>0)
					points[k][1] = UserParVPRect[j].maxV;
				else
					points[k][1] = UserParVPRect[j].minV;
			}				
			//==========================================
			float EventVRPoint[2];
			EventVRPoint[0] = EventVRP[i];
			EventVRPoint[1] = EventVRP[j];
			float DomiVar= sqrt(pow(EventVRPoint[0], 2) + pow(EventVRPoint[1], 2));
			EventVRPoint[0] /= DomiVar;
			EventVRPoint[1] /= DomiVar;

			float BisectorUnitVec[2];
			float var;
			//normalized these four points
			for (int k = 0; k < 4; k++) {
				float DomiVar = sqrt(pow(points[k][0], 2) + pow(points[k][1], 2));
				points[k][0] /= DomiVar;
				points[k][1] /= DomiVar;
			}
			//find the two points to the two vectors enclosing the biggest angle
			float maxAngleCos = 1;
			int maxAngleStart = 0;
			int maxAngleEnd = 0;
			for (int k = 0; k < 4; k++) {
				float tAngleCos = 0;
				for (int l = k+1; l < 4; l++) {
					//calculate cosine
					tAngleCos = points[k][0] * points[l][0] + points[k][1] * points[l][1];
					
					if (tAngleCos < maxAngleCos) {
						maxAngleCos = tAngleCos;
						maxAngleStart = k;
						maxAngleEnd = l;
					}
				}
			}
			//BisectorUnitVec
			float alphacosin; //angle between a point to BisectorUnitVec;
			float Betacosin, BetacosinStart;  //angle between an edge vector to BisectorUnitVec
			BisectorUnitVec[0] = points[maxAngleStart][0] + points[maxAngleEnd][0];
			BisectorUnitVec[1] = points[maxAngleStart][1] + points[maxAngleEnd][1];
			var = sqrt(pow(BisectorUnitVec[0], 2) + pow(BisectorUnitVec[1], 2));
			BisectorUnitVec[0] /= var;
			BisectorUnitVec[1] /= var;
			Betacosin = BisectorUnitVec[0] * points[maxAngleEnd][0] + BisectorUnitVec[1] * points[maxAngleEnd][1];
			BetacosinStart= BisectorUnitVec[0] * points[maxAngleStart][0] + BisectorUnitVec[1] * points[maxAngleStart][1];//for remove deviation
			if (BetacosinStart < Betacosin)
				Betacosin = BetacosinStart;*/
			
			/*alphacosin = BisectorUnitVec[0] * EventVRPoint[0] + BisectorUnitVec[1] * EventVRPoint[1];
			
			if (alphacosin < Betacosin) { //not in the area			
				//compute the minAngle cosine
				minCos[i][j] = alphacosin * Betacosin + sqrt(1 - pow(alphacosin, 2))*sqrt(1 - pow(Betacosin, 2));
				minCos[j][i] = minCos[i][j];
				if (minimalMinCos > minCos[i][j]) {
					Top1Dim[0] = i;
					Top1Dim[1] = j;
					minimalMinCos = minCos[i][j];
				}
			}*/
		}
	}

	if (Top2DomDmincost <1)
	{
		DominantDim.push_back(Top1Dim[0]);
		DominantDim.push_back(Top1Dim[1]);


		int i = Top1Dim[0];	
		int k = Top1Dim[1];
		for (int j = 0; j < i; j++) {
			if (minCos[i][j] < 1&& minCos[k][j]<1)
				tmpDominantDimList.push_back(j);
		}
		for (int j = i+1; j < k; j++) {
			if (minCos[i][j] < 1 && minCos[k][j] < 1)
				tmpDominantDimList.push_back(j);
		}
		for (int j = k+1; j < TFIDF_DIM; j++) {
			if (minCos[i][j] < 1 && minCos[k][j] < 1)
				tmpDominantDimList.push_back(j);
		}	
	
		//remove those in DominantDim already from tmpdominantDimList
		vector<int>::iterator dit = tmpDominantDimList.begin();
		int DominantDimSize = DominantDim.size();
		int offset=0;
		while (dit != tmpDominantDimList.end()) {
			int i = 0;
			for ( i= 0; i < DominantDimSize; i++)
				if ((*dit) == DominantDim[i])
					break;
			if (i < DominantDimSize) { //found, remove
				tmpDominantDimList.erase(dit);
				dit = tmpDominantDimList.begin() + offset;
			}
			else {
				dit++;
				offset++;
			}
		}

		while(!tmpDominantDimList.empty())
			SelectNextDominantDim(UserParVPRect, EventVRP, tmpDominantDimList, DominantDim);
	}
	ret = DominantDim.size();
	tmpDominantDimList.clear();
	return ret;
}

int EventRecomOpti::SelectNextDominantDim(ValueRangePair* UserParVPRect, float* EventVRP, 
	vector<int>& CandidateDim, vector<int>& DominantDim) 
{
	int ret=0;
	int Top1Dim = -1;
	int offsetTop1Dim = 0;
	float Top1DimValueGap = 0;
	vector<EventPoint> UserParEdgePoints;
	vector<EventPoint> UserParEdgePointsUnitVec;
	EventPoint BisectorUnitVec;
	int DomNum = DominantDim.size();
	int epointNum = pow(2, DomNum + 1);  //the number of vertexes for the DomNum+1 dimensional cube
	UserParEdgePoints.resize(epointNum);
	UserParEdgePointsUnitVec.resize(epointNum);

	//put the vertexes into UserParEdgePoints
	for (int i = 0; i < DomNum; i++){
		int index = epointNum / pow(2,i+1);
		int loop = pow(2, i+1);		
		for (int j = 0; j < loop; j++) {
			float curr = UserParVPRect[DominantDim[i]].maxV;
			if (j % 2 > 0)
				curr = UserParVPRect[DominantDim[i]].minV;
			for (int k = 0; k < index; k++) {
				UserParEdgePoints[k + index * j].point[DominantDim[i]] = curr;
			}
		}
	}
	//compute the square of the vector length
	for (int i = 0; i < epointNum; i++) {
		UserParEdgePoints[i].DomiVar = 0;
		for (int j = 0; j < DomNum; j++)
			UserParEdgePoints[i].DomiVar += pow(UserParEdgePoints[i].point[DominantDim[j]], 2);
	}

	vector<int>::iterator dit = CandidateDim.begin();
	float alphacosin; //angle between a point to BisectorUnitVec;
	float Betacosin;  //angle between an edge vector to BisectorUnitVec
	int curOffset = 0;
	while (dit != CandidateDim.end()) {
		//process all the boundary points
		int loop = epointNum / 2;
		for (int i = 0; i < loop; i++)
		{
			UserParEdgePoints[i*2].point[*dit] = UserParVPRect[*dit].maxV;
			UserParEdgePoints[i*2+1].point[*dit] = UserParVPRect[*dit].minV;
		}		
		//convert the vector of each point over DominantDim and (*dit) as unit vector.
		for (int i = 0; i < epointNum; i++) {
			float FullDomiVar= UserParEdgePoints[i].DomiVar + pow(UserParEdgePoints[i].point[*dit], 2);
			FullDomiVar = sqrt(FullDomiVar);
			UserParEdgePointsUnitVec[i].point[*dit] = UserParEdgePoints[i].point[*dit] / FullDomiVar;
			for (int j = 0; j < DomNum; j++) {
				UserParEdgePointsUnitVec[i].point[DominantDim[j]] = 
					UserParEdgePoints[i].point[DominantDim[j]] / FullDomiVar;
			}
		}
		// find the two vectors enclosing the biggest angle
		float maxAngleCos = 1;
		int maxAngleEdgeStart = 0;
		int maxAngleEdgeEnd = 0;
		for (int i = 0; i < epointNum; i++) {			
			float tAngleCos = 0;
			for (int j = i; j < epointNum; j++) {
				//calculate cosine
				tAngleCos = 0;
				for (int k = 0; k < DomNum; k++)
					tAngleCos += UserParEdgePointsUnitVec[i].point[DominantDim[k]] * UserParEdgePointsUnitVec[j].point[DominantDim[k]];
				tAngleCos += UserParEdgePointsUnitVec[i].point[*dit] * UserParEdgePointsUnitVec[j].point[*dit];

				if (tAngleCos < maxAngleCos) {
					maxAngleCos = tAngleCos;
					maxAngleEdgeStart = i;
					maxAngleEdgeEnd = j;
				}
			}
		}
		//compute the angular bisector of these two vectors
		Betacosin = 0;
		BisectorUnitVec.DomiVar = 0;
		for (int k = 0; k < DomNum; k++) {
			BisectorUnitVec.point[DominantDim[k]] = UserParEdgePointsUnitVec[maxAngleEdgeStart].point[DominantDim[k]] +
				UserParEdgePointsUnitVec[maxAngleEdgeEnd].point[DominantDim[k]];
			BisectorUnitVec.DomiVar += pow(BisectorUnitVec.point[DominantDim[k]], 2);
			Betacosin += BisectorUnitVec.point[DominantDim[k]] * UserParEdgePointsUnitVec[maxAngleEdgeStart].point[DominantDim[k]];
		}
		BisectorUnitVec.point[*dit] = UserParEdgePointsUnitVec[maxAngleEdgeStart].point[*dit] +
			UserParEdgePointsUnitVec[maxAngleEdgeEnd].point[*dit];
		Betacosin += BisectorUnitVec.point[*dit] * UserParEdgePointsUnitVec[maxAngleEdgeStart].point[*dit];
		
		BisectorUnitVec.DomiVar += pow(BisectorUnitVec.point[*dit], 2);
		BisectorUnitVec.DomiVar = sqrt(BisectorUnitVec.DomiVar);

		if(BisectorUnitVec.DomiVar>0)
			Betacosin /= BisectorUnitVec.DomiVar;
		
		//for test compute all the points in UserParEdgePointsUnitVec and see if it is enclosed by maxAngle
		/*for (int i = 0; i < epointNum; i++) {
			alphacosin = 0;
			for (int k = 0; k < DomNum; k++) {
				alphacosin += BisectorUnitVec.point[DominantDim[k]] * UserParEdgePointsUnitVec[i].point[DominantDim[k]];
			}
			alphacosin += BisectorUnitVec.point[*dit] * UserParEdgePointsUnitVec[i].point[*dit];
			if (BisectorUnitVec.DomiVar > 0)
				alphacosin/= BisectorUnitVec.DomiVar;
			if (alphacosin < Betacosin) {
				cout << "point " << i << " is not enclosed\t" <<"alphcosin: "<<alphacosin<<"Betacosin: "<< Betacosin<< endl;
			}
		}*/
		//end for test

		//compute the cosine of p to angular bisector
		alphacosin = 0;
		for (int k = 0; k < DomNum; k++) {
			alphacosin += BisectorUnitVec.point[DominantDim[k]] * EventVRP[DominantDim[k]];
		}
		alphacosin += BisectorUnitVec.point[*dit] * EventVRP[*dit];
		if (BisectorUnitVec.DomiVar > 0)
			alphacosin /= BisectorUnitVec.DomiVar;
		if (alphacosin > Betacosin) {
			cout << "EventVRP is not enclosed" << endl;
			float gap = alphacosin - Betacosin;
			if (gap > Top1DimValueGap) {
				Top1Dim = (*dit);
				offsetTop1Dim =curOffset;
				Top1DimValueGap = gap;
			}	
			dit++;
			curOffset++;
		}
		else
		{
			//EventVRP is enclosed, so this dimension is not dominant dimension, and should be removed from CandidateDim.
			CandidateDim.erase(dit);
			dit = CandidateDim.begin() + curOffset;
		}
	}
	//==========
	if (Top1Dim >= 0)  //found
	{
		DominantDim.push_back(Top1Dim);
		dit = CandidateDim.begin() + offsetTop1Dim;
		CandidateDim.erase(dit);
		ret = 1;
	}
	UserParEdgePoints.clear();
	UserParEdgePointsUnitVec.clear();
	//===========
	return ret;
}

float EventRecomOpti::GetTBoundCosofDominantDim(ValueRangePair* UserParVPRect, float* EventVRP,
	vector<int>& DominantDim)  //in multiple dimensions, compute the cosine of angular between EventVRP and closet boundary of UserParVPRect 
{
	float ret = 1;
	vector<EventPoint> UserParEdgePoints;
	vector<EventPoint> UserParEdgePointsUnitVec;
	EventPoint BisectorUnitVec;
	int DomNum = DominantDim.size();
	int epointNum =(int) pow(2, DomNum);  //the number of vertexes for the DomNum dimensional cube
	UserParEdgePoints.resize(epointNum);
	UserParEdgePointsUnitVec.resize(epointNum);

	//put the vertexes into UserParEdgePoints
	int currentDom = 0;
	if (DomNum > 1) {
		for (int i = 0; i < DomNum-1; i++)
		{
			int index = epointNum / pow(2, i + 1);
			int loop = pow(2, i + 1);
			for (int j = 0; j < loop; j++)
			{
				float curr = UserParVPRect[DominantDim[i]].maxV;
				if (j % 2 > 0)
					curr = UserParVPRect[DominantDim[i]].minV;
				for (int k = 0; k < index; k++) {
					UserParEdgePoints[k + loop * j].point[DominantDim[i]] = curr;  //has error here to be fixed
				}
			}
		}
	}
	int loop = epointNum / 2;
	for (int j = 0; j < loop; j++)
	{
		UserParEdgePoints[j * 2].point[DominantDim[DomNum - 1]] = UserParVPRect[DominantDim[DomNum - 1]].maxV;
		UserParEdgePoints[j * 2 + 1].point[DominantDim[DomNum - 1]] = UserParVPRect[DominantDim[DomNum - 1]].minV;
	}
	//compute the square of the vector length
	for (int i = 0; i < epointNum; i++) {
		UserParEdgePoints[i].DomiVar = 0;
		for (int j = 0; j < DomNum; j++)
			UserParEdgePoints[i].DomiVar += pow(UserParEdgePoints[i].point[DominantDim[j]], 2);		
	}

	//convert the vector of each point over DominantDim as unit vector.
	for (int i = 0; i < epointNum; i++) {
		float FullDomiVar = sqrt(UserParEdgePoints[i].DomiVar);
		if (FullDomiVar == 0) 
			continue;		
		for (int j = 0; j < DomNum; j++) 
			UserParEdgePointsUnitVec[i].point[DominantDim[j]] =	UserParEdgePoints[i].point[DominantDim[j]] / FullDomiVar;
	}

	float alphacosin; //angle between a point to BisectorUnitVec;
	float Betacosin;  //angle between an edge vector to BisectorUnitVec
	// find the two vectors enclosing the biggest angle
	float maxAngleCos = 0;
	int maxAngleEdgeStart = 0;
	int maxAngleEdgeEnd = 0;
	for (int i = 0; i < epointNum; i++) {
		float tAngleCos = 0;
		for (int j = i; j < epointNum; j++) {
			//calculate cosine
			tAngleCos = 0;
			for (int k = 0; k < DomNum; k++)
				tAngleCos += UserParEdgePointsUnitVec[i].point[DominantDim[k]] * UserParEdgePointsUnitVec[j].point[DominantDim[k]];
			
			if (tAngleCos > maxAngleCos) {
				maxAngleCos = tAngleCos;
				maxAngleEdgeStart = i;
				maxAngleEdgeEnd = j;
			}
		}
	}
	//compute the angular bisector of these two vectors
	Betacosin = 0;
	BisectorUnitVec.DomiVar = 0;
	for (int k = 0; k < DomNum; k++) {
		BisectorUnitVec.point[DominantDim[k]] = UserParEdgePointsUnitVec[maxAngleEdgeStart].point[DominantDim[k]] +
			UserParEdgePointsUnitVec[maxAngleEdgeEnd].point[DominantDim[k]];
		BisectorUnitVec.DomiVar += pow(BisectorUnitVec.point[DominantDim[k]], 2);
		Betacosin += BisectorUnitVec.point[DominantDim[k]] * UserParEdgePointsUnitVec[maxAngleEdgeStart].point[DominantDim[k]];
	}
	BisectorUnitVec.DomiVar = sqrt(BisectorUnitVec.DomiVar);

	if(BisectorUnitVec.DomiVar>0)
		Betacosin /= BisectorUnitVec.DomiVar;

	//compute the cosine of p to angular bisector
	alphacosin = 0;
	for (int k = 0; k < DomNum; k++) 
		alphacosin += BisectorUnitVec.point[DominantDim[k]] * EventVRP[DominantDim[k]];	
	if (BisectorUnitVec.DomiVar > 0)
		alphacosin /= BisectorUnitVec.DomiVar;

	UserParEdgePoints.clear();
	UserParEdgePointsUnitVec.clear();
	//compute the cosine of alpha-belta; cos(alpha-belta)=cos alpha cos belta + sin alpha sin belta
	//sin alpha * sin alpha + cos alpha * cos alpha =1
	if (alphacosin > Betacosin)
		ret = 1;
	else
		ret = alphacosin * Betacosin + sqrt(1 - alphacosin * alphacosin) * sqrt(1 - Betacosin * Betacosin);
	return ret;
}
//===================================

float EventRecomOpti::ComputeProb_EvEn(UPEventPartition& UserProfileEventPartition, SubEvent& IncomingEvent, int bucketNo)
{
	float Prob_EvEn = 0;
	SubEvent VirtualUPPevent;

	GetDomiUserVirEvent(UserProfileEventPartition, IncomingEvent, VirtualUPPevent, bucketNo);

	EventMigration eventmig;
	Prob_EvEn = eventmig.EventMigrationProb(VirtualUPPevent, IncomingEvent);

	return Prob_EvEn;
}

void EventRecomOpti::GetDomiUserVirEvent(UPEventPartition& UserProfileEventPartition, SubEvent& IncomingEvent, SubEvent&VirtualUPPevent, int bucketNo)
{
	//estiate user influential between UserProfileEventPartition and IncomingEvent
	//Get all the users in UserProfileEventPartition
	std::vector<int> userlist;
	GetUserInEventPartition(UserProfileEventPartition, userlist, bucketNo);

	//Select all the users appearing in UserProfileEventPartition and influencing users in IncomingEvent , and calculate the average influence	
	std::vector<float> influentials;
	for (int i = 0; i < TUNUM; i++)
		influentials.push_back(0);
	RemoveNonInfluentialUsers(userlist, IncomingEvent.GetEventUserIDs(),influentials);
	
	//rank the selected users in UserProfileEventPartition based on the average influentials they can generate to IncomingEvent.
	RankInfluentialUsers(userlist, influentials);

	//select the top un_{min} users from UserProfileEventPartition as the dominant ones	
	int ulsize = userlist.size();
	if (ulsize > UserProfileEventPartition.getMinNumInfluencedUsers()) {
		userlist.erase(userlist.begin() + UserProfileEventPartition.getMinNumInfluencedUsers(), userlist.begin() + ulsize);
	}

	//form VirtualUPPevent
	VirtualUPPevent.SetEventUserIDs_Vec(userlist);
}

void EventRecomOpti::RankInfluentialUsers(std::vector<int>& userlist, std::vector<float>& influentials)
{
	int userlistsize = userlist.size();
	for (int i = 0; i < userlistsize; i++) 
	{
		for (int j = i+1; j < userlistsize; j++) 
		{
			if (userlist[j] > userlist[i])
			{
				//swap
				int temp= userlist[i];
				userlist[i] = userlist[j];
				userlist[j] = temp;
			}
		}
	}
}

void EventRecomOpti::GetUserInEventPartition(UPEventPartition& UserProfileEventPartition, std::vector<int>& userlist, int bucketNo)
{
	if (bucketNo == -1)  //process the whole partition
	{
		std::vector<UPEventBucket>::iterator upebit = UserProfileEventPartition.getUProfileEventGroup().begin();
		while (upebit != UserProfileEventPartition.getUProfileEventGroup().end()) {
			std::vector<SubEvent>::iterator seit = (*upebit).getUProfileEventGroup().begin();
			while (seit != (*upebit).getUProfileEventGroup().end()) {
				//check each user in (*seit), and see if it is in userlist
				std::vector<EUserFrePair>::iterator uit = (*seit).GetEventUserIDs().begin();
				while (uit != (*seit).GetEventUserIDs().end())
				{
					std::vector<int>::iterator ulit = userlist.begin();
					while (ulit != userlist.end())
					{
						if ((*uit).userid == (*ulit)) {
							break;
						}
						ulit++;
					}
					if (ulit == userlist.end()) {
						userlist.push_back((*uit).userid);
					}
					uit++;
				}
				seit++;
			}
			upebit++;
		}
	}
	else {  //process bucketNo only
		//===================
		std::vector<UPEventBucket>::iterator upebit = UserProfileEventPartition.getUProfileEventGroup().begin();
		if (bucketNo <= UserProfileEventPartition.getUProfileEventGroup().size())
			upebit = upebit + bucketNo;
		//while (upebit != UserProfileEventPartition.getUProfileEventGroup().end()) {
		if (upebit != UserProfileEventPartition.getUProfileEventGroup().end()) {
			std::vector<SubEvent>::iterator seit = (*upebit).getUProfileEventGroup().begin();
			while (seit != (*upebit).getUProfileEventGroup().end()) {
				//check each user in (*seit), and see if it is in userlist
				std::vector<EUserFrePair>::iterator uit = (*seit).GetEventUserIDs().begin();
				while (uit != (*seit).GetEventUserIDs().end())
				{
					std::vector<int>::iterator ulit = userlist.begin();
					while (ulit != userlist.end())
					{
						if ((*uit).userid == (*ulit)) {
							break;
						}
						ulit++;
					}
					if (ulit == userlist.end()) {
						userlist.push_back((*uit).userid);
					}
					uit++;
				}
				seit++;
			}
			//upebit++;
		}
	}
}

void EventRecomOpti::RemoveNonInfluentialUsers(std::vector<int>& userlist, std::vector<EUserFrePair> &eventUserIdsFre, std::vector<float>& influentials)
{
	std::vector<int>::iterator ulit, eraselit;
	ulit= userlist.begin();		
	while (ulit != userlist.end()) 
	{
		//check if (*ulit) influence IncomingEvent
		int userNumBeInfluenced = 0; //count the number of user being influenced by (*ulit)
		std::vector<EUserFrePair>::iterator euifit = eventUserIdsFre.begin();		
		while (euifit != eventUserIdsFre.end()) 
		{
			std::vector<UPInfluDistriEle>::iterator upDit = UserProfileHashMap[(*ulit)].UserInfluenceDistri.begin();
			while (upDit != UserProfileHashMap[(*ulit)].UserInfluenceDistri.end()) {
				if ((*upDit).userid == ((*euifit).userid)) {
					if ((*upDit).userInflu > 0) {//has influence
						userNumBeInfluenced++;
						influentials[*ulit] += (*upDit).userInflu;
					}
				}
				upDit++;
			}			
			euifit++;
		}
		if (!userNumBeInfluenced)//no influence
		{			
			eraselit = ulit;
			if (ulit == userlist.begin())
			{
				userlist.erase(eraselit);	
				ulit=userlist.begin();
			}
			else {
				ulit--;
				userlist.erase(eraselit);
				ulit++;
			}			
		}
		else  //has influence
		{
			influentials[*ulit] /= userNumBeInfluenced;
			ulit++;
		}
	}
}

void EventRecomOpti::EventSimilarityJoin(UPEventPartition& UserProfileEventPartion, 
	std::vector<SubEvent>&IncomingEventSubset, float SimiThreshold, EventRecommendation eventRec)
{			
	std::vector<SubEvent>::iterator IESit = IncomingEventSubset.begin();
	while (IESit != IncomingEventSubset.end()) 
	{
		int bucketNum = UserProfileEventPartion.getUProfileEventGroup().size();
		for (int i = 0; i < bucketNum; i++) //for UserProfileEventPartition
		{
			std::vector<SubEvent>::iterator seit = UserProfileEventPartion.getUProfileEventGroup()[i].getUProfileEventGroup().begin();
			while (seit != UserProfileEventPartion.getUProfileEventGroup()[i].getUProfileEventGroup().end()) 
			{
				float simiV = eventRec.GetESim((*IESit), (*seit));
				if (simiV >= SimiThreshold) //recommend (*IESit) to the users whose profiles contain (*seit), update the RecUserSimi in (*IESit)
				{
					UpdateRecUserSimi((*IESit),(*seit),simiV);
				}
				seit++;
			}
		}
		IESit++;
	}
}

void EventRecomOpti::UpdateRecUserSimi(SubEvent& IncomingEvent, SubEvent& UserProfileEvent, float simiV)
{
	//int NU_seit = UserProfileEvent.userlist.size();
	int NU_seit = UserProfileEvent.GetEventUserIDs().size();
	for (int j = 0; j < NU_seit; j++)
	{
		//check if (*seit).userlist[j] is in (*IESit).RecUserSimi
		int NRU_IESit = IncomingEvent.RecUserSimi.size();
		int k = 0;
		for (k = 0; k < NRU_IESit; k++)
		{
			if (UserProfileEvent.GetEventUserIDs()[j].userid == IncomingEvent.RecUserSimi[k].userid)
			{
				if (simiV > IncomingEvent.RecUserSimi[k].simi)
					IncomingEvent.RecUserSimi[k].simi = simiV;
				break;
			}
		}
		//if (k < NRU_IESit||k==0) //not in the RecUserSimi list, insert it
		if(k==NRU_IESit)//not in the RecUserSimi list, insert it
		{
			EventUserSimi eusTuple;
			eusTuple.userid = UserProfileEvent.GetEventUserIDs()[j].userid;
			eusTuple.simi = simiV;
			
			std::vector<EventUserSimi>::iterator rusit = IncomingEvent.RecUserSimi.begin();
			int RUSsize = IncomingEvent.RecUserSimi.size();
			while (rusit != IncomingEvent.RecUserSimi.end()) {
				if((*rusit).simi>simiV)
					rusit++;
				else {
					IncomingEvent.RecUserSimi.insert(rusit, eusTuple);
					break;
				}
			}
			if (RUSsize == IncomingEvent.RecUserSimi.size()) {  //have not been inserted yet, then push back
				if(IncomingEvent.RecUserSimi.size()< TOPK)
					IncomingEvent.RecUserSimi.push_back(eusTuple);
			}
			if (IncomingEvent.RecUserSimi.size() > TOPK) {
				rusit = IncomingEvent.RecUserSimi.end();
				rusit--;
				IncomingEvent.RecUserSimi.erase(rusit);
			}
		}
	}
}