#include "Event.h"
#include "EventRecomOpti.h"

void SocialEventOperation::FindSubEvents(vector<SocialMSG>& HashTagedMSGlist, 
	vector<SocialMSG>& NonHashTagedMSGlist, vector<SubEvent>& Eventclusters, 
	vector<SubEvent>& Eventcandidates) 
{
	FindRetweetClusters(HashTagedMSGlist, Eventclusters);	
	FindRetweetClusters(NonHashTagedMSGlist, Eventcandidates);

	for (int i = 0; i < Eventclusters.size(); i++) {
		Eventclusters[i].SetEventNo(i+1);
		Eventclusters[i].SetmigEventNo(0);
	}

	//check if each cluster in NonHashTagclusters is an event related subEvent
	vector<SubEvent>::iterator HashtagedIt, NonHashtagedIt, eraseit;
	NonHashtagedIt = Eventcandidates.begin();
	int countPtr = 0;
	while (NonHashtagedIt != Eventcandidates.end())
	{
		HashtagedIt = Eventclusters.begin();				
		int countHashtagit = 0;
		while (HashtagedIt != Eventclusters.end())
		{
			float ESim = (*HashtagedIt).EventSimi(*NonHashtagedIt);
			if (ESim >= ELIPSE) {
				//printf("Parent clusterno: %d\t ESim: %.4f\n", (*HashtagedIt).GetEventNo(), ESim);
				//==========set event no and keep its connection to the parent event
				(*NonHashtagedIt).SetEventNo(Eventclusters.size()+1);
				(*NonHashtagedIt).SetmigEventNo((*HashtagedIt).GetEventNo());
				//=======================
				Eventclusters.push_back(*NonHashtagedIt);
				eraseit = NonHashtagedIt;
				(*eraseit).cleansubEvent();
				Eventcandidates.erase(eraseit);
				
				NonHashtagedIt=Eventcandidates.begin()+ countPtr;
				HashtagedIt = Eventclusters.begin() + countHashtagit;
								
				break;
			}
			
			HashtagedIt++;
			countHashtagit++;
		}	
		
		if (HashtagedIt == Eventclusters.end()) {
			//NonHashtagedIt++;
			countPtr++;
			if(countPtr<Eventcandidates.size())
				NonHashtagedIt = Eventcandidates.begin() + countPtr;
			else
			{
				NonHashtagedIt = Eventcandidates.end();
			}
			
		}
	}

	//seting eventUserIdsFre for future event migration identification
	SetEventUserIdsFre(Eventclusters);
	SetEventUserIdsFre(Eventcandidates);
}

void SocialEventOperation::FindRetweetClusters(vector<SocialMSG>& MSGset,
	vector<SubEvent>& subEvents)
{
	if (MSGset.empty())
		return;

	int hashtagedFlag = 0;

	vector<SocialMSG>::iterator mp1 = MSGset.begin();
	if ((*mp1).hashtaged)
		hashtagedFlag = 1;

	int countmsg = 0;
	int ptrPos;

	while (mp1 != MSGset.end())
	{
		if(countmsg==51)
			printf("countmsg=%d\n", countmsg);
		countmsg++;
		vector<SubEvent>::iterator seit = subEvents.begin();
		
		while (seit != subEvents.end()) 
		{
			//find the retweeted subevent
			vector<SocialMSG>::iterator mp2 = (*seit).GetEventMSGs().begin();
			ptrPos = 0;
			while (mp2 != (*seit).GetEventMSGs().end()) 
			{
				unsigned long long int mp1R = (*mp1).getRetweetStatus();
				unsigned long long int mp2R = (*mp2).getRetweetStatus();

				if (mp1R == (*mp2).getMSGID() || mp2R == (*mp1).getMSGID()||
					(mp1R==mp2R && mp1R>0))
				{
					(*seit).uploadEventMsg(*mp1);
					(*seit).SetTimeRange();
					(*seit).SetSpaceRange();
					(*seit).SetCluster_ConceptTFIDFVec();
					(*seit).SetEventSpaceRanges();
					(*seit).SetEventTimeRanges();
					//check and added (*mp1).HashtagList if needed
					for (int i = 0; i < (*mp1).HashtagList.size(); i++) {
						int j=0;
						for (j = 0; j < (*seit).HashtagList.size(); j++) {
							if (strcmp((*mp1).HashtagList[i].c_str(), (*seit).HashtagList[j].c_str()) == 0) {
								break; //in the subevent hashtaglist already
							}
						}
						if (j == (*seit).HashtagList.size())//not found
							(*seit).HashtagList.push_back((*mp1).HashtagList[i]);
					}
					(*mp1).HashtagList.clear();
					//======================
					ptrPos++;
					mp2 = (*seit).GetEventMSGs().begin() + ptrPos;
					break;
				}

				//mp2++;
				ptrPos++;
				mp2 = (*seit).GetEventMSGs().begin()+ptrPos;
			}
			if (mp2 != (*seit).GetEventMSGs().end()) // in the current cluster
				break;	

			seit++;
		}

		if (seit == subEvents.end()) //not in any cluster, then take the current msg as a new cluster
		{
			SubEvent eseed;
			eseed.uploadEventMsg(*mp1);
			
			eseed.SetTimeRange();
			eseed.SetSpaceRange();
			eseed.SetCluster_ConceptTFIDFVec();
			eseed.SetEventSpaceRanges();
			eseed.SetEventTimeRanges();
			
			//check and add (*mp1).HashtagList
			for (int i = 0; i < (*mp1).HashtagList.size(); i++) {
				int j = 0;
				for (j = 0; j < eseed.HashtagList.size(); j++) {
					if (strcmp((*mp1).HashtagList[i].c_str(), eseed.HashtagList[j].c_str()) == 0) {
						break; //in the subevent hashtaglist already
					}
				}
				if (j == eseed.HashtagList.size())//not found
					eseed.HashtagList.push_back((*mp1).HashtagList[i]);
			}
			(*mp1).HashtagList.clear();

			subEvents.push_back(eseed);
		}
		mp1++;
	}	
	//==ignore the hashtag-based merge, return directly========================
	return;
	//==========================
	//merge subEvents based on hashtags. If two subEvents has common hashtag, they are merged
	if (hashtagedFlag) {
		vector<SubEvent>::iterator seit = subEvents.begin();
		while (seit != subEvents.end()) 
		{
			int LoopFlag = 1;
			while (LoopFlag) 
			{
				vector<SubEvent>::iterator seitIn = seit;				
				ptrPos = 1;
				seitIn = seit + ptrPos;
				while (seitIn != subEvents.end()) 
				{
					if (ShareHashTags((*seit).HashtagList, (*seitIn).HashtagList)) //merge
					{
						mp1 = (*seitIn).GetEventMSGs().begin();
						while (mp1 != (*seitIn).GetEventMSGs().end()) {
							(*seit).uploadEventMsg(*mp1);							
							mp1++;
						}
						(*seit).SetTimeRange();
						(*seit).SetSpaceRange();
						(*seit).SetCluster_ConceptTFIDFVec();
						(*seit).SetEventSpaceRanges();
						(*seit).SetEventTimeRanges();

						//check and added (*seitIn).HashtagList if needed
						for (int i = 0; i < (*seitIn).HashtagList.size(); i++) {
							int j = 0;
							for (j = 0; j < (*seit).HashtagList.size(); j++) 
								if (strcmp((*seitIn).HashtagList[i].c_str(), (*seit).HashtagList[j].c_str()) == 0) {
									break; //in the seit subevent hashtaglist already
								}							
							if (j == (*seit).HashtagList.size())//not found
								(*seit).HashtagList.push_back((*seitIn).HashtagList[i]);
						}
						(*seitIn).cleansubEvent();
						subEvents.erase(seitIn);
						//======================
						
						seitIn = seit + ptrPos;
						break;
					}
					//seitIn++;
					ptrPos ++;
					seitIn = seit + ptrPos;
				}
				if (seitIn == subEvents.end())	{
					LoopFlag = 0;					
					break;
				}
			}
			seit++;
		}		
	}
}

int SocialEventOperation::ShareHashTags(vector<string>& Phashtaglist, vector<string>& Shashtaglist)
{
	int ret = 0;
	int Psize = Phashtaglist.size();
	int Ssize = Shashtaglist.size();
	int i, j;
	for (i = 0; i < Psize; i++) {
		for (j = 0; j < Ssize; j++) {
			if (strcmp(Phashtaglist[i].c_str(), Shashtaglist[j].c_str()) == 0)
			{
				ret = 1;
				break;
			}
		}
		if (j < Ssize)
			break;
	}
	return ret;
}
void SocialEventOperation::SetEventUserIdsFre(vector<SubEvent>& Eventclusters)
{
	vector<SubEvent>::iterator ecit = Eventclusters.begin();
	while (ecit != Eventclusters.end())
	{
		(*ecit).SetEventUserIDs();
		ecit++;
	}
}

float SocialEventOperation::l2_dist_int(int* _p1, int* _p2, int _dim)
{
	float ret = 0;
	for (int i = 0; i < _dim; i++)
	{
		float dif = (float)(_p1[i] - _p2[i]);
		ret += dif * dif;
	}

	return ret;
}

//produce hash vectors for event representative concept vector
void SocialEventOperation::HashMappingEvent(SubEvent& se, LSB& lsb) {
	/*float* _g = NULL;
	_g = new float[lsb.m];

	lsb.getHashVector(0, se.GetCluster_ConceptTFIDFVec(), _g);		//tableID is also 0
	lsb.getZ(_g, se.EHashV);

	if (_g != NULL)
		delete _g;*/

	float* _g = NULL;
	_g = new float[lsb.m];
	int* hashV = NULL;
	hashV = new int[lsb.m];

	EventRecomOpti ero;
	ero.getEventHashVector(0, se.GetCluster_ConceptTFIDFVec(), _g, lsb);  
	   		
	for (int i = 0; i < lsb.m; i++)
		hashV[i] = 0;

	lsb.getZ(_g, hashV);

	for (int i = 0; i < MVALUE; i++)
		se.EHashV[i] = hashV[i];

	if (_g != NULL)
		delete _g;
	if (hashV != NULL)
		delete hashV;
}