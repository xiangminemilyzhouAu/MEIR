#pragma once

#include "EventRecommendation.h"
#include "strtokenizer.h"

struct ValueRangePair {	
	float minV;
	float maxV;
};

struct UserValueRangePair {
	int userid;
	float minV;
	float maxV;
};
class UPEventBucket {
private:
	int userNum; //the number of users in this partition
	vector<SubEvent> UProfileEventGroup;
	//vector<ValueRangePair> TopicRangeVector;
	ValueRangePair TopicRangeVector[TFIDF_DIM];
	vector<UserValueRangePair> InfluenceRangeVector;  //include TUNUM ValueRangePairs
	int minNumOfInfluencedUsers;
	int maxNumOfInfluencedUsers;
	SubEvent TFIDFCenter;
	float minAngleCos;
	float minAngleCosForCHDSet;
	float minAngleCosForNonCHDSet;

	//========
	ValueRangePair TimeRangePair;
	ValueRangePair SpaceRangePair[2]; //SpaceRangePair [0] stores max and min Lat, SpaceRangePair[1] stores max and min longi
	SpaceRange centreP; //the centre location point of all the subevents 
	float minimalRadius; //the minimal radius of subevents in this partion
	ValueRangePair TopicVectorAngleTanRanges[TFIDF_DIM];
public:
	vector<SpaceRange> clusterCentreSet;
	vector<DimHashKeyPair> commonHashDimSet;
	float maxModulesAngleCosForCHDSet_Non[2];
	UPEventBucket() {
		userNum = 1;
		//InfluenceRangeVector = new ValueRangePair[userNum];
		for (int i = 0; i < TFIDF_DIM; i++) {
			DimHashKeyPair kp;
			kp.dim = i;
			kp.HashKey = 0;
			commonHashDimSet.push_back(kp);
		}
	}

	UPEventBucket(int uNum) {
		userNum = uNum;
	//	InfluenceRangeVector = new ValueRangePair[userNum];
	}
	///////////////
	void setTopicVectorAngleTanRanges(ValueRangePair* TRV) {
		for (int i = 0; i < TFIDF_DIM; i++) {
			TopicVectorAngleTanRanges[i].minV = TRV[i].minV;
			TopicVectorAngleTanRanges[i].maxV = TRV[i].maxV;
		}
	}

	ValueRangePair* getTopicVectorAngleTanRanges() {
		return TopicVectorAngleTanRanges;
	}
	SpaceRange& getSpaceRangecentreP()
	{
		return centreP;
	}
	void setSpaceRangecentreP(SpaceRange& cp) {
		centreP.lat = cp.lat;
		centreP.longi = cp.longi;
		centreP.radius = cp.radius;
	}
	void setSpaceRangePair(ValueRangePair* TRV) {
		for (int i = 0; i < 2; i++) {
			SpaceRangePair[i].minV = TRV[i].minV;
			SpaceRangePair[i].maxV = TRV[i].maxV;
		}
	}
	ValueRangePair* getSpaceRangePair() {
		return SpaceRangePair;
	}
	void setTimeRangePair(ValueRangePair& TRV) {
		TimeRangePair.minV = TRV.minV;
		TimeRangePair.maxV = TRV.maxV;
	}
	ValueRangePair& getTimeRangePair() {
		return TimeRangePair;
	}
//finish==================modified by Emily on Jan.2022
	float GetminimalRadius() {
		return minimalRadius;
	}
	void setminimalRadius(float& miniR) {
		minimalRadius = miniR;
	}
	/////////////
	void setminAngleCos(float& minCos) {
		minAngleCos = minCos;
	}
	float& getminAngleCos() {
		return minAngleCos;
	}
		
	float getminAngleCosForCHDSet() {
		return minAngleCosForCHDSet;
	}

	float getminAngleCosForNonCHDSet() {
		return minAngleCosForNonCHDSet;
	}
	void setminAngleCosForCHDSet(float& minCos) {
		minAngleCosForCHDSet = minCos;
	}
	void setminAngleCosForNonCHDSet(float& minCos) {
		minAngleCosForNonCHDSet = minCos;
	}

	void setTFIDFCenter(SubEvent& e) {
		TFIDFCenter.setConceptTFIDFVec(e.GetCluster_ConceptTFIDFVec());
	}
	SubEvent& getTFIDFCenter() {
		return TFIDFCenter;
	}
	void setUProfileEventGroup(SubEvent&e) {
		UProfileEventGroup.push_back(e);
	}

	vector<SubEvent> &getUProfileEventGroup() {
		return UProfileEventGroup;
	}

	
	void setTopicRangeVector(ValueRangePair* TRV) {
		for (int i = 0; i < TFIDF_DIM; i++) {
			TopicRangeVector[i]=TRV[i];
		}
	}

	ValueRangePair * getTopicRangeVector() {
		return TopicRangeVector;
	}

	/*void setInfluenceRangeVector(vector<UserValueRangePair> &IRV) {
		int IRVnum = IRV.size();
		for (int i = 0; i < IRVnum; i++) {
			InfluenceRangeVector.push_back(IRV[i]);			
		}
	}*/

	void setInfluenceRangeVector(vector<UserValueRangePair>& IRV) {
		for (int i = 0; i < IRV.size(); i++) {
			//check if UVRP is updated in influenceRangeVec
			vector<UserValueRangePair>::iterator irvit = InfluenceRangeVector.begin();
			int inserted = 0;
			while (irvit != InfluenceRangeVector.end()) {
				if ((*irvit).userid == IRV[i].userid) {
					(*irvit).maxV = IRV[i].maxV;
					(*irvit).minV = IRV[i].minV;
					inserted = 1;
					break;
				}
				else if ((*irvit).userid > IRV[i].userid)
				{
					InfluenceRangeVector.insert(irvit, IRV[i]);
					inserted = 1;
					break;
				}
				irvit++;
			}
			if (!inserted)
				///////////////
				InfluenceRangeVector.push_back(IRV[i]);
		}
	}

	vector<UserValueRangePair>& getInfluenceRangeVector() {
		return InfluenceRangeVector;
	}

	void setMinNumInfluencedUsers(int minNum) {
		minNumOfInfluencedUsers = minNum;
	}

	void setMaxNumInfluencedUsers(int maxNum) {
		maxNumOfInfluencedUsers = maxNum;
	}

	int getMinNumInfluencedUsers() {
		return minNumOfInfluencedUsers;
	}

	int getMaxNumInfluencedUsers() {
		return maxNumOfInfluencedUsers;
	}

	void CleanBucketEvent() {
		UProfileEventGroup.clear();
		InfluenceRangeVector.clear();  
		commonHashDimSet.clear();
		clusterCentreSet.clear();
	}
	~UPEventBucket()
	{
		UProfileEventGroup.clear();
		InfluenceRangeVector.clear();  //include TUNUM ValueRangePairs
		commonHashDimSet.clear();
		clusterCentreSet.clear();
	}
};
class UPEventPartition { //user profile event partition
private:
	int userNum; //the number of users in this partition
	std::vector<UPEventBucket> UProfileEventGroup;
	ValueRangePair TopicRangeVector[TFIDF_DIM];
	ValueRangePair TimeRangePair;
	ValueRangePair SpaceRangePair[2]; //SpaceRangePair [0] stores max and min Lat, SpaceRangePair[1] stores max and min longi

	vector<UserValueRangePair> InfluenceRangeVector;  //include TUNUM ValueRangePairs
	int minNumOfInfluencedUsers;
	int maxNumOfInfluencedUsers;	

	SpaceRange centreP; //the centre location point of all the subevents 
	float minimalRadius; //the minimal radius of subevents in this partion
	ValueRangePair TopicVectorAngleTanRanges[TFIDF_DIM];
	float minAngleCos;
	float minAngleCosForCHDSet;
	float minAngleCosForNonCHDSet;
	SubEvent TFIDFCenter;
public:
	vector<SpaceRange> clusterCentreSet;
	vector<DimHashKeyPair> commonHashDimSet;
	float maxModulesAngleCosForCHDSet_Non[2];
	UPEventPartition() {
		userNum = 1;		
	}

	UPEventPartition(int uNum) {
		userNum = uNum;		
	}

	void setTopicVectorAngleTanRanges(ValueRangePair* TRV) {
		for (int i = 0; i < TFIDF_DIM; i++) {
			TopicVectorAngleTanRanges[i].minV = TRV[i].minV;
			TopicVectorAngleTanRanges[i].maxV = TRV[i].maxV;
		}
	}

	ValueRangePair* getTopicVectorAngleTanRanges() {
		return TopicVectorAngleTanRanges;
	}
	void setUProfileEventGroup(UPEventBucket &e) {
		UProfileEventGroup.push_back(e);
	}

	void setUProfileEvent(SubEvent& e, int Bucketno) {
		if (UProfileEventGroup.size() <= Bucketno)
			UProfileEventGroup.resize(Bucketno + 1);
		UProfileEventGroup[Bucketno].setUProfileEventGroup(e);
	}

	/*void setTFIDFCenter(SubEvent& e, int Bucketno) {
		if (UProfileEventGroup.size() <= Bucketno)
			UProfileEventGroup.resize(Bucketno + 1);
		UProfileEventGroup[Bucketno].setTFIDFCenter(e);
	}

	void setminAngleCos(float& minCos, int Bucketno) {
		UProfileEventGroup[Bucketno].setminAngleCos(minCos);
	}*/

	std::vector<UPEventBucket> &getUProfileEventGroup() {
		return UProfileEventGroup;
	}

	void setTopicRangeVector(ValueRangePair* TRV) {
		for (int i = 0; i < TFIDF_DIM; i++) {
			TopicRangeVector[i].minV = TRV[i].minV;
			TopicRangeVector[i].maxV = TRV[i].maxV;
		}
	}

	//==================modified by Emily on 27 Feb.2021
	float &GetminimalRadius() {
		return minimalRadius;
	}
	void setminimalRadius(float& miniR) {
		minimalRadius = miniR;
	}
	SpaceRange& getSpaceRangecentreP()
	{
		return centreP;
	}
	void setSpaceRangecentreP(SpaceRange& cp) {
		centreP.lat = cp.lat;
		centreP.longi = cp.longi;
		centreP.radius = cp.radius;
	}

	void setminAngleCos(float& minCos) {
		minAngleCos = minCos;
	}
	float& getminAngleCos() {
		return minAngleCos;
	}

	float getminAngleCosForCHDSet(){
		return minAngleCosForCHDSet;
	}

	float getminAngleCosForNonCHDSet(){
		return minAngleCosForNonCHDSet;
	}
	void setminAngleCosForCHDSet(float& minCos) {
		minAngleCosForCHDSet=minCos;
	}
	void setminAngleCosForNonCHDSet(float& minCos) {
		 minAngleCosForNonCHDSet = minCos;
	}

	void setTFIDFCenter(SubEvent& e) {
		TFIDFCenter.setConceptTFIDFVec(e.GetCluster_ConceptTFIDFVec());
	}
	SubEvent& getTFIDFCenter() {
		return TFIDFCenter;
	}
	//finish==================modified by Emily on 27 Feb.2021

	ValueRangePair* getTopicRangeVector() {
		return TopicRangeVector;
	}

	void setSpaceRangePair(ValueRangePair* TRV) {
		for (int i = 0; i < 2; i++) {
			SpaceRangePair[i].minV = TRV[i].minV;
			SpaceRangePair[i].maxV = TRV[i].maxV;
		}
	}
	ValueRangePair* getSpaceRangePair() {
		return SpaceRangePair;
	}
	void setTimeRangePair(ValueRangePair& TRV) {
		TimeRangePair.minV = TRV.minV;
		TimeRangePair.maxV = TRV.maxV;
	}
	ValueRangePair& getTimeRangePair() {
		return TimeRangePair;
	}

	void setInfluenceRangeVector(vector<UserValueRangePair> &IRV) {
		for (int i = 0; i < IRV.size(); i++) {
			//check if UVRP is updated in influenceRangeVec
			vector<UserValueRangePair>::iterator irvit = InfluenceRangeVector.begin();
			int inserted = 0;
			while (irvit != InfluenceRangeVector.end()) {
				if ((*irvit).userid == IRV[i].userid) {
					(*irvit).maxV = IRV[i].maxV;
					(*irvit).minV = IRV[i].minV;
					inserted = 1;
					break;
				}
				else if ((*irvit).userid > IRV[i].userid)
				{
					InfluenceRangeVector.insert(irvit, IRV[i]);
					inserted = 1;
					break;
				}
				irvit++;
			}
			if (!inserted)
				///////////////
				InfluenceRangeVector.push_back(IRV[i]);
		}
	}
	vector<UserValueRangePair>& getInfluenceRangeVector() {
		return InfluenceRangeVector;
	}

	void setMinNumInfluencedUsers(int minNum) {
		minNumOfInfluencedUsers = minNum;
	}
	
	void setMaxNumInfluencedUsers(int maxNum) {
		maxNumOfInfluencedUsers = maxNum;
	}

	int getMinNumInfluencedUsers() {
		return minNumOfInfluencedUsers;
	}

	int getMaxNumInfluencedUsers() {
		return maxNumOfInfluencedUsers;
	}

	~UPEventPartition()
	{
		UProfileEventGroup.clear();		
		clusterCentreSet.clear();
		InfluenceRangeVector.clear();
	}
};

class EventRecomOpti {
private:
	
public:
	EventRecomOpti() {}
	~EventRecomOpti() {}
	void UserProfileDataPartition(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups, std::vector<UPEventPartition> &UProfileEventGroupSets, LSB &lsb, SocialEventOperation &seoper);
	void ProduceDataPartitionSummary(UPEventPartition & UProfileEventGroup);
	void ContinuousUserProfileDataPartition(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups, 
		std::vector<UPEventPartition>& UProfileEventGroupSets, LSB& lsb, SocialEventOperation& seoper);

	//=====Emily in Dec. 2021===========================
	void UserProfileDataPartitionAngleHash(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups, std::vector<UPEventPartition>& UProfileEventGroupSets, SocialEventOperation& seoper);
	void getkmeansCentres(vector<SubEvent>& inputEventlist, int NumOfGroups, vector<SubEvent> outeventGroups[], vector<SubEvent>& TFIDFCenters);
	void kmeansClusters(vector<SubEvent>& inputEventlist, int NumOfGroups, vector<SubEvent> outeventGroups[], vector<SubEvent>& TFIDFCenters);
	
	void UserProfileDataPartitionAngleHashMixedHashKMeans(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
		std::vector<UPEventPartition>& UProfileEventGroupSets, SocialEventOperation& seoper);
	void ContinuousUserProfileDataPartitionAngleHashMixedHashKMeans(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
		std::vector<UPEventPartition>& UProfileEventGroupSets);

	void ProduceEventBucketSummary(UPEventBucket& UProfileEventBucket);
	float ComputeMinAngleCos(UPEventBucket& UProfileEventBucket, SubEvent& TFIDFCenters);
	int ComputeTopicCentre(UPEventBucket& UProfileEventBucket, float TopicVectoCentre[]);
	void ComputeAngleVector(SubEvent& eventV, float TopicVectorAngle[]);
	void ReadMaxMinDimValues(char* FileName, float MaxValues[], float MinValues[]);
	float ComputeUnionMinAngleCos(UPEventBucket& UProfileEventBucketF, vector<UPEventBucket>& UProfileEventBucketS);
	float ComputeBucketUnionMinAngleCos(UPEventBucket& UProfileEventBucketF, UPEventBucket & UProfileEventBucketS);
	int ComputeCommonHashKeyDim(UPEventBucket& UProfileEventBucketF, UPEventBucket& UProfileEventBucketS);
	void AllocateBucketsofGroups2ProcessorsUnion(std::vector<UPEventBucket>& UPEBuckets, int NumOfGroups,
		std::vector<UPEventPartition>& UProfileEventGroupProcessors);
	int ComputeTopicCentrePartition(vector<UPEventBucket>& UProfileEventBucket, float TopicVectoCentre[]);
	float ComputePartitionMinAngleCos(UPEventPartition& UProfileEventPartition, SubEvent& TFIDFCenters);
	
	float GetTBoundValue(ValueRangePair* UserParVPRect, float* EventVRP, float* VirtualEventTopic, 
		vector<DimHashKeyPair>& commondims, float& ModuleVirETopicSquare, float& ModuleEVRPSquare, UPEventBucket& upebut, SubEvent& IncomingEvent);

	void ContinuousUserProfileDataPartitionAngleHash(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
		std::vector<UPEventPartition>& UProfileEventGroupSets);
	void ConflictEvents2BucketsCosinAngle(std::vector<SubEvent>& UProfileEventSet,
		std::vector<UPEventBucket>& UPEventBuckets);
	void ConflictEvents2BucketsDimHash(std::vector<SubEvent>& UProfileEventSet, 
		std::vector<UPEventBucket>& UPEventBuckets, int conflictKeyNum);
	void UnionBucketsBySimilarity(std::vector<UPEventBucket>& UPEBuckets, float simiThreshold, int conflictKeyNumThre);

	void UnionIncomingBucketsToParitionsBySimilarity(std::vector<UPEventPartition>& UProfileEventGroupSets,std::vector<UPEventBucket>& UPEBuckets, float simiThreshold, int conflictKeyNumThre);
	void AllocateIncomingBucketsofGroups2ProcessorsUnion(std::vector<UPEventBucket>& UPEBuckets, int NumOfGroups,
		std::vector<UPEventPartition>& UProfileEventGroupProcessors);
	//========================================
	void UserProfileDataPartitionContentUser(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
		std::vector<UPEventPartition>& UProfileEventGroupSets, LSB& lsb, LSB& lsbuser, SocialEventOperation& seoper);
	void MapEvent2VecContentUser(std::vector<SubEvent>& UProfileEventSet, LSB& lsb, LSB& lsbuser);
	void ContinuousUserProfileDataPartitionContentUser(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups,
		std::vector<UPEventPartition>& UProfileEventGroupSets, LSB& lsb, LSB& lsbuser, SocialEventOperation& seoper);
	
	void UserProfileDataPartitionHP(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups, std::vector<UPEventPartition>& UProfileEventGroupSets, SocialEventOperation& seoper);
	void ContinuousUserProfileDataPartitionHP(std::vector<SubEvent>& UProfileEventSet, int NumOfGroups, std::vector<UPEventPartition>& UProfileEventGroupSets, SocialEventOperation& seoper);
	void onePassClustering(std::vector<SubEvent>& dataset, float SimiT, std::vector<UPEventBucket>& subsets);
	//==============
	void IncomingEventSubsetIdentification(std::vector<SubEvent>&IncomingEventSet, std::vector<SubEvent>&IncomingEventSubset,
		UPEventPartition &UPEPar, float SimiThreshold, float alpha);
	void EventSimilarityJoin(UPEventPartition& UserProfileEventPartion, std::vector<SubEvent>&IncomingEventSubset, float SimiThreshold, EventRecommendation eventRec);

	///supporting fuctions for UserProfileDataPartition
	void MapEvent2Vec(std::vector<SubEvent>& UProfileEventSet, LSB &lsb);
	void getEventHashVector(int _tableID, float * _key, float *_g, LSB &lsb);
	void ConflictEvents2Buckets(std::vector<SubEvent>& UProfileEventSet, std::vector<UPEventBucket>&UPEventBuckets, LSB &lsb, SocialEventOperation &seoper);
	void AllocateBucketsofGroups2Processors(std::vector<UPEventBucket> &UPEBuckets, int NumOfGroups, std::vector<UPEventPartition>& UProfileEventGroupProcessors, LSB &lsb, SocialEventOperation &seoper);

	void ContinuousAllocateBucketsofGroups2Processors(std::vector<UPEventBucket>& UPEBuckets, int NumOfGroups, std::vector<UPEventPartition>& UProfileEventGroupProcessors, LSB& lsb, SocialEventOperation& seoper);

	int findSmallestGroup(std::vector<UPEventPartition>& UProfileEventGroupProcessors, int NumOfGroups);

	//supporting functions for IncomingEventSubsetIdentification
	float ComputeUPmax(UPEventPartition& UserProfileEventPartition, SubEvent& IncomingEvent, float alpha, float SimiThreshold);
	float ComputeUPmaxT(UPEventPartition& UserProfileEventPartition, SubEvent& IncomingEvent,int bucketNo);
	float ComputeProb_EvEn(UPEventPartition& UserProfileEventPartition, SubEvent& IncomingEvent, int bucketNo);

	
	//added by Emily on 27June, 2021
	int SelectDimOutRect(ValueRangePair* UserParVPRect, float* EventVRP, vector<int>& DominantDim, float& Top2DomDmincost);
	int SelectNextDominantDim(ValueRangePair* UserParVPRect, float* EventVRP, vector<int>& CandidateDim, vector<int>& DominantDim);
	float GetTBoundCosofDominantDim(ValueRangePair* UserParVPRect, float* EventVRP, vector<int>& DominantDim);  //in multiple dimensions

	//==================modified by Emily on 27 Feb.2021
	float ComputeUPmaxLocationNew(SpaceRange & sr, float& minimalRange, SubEvent& IncomingEvent);
	float ComputeCircleSlopeCoefficient(SpaceRange* sr); //K--Tan angle
	int GetCrossCircleLineCrossPoint(SpaceRange& sr, SubEvent& IncomingEvent, SpaceRange& crossPoint);
	//finish==================modified by Emily on 27 Feb.2021

	float ComputeUPmaxTime(ValueRangePair &vrp, SubEvent& IncomingEvent);

	void GetDomiUserVirEvent(UPEventPartition& UserProfileEventPartition, SubEvent& IncomingEvent, SubEvent& VirtualUPPevent, int bucketNo);
	void GetUserInEventPartition(UPEventPartition& UserProfileEventPartition, std::vector<int> &userlist, int bucketNo);

	void RemoveNonInfluentialUsers(std::vector<int> &userlist, std::vector<EUserFrePair> &eventUserIdsFre, std::vector<float> &influentials);
	void RankInfluentialUsers(std::vector<int>& userlist, std::vector<float>& influentials);

	//supporing function for EventSimilarityJoin
	void UpdateRecUserSimi(SubEvent& IncomingEvent, SubEvent& UserProfileEvent, float simiV);
	void UnionLSHBucketsBySimilarity(std::vector<UPEventBucket>& UPEBuckets, float simiThreshold);
};