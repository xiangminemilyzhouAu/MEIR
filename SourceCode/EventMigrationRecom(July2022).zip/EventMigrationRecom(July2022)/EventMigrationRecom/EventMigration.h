#pragma once

#include "SocialMessage.h"
#include "Event.h"

extern vector<SubEvent> UPEventList;

//#define TUNUM 135782//14978//20//10000 //total number of users in training dataset
//#define WUIPV 0.7   


struct UserProfile
{
	int userId;  //the index no of user in user dictionary
	unsigned long long int userOId;  // the original user id from twitter
	vector<UPInfluDistriEle> UserInfluenceDistri;

	SpaceRange UserPhysicalLocation;
	int PostNum;//the toal number of posts for this user
	vector<UPRespnseEle> UserResponseNumbers; //user variable length array to reduce the memory cost
	vector<SubEvent> UserInterestEvents;

	int Inserted;//if allocated to a partition, for user partition 
};

extern vector<UserProfile> UserProfileHashMap;

struct GraphEdge {
	UserProfile upStart;
	UserProfile upEnd;
	float weight;	

	//for recording middle results
	float physicalRel; //based on physical distance
	float SocialRel; //based on social network
};

extern vector<UserProfile> UserProfileHashMap;

class UserInfluenceGraph {
private:
	vector<UserProfile> uplist;
	vector<GraphEdge> GEdgeSet;
	float WUIP; // WUIP is the weight of user influence probability
public:
	UserInfluenceGraph() { WUIP = WUIPV; }
	void loadtoUplist(UserProfile & up) {
		uplist.push_back(up);
	}

	void setNewUpValue(UserProfile & up) {
		vector<UserProfile>::iterator uit = uplist.begin();
		int listSize = uplist.size();
		int i;
		for ( i = 0; i < uplist.size(); i++) {
			if (uplist[i].userId == up.userId){
				uplist[i] = up;
				break;
			}
			else if (uplist[i].userId > up.userId)
			{
				uit = uit + i;
				uplist.insert(uit, up);
				break;
			}
		}
		if (i == listSize)
			uplist.push_back(up);
	}

	void setWUIP(float &uipweight) {
		WUIP = uipweight;
	}

	float getWUIP() {
		return WUIP;
	}

	void setEdge(GraphEdge & gEdge) {
		GEdgeSet.push_back(gEdge);
	}

	vector<GraphEdge> & GetEdgeSet() {
		return GEdgeSet;
	}

	vector<UserProfile> & Getuplist() {
		return uplist;
	}

	~UserInfluenceGraph() { 
		uplist.clear();
		GEdgeSet.clear();
	}

};

class EventMigration {
private:
		
public:
	UserInfluenceGraph uiGraph;
	EventMigration(){}
	EventMigration(UserInfluenceGraph & uig) {
		uiGraph = uig;
	}

	double rad(double d) {
		return d * PI / 180.0;
	}

	double round(double d) {
		return floor(d + 0.5);
	}

	double get_distance(double lat1, double lng1, double lat2, double lng2) //compute distance of two points on earth surface
	{
		double radLat1 = rad(lat1);
		double radLat2 = rad(lat2);
		double a = radLat1 - radLat2;
		double b = rad(lng1) - rad(lng2);
		double s = 2 * asin(sqrt(pow(sin(a / 2), 2) + cos(radLat1)*cos(radLat2)*pow(sin(b / 2), 2)));
		s = s * EARTH_RADIUS;
		s = round(s * 10000) / 10000;
		return s;
	}

	float UserlocationSim(SpaceRange & sp1, SpaceRange &sp2);  //compute the location similarity of two users

	int uploadUserProfilesNew(char* flist, char* path); //read user profiles to UserInfluenceGraph class. all the user profile information is in a single file flist
	int uploadUserProfilesIntoHashMap(char* flist, char* userProfilePath); //read user profiles to UserProfileHashMap
	int constructIGEdges();  //construct the edges of uiGraph, each edge is the Im between two users
	int loadIGEdges(); //read the edges of uiGraph, each edge is the Im between two users
	float GetDirectInfluence(UserProfile &up1, UserProfile &up2, GraphEdge& gedge); //compute the direct influence probability from up1 to up2
	float GetUserSimi(UserProfile &up1, UserProfile &up2);  //compute the similarity of two users
	//void Dijkstra(int n, int v, float *simi, int *prev, float c[][TUNUM+1]);
	void Dijkstra(int n, int v, float* simi, int* prev, float c[][ROWSV + 1]);

	int constructSlotIGEdges(EventMigration& em);  //for single time slot edge construction
	int ConstructSlotUserInfluenceGraphSubRoutine(char* flist, char* path, EventMigration& em);
	int GenerateSlotUserGroups(vector<UserProfile>& uplist, vector<vector<int>>& uidPPtr, EventMigration& em);

	int ConstructUserInfluenceGraph(char *flist, char *path);
	int ConstructUserInfluenceGraphSubRoutine(char* flist, char* path);
	int GenerateUserGroups(vector<UserProfile>& uplist, vector<vector<int>>& uidPPtr);
	int InGroup(vector<int>& userlist, int userid);

	int ContinuousUserInfluenceGraphUpdate(char* flistname, char* path);
	int IncrementalUserInfluenceGraphUpdate(char* filename, char* path);
	//compute the relevance probability Probr of seventF and sevent2
	float EventMigrationProb(SubEvent&seFirst, SubEvent&seMigrate);
	
	int IsMigrateEvent(SubEvent&seFirst, SubEvent&seMigrate, float migrateT);
		
	//added by emily Feb 11
	int loadUserInfluenceGraph(char* UIfname); //input the user influence filename, and load the user influence information into the graph
	int loadUserProfileHashMap(char* UIfname); //input the user influence filename, and load the user influence information into UserProfileHashMap
	int BulkLoadUserHistoryEvents(char* userEventflist, char* path);//for all users

	int UpdateUserProfileHashMap(char* UIfname);  //for continuously updating the user profiles considering the new user interactions in the recent time slots.
	int LoadUserProfileEvents(char* UEventfname,int StartClusterNo); //

	//for parallel
	int LoadUserHistoryEventsForSpark(char* UEventfname, int userid, vector<SubEvent>& elist);
	int BulkLoadUserHistoryEventsForSpark(char* userflist,vector<SubEvent>&elist);//for all users
	
	~EventMigration(){}
};