#pragma once
#include "EventMigration.h"

#define MAXEVENTNUM 20000//20  //The maximal number of incoming events in a time slot
#define ALPHA 0.7//0.4
#define KUNUM 500

struct RecItem {  //remember: recommend a given item to users, USERID should be output
	int UserID;
	float simi;
};

struct RecEventItem {  //remember: recommend a given item to users related to top k relevant events, EventID is output for evaluation. USERID should be output
	int EventID;
	float simi;
	set<int> UserID;
};

class EventRecommendation {
private:
	float alpha; //(1-alpha): the weight of ESim; alpha: the weight of migration
	int curEventNum; //the number of incoming events in the current time slot
public:
	EventRecommendation() { }
	EventRecommendation(float alphaV, int curEnum) {
		alpha = alphaV;
		curEventNum=curEnum;		
	}

	~EventRecommendation() {		
	}

	void setcurEventNum(int curEnum) {
		curEventNum = curEnum;
	}
	int getEventNum() { return curEventNum; }
	//matching two events
	float GetESim(SubEvent &En, SubEvent&Eu);
	//matching an incoming event with a user profile
	float GetESimUser(SubEvent &En, UserProfile &up);
	
	float GetIntraSjIa(int gjattrJx_eventlistSize, int gjattrJy_eventlistSize);
	
	int Get_gjx_eventlist_Size(int j, float x);

	float GetProbEventClusters(int EnNo, int EuNo);
	float GetProbUserEvent(SubEvent&En, int EnNo, UserProfile &up);
};