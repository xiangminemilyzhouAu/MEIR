﻿#pragma once
#include <list>
#include <vector>
#include "SocialMessage.h"
#include "lsb.h"


typedef vector<SocialMSG> MSGSET;

class SubEvent {
private:	
	long long int retweetedStatus;
	TimeRange Cluster_TR;
	SpaceRange Cluster_SR;
		
	float Cluster_ConceptTFIDFVec[TFIDF_DIM];
	vector<EUserFrePair> eventUserIdsFre; // a number of user-event interaction recorders, here users are those attached with this message
	vector<SocialMSG> EventMSG;
	
	vector<SpaceRange> msgSRset;
	vector<TimeRange> msgTRset;

	float UserInfluVec[TFIDF_DIM];

	int eventno;
	int migEno;  //this subevent eventno is relevant to migEno based on similarity or migration
	float migSimi;
	float TFIDFVecAngleSphericalCorSys[TFIDF_DIM];
public:
	int EHashV[MVALUE]; //leave it for hash-based clustering.
	DimHashKeyPair EDIMHashV[TFIDF_DIM]; //hashing each dimension for hash-based clustering
	//int* EventHashV = NULL; //leave it for hash-based data partition for parallel processing over spark.
	std::vector<EventUserSimi> RecUserSimi; //the user id list with similarity for recommending this event to, for parallel processing over spark only
//	std::vector<int> userlist; //a list of users whose user profile contains this event

	vector<string> HashtagList;
	int eventCluster; //for checking if the current subEvent is in groudtruth event
	float HistEventSimilarity; //for history events similarity precomputation for fast recommendation
	SubEvent() {
	}
		
	void uploadmsgSRset(SpaceRange &sr) {
		msgSRset.push_back(sr);
	}
	void uploadmsgTRset(TimeRange& tr) {
		msgTRset.push_back(tr);
	}
	vector<SpaceRange>& getmsgSRset() {
		return msgSRset;
	}
	vector<TimeRange>& getmsgTRset() {
		return msgTRset;
	}

	float EventSimi(SubEvent& otherSubEvent) {
		float simi = 1;
		
		simi = GetGlobalSimilarity(&otherSubEvent);
		return simi;
	}	

	SubEvent(float* vec, float *userinflu, TimeRange tr, SpaceRange sr, long long int retweetedNo) 
	{
		//Cluster_ConceptTFIDFVec = new float[TFIDF_DIM];
		for (int i = 0; i < TFIDF_DIM; i++) {
			Cluster_ConceptTFIDFVec[i] = vec[i];
			UserInfluVec[i] = userinflu[i];
			TFIDFVecAngleSphericalCorSys[i] = 0;  //initialize
		}
		Cluster_TR.TimeStampCentre = tr.TimeStampCentre;
		Cluster_TR.range = tr.range;

		Cluster_SR.lat = sr.lat;
		Cluster_SR.longi = sr.longi;
		Cluster_SR.radius = sr.radius;

		retweetedStatus = retweetedNo;
		eventCluster = 0;
		eventno = 0;
		migEno = 0;
	}


	void EventReset() 
	{		
		for (int i = 0; i < TFIDF_DIM; i++) {
			Cluster_ConceptTFIDFVec[i] = 0;
			UserInfluVec[i] = 0;
			TFIDFVecAngleSphericalCorSys[i] = 0;
		}
		Cluster_TR.TimeStampCentre = 0;
		Cluster_TR.range = 0;
		Cluster_SR.lat = 0;
		Cluster_SR.longi =0;
		Cluster_SR.radius = 0;
		eventno = 0;
		migEno = 0;
		eventCluster = 0;
		HistEventSimilarity = 0;
		cleansubEvent();
	}
	void SetEventNo(int eno) {
		eventno = eno;
	}

	int GetEventNo() {
		return eventno;
	}

	void SetmigEventNo(int eno) {
		migEno = eno;
	}

	int GetmigEventNo() {
		return migEno;
	}
	void SetmigSimi(float msim) {
		migSimi = msim;
	}
	float GetmigSimi() {
		return migSimi;
	}
	int setEventUserIDs(vector<EUserFrePair>& euidlist) {
		for (int i = 0; i < euidlist.size(); i++)
		{
			eventUserIdsFre.push_back(euidlist[i]);
		}
		return eventUserIdsFre.size();
	}

	int SetEventCommentUserIDs() 
	{
		int usernumber = 0;
		eventUserIdsFre.clear();
		vector<SocialMSG>::iterator smgit = EventMSG.begin();
		while (smgit != EventMSG.end()) {
			vector<EUserFrePair>::iterator euit = (*smgit).getEventUserIDsFre().begin();
			vector<EUserFrePair>::iterator euitend = (*smgit).getEventUserIDsFre().end();
			while (euit != euitend)
			{
				//skip the first user which is the author of the message
				if (euit == (*smgit).getEventUserIDsFre().begin()) {
					euit++;
					continue;
				}
				//search eventUserIdsFre
				vector<EUserFrePair>::iterator eufpit = eventUserIdsFre.begin();
				while (eufpit != eventUserIdsFre.end())
				{
					if ((*eufpit).userid == (*euit).userid) //found from the eventUserIDsFre
					{
						(*eufpit).frequency += (*euit).frequency;
						break;
					}
					eufpit++;
				}
				if (eufpit == eventUserIdsFre.end())  //not found from the eventUserIDsFre
				{
					EUserFrePair newUFpair;
					newUFpair.userid = (*euit).userid;
					newUFpair.frequency = (*euit).frequency;
					eventUserIdsFre.push_back(newUFpair);
				}

				euit++;
			}
			smgit++;
		}
		return eventUserIdsFre.size();
	}
	int SetEventUserIDs() 
	{
		int usernumber = 0;
		eventUserIdsFre.clear();
		vector<SocialMSG>::iterator smgit = EventMSG.begin();
		while (smgit != EventMSG.end()) {
			vector<EUserFrePair>::iterator euit = (*smgit).getEventUserIDsFre().begin();
			vector<EUserFrePair>::iterator euitend = (*smgit).getEventUserIDsFre().end();
			while (euit != euitend) 
			{
				//search eventUserIdsFre
				vector<EUserFrePair>::iterator eufpit = eventUserIdsFre.begin();
				while (eufpit != eventUserIdsFre.end()) 
				{
					if ((*eufpit).userid == (*euit).userid) //found from the eventUserIDsFre
					{
						(*eufpit).frequency += (*euit).frequency;
						break;
					}
					eufpit++;
				}
				if (eufpit == eventUserIdsFre.end())  //not found from the eventUserIDsFre
				{
					EUserFrePair newUFpair;
					newUFpair.userid = (*euit).userid;
					newUFpair.frequency = (*euit).frequency;
					eventUserIdsFre.push_back(newUFpair);
				}	
				
				euit++;
			}
			smgit++;
		}
		return eventUserIdsFre.size();
	}
	void cleanMsg() {
		for (int i = 0; i < EventMSG.size(); i++)
			EventMSG[i].cleanMSG();
		EventMSG.clear();
	}

	int SetEventSpaceRanges()
	{		
		vector<SocialMSG>::iterator smgit = EventMSG.begin();
		while (smgit != EventMSG.end()) 
		{
			vector<SpaceRange>::iterator msgsrit = msgSRset.begin();
			SpaceRange sr = (*smgit).getSpaceRange();
			int inserted = 0;
			while (msgsrit != msgSRset.end()) 
			{
				if ((*msgsrit).lat > sr.lat) {
					msgSRset.insert(msgsrit, sr);
					inserted = 1;
					break;
				}
				else if ((*msgsrit).lat == sr.lat)
				{
					if ((*msgsrit).longi > sr.longi)
					{
						msgSRset.insert(msgsrit, sr);
						inserted = 1;
						break;
					}
					else if ((*msgsrit).longi == sr.longi) {
						inserted = 1;
						break;
					}
				}				
				msgsrit++;
			}	
			if (!inserted) {
				msgSRset.push_back(sr);
			}
			smgit++;
		}
		return msgSRset.size();
	}
	
	vector<TimeRange>& GetEventTimeRanges() {
		return msgTRset;
	}

	int SetEventTimeRanges()
	{
		vector<SocialMSG>::iterator smgit = EventMSG.begin();
		while (smgit != EventMSG.end())
		{
			vector<TimeRange>::iterator msgsrit = msgTRset.begin();
			TimeRange tr = (*smgit).getTimeRange();
			int inserted = 0;
			while (msgsrit != msgTRset.end())
			{
				if ((*msgsrit).TimeStampCentre > tr.TimeStampCentre) {
					msgTRset.insert(msgsrit, tr);
					inserted = 1;
					break;
				}
				else if ((*msgsrit).TimeStampCentre == tr.TimeStampCentre)
				{					
					inserted = 1;
					break;					
				}
				msgsrit++;
			}
			if (!inserted) {
				msgTRset.push_back(tr);
			}
			smgit++;
		}
		return msgTRset.size();
	}
	//for EventRecomOpti.cpp
	int SetEventUserIDs_Vec(vector<int> &userlist)
	{
		int usernumber = userlist.size();
		EUserFrePair upair;
		upair.frequency = 1;
		for (int i = 0; i < usernumber; i++) {
			upair.userid = userlist[i];
			eventUserIdsFre.push_back(upair);
		}
		return usernumber;
	}
	////////////////////

	vector<SocialMSG>& GetEventMSGs() {
		return EventMSG;
	}
	vector<EUserFrePair> & GetEventUserIDs() {
		return eventUserIdsFre;
	}

	void setConceptTFIDFVec(float* vec) {
		for (int i = 0; i < TFIDF_DIM; i++) {
			Cluster_ConceptTFIDFVec[i] = vec[i];
		}
	}

	void setTFIDFVecAngleSphericalCorSys(float* vec) {
		for (int i = 0; i < TFIDF_DIM; i++) {
			TFIDFVecAngleSphericalCorSys[i] = vec[i];
		}
	}
	

	void setUserInfluVec(float* vec) {
		for (int i = 0; i < TFIDF_DIM; i++)
			UserInfluVec[i] = vec[i];
	}

	float GetGlobalSimilarity(SubEvent *sevt)
	{	
		float Gsim = 0;

		switch (MethodChoice) {
		case 1:
			Gsim = GetConceptSimilarity(sevt);
			break;
		case 2:
			Gsim = GetTimeSimilarity(sevt);
			break;
		case 3:
			Gsim = GetSpaceSimilarity(sevt);
			break;
		case 4:			
			Gsim = omeg1 * GetConceptSimilarity(sevt) + (1 - omeg1)*GetTimeSimilarity(sevt);
			break;
		case 5:
			Gsim = omeg1* GetConceptSimilarity(sevt) + (1 - omeg1)*GetSpaceSimilarity(sevt);
			break;
		case 6:
			Gsim = omeg1 * GetConceptSimilarity(sevt) + omeg2 * GetTimeSimilarity(sevt) + (1 - omeg1 - omeg2) * GetSpaceSimilarity(sevt);
			break;		
		}

		return Gsim;
	}
	//===copied from SocialMessage.h
	float CVModule() {
		float ret = 0;
		for (int i = 0; i < TFIDF_DIM; i++) {
			ret += this->Cluster_ConceptTFIDFVec[i] * this->Cluster_ConceptTFIDFVec[i];
		}
		return sqrt(ret);
	}
	
	float GetConceptSimilarity(SubEvent* sevt) {
		float simi = 0;
		for (int i = 0; i < TFIDF_DIM; i++) {
			simi += sevt->Cluster_ConceptTFIDFVec[i] * Cluster_ConceptTFIDFVec[i];
		}
		float thisModule = this->CVModule();
		float smsgModule = sevt->CVModule();

		if(simi!=0)
		{
			simi /= thisModule;
			simi /= smsgModule;
		}
		return simi;
	}

	float GetConceptSimilaritySubspace(SubEvent* sevt) {
		float simi = 0;
		float thisModule = 0;
		float smsgModule = 0;
		for (int i = 0; i < TFIDF_KEYDIM; i++) {
			simi += sevt->Cluster_ConceptTFIDFVec[KeyDim[i]] * Cluster_ConceptTFIDFVec[KeyDim[i]];
			thisModule += pow(Cluster_ConceptTFIDFVec[KeyDim[i]], 2);
			smsgModule += pow(sevt->Cluster_ConceptTFIDFVec[KeyDim[i]], 2);
		}
		thisModule = sqrt(thisModule);
		smsgModule = sqrt(smsgModule);
		if (simi != 0) {
			simi /= thisModule;
			simi /= smsgModule;
		}
		return simi;
	}

	float GetConceptSimilarityDimSubset(SubEvent* sevt, vector<DimHashKeyPair> & Dims, float & thisModuleSquare, float &sevtModuleSquare) {
		float simi = 0;
		float thisModule = 0;
		float smsgModule = 0;
		int dimNo = Dims.size();
		for (int i = 0; i < dimNo; i++) {
			simi += sevt->Cluster_ConceptTFIDFVec[Dims[i].dim] * Cluster_ConceptTFIDFVec[Dims[i].dim];
			thisModule += pow(Cluster_ConceptTFIDFVec[Dims[i].dim], 2);
			smsgModule += pow(sevt->Cluster_ConceptTFIDFVec[Dims[i].dim], 2);
		}
		thisModuleSquare = thisModule;
		sevtModuleSquare = smsgModule;
		thisModule = sqrt(thisModule);
		smsgModule = sqrt(smsgModule);
		
		if (simi != 0) {
			simi /= thisModule;
			simi /= smsgModule;
		}
		return simi;
	}

	float GetTimeSimilarity(SubEvent* sevt) {
		float Tsim;
		
		//===include Hausdorff
		Tsim = getTimeDiff(&Cluster_TR, &sevt->Cluster_TR);
		/*//get the Hausdorff similarity
		float haus = get_Hausdorff_Timediff(sevt);

		Tsim = (Tsim + haus) / 2;
		*///=================
		return Tsim;
	}
	//the smallest of all the time similarity from a point in one set to the closest point in the other set.
	float get_Hausdorff_Timediff(SubEvent* sevt) {
		float HausDist = 1.0;

		float ThisPoint2SevtSet = 1.0;
		vector<TimeRange>::iterator innSit;
		vector<TimeRange>::iterator thisMSit = msgTRset.begin();
		while (thisMSit != msgTRset.end())
		{
			float nearDist = 0;
			innSit = sevt->msgTRset.begin();

			while (innSit != sevt->msgTRset.end()) {
				float tmpDist = getTimeDiff(&(*thisMSit),&(*innSit));
				if (tmpDist > nearDist)
					nearDist = tmpDist;

				innSit++;
			}
			if (nearDist < ThisPoint2SevtSet)
				ThisPoint2SevtSet = nearDist;
			thisMSit++;
		}

		float SevtSet2ThisPoint = 1.0;

		thisMSit = sevt->msgTRset.begin();
		while (thisMSit != sevt->msgTRset.end())
		{
			float nearDist = 0;  //maximal similarity
			innSit = msgTRset.begin();

			while (innSit != msgTRset.end()) {
				float tmpDist = getTimeDiff(&(*thisMSit), &(*innSit));
				if (tmpDist > nearDist)
					nearDist = tmpDist;

				innSit++;
			}
			if (nearDist < SevtSet2ThisPoint)
				SevtSet2ThisPoint = nearDist;
			thisMSit++;
		}

		HausDist = (ThisPoint2SevtSet + SevtSet2ThisPoint) / 2;
		return HausDist;
	}

	float getTimeDiff(TimeRange *thisTR, TimeRange* sevtR) {
		float Tsim=0;
		//for tau=0
		if (TIMERADIUST == 0)
		{
			if (thisTR->TimeStampCentre == sevtR->TimeStampCentre)
				Tsim = 1;

			return Tsim;
		}
		//============
		TimeRange* maxPtr, * minPtr;
		if (thisTR->TimeStampCentre >= sevtR->TimeStampCentre) {
			maxPtr = thisTR;
			minPtr = sevtR;
		}
		else {
			maxPtr = sevtR;
			minPtr = thisTR;
		}

		if (maxPtr->TimeStampCentre - minPtr->TimeStampCentre >= 2 * maxPtr->range)
			Tsim = 0;
		else {
			float intersectT = (minPtr->TimeStampCentre + minPtr->range) - (maxPtr->TimeStampCentre - maxPtr->range);
			float unionT = (maxPtr->TimeStampCentre + maxPtr->range) - (minPtr->TimeStampCentre - minPtr->range);
			Tsim = intersectT / unionT;
		}				
		return Tsim;
	}

	float GetSpaceSimilarity(SubEvent* sevt) {
		float Ssim;
		double GreatCircleDist = get_distance(this->Cluster_SR.lat, this->Cluster_SR.longi, sevt->Cluster_SR.lat, sevt->Cluster_SR.longi);
		//get the Hausdorff distance
		double haus = get_Hausdorff_distance(sevt);

		//Ssim = 1 - GreatCircleDist / 500;  //put 500 first, default, it can be the maximal Great Circle distance between two locations in dataset
		Ssim = 1 - (haus+GreatCircleDist)/ 1000;

		if (Ssim < 0)
			Ssim = 0;
		
		return Ssim;
	}
	//=================
	TimeRange GetTimeRange() {
		return Cluster_TR;
	}

	void SetTimeRange() {
		vector<SocialMSG>::iterator emit = EventMSG.begin();
		//find the minimal time point, and maximal time point
		float minT = MAXFLOAT;
		float maxT = 0;
		while (emit != EventMSG.end()) {
			float tmin = (*emit).getTimeRange().TimeStampCentre - (*emit).getTimeRange().range;
			float tmax = (*emit).getTimeRange().TimeStampCentre + (*emit).getTimeRange().range;
			if (tmin < minT)
				minT = tmin;
			if (tmax > maxT)
				maxT = tmax;

			emit++;
		}
		Cluster_TR.TimeStampCentre = (minT + maxT) / 2;
		//Cluster_TR.range = (maxT - minT) / 2;		
		Cluster_TR.range = TIMERADIUST; //fix the time range
	}

	SpaceRange GetSpaceRange() {
		return Cluster_SR;
	}

	void SetSpaceRange() {
		vector<SocialMSG>::iterator emit = EventMSG.begin();
		//find the minimal time point, and maximal time point
		
		float meanLat = 0;
		float meanLon = 0;
		while (emit != EventMSG.end()) {
			SpaceRange sr = (*emit).getSpaceRange();
			meanLat += sr.lat;
			meanLon += sr.longi;

			emit++;
		}
		int emsgSize = EventMSG.size();
		if (emsgSize > 0) {
			Cluster_SR.lat = meanLat / emsgSize;
			Cluster_SR.longi = meanLon / emsgSize;
		}

		emit = EventMSG.begin();
		Cluster_SR.radius = 0;
		while (emit != EventMSG.end()) {
			SpaceRange sr = (*emit).getSpaceRange();
			float dis = (float)get_distance(Cluster_SR.lat, Cluster_SR.longi, sr.lat, sr.longi);
			if (dis > Cluster_SR.radius)
				Cluster_SR.radius = dis;
			emit++;
		}
	}


	void SetCluster_ConceptTFIDFVec() 
	{ 				
		std::vector<SocialMSG>::iterator emit = EventMSG.begin();
		for (int i = 0; i < TFIDF_DIM; i++) {
			Cluster_ConceptTFIDFVec[i] = 0;
		}
		while (emit != EventMSG.end()) {
			for (int i = 0; i < TFIDF_DIM; i++) {
				Cluster_ConceptTFIDFVec[i] += (*emit).getConceptTFIDFVec()[i];
			}
			emit++;
		}
		for (int i = 0; i < TFIDF_DIM; i++) {
			Cluster_ConceptTFIDFVec[i] /= EventMSG.size();
		}
	}

	float* GetCluster_ConceptTFIDFVec() {
		return Cluster_ConceptTFIDFVec;
	}

	float* GetTFIDFVecAngleSphericalCorSys() {
		return TFIDFVecAngleSphericalCorSys;
	}
	float* GetCluster_UserInfluVec() {
		return UserInfluVec;
	}
	void ProduceEventPresentation()
	{
		SetCluster_ConceptTFIDFVec();		
		SetEventUserIDs();		
		SetEventTimeRanges();
		SetTimeRange();
		SetEventSpaceRanges();
		SetSpaceRange();
		
	}

	void ProduceEventPresentationForRecEvaluation()
	{
		SetCluster_ConceptTFIDFVec();
		SetEventCommentUserIDs();
		SetEventTimeRanges();
		SetTimeRange();
		SetEventSpaceRanges();
		SetSpaceRange();
	}

	double rad(double d) {
		return d * PI / 180.0;
	}


	double round(double d) {
		return floor(d + 0.5);
	}

	//the greatest of all the distances from a point in one set to the closest point in the other set.
	double get_Hausdorff_distance(SubEvent* sevt) {
		double HausDist = 0;
		
		double ThisPoint2SevtSet=0;
		vector<SpaceRange>::iterator innSit;
		vector<SpaceRange>::iterator thisMSit = msgSRset.begin();
		while (thisMSit != msgSRset.end())
		{
			double nearDist = EARTH_RADIUS;
			innSit = sevt->msgSRset.begin();
			
			while (innSit != sevt->msgSRset.end()) {
				double tmpDist = get_distance((*thisMSit).lat, (*thisMSit).longi, (*innSit).lat, (*innSit).longi);
				if (tmpDist < nearDist)
					nearDist = tmpDist;

				innSit++;
			}
			if (nearDist > ThisPoint2SevtSet)
				ThisPoint2SevtSet = nearDist;
			thisMSit++;
		}

		double SevtSet2ThisPoint = 0;
		
		thisMSit = sevt->msgSRset.begin();
		while (thisMSit != sevt->msgSRset.end())
		{
			double nearDist = EARTH_RADIUS;
			innSit = msgSRset.begin();

			while (innSit != msgSRset.end()) {
				double tmpDist = get_distance((*thisMSit).lat, (*thisMSit).longi, (*innSit).lat, (*innSit).longi);
				if (tmpDist < nearDist)
					nearDist = tmpDist;

				innSit++;
			}
			if (nearDist > SevtSet2ThisPoint)
				SevtSet2ThisPoint = nearDist;
			thisMSit++;
		}

		//HausDist = (ThisPoint2SevtSet + SevtSet2ThisPoint) / 2;
		HausDist = max(ThisPoint2SevtSet, SevtSet2ThisPoint);

		return HausDist;
	}

	double get_distance(double lat1, double lng1, double lat2, double lng2)
	{
		double radLat1 = rad(lat1);
		double radLat2 = rad(lat2);
		double a = radLat1 - radLat2;
		double b = rad(lng1) - rad(lng2);
		double s = 2 * asin(sqrt(pow(sin(a / 2), 2) + cos(radLat1)*cos(radLat2)*pow(sin(b / 2), 2)));
		s = s * EARTH_RADIUS;
		s = round(s * 10000) / 10000;
		return s;
	}

	void setTimeRange(TimeRange tr) {
		Cluster_TR.TimeStampCentre = tr.TimeStampCentre;
		Cluster_TR.range = tr.range;
	}

	void setSpaceRange(SpaceRange sr) {
		Cluster_SR.lat = sr.lat;
		Cluster_SR.longi = sr.longi;
		Cluster_SR.radius = sr.radius;
	}

	void uploadEventMsg(SocialMSG & smg) {
		EventMSG.push_back(smg);
	}
	void cleansubEvent() {
		for (int i = 0; i < EventMSG.size(); i++)
			EventMSG[i].cleanMSG();
		EventMSG.clear();
		HashtagList.clear();
		eventUserIdsFre.clear();	
		msgSRset.clear();
		msgTRset.clear();
		RecUserSimi.clear();
	}
	~SubEvent()
	{
		cleansubEvent();
	}
};

class SocialEventOperation {
private:
public:
	SocialEventOperation() {  }

	void FindSubEvents(vector<SocialMSG> &HashTagedMSGlist, vector<SocialMSG> &NonHashTagedMSGlist, vector<SubEvent>& Eventclusters, vector<SubEvent>& Eventcandidates);
	//return a set of subEvent candidates
	void FindRetweetClusters(vector<SocialMSG>& MSGset, vector<SubEvent>& subEvents);
	void SetEventUserIdsFre(vector<SubEvent>& Eventclusters);
	int ShareHashTags(vector<string>& Phashtaglist, vector<string>& Shashtaglist);

	float l2_dist_int(int *_p1, int *_p2, int _dim);

	

	//produce hash vectors for event representative concept vector
	void HashMappingEvent(SubEvent& se, LSB& lsb);

	~SocialEventOperation() {}
};