package org.turningme.theoretics.api;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.io.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.turningme.theoretics.common.RecContext;
import org.turningme.theoretics.common.beans.UPEventBucket;
import org.turningme.theoretics.common.beans.UPEventPartition;
import org.turningme.theoretics.common.event.EventMigration;
import org.turningme.theoretics.common.event.EventRecomOpti;
import org.turningme.theoretics.common.event.EventRecommendation;
import org.turningme.theoretics.common.event.SocialEvent;
import org.turningme.theoretics.common.event.SocialEventOperation;

import org.turningme.theoretics.common.event.loadMigrationEventDetectResultSummary;

/**
 * Created by E20477: XZhou on 2022/1/25.
 */
public class PreprocessingHelperContinuous implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static final Logger LOG = LoggerFactory.getLogger(PreprocessingHelperContinuous.class);
    RecContext recContext;
   /* String userProfilePath = "/Users/jpliu/CLionProjects/EventRecoHelper/UserInfluDictfile.txt";
    String userProfileInfoPath = "/Users/jpliu/CLionProjects/EventRecoHelper/userprofile217.txt";
    String userNameList = "/Users/jpliu/CLionProjects/EventRecoHelper/UserNamelist.txt";
    String lsbFilepath = "/Users/jpliu/CLionProjects/EventRecoHelper/para.txt";*/
    
  /*  String userProfilePath = "/Users/e20477/CLionProjects/EventRecoHelper/UserInfluDictfile_Nepal010(Training15April-24April).txt";
    String userProfileInfoPath = "/Users/e20477/CLionProjects/EventRecoHelper/NepalUserProfile(Training15April-24April).txt";
    String userNameList = "/Users/e20477/CLionProjects/EventRecoHelper/UserNamelist.txt";
    String lsbFilepath = "/Users/e20477/CLionProjects/EventRecoHelper/para.txt";*/
    
//    String userProfilePath = "/Users/e20477/CLionProjects/EventRecoHelper/UserInfluDictfile_Nepal010(Training15April-24April).txt";    
//    String userProfileInfoPath = "/Users/e20477/CLionProjects/EventRecoHelper/NepalUserProfile(Training15April-24April).txt";
    
    //String SlotPartitionFileName = "/Users/e20477/CLionProjects/EventRecoHelper/napelDataTestFlist(April25-May1).txt.UPP";
//     String SlotPartitionFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_Partition_ContentAngleMixedHashKMeans/napelDataTestFlist(April25-May1).txt.UPPWhole";    
    //String SlotPartitionFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_8Partition_ContentAngleMixedHashKMeans/napelDataTestFlist(April25-May1).txt.UPPWhole";
   //String SlotPartitionFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_8Partition_ContentHP/napelDataTestFlist(April25-May1).txt.UPPWhole";
    //String SlotPartitionFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUPPartion(HashMixed)/napelDataTestFlist(April25-May1).UPP";
   // String lsbFilepath = "/Users/e20477/CLionProjects/EventRecoHelper/PVLDB21para.txt";
 
    String userProfilePath = "/Users/e20477/CLionProjects/EventRecoHelper/UserInfluDictfile_TexasFlood010(Training12-21May).txt";   
    String userProfileInfoPath="/Users/e20477/CLionProjects/EventRecoHelper/TexasFlood_UserProfileResult(Training12May-21May).txt";
    String SlotPartitionFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Texas_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_Partition_ContentAngleMixedHashKMeans/TexasFloodDataFlist(22-28May).txt.UPPWhole";  
    //String SlotPartitionFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Texas_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_Partition_ContentHP/TexasFloodDataFlist(22-28May).txt.UPPWhole"; 
     
    int numofGroups = 10;
    //int numofGroups = 4;
    //int numofGroups = 6;
   // int numofGroups = 8;

    public PreprocessingHelperContinuous() {
    }


    EventMigration eventMigration;
    EventRecomOpti eropti;
    SocialEventOperation SEO;
    EventRecommendation eventRecommendation;

    public PreprocessingHelperContinuous setup() {
        RecContext recCxt = new RecContext();

        eventMigration = new EventMigration(recCxt);
        eropti = new EventRecomOpti(recCxt);
        SEO = new SocialEventOperation(recCxt);
        eventRecommendation = new EventRecommendation(recCxt);
        recContext = recCxt;
        return this;
    }


    /**
     * with  user profile
     * and  straming messages mini batch which were reduced into  subset
     */
    public void similarityJoinManually() {

/*        List<SocialEvent> IncomingEventSubset = new ArrayList<>();
//        float SimiThreshold = 0.7f;
          float alpha = 0.5f;
        float SimiThreshold = 0.f;
        for (int i = 0; i < numofGroups; i++) {
            /// too much code not used in the whole code stack
            eropti.IncomingEventSubsetIdentification(Eventclusters, IncomingEventSubset, uprofileEventGroupSet.get(i),
                                                     SimiThreshold, alpha);
            ///

            eropti.EventSimilarityJoin(uprofileEventGroupSet.get(i), IncomingEventSubset, SimiThreshold);
            IncomingEventSubset.clear();
            System.out.printf("join %d\n", i);

        }*/
    }

    public PreprocessingHelperContinuous preLoadMessageData(int index) {
    	List<String> results = new ArrayList<String>();
    	//File[] files = new File("/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP(June2021)/").listFiles();
    	String featurefilePath="/Users/e20477/CLionProjects/EventRecoHelper/Texas_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize/";
    	File[] files = new File(featurefilePath).listFiles();
    	//File[] files = new File("/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize/").listFiles();
    	//If this pathname does not denote a directory, then listFiles() returns null. 
    	
    	for (File file : files) {
    	    if (file.isFile()) {
    	        results.add(file.getName());    	       
    	    }
    	}
    	    	
        //String FullSlotFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP(June2021)/"+results.get(index);
    	//String FullSlotFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize/"+results.get(index);
    	String FullSlotFileName =featurefilePath+results.get(index);
    	//added by Emily==============
        //String FullSlotFileName = "/Users/e20477/CLionProjects/EventRecoHelper/statuses.log.2015-04-26-01.UPdata";
    	//String FullSlotFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP/statuses.log.2015-04-26-01.UPdata";
        List<SocialEvent> Eventclusters = new ArrayList<>();

        try {
			loadMigrationEventDetectResultSummary.loadMigrationEventDetectResultSummary(FullSlotFileName, Eventclusters);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      
        recContext.setEventclusters(Eventclusters);
        return this;
    }
    
    public PreprocessingHelperContinuous preLoadUpdateStatisticsData(int index ) {
    	//added by Emily==============
    	
    	List<String> results = new ArrayList<String>();
    	//File[] files = new File("/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUPPartion(June2021)/").listFiles();
    	String partitionfilePathContinuous= "/Users/e20477/CLionProjects/EventRecoHelper/Texas_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_Partition_ContentAngleMixedHashKMeans/Incoming/";
    	//String partitionfilePathContinuous= "/Users/e20477/CLionProjects/EventRecoHelper/Texas_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_Partition_ContentHP/Incoming/";
    	
    	File[] files =new File(partitionfilePathContinuous).listFiles();
    	//File[] files =new File("/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_Partition_ContentAngleMixedHashKMeans/Incoming/").listFiles();
    	//File[] files =new File("/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_8Partition_ContentAngleMixedHashKMeans/Incoming/").listFiles();
    	//File[] files =new File("/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_8Partition_ContentHP/Incoming/").listFiles();
    	//If this pathname does not denote a directory, then listFiles() returns null. 

    	for (File file : files) {
    	    if (file.isFile()) {
    	        results.add(file.getName());
    	    }
    	}
    	    	
    	String FullSlotPartitionFileName =partitionfilePathContinuous+results.get(index);
       // String FullSlotPartitionFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUPPartion(June2021)/"+results.get(index);
    //	String FullSlotPartitionFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_Partition_ContentAngleMixedHashKMeans/Incoming/"+results.get(index);
        //	String FullSlotPartitionFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_8Partition_ContentAngleMixedHashKMeans/Incoming/"+results.get(index);
    //	String FullSlotPartitionFileName = "/Users/e20477/CLionProjects/EventRecoHelper/Nepal_UserHistUP_ConceptTimeLocationMigNoHashTagMerge_TFIDFNormalize_8Partition_ContentHP/Incoming/"+results.get(index);
        List<UPEventPartition> uprofileEventGroupSet = new ArrayList<>(10);
       /* for (int i = 0; i < 10; i++) {
            uprofileEventGroupSet.add(new UPEventPartition());
          //  uprofileEventGroupSet[i].
        }*/
    //    LOG.info("start loading LoadHistPartitionsUpdates ... ");  //for uploading user profile event partitions for spark.
       
        try {
        	//SlotPartitionFileName should be the one which consider all the dataset clusters as history. 
        	//when make recommendation, just consider the events appearing before the current time slots.
        	//map the partitions to the ones containing the events before the current slot.
        	eventMigration.LoadHistPartitionsUpdates(FullSlotPartitionFileName, uprofileEventGroupSet);  
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        recContext.setCurUpStaticsEventPartitionList(uprofileEventGroupSet);
        return this;
    }
    
    public PreprocessingHelperContinuous updateUsrProfileUpdates(int index) {
    	//LOG.info("start UpdateUserProfileHashMap ... ");
    	
    	List<String> results = new ArrayList<String>();
    	
    	String UserinfluencePath="/Users/e20477/CLionProjects/EventRecoHelper/TexasUserInfluences010/Incoming/";
    	File[] files =new File(UserinfluencePath).listFiles();
    	//File[] files =new File("/Users/e20477/CLionProjects/EventRecoHelper/NepalUserInfluences010/Incoming/").listFiles();
    	
    	for (File file : files) {
    	    if (file.isFile()) {
    	        results.add(file.getName());
    	    }
    	}
    	    	
       //String FullSlotPartitionFileName = "/Users/e20477/CLionProjects/EventRecoHelper/NepalUserInfluences010/Incoming/"+results.get(index);
    	String FullSlotPartitionFileName = UserinfluencePath+results.get(index); 
       
       recContext.eventMigration.UpdateUserProfileHashMap(FullSlotPartitionFileName);         
        
	   return this;    	
    }
    
    public PreprocessingHelperContinuous preLoadUsrProfileUpdates() {
        LOG.info("start preProcessing on local machine");


        LOG.info("start loading loadUserProfileHashMap ... ");
        eventMigration.loadUserProfileHashMap(userProfilePath);

        LOG.info("start loading uploadUserProfilesIntoHashMap ... ");
        eventMigration.uploadUserProfilesIntoHashMap(userProfileInfoPath);


        //====added by emily--start        
        LOG.info("start constructing  uprofileEventGroupSet container ... ");
        //List<UPEventPartition> uprofileEventGroupSet = new ArrayList<>(10);
        List<UPEventPartition> uprofileEventGroupSet = new ArrayList<>(4);
        /*for (int i = 0; i < 10; i++) {
            uprofileEventGroupSet.add(new UPEventPartition());          
        }*/
       // LOG.info("start loading LoadHistPartitions statisticsupdates ... ");  //for uploading user profile event partitions for spark.
       
        try {
        	//SlotPartitionFileName should be the one which consider all the dataset clusters as history. 
        	//when make recommendation, just consider the events appearing before the current time slots.
        	//map the partitions to the ones containing the events before the current slot.
        	EventMigration.LoadHistPartitions(SlotPartitionFileName, uprofileEventGroupSet);  
        	preLoadUpdateStatisticsData(0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        recContext.setUpEventPartitionList(uprofileEventGroupSet);
        
      //====added by emily--end
        
      return this;
    }

    public int getMinEventNo(){
    	return recContext.Eventclusters.get(0).getEventno();
    }
    
    public void getUserprofileMap() {
        recContext.eventMigration.getUserProfileHashMap();
    }


    public List<UPEventPartition> getUserProfilePartition() {
        return recContext.getUpEventPartitionList();
    }

    public List<UPEventPartition> getCurUpStaticsEventPartition() {
        return recContext.getCurUpStaticsEventPartitionList();
    }
    
    public List<SocialEvent> getStaticClusterEvent() {
        return recContext.getEventclusters();
    }

    public static PreprocessingHelperContinuous build() {
    	PreprocessingHelperContinuous instance = new PreprocessingHelperContinuous();
        instance.recContext = new RecContext();

        return instance;
    }


    public List<SocialEvent> IncomingEventSubsetIdentification(SocialEvent IESit, UPEventPartition UPEPar, float SimiThreshold, float alpha) {
        List<SocialEvent> ncomingEventSubset = new ArrayList<>();
        float upmax = eropti.ComputeUPmax(UPEPar, IESit, alpha);
        if (upmax >= SimiThreshold) {
            ncomingEventSubset.add(IESit);
        }
       // System.out.printf("upmax=%f\t EventID=%d\t UserEventID=%d\n", upmax, IESit.getEventno(), UPEPar.getgroupid());
        
        return ncomingEventSubset;
    }


    public SocialEvent EventSimilarityJoin(UPEventPartition UserProfileEventPartion, SocialEvent IncomingEventSubsetEle, float SimiThreshold) {
        int bucketNum = UserProfileEventPartion.getUProfileEventGroup().size();
        EventRecommendation eventRec = recContext.getRecommendation();
        for (int i = 0; i < bucketNum; i++) {
            UPEventBucket upBucket = UserProfileEventPartion.getUProfileEventGroup().get(i);
            int seit = 0;
            while (seit < upBucket.getUProfileEventGroup().size()) {
                float simiV = eventRec.GetESim(IncomingEventSubsetEle, upBucket.getUProfileEventGroup().get(seit));

                if (simiV >= SimiThreshold) //recommend (*IESit) to the users whose profiles contain (*seit), update the RecUserSimi in (*IESit)
                {
                    eropti.UpdateRecUserSimi(IncomingEventSubsetEle, (upBucket.getUProfileEventGroup().get(seit)), simiV);
                }
                seit++;
            }

        }

        return IncomingEventSubsetEle;
    }
    
    public UPEventPartition UpdateUserProfilePartitions(UPEventPartition UserProfileEventPartion, UPEventPartition IncomingEventPartition, float maxTime) {
        

        return IncomingEventPartition;
    }
    
    public UPEventPartition CurrEventPartitionFilter(int index, int maxHistENo, UPEventPartition UPEPar) {
    	List<UPEventBucket> UPEBuckets = new ArrayList<>();
    	UPEventPartition UPEParMap=new UPEventPartition();
    	UPEventBucket UPbucket=new UPEventBucket();
    	
        //remove the events with eventNo>maxHistENo
    	int eventlistSize=UPEPar.getUProfileEventGroup().get(0).getUProfileEventGroup().size();
    	
    	// System.out.printf("eventlistSize=%d\n", eventlistSize);
    	int i;
    	for(i=0;i<eventlistSize;i++) {
    		if(UPEPar.getUProfileEventGroup().get(0).UProfileEventGroup.get(i).getEventno()<maxHistENo) {
    			UPbucket.getUProfileEventGroup().add(UPEPar.getUProfileEventGroup().get(0).getUProfileEventGroup().get(i));
    		}
    		//else
    		//	break;
    	}
    	
    	UPEBuckets.add(UPbucket);
        //update the partition and bucket statistics information with the updated CurUpStaticsEventPartitionList
    	preLoadUpdateStatisticsData(index);
    	UPEParMap= recContext.CurUpStaticsEventPartitionList.get(UPEPar.groupid);
    	UPEParMap.UProfileEventGroup=UPEBuckets;
        return UPEParMap;
    }

    
}
