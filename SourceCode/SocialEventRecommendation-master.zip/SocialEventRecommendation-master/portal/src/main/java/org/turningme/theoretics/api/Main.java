package org.turningme.theoretics.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by jpliu on 2020/2/25.
 */
public class Main {
    static final Logger LOG = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args){
        System.out.println("new world");
    }
}
