package org.turningme.theoretics



import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.slf4j.{Logger, LoggerFactory}
//import org.turningme.theoretics.api.PreprocessingHelper
import org.turningme.theoretics.common.beans.UPEventPartition
import org.turningme.theoretics.common.event.SocialEvent

import org.turningme.theoretics.api.PreprocessingHelperContinuous

/**
  * Created by jpliu on 2020/2/25.
  * This is for experiment testing , incoming messages is mocked by static files
  * In fact . read file streaming is easy , but hard to test for running time and some overhead during spark streaming mechanism operating
  */

object StaticSimilarityJoin {  
  val LOG: Logger = LoggerFactory.getLogger(StaticSimilarityJoin.getClass);
 
  //for nepal dataset alpha = 0.7f, for texas flood dataset, alpha = 0.6f
  val alpha = 0.6f;//0.7f;
  val SimiThreshold = 0.3f;
  val parnum=10;

  def main(args: Array[String]): Unit = {
    //added by emily     
  /*  println("start StaticSimilarityJoin ");
  //=========================
    //in local mode , the thread num is set to 5 , which is depend on your pc configuration . on cluser please refer official website or google
    val spark = SparkSession.builder().appName("demo_spark").master("local[5]").config("SPARK_LOCAL_IP", "127.0.0.1").getOrCreate()
    val preHelper: PreprocessingHelper = PreprocessingHelper.build().setup().preLoadUsrProfile()

    val rdd: RDD[UPEventPartition] = spark.sparkContext.parallelize(preHelper.getUserProfilePartition().toArray(new Array[UPEventPartition](0)), 10)
    
    //    //load local static messages by now
    preHelper.preLoadMessageData()

    val rddClusterEvent: RDD[SocialEvent] = spark.sparkContext.parallelize(preHelper.getStaticClusterEvent.toArray(new Array[SocialEvent](0)), 1)

    

    val simRank = rdd.cartesian(rddClusterEvent).filter((e) => {
      preHelper.IncomingEventSubsetIdentification(e._2, e._1, SimiThreshold, alpha).size() > 0
    })
      .map(ff=>{
        preHelper.EventSimilarityJoin(ff._1,ff._2,SimiThreshold)
      })

      //added by emily     
    println("start simRank");
    
    simRank.count()*/

    println("start ContinuousSimilarityJoin ");
  //=========================
    //in local mode , the thread num is set to 5 , which is depend on your pc configuration . on cluser please refer official website or google
    val spark = SparkSession.builder().appName("demo_spark").master("local[5]").config("SPARK_LOCAL_IP", "127.0.0.1").getOrCreate()
    val preHelper: PreprocessingHelperContinuous = PreprocessingHelperContinuous.build().setup().preLoadUsrProfileUpdates();

    //val rdd: RDD[UPEventPartition] = spark.sparkContext.parallelize(preHelper.getUserProfilePartition().toArray(new Array[UPEventPartition](0)), 10)
    val rdd: RDD[UPEventPartition] = spark.sparkContext.parallelize(preHelper.getUserProfilePartition().toArray(new Array[UPEventPartition](0)), parnum)
    println("dd " + rdd.getNumPartitions)
    LOG.info("ss " + rdd.getNumPartitions)
   // rdd.collect().foreach(println);
        
    /*val rddRef: RDD[UPEventPartition] = spark.sparkContext.parallelize(preHelper.getCurUpStaticsEventPartition().toArray(new Array[UPEventPartition](0)), 1)
    println("rddRef " + rddRef.getNumPartitions)
    LOG.info("ss rddRef " + rddRef.getNumPartitions)*/
    
    val rddRef: RDD[Int] = spark.sparkContext.parallelize(List(1),1)
    println("rddRef " + rddRef.getNumPartitions)
    LOG.info("ss rddRef " + rddRef.getNumPartitions)
    
    val cartesianRdd = rdd.cartesian(rddRef)
    //cartesianRdd.collect().foreach(println);
    println("cartesianRdd " + cartesianRdd.getNumPartitions)
    
    var now = System.nanoTime



    val i=0    
    for(i <- 0 to 71){
   //   for(i <- 0 to 11){
     // for(i <- 12 to 23){  
     // for(i <- 24 to 35){
    //for(i <- 36 to 47){   
    //  for(i <- 48 to 59){ 
   //  for(i <- 60 to 71){
         ////load local static messages by now
      preHelper.preLoadMessageData(i)  
      val rddClusterEvent: RDD[SocialEvent] = spark.sparkContext.parallelize(preHelper.getStaticClusterEvent.toArray(new Array[SocialEvent](0)), 1)
  
      //rddClusterEvent.collect().foreach(println);
    
      val maxEventNo_rdd=preHelper.getMinEventNo()        
      val curHistrdd=cartesianRdd.map(f=>{preHelper.CurrEventPartitionFilter(i, maxEventNo_rdd, f._1)})
      
      //curHistrdd.collect().foreach(println);
      
     /* preHelper.updateUsrProfileUpdates(2*i)
      preHelper.updateUsrProfileUpdates(2*i+1)
      */
      
      val simRank = curHistrdd.cartesian(rddClusterEvent).filter((e) => {
        preHelper.IncomingEventSubsetIdentification(e._2, e._1, SimiThreshold, alpha).size() > 0
      })
        .map(ff=>{
          preHelper.EventSimilarityJoin(ff._1,ff._2,SimiThreshold)
        })
        
          //added by emily     
        println("start simRank, i="+i);
        
        simRank.count()
        println("dd curHistrdd" + curHistrdd.getNumPartitions)
        LOG.info("ss curHistrdd" + curHistrdd.getNumPartitions)
        println("ll " + simRank.count())
    }
    var timeElapsed = System.nanoTime - now
    println("timeElapsed=" + timeElapsed)
    println("Elapsed time: " + timeElapsed + "ns")
    println("Elapsed time: " + timeElapsed/1000000000 + "s")
       
   // val rdd1=rdd.cartesian(rdd).map(f=>{preHelper.UpdateUserProfilePartitions(f._1, f._2,10000)})
    
    /*val dataColl=simRank.collect()
    dataColl.foreach(println)*/
   
    println("ll ") 
    
  }
}
