package Xi_recommendation;

public class RecItem {
    public int UserID;
    public float simi;
}
