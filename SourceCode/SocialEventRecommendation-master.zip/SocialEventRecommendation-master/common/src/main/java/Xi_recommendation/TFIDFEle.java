package Xi_recommendation;

public class TFIDFEle {


    /**
     * @author Xi chen on 27/09/2020
     */
    static void GetEventMSGs(){};
    void SetEventUserIDs(){};
    void SetCluster_ConceptTFIDFVec(){};
    void SetTimeRange(){};
    void EventReset(){};
    void SetEventNo(){};


}
