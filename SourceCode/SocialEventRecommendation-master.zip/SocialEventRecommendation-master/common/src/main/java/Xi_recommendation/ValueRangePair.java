package Xi_recommendation;

public class ValueRangePair {
    public  float minV;
    public  float maxV;
}
