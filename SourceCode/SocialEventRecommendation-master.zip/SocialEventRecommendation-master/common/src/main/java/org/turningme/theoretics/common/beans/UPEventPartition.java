package org.turningme.theoretics.common.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.turningme.theoretics.common.event.SocialEvent;

/**
 * Created by jpliu on 2020/2/24.
 */
public class UPEventPartition implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int userNum; //the number of users in this partition
    public List<UPEventBucket> UProfileEventGroup = new ArrayList<>();
   // public ValueRangePair[] TopicRangeVector = new ValueRangePair[TFIDF_DIM];
    //public ValueRangePair[] InfluenceRangeVector = new ValueRangePair[TUNUM];  //include TUNUM ValueRangePairs
    public int minNumOfInfluencedUsers;
    public int maxNumOfInfluencedUsers;

    public SocialEvent TFIDFCenter=new SocialEvent();
    public float minAngleCos;    
    public SpaceRange centreP=new SpaceRange(); //the centre location point of all the subevents 
    public float minimalRadius; //the minimal radius of subevents in this partion
    
    public  ValueRangePair TimeRangePair=new ValueRangePair();
    //public  ValueRangePair[] SpaceRangePair = new ValueRangePair[2]; //SpaceRangePair [0] stores max and min Lat, SpaceRangePair[1] stores max and min longi
    public List<UserValueRangePair> InfluenceRangeVector= new ArrayList<>();
    
    //public List<SocialEvent> UProfileEvents = new ArrayList<>();

    public UPEventPartition() {
        userNum = 1;
    }

    public UPEventPartition(int uNum) {
        userNum = uNum;
    }

   /* public void setUProfileEvents(SocialEvent e) {
        UProfileEvents.add(e);
    }

    public List<SocialEvent> getUProfileEvents() {
        return UProfileEvents;
    }*/
    
    public void setUProfileEventGroup(UPEventBucket e) {
        UProfileEventGroup.add(e);
    }

    public List<UPEventBucket> getUProfileEventGroup() {
        return UProfileEventGroup;
    }

  /*  public void setTopicRangeVector(ValueRangePair[] TRV) {
        for (int i = 0; i < TFIDF_DIM; i++) {
            if ( TopicRangeVector[i]== null){
                TopicRangeVector[i] = new ValueRangePair();
            }
            TopicRangeVector[i].minV = TRV[i].minV;
            TopicRangeVector[i].maxV = TRV[i].maxV;
        }

    }

    public ValueRangePair [] getTopicRangeVector() {
        return TopicRangeVector;
    }

    public  void setSpaceRangePair(ValueRangePair[] TRV) {
        for (int i = 0; i < 2; i++) {
            if (SpaceRangePair[i] == null){
                SpaceRangePair[i] = new ValueRangePair();
            }
            SpaceRangePair[i].minV = TRV[i].minV;
            SpaceRangePair[i].maxV = TRV[i].maxV;
        }
    }

    public  ValueRangePair[] getSpaceRangePair() {
        return SpaceRangePair;
    }*/

    public  void setTimeRangePair(ValueRangePair TRV) {
        if (TimeRangePair == null){
            TimeRangePair = new ValueRangePair();
        }
        TimeRangePair.minV = TRV.minV;
        TimeRangePair.maxV = TRV.maxV;
    }

    public  ValueRangePair getTimeRangePair() {
        return TimeRangePair;
    }
    
 /*   public void setInfluenceRangeVector(ValueRangePair[] IRV) {
        for (int i = 0; i < TUNUM; i++) {

            if ( InfluenceRangeVector[i]== null){
                InfluenceRangeVector[i] = new ValueRangePair();
            }
            InfluenceRangeVector[i].minV = IRV[i].minV;
            InfluenceRangeVector[i].maxV = IRV[i].maxV;
        }
    }
    
    public void setInfluenceRangeVectorUser(ArrayList<UserValueRangePair> UIRV) {
    	int size=UIRV.size();
    	
        for (int i = 0; i < size; i++) {

            if ( InfluenceRangeVector[UIRV.get(i).userid]== null){
                InfluenceRangeVector[UIRV.get(i).userid] = new ValueRangePair();
            }
            InfluenceRangeVector[UIRV.get(i).userid].minV = UIRV.get(i).minV;
            InfluenceRangeVector[UIRV.get(i).userid].maxV = UIRV.get(i).maxV;
        }
    }

    public ValueRangePair [] getInfluenceRangeVector() {
        return InfluenceRangeVector;
    }*/

    public void setMinNumInfluencedUsers(int minNum) {
        minNumOfInfluencedUsers = minNum;
    }

    public void setMaxNumInfluencedUsers(int maxNum) {
        maxNumOfInfluencedUsers = maxNum;
    }

    public int getMinNumInfluencedUsers() {
        return minNumOfInfluencedUsers;
    }

    public int getMaxNumInfluencedUsers() {
        return maxNumOfInfluencedUsers;
    }
    
  //added by Emily
    public int groupid;
    public void setgroupid(int gid) {
    	groupid = gid;
    }

    public int getgroupid() {
        return groupid;
    }
      
    public void setTFIDFCenter(float [] vec) {
		TFIDFCenter.setConceptTFIDFVec(vec);;
	}
    
    public SocialEvent getTFIDFCenter() {
		return TFIDFCenter;
	}
    
    public void setminAngleCos(float minCos) {
		minAngleCos = minCos;
	}
    public float getminAngleCos() {
		return minAngleCos;
	}
    
    public float GetminimalRadius() {
		return minimalRadius;
	}
	public void setminimalRadius(float miniR) {
		minimalRadius = miniR;
	}
	public SpaceRange getSpaceRangecentreP()
	{
		return centreP;
	}
	public void setSpaceRangecentreP(SpaceRange cp) {
		centreP.lat = cp.lat;
		centreP.longi = cp.longi;
		centreP.radius = cp.radius;
	}
	public void setSpaceRangecentrePoint(float[] cp) {
		centreP.lat = cp[0];
		centreP.longi = cp[1];
		centreP.radius = cp[2];
	}
	
    public void UPEventPartitionClear() {
        this.UProfileEventGroup.clear();
    }
    public void SetUN(ValueRangePair un) {
        minNumOfInfluencedUsers= (int) un.minV;
        maxNumOfInfluencedUsers= (int) un.maxV;
    }
    
    public void setInfluenceRangeVector(UserValueRangePair IRV) {
      	InfluenceRangeVector.add(IRV);
         /* for (int i = 0; i < userNum; i++) {
              InfluenceRangeVector[i].minV = IRV[i].minV;
              InfluenceRangeVector[i].maxV = IRV[i].maxV;
          }*/
      }

      public  void setInfluenceRangeVectorList(ArrayList<UserValueRangePair> IRV) {
          for (int i = 0; i < IRV.size(); i++) {
              InfluenceRangeVector.add(IRV.get(i));
          }
      }
      //public ValueRangePair[]  getInfluenceRangeVector() {
      public List<UserValueRangePair> getInfluenceRangeVector() {
          return InfluenceRangeVector;
      }
}
