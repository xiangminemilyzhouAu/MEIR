package org.turningme.theoretics.common.event;

//import it.unimi.dsi.fastutil.Hash;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.turningme.theoretics.common.beans.EUserFrePair;
import org.turningme.theoretics.common.beans.SpaceRange;
import org.turningme.theoretics.common.beans.TimeRange;

//import static org.turningme.theoretics.common.Constants.MVALUE;
//import static org.turningme.theoretics.common.Constants.TFIDF_DIM;
//import parameters.TFIDF_DIM;
//added by Emily===================
import static org.turningme.theoretics.common.Constants.TFIDF_DIM;
//==================================
public class loadMigrationEventDetectResultSummary {


    private static BufferedReader f_open;

	public static int loadMigrationEventDetectResultSummary(String filename, List<SocialEvent> eventClusters) throws IOException {
        int ret = 0;

//        ArrayList<EUserFrePair> euit=new ArrayList<>();

        String line;
     //   int eid = 0;

        if (new File(filename).exists()) {
            f_open = new BufferedReader(new FileReader(filename));
            line = f_open.readLine();

            while (line != null) {

                SocialEvent curEvent = new SocialEvent();
                float[] vec = new float[TFIDF_DIM];

                TimeRange newTR = new TimeRange();
                SpaceRange newSR = new SpaceRange();

                if (line.length() <= 0) {
                    System.out.println("Invalid (empty) line!\n");
                    return 1;
                }

                line=f_open.readLine();
                line=f_open.readLine();

                curEvent.SetEventNo(Integer.parseInt(line.substring(line.indexOf("<clusterid>") + 11, line.indexOf("</clusterid>")).trim()));

                line=f_open.readLine();

                String[] tfidfstr = line.substring(line.indexOf("<msgcontfidf>") + 13, line.indexOf("</msgcontfidf>")).trim().split("\t");
                for (int i = 0; i < tfidfstr.length; i++) {
                    vec[i] = Float.parseFloat(tfidfstr[i]);
                }
                curEvent.setConceptTFIDFVec(vec);

                line=f_open.readLine();

                String[] SpaceRange = line.substring(line.indexOf("<SpaceRange>") + 12, line.indexOf("</SpaceRange>")).trim().split("\t");
                newSR.lat = Float.parseFloat(SpaceRange[0]);
                newSR.longi = Float.parseFloat(SpaceRange[1]);
                newSR.radius = Float.parseFloat(SpaceRange[2]);
                curEvent.setSpaceRange(newSR);

                line=f_open.readLine();

                String[] TimeRange = line.substring(line.indexOf("<TimeRange>") + 11, line.indexOf("</TimeRange>")).trim().split("\t");
                newTR.TimeStampCentre = Float.parseFloat(TimeRange[0]);
                newTR.range = Float.parseFloat(TimeRange[1]);
                curEvent.setTimeRange(newTR);

                line=f_open.readLine();

                String[] SpaceRangeSet = line.substring(line.indexOf("<SpaceRangeSet>") + 15, line.indexOf("</SpaceRangeSet>")).trim().split("\t");

                for(int i=0; i<SpaceRangeSet.length;i++){

                    SpaceRange srtmp = new SpaceRange();
                    String[] temp=SpaceRangeSet[i].split(" ");
                    srtmp.lat = Float.parseFloat(temp[0]);
                    srtmp.longi = Float.parseFloat(temp[1]);
                    srtmp.radius = Float.parseFloat(temp[2]);
                    curEvent.uploadmsgSRset(srtmp);
                }
                line=f_open.readLine();

                String[] TimeRangeSet = line.substring(line.indexOf("<TimeRangeSet>") + 14, line.indexOf("</TimeRangeSet>")).trim().split("\t");
                for(int i=0; i<TimeRangeSet.length;i++) {
                    TimeRange trtmp = new TimeRange();
                    String[] temp=TimeRangeSet[i].split(" ");
                    trtmp.TimeStampCentre = Float.parseFloat(temp[0]);
                    trtmp.range = Float.parseFloat(temp[1]);
                    curEvent.uploadmsgTRset(trtmp);
                }

                line=f_open.readLine();

                String[] Hashvalues = line.substring(line.indexOf("<HashkeyValues>") + 15, line.indexOf("</HashkeyValues>")).trim().split("\t");
                for (int i = 0; i < Hashvalues.length; i++) {
                   // curEvent.EHashV.add(Long.parseLong(Hashvalues[i]));                                       
                	curEvent.EHashV[i]=Integer.parseInt(Hashvalues[i]);  //added by Emily
                }

                line=f_open.readLine();
                
                ArrayList<EUserFrePair> euids = new ArrayList<>();
                String[] useridlist = line.substring(line.indexOf("<useridlist>") + 12, line.indexOf("</useridlist>")).trim().split("\t");
                for (int i = 0; i < useridlist.length; i++) {

                    EUserFrePair eufPair = new EUserFrePair();
                    eufPair.userid = Integer.parseInt(useridlist[i].split(" ")[0]);
                    eufPair.frequency = Integer.parseInt(useridlist[i].split(" ")[1]);

                    if(euids.size()==0){
                        euids.add(eufPair);
                    }else if(euids.get(euids.size()-1).userid<eufPair.userid){
                        euids.add(eufPair);
                    }else {
                        for (int j = 0; j < euids.size(); j++) {
                            if (eufPair.userid > euids.get(j).userid) {
                                euids.set(j, eufPair);
                                break;
                            }
                        }
                    }
                }

                curEvent.setEventUserIDs(euids);

                eventClusters.add(curEvent);
                line = f_open.readLine();
            }
            if (f_open != null)   
            	f_open.close();
        }
        
        ret = eventClusters.size();
        return ret;
    }
}
