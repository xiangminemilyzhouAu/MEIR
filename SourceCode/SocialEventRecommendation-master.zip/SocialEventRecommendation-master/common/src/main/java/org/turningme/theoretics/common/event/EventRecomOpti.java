package org.turningme.theoretics.common.event;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.turningme.theoretics.common.RecContext;
import org.turningme.theoretics.common.parameters;
import org.turningme.theoretics.common.beans.EUserFrePair;
import org.turningme.theoretics.common.beans.TimeRange;
import org.turningme.theoretics.common.beans.UPEventBucket;
import org.turningme.theoretics.common.beans.UPEventPartition;
import org.turningme.theoretics.common.beans.UPInfluDistriEle;
import org.turningme.theoretics.common.beans.UserProfile;
import org.turningme.theoretics.common.beans.ValueRangePair;
import static org.turningme.theoretics.common.Constants.TUNUM;

/**
 * Created by jpliu on 2020/2/24.
 */
public class EventRecomOpti implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	RecContext recCxt;


    public EventRecomOpti() {
    }

    public EventRecomOpti(RecContext recCxt) {
        this.recCxt = recCxt;
        recCxt.setEventRecomOpti(this);
    }

    /**
     *
     * @param IncomingEventSet
     * @param IncomingEventSubset
     * @param UPEPar
     * @param SimiThreshold
     * @param alpha
     *
     * return IncomingEventSubset as an middle result
     */
    public void IncomingEventSubsetIdentification(List<SocialEvent> IncomingEventSet, List<SocialEvent> IncomingEventSubset,
            UPEventPartition UPEPar, float SimiThreshold, float alpha)
    {


        for (SocialEvent IESit:IncomingEventSet
             ) {
            float upmax = ComputeUPmax(UPEPar, IESit,alpha);
            
            System.out.printf("upmax=%f\t EventID=%d\t UserEventID=%d\n", upmax, IESit.GetEventNo(), UPEPar.getgroupid());
            if (upmax >= SimiThreshold)
            {
                IncomingEventSubset.add(IESit);
            }
        }

    }

    float ComputeUPmaxTime(ValueRangePair vrp, SocialEvent IncomingEvent) {
    	float UPmaxTime = 0;

    	SocialEvent virtualEvent=new SocialEvent();
    	TimeRange tr=new TimeRange();
    	tr.TimeStampCentre = vrp.maxV;
    	tr.range = parameters.TIMERADIUST;
    	virtualEvent.setTimeRange(tr);

    	UPmaxTime = virtualEvent.GetTimeSimilarity(IncomingEvent);

    	return UPmaxTime;
    }

    public float ComputeUPmax(UPEventPartition UserProfileEventPartition, SocialEvent  IncomingEvent, float alpha)
    {
        float UPmax = 0;

       // float UPmaxT = ComputeUPmaxT(UserProfileEventPartition, IncomingEvent)*alpha;
       // float UPmaxI = ComputeProb_EvEn(UserProfileEventPartition, IncomingEvent) * (1 - alpha);

      //revised by emily 
     /*   float UPmaxT = ComputeUPmaxT(UserProfileEventPartition, IncomingEvent)* parameters.omeg1*(1 - alpha);
        float UPmaxI = ComputeProb_EvEn(UserProfileEventPartition, IncomingEvent) * (1 - alpha);
        
        UPmax = UPmaxT + UPmaxI;*/
        
        int i = 0;
        ValueRangePair vrp = UserProfileEventPartition.getTimeRangePair();
        float UPmaxLocation = (1 - parameters.omeg1 - parameters.omeg2) * (1 - alpha);
    	//float UPmaxTime = parameters.omeg2 * (1 - alpha);
        float UPmaxTime = ComputeUPmaxTime(vrp, IncomingEvent) * parameters.omeg2 * (1 - alpha);

    	float UPmaxT = ComputeUPmaxT(UserProfileEventPartition, IncomingEvent, -1) * parameters.omeg1 * (1 - alpha);  //based on super-cone only
    	float UPmaxI = ComputeProb_EvEn(UserProfileEventPartition, IncomingEvent, -1) * alpha;    	
    	
    	UPmax = UPmaxT + UPmaxI + UPmaxLocation + UPmaxTime;
    	
    	if (UPmax < parameters.SimiThreshold) {
    		//cout << "filtered by partition" << endl;
    		return UPmax;
    	}

    	//============================
    	UPmax = -1;
    	int bucketnum = UserProfileEventPartition.getUProfileEventGroup().size();
    	for (i = 0; i < bucketnum; i++) 
    	{
    		vrp = UserProfileEventPartition.getUProfileEventGroup().get(i).getTimeRangePair();
    		/*vrpSpaceRange = UserProfileEventPartition.getUProfileEventGroup().get(i).getBuckcentreP();
    		miniRadius = UserProfileEventPartition.getUProfileEventGroup()[i].GetminimalRadius();
    		UPmaxLocation = ComputeUPmaxLocationNew(vrpSpaceRange, miniRadius, IncomingEvent) * (1 - omeg1 - omeg2) * (1 - alpha);*/
    		UPmaxTime = ComputeUPmaxTime(vrp, IncomingEvent) * parameters.omeg2 * (1 - alpha);		

    		UPmaxT = ComputeUPmaxT(UserProfileEventPartition, IncomingEvent, i) * parameters.omeg1 * (1 - alpha);

    		UPmaxI = ComputeProb_EvEn(UserProfileEventPartition, IncomingEvent,i) * alpha;

    		float UPmaxTmp = UPmaxT + UPmaxI + UPmaxLocation + UPmaxTime;
    		if (UPmaxTmp > UPmax) 
    			UPmax = UPmaxTmp;
    		if (UPmax >= parameters.SimiThreshold) //cannot be filtered, stop early
    			return UPmax;
    	}

        return UPmax;
    }


    float ComputeUPmaxT(UPEventPartition UserProfileEventPartition, SocialEvent  IncomingEvent, float alpha)
    {
        float UPmaxT = 1.0f;

       /* SocialMSG smg = new SocialMSG();
        float[] virtualConceptVec = new float[TFIDF_DIM]; // default 0 = { 0 };
        ValueRangePair[] upep = UserProfileEventPartition.getTopicRangeVector();
        float[] incomingConceptVec = IncomingEvent.GetCluster_ConceptTFIDFVec();

        for (int i = 0; i < TFIDF_DIM-1; i++)
            GetTBoundValueofDim(upep,i, incomingConceptVec,i, virtualConceptVec,i);

        UPmaxT=smg.GetConceptVectorSimilarity(virtualConceptVec,IncomingEvent.GetCluster_ConceptTFIDFVec());*/

        return UPmaxT;
    }



    float GetTBoundValueofDim(ValueRangePair UserParVPRect[], float EventVRP[], float VirtualEventTopic[])
    {
        float BoundValue = 0;  //0 not to be filtered

        float minRectAngleTan = UserParVPRect[1].minV / UserParVPRect[0].maxV;  //here dim i to 0, dim j to 1
        float maxRectAngleTan = UserParVPRect[1].maxV / UserParVPRect[0].minV;

        float EventVRPAngleTan = EventVRP[1] / EventVRP[0];

        if (EventVRPAngleTan > maxRectAngleTan)  //for the case like T3 in the figure 6 of the paper
        {
            VirtualEventTopic[0] = UserParVPRect[0].minV;
            VirtualEventTopic[1] = UserParVPRect[1].maxV;
            BoundValue = 1;
        }
        else if (EventVRPAngleTan < minRectAngleTan) //for the case like T2 in the figure 6 of the paper
        {
            VirtualEventTopic[0] = UserParVPRect[0].maxV;
            VirtualEventTopic[1] = UserParVPRect[1].minV;
            BoundValue = 1;
        }
        else //for the case like T1 in the figure 6 of the paper
        {
            VirtualEventTopic[0] = EventVRP[0];
            VirtualEventTopic[1] = EventVRP[1];
        }

        return BoundValue;
    }


    float GetTBoundValueofDim(ValueRangePair UserParVPRect[] , int UserParVPRectPos, float EventVRP[] , int EventVRPPos, float VirtualEventTopic[], int VirtualEventTopicPos)
    {
        float BoundValue = 0;  //0 not to be filtered

        float minRectAngleTan = UserParVPRect[1+UserParVPRectPos].minV / UserParVPRect[0+UserParVPRectPos].maxV;  //here dim i to 0, dim j to 1
        float maxRectAngleTan = UserParVPRect[1 + UserParVPRectPos].maxV / UserParVPRect[0 + UserParVPRectPos].minV;

        float EventVRPAngleTan = EventVRP[1 + EventVRPPos] / EventVRP[0 + EventVRPPos];

        if (EventVRPAngleTan > maxRectAngleTan)  //for the case like T3 in the figure 6 of the paper
        {
            VirtualEventTopic[0 + VirtualEventTopicPos] = UserParVPRect[0 + UserParVPRectPos].minV;
            VirtualEventTopic[1 + VirtualEventTopicPos] = UserParVPRect[1 + UserParVPRectPos].maxV;
            BoundValue = 1;
        }
        else if (EventVRPAngleTan < minRectAngleTan) //for the case like T2 in the figure 6 of the paper
        {
            VirtualEventTopic[0 + VirtualEventTopicPos] = UserParVPRect[0 + UserParVPRectPos].maxV;
            VirtualEventTopic[1 + VirtualEventTopicPos] = UserParVPRect[1 + UserParVPRectPos].minV;
            BoundValue = 1;
        }
        else //for the case like T1 in the figure 6 of the paper
        {
            VirtualEventTopic[0 + VirtualEventTopicPos] = EventVRP[0 + EventVRPPos];
            VirtualEventTopic[1 + VirtualEventTopicPos] = EventVRP[1 + EventVRPPos];
        }

        return BoundValue;
    }


   /* float ComputeProb_EvEn(UPEventPartition UserProfileEventPartition, SocialEvent  IncomingEvent)
    {
        float Prob_EvEn = 0;
        SocialEvent VirtualUPPevent = new SocialEvent();
        VirtualUPPevent.EventReset();

        GetDomiUserVirEvent(UserProfileEventPartition, IncomingEvent, VirtualUPPevent);

        EventMigration eventmig = recCxt.getEventMigration();
        Prob_EvEn = eventmig.EventMigrationProb(VirtualUPPevent, IncomingEvent);

        return Prob_EvEn;
    }*/

    float ComputeProb_EvEn(UPEventPartition UserProfileEventPartition, SocialEvent  IncomingEvent, int bucketNo)
    {
        float Prob_EvEn = 0;
        SocialEvent VirtualUPPevent = new SocialEvent();
        VirtualUPPevent.EventReset();

        GetDomiUserVirEvent(UserProfileEventPartition, IncomingEvent, VirtualUPPevent, bucketNo);

        EventMigration eventmig = recCxt.getEventMigration();
        Prob_EvEn = eventmig.EventMigrationProb(VirtualUPPevent, IncomingEvent);

        return Prob_EvEn;
    }

    void GetDomiUserVirEvent(UPEventPartition UserProfileEventPartition, SocialEvent IncomingEvent, SocialEvent  VirtualUPPevent, int bucketNo)
    {
        //estiate user influential between UserProfileEventPartition and IncomingEvent
        //Get all the users in UserProfileEventPartition
        List<Integer> userlist = new ArrayList<>();
        GetUserInEventPartition(UserProfileEventPartition, userlist, bucketNo);

        //Select all the users appearing in UserProfileEventPartition and influencing users in IncomingEvent , and calculate the average influence
        float[] influentials = new float[TUNUM];
        for (int i = 0; i < TUNUM; i++)
            influentials[i] = (0f);
        RemoveNonInfluentialUsers(userlist, IncomingEvent.GetEventUserIDs(),influentials);

        //rank the selected users in UserProfileEventPartition based on the average influentials they can generate to IncomingEvent.
        RankInfluentialUsers(userlist, influentials);

        //select the top un_{min} users from UserProfileEventPartition as the dominant ones
        int ulsize = userlist.size();
        if(ulsize> UserProfileEventPartition.getMinNumInfluencedUsers())

            //remove operation include first one    , not the last one
            for (int i=0 + UserProfileEventPartition.getMinNumInfluencedUsers() ; i < 0 + ulsize-1; i++){
                userlist.remove(i);
            }


        //form VirtualUPPevent
        VirtualUPPevent.SetEventUserIDs_Vec(userlist);
    }

    void GetUserInEventPartition(UPEventPartition UserProfileEventPartition, List<Integer> userlist,int bucketNo)
    {

    	if (bucketNo == -1) { //process the whole partition
	        for (UPEventBucket upebit:UserProfileEventPartition.getUProfileEventGroup() ) {
	            for (SocialEvent seit: (upebit).getUProfileEventGroup()) {
	                for (EUserFrePair uit: (seit).GetEventUserIDs()) {
	                	boolean flag = false;
	                    for (Integer ulit:userlist) {
	                        if ((uit).userid == (ulit)) {
	                            flag = true;
	                            break;
	                        }
	                    }
	
	                    if (!flag) {
	                        userlist.add((uit).userid);
	                    }
	                }
	            }            
	        }
    	}
    	else { //process bucketNo only
			UPEventBucket upebit=new UPEventBucket();
			if(bucketNo<UserProfileEventPartition.getUProfileEventGroup().size())
    			upebit=UserProfileEventPartition.getUProfileEventGroup().get(bucketNo);    		
	            for (SocialEvent seit: (upebit).getUProfileEventGroup()) {
	                for (EUserFrePair uit: (seit).GetEventUserIDs()) {
	                	boolean flag = false;
	                    for (Integer ulit:userlist) {
	                        if ((uit).userid == (ulit)) {
	                            flag = true;
	                            break;
	                        }
	                    }
	
	                    if (!flag) {
	                        userlist.add((uit).userid);
	                    }
	                }
	            }            
	        
    	}

    }

    /*void GetDomiUserVirEvent(UPEventPartition UserProfileEventPartition, SocialEvent IncomingEvent, SocialEvent  VirtualUPPevent)
    {
        //estiate user influential between UserProfileEventPartition and IncomingEvent
        //Get all the users in UserProfileEventPartition
        List<Integer> userlist = new ArrayList<>();
        GetUserInEventPartition(UserProfileEventPartition, userlist);

        //Select all the users appearing in UserProfileEventPartition and influencing users in IncomingEvent , and calculate the average influence
        float[] influentials = new float[TUNUM];
        for (int i = 0; i < TUNUM; i++)
            influentials[i] = (0f);
        RemoveNonInfluentialUsers(userlist, IncomingEvent.GetEventUserIDs(),influentials);

        //rank the selected users in UserProfileEventPartition based on the average influentials they can generate to IncomingEvent.
        RankInfluentialUsers(userlist, influentials);

        //select the top un_{min} users from UserProfileEventPartition as the dominant ones
        int ulsize = userlist.size();
        if(ulsize> UserProfileEventPartition.getMinNumInfluencedUsers())

            //remove operation include first one    , not the last one
            for (int i=0 + UserProfileEventPartition.getMinNumInfluencedUsers() ; i < 0 + ulsize-1; i++){
                userlist.remove(i);
            }


        //form VirtualUPPevent
        VirtualUPPevent.SetEventUserIDs_Vec(userlist);
    }


    void GetUserInEventPartition(UPEventPartition UserProfileEventPartition, List<Integer> userlist)
    {


        for (UPEventBucket upebit:UserProfileEventPartition.getUProfileEventGroup()
             ) {
            for (SocialEvent seit: (upebit).getUProfileEventGroup()
                 ) {
                for (EUserFrePair uit: (seit).GetEventUserIDs()
                     ) {


                    boolean flag = false;
                    for (Integer ulit:userlist
                         ) {
                        if ((uit).userid == (ulit)) {
                            flag = true;
                            break;

                        }

                    }


                    if (!flag) {
                        userlist.add((uit).userid);
                    }

                    
                }
                
                
                
            }
            
        }

    }
*/


    void RemoveNonInfluentialUsers(List<Integer> userlist, List<EUserFrePair> eventUserIdsFre,  float[] influentials)
    {

        Map<Integer,UserProfile> UserProfileHashMap = recCxt.getEventMigration().UserProfileHashMap;
        int ulit=0, eraselit = 0;
        while(ulit < userlist.size()){
            //check if (*ulit) influence IncomingEvent
            int userNumBeInfluenced = 0; //count the number of user being influenced by (*ulit)
            int euifit = 0;

            while (euifit < eventUserIdsFre.size()){
                EUserFrePair euifitEle = eventUserIdsFre.get(euifit);
                int upDit = 0;
                while (upDit < UserProfileHashMap.get(ulit).UserInfluenceDistri.size()) {
                    UPInfluDistriEle upDitEle =  UserProfileHashMap.get(ulit).UserInfluenceDistri.get(upDit);
                    if (upDitEle.userid == ((euifitEle).userid)) {
                        if ((upDitEle).userInflu > 0) {//has influence
                            userNumBeInfluenced++;
                            influentials[ulit] += (upDitEle).userInflu;
                        }
                    }
                    upDit++;
                }
                euifit++;

            }


            ////
            if (! (userNumBeInfluenced !=0 ))//no influence
            {
                eraselit = ulit;
                if (ulit ==0)
                {
                    userlist.remove(eraselit);
                    ulit=0;
                }
                else {
                    ulit--;
                    userlist.remove(eraselit);
                    ulit++;
                }
            } else  //has influence
            {
                influentials[ulit] /= userNumBeInfluenced;
                ulit++;
            }

        }
    }



    // list could be array
    void RankInfluentialUsers(List<Integer> userlist, float[] influentials)
    {
        int userlistsize = userlist.size();
        for (int i = 0; i < userlistsize; i++)
        {
            for (int j = i+1; j < userlistsize; j++)
            {
                if (userlist.get(j) > userlist.get(i))
                {
                    //swap
                    int temp= userlist.get(i);
                    userlist.set(i,userlist.get(j)) ;
                    userlist.set(j,temp);
                }
            }
        }
    }


    public void EventSimilarityJoin(UPEventPartition UserProfileEventPartion, List<SocialEvent> IncomingEventSubset, float SimiThreshold)
    {
        EventRecommendation eventRec = recCxt.getRecommendation();

        int IESit = 0;
        while (IESit < IncomingEventSubset.size()){
            int bucketNum = UserProfileEventPartion.getUProfileEventGroup().size();

            for (int i = 0; i < bucketNum; i++){
                UPEventBucket upBucket = UserProfileEventPartion.getUProfileEventGroup().get(i);
                int  seit  = 0;
                while(seit < upBucket.getUProfileEventGroup().size()){
                    float simiV = eventRec.GetESim(IncomingEventSubset.get(IESit), upBucket.getUProfileEventGroup().get(seit));

                    if (simiV >= SimiThreshold) //recommend (*IESit) to the users whose profiles contain (*seit), update the RecUserSimi in (*IESit)
                    {
                        UpdateRecUserSimi(IncomingEventSubset.get(IESit),( upBucket.getUProfileEventGroup().get(seit)),simiV);
                    }
                    seit++;
                }

            }
                /////////
            IESit ++;
        }
    }


    public void UpdateRecUserSimi(SocialEvent  IncomingEvent, SocialEvent  UserProfileEvent, float simiV)
    {
        int NU_seit = UserProfileEvent.userlist.size();
        for (int j = 0; j < NU_seit; j++)
        {
            //check if (*seit).userlist[j] is in (*IESit).RecUserSimi
            int NRU_IESit = IncomingEvent.RecUserSimi.size();
            for (int k = 0; k < NRU_IESit; k++)
            {
                if (UserProfileEvent.userlist.get(j) == IncomingEvent.RecUserSimi.get(k).userid)
                {
                    if (simiV > IncomingEvent.RecUserSimi.get(k).simi)
                        IncomingEvent.RecUserSimi.get(k).simi = simiV;
                    break;
                }
            }
        }
    }
}
