package org.turningme.theoretics.common;

import java.io.Serializable;
//import java.util.ArrayList;

public class parameters implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	  public static int MAXEVENTNUM=20000; //20  //The maximal number of incoming events in a time slot
    public static int KUNUM=100;
    public static float WUIPV=1.0f;
    public static int MVALUE=10;
    public static int TFIDF_DIM=50;
    //public static float MAXFLOAT=0.12f;
    public static float MAXFLOAT=10000.12f;
    //public static float TIMERADIUST=0.5f;
     public static final double  EARTH_RADIUS = 6378.137;
    public static float migrateT=0.01f;
    public static int coupling=0;
    //public static float elip=0.25f;

    //ArrayList<SubEvent> UPEventList=new ArrayList<>();
    //for nepal parameter setting
   /* public static int TUNUM=135782; //total number of users in training dataset
    public static float ALPHA=0.7f;
    public static float TIMERADIUST=2.0f;  //for Nepal dataset
    public static float omeg1=0.7f;
    public static float omeg2=0.1f;*/
    //==================

    public static int TOPK=10;   
  //added by emily in Jan. 2022
    public static float SimiThreshold=0.3f;
    
    //for texas flood parameter setting
    public static float ALPHA=0.6f;
    public static int TUNUM= 64240;
    public static float TIMERADIUST=8.0f;
    public static float omeg1=0.6f;
    public static float omeg2=0.3f;
    
}
