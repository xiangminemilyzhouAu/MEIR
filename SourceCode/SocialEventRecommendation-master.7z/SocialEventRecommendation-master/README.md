org.turningme.theoretics.StaticSimilarityJoin . then entrance


# SoicalEventRecommendation
SoicalEventRecommendation partial

========= steps
1、cover spark logic process in cpp program 


2、java local jvm program ready


3、logger serialization 


4、to spark scheduler program 


========== 
