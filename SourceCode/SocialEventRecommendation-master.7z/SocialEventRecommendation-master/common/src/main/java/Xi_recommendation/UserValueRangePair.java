package Xi_recommendation;

import java.io.Serializable;

public class UserValueRangePair implements Serializable {
    public int userid;
    public float minV;
    public float maxV;
}
