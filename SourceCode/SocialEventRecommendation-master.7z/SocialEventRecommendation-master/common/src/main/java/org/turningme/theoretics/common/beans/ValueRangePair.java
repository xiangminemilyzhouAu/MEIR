package org.turningme.theoretics.common.beans;

import java.io.Serializable;

/**
 * Created by jpliu on 2020/2/24.
 */
public class ValueRangePair  implements Serializable {
    public float minV;
    public float maxV;

    public ValueRangePair() {
    }
}
