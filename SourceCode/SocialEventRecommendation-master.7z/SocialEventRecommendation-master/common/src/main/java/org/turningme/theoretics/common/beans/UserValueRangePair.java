package org.turningme.theoretics.common.beans;

import java.io.Serializable;

public class UserValueRangePair implements Serializable{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
public int userid;
public float minV;
public float maxV;
public UserValueRangePair() {
}
}
