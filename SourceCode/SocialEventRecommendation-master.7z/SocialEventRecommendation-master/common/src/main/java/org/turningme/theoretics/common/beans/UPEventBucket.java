package org.turningme.theoretics.common.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.turningme.theoretics.common.event.SocialEvent;

/**
 * Created by jpliu on 2020/2/24.
 */
public class UPEventBucket  implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int userNum; //the number of users in this partition
    public List<SocialEvent> UProfileEventGroup = new ArrayList<>();
    //public ValueRangePair[] TopicRangeVector = new ValueRangePair[TFIDF_DIM] ;
   // public ValueRangePair[] InfluenceRangeVector = new ValueRangePair[TUNUM]  ;  //include TUNUM ValueRangePairs    
    public int minNumOfInfluencedUsers;
    public int maxNumOfInfluencedUsers;

    public SocialEvent TFIDFCenter=new SocialEvent();
    public float minAngleCos;
    
    public SpaceRange centreP=new SpaceRange(); //the centre location point of all the subevents 
    public float minimalRadius; //the minimal radius of subevents in this partion
    public  ValueRangePair TimeRangePair=new ValueRangePair();
    //public  ValueRangePair[] SpaceRangePair = new ValueRangePair[2]; //SpaceRangePair [0] stores max and min Lat, SpaceRangePair[1] stores max and min longi    
    public List<UserValueRangePair> InfluenceRangeVector= new ArrayList<>();
    
    public UPEventBucket() {
        userNum = 1;
        //InfluenceRangeVector = new ValueRangePair[userNum];
    }



    public UPEventBucket(int uNum) {
        userNum = uNum;
        //	InfluenceRangeVector = new ValueRangePair[userNum];
    }

    public void setUProfileEventGroup(SocialEvent e) {
        UProfileEventGroup.add(e);
    }

    public List<SocialEvent> getUProfileEventGroup() {
        return UProfileEventGroup;
    }

   /* public void setTopicRangeVector(ValueRangePair[] TRV) {
        for (int i = 0; i < TFIDF_DIM; i++) {
            TopicRangeVector[i].minV = TRV[i].minV;
            TopicRangeVector[i].maxV = TRV[i].maxV;
        }

    }

    public ValueRangePair[]  getTopicRangeVector() {
        return TopicRangeVector;
    }

    public void setInfluenceRangeVector(ValueRangePair[]  IRV) {
        for (int i = 0; i < userNum; i++) {
            InfluenceRangeVector[i].minV = IRV[i].minV;
            InfluenceRangeVector[i].maxV = IRV[i].maxV;
        }
    }

    public ValueRangePair[]  getInfluenceRangeVector() {
        return InfluenceRangeVector;
    }*/

    public void setMinNumInfluencedUsers(int minNum) {
        minNumOfInfluencedUsers = minNum;
    }

    public void setMaxNumInfluencedUsers(int maxNum) {
        maxNumOfInfluencedUsers = maxNum;
    }

    public int getMinNumInfluencedUsers() {
        return minNumOfInfluencedUsers;
    }

    public int getMaxNumInfluencedUsers() {
        return maxNumOfInfluencedUsers;
    }
    
    //added by Emily in Jan. 2022
    //added by Emily
      public int bucketid;
      public void setbucketid(int bid) {
      	bucketid = bid;
      }

      public int getbucketid() {
          return bucketid;
      }
      //==========
      
      public void setTFIDFCenter(float [] vec) {
  		TFIDFCenter.setConceptTFIDFVec(vec);
  	}
      public SocialEvent getTFIDFCenter() {
  		return TFIDFCenter;
  	}
      
      
      public void setminAngleCos(float minCos) {
  		minAngleCos = minCos;
  	}
      public float getminAngleCos() {
  		return minAngleCos;
  	}
      
      public float GetminimalRadius() {
  		return minimalRadius;
  	}
  	public void setminimalRadius(float miniR) {
  		minimalRadius = miniR;
  	}
  	public SpaceRange getSpaceRangecentreP()
  	{
  		return centreP;
  	}
  	public void setSpaceRangecentreP(SpaceRange cp) {
  		centreP.lat = cp.lat;
  		centreP.longi = cp.longi;
  		centreP.radius = cp.radius;
  	}
  	
  	public void setSpaceRangecentrePoint(float[] cp) {
  		centreP.lat = cp[0];
  		centreP.longi = cp[1];
  		centreP.radius = cp[2];
  	}
      //==========
  	
  	//=added by Emily=========================================
              
     
    /*  public void setSpaceRangePair(ValueRangePair[] TRV) {
          for (int i = 0; i < 2; i++) {
              this.SpaceRangePair[i]=TRV[i];
//              this.SpaceRangePair[i].minV = TRV[i].minV;
//              this.SpaceRangePair[i].maxV = TRV[i].maxV;
          }
      }

      public ValueRangePair[] getSpaceRangePair() {

          return this.SpaceRangePair;
      }*/

      public void setTimeRangePair(ValueRangePair TRV) {
          this.TimeRangePair.minV = TRV.minV;
          this.TimeRangePair.maxV = TRV.maxV;
      }

      public ValueRangePair getTimeRangePair() {
          return this.TimeRangePair;
      }

      public void UPEventPartitionClear() {
          this.UProfileEventGroup.clear();
      }


      public void SetUN(ValueRangePair un) {
          this.minNumOfInfluencedUsers= (int) un.minV;
          this.maxNumOfInfluencedUsers= (int) un.maxV;
      }
      //==========================================
      public void setInfluenceRangeVector(UserValueRangePair IRV) {
      	InfluenceRangeVector.add(IRV);
         /* for (int i = 0; i < userNum; i++) {
              InfluenceRangeVector[i].minV = IRV[i].minV;
              InfluenceRangeVector[i].maxV = IRV[i].maxV;
          }*/
      }

      public  void setInfluenceRangeVectorList(ArrayList<UserValueRangePair> IRV) {
          for (int i = 0; i < IRV.size(); i++) {
              InfluenceRangeVector.add(IRV.get(i));
          }
      }
      //public ValueRangePair[]  getInfluenceRangeVector() {
      public List<UserValueRangePair> getInfluenceRangeVector() {
          return InfluenceRangeVector;
      }
}
