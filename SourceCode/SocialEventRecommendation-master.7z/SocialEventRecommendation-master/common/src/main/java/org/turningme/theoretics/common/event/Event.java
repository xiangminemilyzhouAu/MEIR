package org.turningme.theoretics.common.event;

import java.io.Serializable;

/**
 * Created by jpliu on 2020/2/23.
 */
public interface Event extends Serializable{
}
