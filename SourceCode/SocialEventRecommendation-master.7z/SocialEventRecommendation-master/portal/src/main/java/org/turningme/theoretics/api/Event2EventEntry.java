package org.turningme.theoretics.api;

import java.io.Serializable;

public class Event2EventEntry implements Serializable {

}
