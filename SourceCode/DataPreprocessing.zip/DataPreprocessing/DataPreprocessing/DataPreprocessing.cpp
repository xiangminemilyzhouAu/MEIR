// DataPreprocessing.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string.h>
#include "strtokenizer.h"
#include <vector>
#include "DataPreprocessing.h"


int TRAIN_MSG=0;
int main(int argc, char* argv[])
{
    bool		failed = false;
	char		c = -1;
	char		para[200];
	char		tpara[200];
	char		* cp = NULL;
	int			cnt = 1;
	char		* flistname=NULL;
	char		* path = NULL;
	char		* outpath = NULL;
	char		* DimDict = NULL;
	char* TrainingSetGramMSGNoFname = NULL;
	///////////////
	char* UserNameFile = NULL;
	char* InteractUserNameFile = NULL;
	char* InteractFlist = NULL;
	char* InteractFpath = NULL;
	char* resultfile = NULL;

	char* GTfile = NULL;
	char* GTFfile = NULL;
	/////////////////
	
	while (cnt < argc && !failed)
	{
		cp = argv[cnt];

		c = cp[0];
		if (c != '-')
		{
			failed = true;
			break;
		}

		strcpy_s(tpara, cp + 1);
		
		cnt++;
		if (cnt == argc){
			failed = true;
			break;
		}

		cp = argv[cnt];

		if (strcmp(tpara, "pt") == 0)
		{
			flistname =cp;// ProcessTrainingSet(char* flistname);
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "bp") == 0)
		{
			flistname =cp;// for BulkProcessMessageSlot(char* SlotFileList)
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "bd") == 0) {
			flistname = cp;// for void BulkGetMessageSlotsDims(char* flistname);
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "bg") == 0)
		{
			flistname = cp;// for BulkGenerateUserProfiles(char* SlotFileList) in training set
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "vbg") == 0)
		{
			flistname = cp;// for BulkGenerateUserProfiles(char* SlotFileList) in training set
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "bsg") == 0)
		{
			flistname = cp;// for BulkGenerateUserProfiles(char* SlotFileList) in single slot
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "ke") == 0)
		{
			flistname = cp;// for BulkExtractDataSetKeyWord(flistname, path);
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "lgt") == 0)
		{
			flistname = cp;// for BulkLabelGroudtruth(flistname, path);
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "cgt") == 0) {
			flistname = cp;// for BulkCompareGroudtruth(flistname, path);
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "gtt") == 0) {
			GTfile = cp;
		}
		else if (strcmp(tpara, "gtf") == 0) {
			GTFfile = cp;
		}
		else if (strcmp(tpara, "pa") == 0) {
			path = cp;
		}
		else if (strcmp(tpara, "op") == 0) {
			outpath = cp;
		}
		else if (strcmp(tpara, "dd") == 0) {
			DimDict = cp;
		}
		else if (strcmp(tpara, "mn") == 0) {
			TrainingSetGramMSGNoFname = cp;
		}		
		else if (strcmp(tpara, "uf") == 0) {
			UserNameFile = cp;
		}
		else if (strcmp(tpara, "iuf") == 0) {
			InteractUserNameFile = cp;
		}
		else if (strcmp(tpara, "if") == 0) {
			InteractFlist = cp;
		}
		else if (strcmp(tpara, "ifp") == 0) {
			InteractFpath = cp;
		}
		else if (strcmp(tpara, "rf") == 0) {
			resultfile = cp;
		}
		else if (strcmp(tpara, "ccigpt") == 0)
		{
			flistname = cp;// ProcessTrainingSetCCIGTensor(char* flistname);
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "ccigbp") == 0) {
			flistname = cp;
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "ccigbpmc") == 0) //process the fourgrams of event messages and event comments
		{
			flistname = cp;
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "ccigvpt") == 0)
		{
			flistname = cp;// ProcessTrainingSetCCIGVideoTensor(char* flistname);
			strcpy_s(para, tpara);
		}
		else if (strcmp(tpara, "ccigvbp") == 0) {
			flistname = cp;
			strcpy_s(para, tpara);
		}				
		cnt++;
	}

	if (strcmp(para, "pt") == 0)	{
		LoadkeywordConceptDict();
		ProcessTrainingSet(flistname,path);  //try this first, finished napel
	}
	else if (strcmp(para, "ccigpt") == 0) {
		ProcessTrainingSetCCIGTensor(flistname, path);
	}	
	else if (strcmp(para, "ccigvpt") == 0) {
		ProcessTrainingSetCCIGVideoTensor(flistname, path);
	}
	else if (strcmp(para, "bd") == 0) {//try this, finished
		LoadkeywordConceptDict();
		BulkGetMessageSlotsDims(flistname,path); 

		for (int i = 0; i < HTSize; i++) {
			GramDocNumHashTable[i].clear();
			for (int j = 0; j < keywordConceptDict[i].size(); j++)
				keywordConceptDict[i][j].cWPlist.clear();
			keywordConceptDict[i].clear();
		}
	}
	else if (strcmp(para, "bp") == 0)  	{
		//SetMSGNoIndex(flistname);
		//BulkSetUserIndex(flistname, path);
		//LoadkeywordConceptTokenDict();
		//return 0;

		char UserPfile[200];
		//strcpy_s(UserPfile, "UserProfileResult(Training25April-9May).txt");
		//strcpy_s(UserPfile, "UserProfileResult(Training15April-24April).txt");
		strcpy_s(UserPfile, "TexasFlood_UserProfileResult(Training12May-21May).txt");

		ReadUserProfiles(UserPfile); //all users are read into UserPHashTable[HTSize]

		//ReadDimensionDict(DimDict);
		ReadGramDocNumHashTable(TrainingSetGramMSGNoFname);		
		LoadkeywordConceptDict();		
		BulkProcessMessageSlot(flistname,path, outpath); //try this, finished

		for (int i = 0; i < HTSize; i++) {
			GramDocNumHashTable[i].clear();
			UserPHashTable[i].clear();
			for (int j = 0; j < keywordConceptDict[i].size(); j++)
				keywordConceptDict[i][j].cWPlist.clear();
			keywordConceptDict[i].clear();
		}
	}
	else if (strcmp(para, "ccigbp") == 0) {
		char UserPfile[200];
		strcpy_s(UserPfile, "TexasFlood_UserProfileResult(Training12May-21May).txt");

		ReadUserProfiles(UserPfile); //all users are read into UserPHashTable[HTSize]

		ReadGramDocNumHashTable(TrainingSetGramMSGNoFname);
		BulkProcessEventSlot(flistname, path, outpath); //try this, finished

		for (int i = 0; i < HTSize; i++) {
			GramDocNumHashTable[i].clear();
			UserPHashTable[i].clear();
			for (int j = 0; j < keywordConceptDict[i].size(); j++)
				keywordConceptDict[i][j].cWPlist.clear();
			keywordConceptDict[i].clear();
		}
	}
	else if (strcmp(para, "ccigvbp") == 0) {
		char UserPfile[200];
		strcpy_s(UserPfile, "Youtube_UserProfileResult.txt");
		ReadYoutubeUserProfiles(UserPfile); //all users are read into UserPHashTable[HTSize]

		ReadGramDocNumHashTable(TrainingSetGramMSGNoFname);
		
		BulkProcessYoutubeVideo(flistname, path, outpath);

		for (int i = 0; i < HTSize; i++) {
			GramDocNumHashTable[i].clear();
			UserPHashTable[i].clear();
			for (int j = 0; j < keywordConceptDict[i].size(); j++)
				keywordConceptDict[i][j].cWPlist.clear();
			keywordConceptDict[i].clear();
		}
	}
	else if (strcmp(para, "ccigbpmc") == 0) {
		BulkProcessEventSlotMsgComments(flistname, path, outpath);
	}
	else if (strcmp(para, "ke") == 0)
	{
		BulkExtractDataSetKeyWord(flistname, path);
	}
	else if (strcmp(para, "lgt") == 0) {
		/*char HashTags[200];
		//strcpy_s(HashTags, "NepalGroudTruthHashTags.txt");
		strcpy_s(HashTags, "TexasGTHashTags.txt");
		ReadHashtags(HashTags); //all event reated hashtags are read into GTHashtagHashTable[HTSize]
		*/
		//for get ground truth messages only
		char GTmsg[200];
		//strcpy_s(GTmsg, "texasGTMsgsLoc2(29May-5June)XiLocFilter.txt");
		//strcpy_s(GTmsg, "Nepal_GT_msglist_True_425to525.txt");
		//strcpy_s(GTmsg, "Texas_GT_msglist_True_522to528.txt");
		//strcpy_s(GTmsg, "Texas_GT_msglist_True.txt");
		//strcpy_s(GTmsg, "Texas_GT_msglist_True_Emily(May29-June5).txt");
		//strcpy_s(GTmsg, "testEvents.txt");
		/*strcpy_s(GTmsg, "Nepal_GT_msglist_True.txt");
		ReadGTMsg(GTmsg, GTMsgSet);
		//======================================
		BulkLabelGroudtruth(flistname, path,outpath);*/
		
	/*	strcpy_s(GTmsg, "TexasGTMsgsLoc2.txt");
		strcpy_s(GTmsg, "texasGTMsgsLoc2(29May-5June).txt");*/
		//strcpy_s(GTmsg, "TexasGTMsgs(May29-June5)NewLocFilter1.txt");		
		/*strcpy_s(GTmsg, "Nepal_GT_msglist_True_425to525WithEmilyHashTagRanked.txt");
		OutputGroudtruthMsg(GTmsg);

		strcpy_s(GTmsg, "texasGTMsgsLoc3(29May-5June).txt");
		strcpy_s(GTmsg, "TexasGTMsgs(May29-June5)New.txt");*/
		strcpy_s(GTmsg, "Nepal_GT_msglist_True_425to501WithEmily.txt");
		rankGroudtruthMsgbyLocation(GTmsg);

	/*	strcpy_s(GTmsg, "Nepal_GT_msglist_True_425to525WithEmily.txt");
		rankGroudtruthMsgbyHashTags(GTmsg);*/
		//======================
	/*	char GTmsg[200];
		//strcpy_s(GTmsg, "Nepal_GT_msglist_True.txt");
	//	strcpy_s(GTmsg, "Texas_GT_msglist_True.txt");
	//	ReadGTMsg(GTmsg, GTMsgSet); //all event reated hashtags are read into GTHashtagHashTable[HTSize]
		strcpy_s(GTmsg, "Texas_GT_msglist_True_522to528.txt");
		ReadGTMsg(GTmsg, GTMsgSet);
		strcpy_s(GTmsg, "Texas_GT_msglist_False.txt");
		ReadGTMsg(GTmsg, NonGTMsgSet);

		BulkOutputGroudtruth(flistname, path);*/
	}
	else if(strcmp(para, "cgt") == 0) {
		char GTmsg[200];
		strcpy_s(GTmsg, GTfile);
		//strcpy_s(GTmsg, "Nepal_GT_msglist_True.txt");
		//strcpy_s(GTmsg, "Texas_GT_msglist_True_522to528.txt");
		ReadGTMsg(GTmsg,GTMsgSet); //all event reated hashtags are read into GTHashtagHashTable[HTSize]

		char NonGTmsg[200];
		strcpy_s(NonGTmsg, GTFfile);
		//strcpy_s(NonGTmsg, "Nepal_GT_msglist_False.txt");
		//strcpy_s(NonGTmsg, "Texas_GT_msglist_False_522to528.txt");
		ReadGTMsg(NonGTmsg, NonGTMsgSet);

		BulkCompareGroudtruth(flistname, path, outpath);
	}
	else if (strcmp(para, "bg")==0) {//for training set
		int startUserIndexID = 0;
		
		startUserIndexID = ReadCommentUserIDandLocation(UserNameFile, startUserIndexID); //for all users from tweet Data
		BulkCountMainUserPostNum(flistname, path);
		startUserIndexID = ReadCommentUserIDandLocation(InteractUserNameFile, startUserIndexID); //for all users from interaction
		InitializeInteraction();
		BulkReadInteractionFile(InteractFlist, InteractFpath);
		UserProfile2File(resultfile);
	}
	else if (strcmp(para, "vbg") == 0) {//for training set
		int startUserIndexID = 0;
		sortedUPlistForUserid2UserOid.clear();
		BulkReadYoutubeUserID(flistname, startUserIndexID,path); //for all users from Youtube Data
		
		YoutubeUserProfile2File(resultfile);
	}
	else if (strcmp(para, "bsg") == 0) {//for training set
		//BulkGenerateUserProfiles(flistname, path);//try this, to be tested, but donot test this due to its old version
		
		//read NepalUserProfile(Training).txt for userid and useroid
		char UserPfile[200];
		//strcpy_s(UserPfile, "UserProfileResult(Training25April-9May).txt");

		//strcpy_s(UserPfile, "UserProfileResult(Training15April-24April).txt");

		strcpy_s(UserPfile, "TexasFlood_UserProfileResult(Training12May-21May).txt");
		ReadUserProfiles(UserPfile); //all users are read into UserPHashTable[HTSize]
				
		strcpy_s(UserPfile, path);
		strcat_s(UserPfile, flistname);
		strcat_s(UserPfile, ".txt");

		CountMainUserPostNum(UserPfile);
				
		InitializeInteractionSlot();
		strcpy_s(UserPfile, InteractFpath);
		strcat_s(UserPfile, InteractFlist);
		strcat_s(UserPfile, ".txt");
		ReadInteractionFile(UserPfile);
		
		SlotUserProfile2File(resultfile);
	}
	return 0;
}
int rankGroudtruthMsgbyHashTags(char* FullFileName) {
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	string CurHashTag;
	set<string> HashtagSet;
	set<string> MsgSet;
	set<string>::iterator lit, mit;
	//=========================
	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			MsgSet.insert(line);
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<hashtags>") == 0) {
					i++;
					CurHashTag.clear();
					CurHashTag = "<hashtags> ";
					while (strcmp(strtok.token(i).c_str(), "</hashtags>") != 0) {
						CurHashTag = CurHashTag + strtok.token(i);
						CurHashTag = CurHashTag + " ";
						i++;
					}
					CurHashTag = CurHashTag + "</hashtags>";
					HashtagSet.insert(CurHashTag);
					break;
					//continue;
				}
				i++;
			}
		}
		fclose(fileDescriptor);
	}

	//output groundtruth message ids
	char outFullGTFile[200];
	//strcpy_s(outFullGTFile, "Texas_GT_msglist_True_XiLocFilter.txt");
	strcpy_s(outFullGTFile, "Nepal_GT_msglist_True_425to525WithEmilyHashTagRanked.txt");
	if ((err = fopen_s(&fileDescriptor, outFullGTFile, "a+")) != 0) {
		printf("fileDescriptor outFullGTFile was not open\n");
	}
	else {
		lit = HashtagSet.begin();
		while (lit != HashtagSet.end()) {
			mit = MsgSet.begin();
			while (mit != MsgSet.end()) {
				std::size_t found = (*mit).find(*lit, 100);
				if (found != std::string::npos) {//found, output (*mit)
					fprintf_s(fileDescriptor, "%s", (*mit).c_str());					
				}
				mit++;
			}
			lit++;
		}
		//output non hashtaged messages
		mit = MsgSet.begin();
		CurHashTag = "<hashtags>";
		while (mit != MsgSet.end()) {
			std::size_t found = (*mit).find(CurHashTag, 100);
			if (found == std::string::npos) {//not found, output (*mit)
				fprintf_s(fileDescriptor, "%s", (*mit).c_str());
			}
			mit++;
		}
		//=============
		fclose(fileDescriptor);
	}
	HashtagSet.clear();
	MsgSet.clear();
	return 0;
}
int rankGroudtruthMsgbyLocation(char* FullFileName) {
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	string CurLoc;
	set<string> LocSet;
	set<string> MsgSet;
	set<string>::iterator lit, mit;
	//=========================
	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			MsgSet.insert(line);
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<coordinates>") == 0) {					
					CurLoc.clear();
					CurLoc = CurLoc + strtok.token(i);
					CurLoc = CurLoc + " ";
					i++;
					CurLoc = CurLoc + strtok.token(i);
					CurLoc = CurLoc + " ";
					i++;
					CurLoc = CurLoc + strtok.token(i);
					CurLoc = CurLoc + " ";
					i++;
					CurLoc = CurLoc + strtok.token(i);
					i++;
					
					LocSet.insert(CurLoc);
					break;
					//continue;
				}
				i++;
			}
		}
		fclose(fileDescriptor);
	}
	
	//output groundtruth message ids
	char outFullGTFile[200];
	//strcpy_s(outFullGTFile, "Texas_GT_msglist_True_XiLocFilter.txt");
	//strcpy_s(outFullGTFile, "TexasGTMsgs(May29-June5)NewLocFilter.txt");
	strcpy_s(outFullGTFile, "Nepal_GT_msglist_True_425to501WithEmilyLocFilter.txt");
	if ((err = fopen_s(&fileDescriptor, outFullGTFile, "a+")) != 0){
		printf("fileDescriptor outFullGTFile was not open\n");
	}
	else{
		lit = LocSet.begin();
		while (lit != LocSet.end()) {
			mit = MsgSet.begin();
			while (mit != MsgSet.end()) {
				std::size_t found = (*mit).find(*lit, 130);
				if (found != std::string::npos) //found, output (*mit)
					fprintf_s(fileDescriptor, "%s", (*mit).c_str());					
				mit++;
			}
			lit++;
		}
		fclose(fileDescriptor);
	}
	LocSet.clear();
	MsgSet.clear();
	return 0;
}
int OutputGroudtruthMsg(char* FullFileName)
{
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	//=========================
	string curMsgid;
	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
			int i = 0;
			while (i < length)
			{
				curMsgid = strtok.token(i).c_str();
				GTMsgSet.insert(curMsgid);
				break;				
			}
		}
		fclose(fileDescriptor);
	}


	//output groundtruth message ids
	char outFullGTFile[200];
	//strcpy_s(outFullGTFile, "Texas_GT_msglist_True_Xi7LocFilter.txt");
	//strcpy_s(outFullGTFile, "texasGTMsgsLoc2(29May-5June)XiLocFilter.txt");
	//strcpy_s(outFullGTFile, "TexasGTMsgs(May29-June5)NewLocFilter1Emily.txt");
	strcpy_s(outFullGTFile, "Nepal_GT_msglist_True_425to525WithEmilyIDs.txt");

	if ((err = fopen_s(&fileDescriptor, outFullGTFile, "a+")) != 0)
	{
		printf("fileDescriptor outFullGTFile was not open\n");
	}
	else
	{
		set<string>::iterator git = GTMsgSet.begin();
		while (git != GTMsgSet.end()) {
			fprintf_s(fileDescriptor, "%s\n", (*git).c_str());
			cout << (*git).c_str() << endl;
			git++;
		}
		GTMsgSet.clear();
		fclose(fileDescriptor);
	}
	return 0;
}

long long compute_hash(string const& s) {
	const int p = 31;
	const int m = 1e9 + 9;
	long long hash_value = 0;
	long long p_pow = 1;
	for (char c : s) {
		hash_value = (hash_value + (c - '0' + 1) * p_pow) % m;
		p_pow = (p_pow * p) % m;
	}
	return hash_value;
}

int ProcessUserProfileVideos(char* UEventfname, char* outFullSlotFileName, int StartClusterNo) {
	int ret = 0;

	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;

	char buffer[BUFFERSIZE];
	float vec[TFIDF_DIM];
	std::vector<string> msgTexts,descriptionTexts;
	std::vector<EventTensorEle> EventTensor;

	string line;
	int eid = 0;
	int videoID=0;
	if ((fopen_s(&fileDescriptor, UEventfname, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", UEventfname);
	}
	else
	{
		if ((fopen_s(&ResultFileDescriptor, outFullSlotFileName, "a+")) != 0)
		{
			printf("ResultFileDescriptor was not open\n");
		}
		else
		{
			while (fgets(buffer, BUFFERSIZE, fileDescriptor))
			{
				line = buffer;
				strtokenizer strtok(line, " \t\r\n");
				int length = strtok.count_tokens();

				if (length <= 0) {
					printf("Invalid (empty) line!\n");
					return 1;
				}

				int i = 0;

				while (i < length)
				{
					if (strcmp(strtok.token(i).c_str(), "<videoid>") == 0) {
						if (msgTexts.size() > 0|| descriptionTexts.size()>0) {//generate tensor representation for the previous cluster
							fprintf_s(ResultFileDescriptor, "<tensor>\t");
							//call a function that convert msgTexts to a vector, and output the vector
							EventTensor.clear();
							WeightedText2TensorNew(msgTexts, descriptionTexts, EventTensor);
							for (int j = 0; j < EventTensor.size(); j++) {
								if (EventTensor[j].DimVal > 0)
									fprintf(ResultFileDescriptor, "%lld %d %d %.4f\t", EventTensor[j].GramVal, EventTensor[j].rowVal, EventTensor[j].colVal, EventTensor[j].DimVal);
							}
							fprintf_s(ResultFileDescriptor, "</tensor>\n");
							EventTensor.clear();
						}

						fprintf_s(ResultFileDescriptor, "<videoid>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</videoid>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</videoid>\n");
						msgTexts.clear();
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<title>") == 0) {
						int j = 0;
						i++;
						while (strcmp(strtok.token(i).c_str(), "</title>") != 0) {
							msgTexts.push_back(strtok.token(i).c_str());
							i++;
						}
						i++;
						continue;
					}
					if (strcmp(strtok.token(i).c_str(), "<description>") == 0) {
						int j = 0;
						i++;
						while (strcmp(strtok.token(i).c_str(), "</description>") != 0) {
							descriptionTexts.push_back(strtok.token(i).c_str());
							i++;
						}
						i++;
						continue;
					}
					i++;
				}
			}

			if (msgTexts.size() > 0 ||descriptionTexts.size() > 0) {//generate tensor representation for the last cluster in this current slot
				fprintf_s(ResultFileDescriptor, "<tensor>\t");
				//call a function that convert msgTexts to a vector, and output the vector
				EventTensor.clear();

				WeightedText2TensorNew(msgTexts, descriptionTexts, EventTensor);
				for (int j = 0; j < EventTensor.size(); j++) {
					if (EventTensor[j].DimVal > 0)
						fprintf(ResultFileDescriptor, "%lld %d %d %.4f\t", EventTensor[j].GramVal, EventTensor[j].rowVal, EventTensor[j].colVal, EventTensor[j].DimVal);
				}

				fprintf_s(ResultFileDescriptor, "</tensor>\n");
				EventTensor.clear();
			}
			fclose(ResultFileDescriptor);
		}
		//=====================
		fclose(fileDescriptor);
	}
	return ret;
}

//added by emily on Sept 11, put event statistics information. No message kept to save memory
int ProcessUserProfileEvents(char* UEventfname, char* outFullSlotFileName, int StartClusterNo) {
	int ret = 0;

	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;

	char buffer[BUFFERSIZE];
	float vec[TFIDF_DIM];
	std::vector<string> msgTexts;
	std::vector<EventTensorEle> EventTensor;
	   
	string line;
	int eid = 0;
	if ((fopen_s(&fileDescriptor, UEventfname, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", UEventfname);
	}
	else
	{
		if ((fopen_s(&ResultFileDescriptor, outFullSlotFileName, "a+")) != 0)
		{
			printf("ResultFileDescriptor was not open\n");
		}
		else
		{
			while (fgets(buffer, BUFFERSIZE, fileDescriptor))
			{
				line = buffer;
				strtokenizer strtok(line, " \t\r\n");
				int length = strtok.count_tokens();

				if (length <= 0) {
					printf("Invalid (empty) line!\n");
					return 1;
				}

				int i = 0;

				while (i < length) 
				{
					if (strcmp(strtok.token(i).c_str(), "<clusterid>") == 0) {
						if (msgTexts.size() > 0) {//generate tensor representation for the previous cluster
							fprintf_s(ResultFileDescriptor, "<tensor>\t");
							//call a function that convert msgTexts to a vector, and output the vector
							EventTensor.clear();
							Text2TensorNew(msgTexts, EventTensor);
							for (int j = 0; j < EventTensor.size(); j++) {
								if (EventTensor[j].DimVal > 0)
									fprintf(ResultFileDescriptor, "%lld %d %d %.4f\t", EventTensor[j].GramVal, EventTensor[j].rowVal, EventTensor[j].colVal, EventTensor[j].DimVal);
							}
							fprintf_s(ResultFileDescriptor, "</tensor>\n");
							EventTensor.clear();
						}

						fprintf_s(ResultFileDescriptor, "<clusterid>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</clusterid>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</clusterid>\n");
						msgTexts.clear();
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<text>") == 0) {
						int j = 0;
						i++;
						while (strcmp(strtok.token(i).c_str(), "</text>") != 0) {
							msgTexts.push_back(strtok.token(i).c_str());
							i++;
						}
						i++;
						continue;
					}
					i++;
				}
			}

			if (msgTexts.size() > 0) {//generate tensor representation for the last cluster in this current slot
				fprintf_s(ResultFileDescriptor, "<tensor>\t");
				//call a function that convert msgTexts to a vector, and output the vector
				EventTensor.clear();

				Text2TensorNew(msgTexts, EventTensor);
				for (int j = 0; j < EventTensor.size(); j++) {
					if (EventTensor[j].DimVal > 0)
						fprintf(ResultFileDescriptor, "%lld %d %d %.4f\t", EventTensor[j].GramVal, EventTensor[j].rowVal, EventTensor[j].colVal, EventTensor[j].DimVal);
				}

				fprintf_s(ResultFileDescriptor, "</tensor>\n");
				EventTensor.clear();
			}
			fclose(ResultFileDescriptor);
		}
		//=====================
		fclose(fileDescriptor);
	}	
	return ret;
}

int BulkCompareGroudtruth(char* flistname, char* path, char* outpath) {
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	//char outFullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	set<string> RetrievedTrue;

	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		int count = 0;
		while (fgets(buffer, MSGLEN, fileDescriptor)) {

			count++;
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");

			//printf("%s", buffer);
			CompareMSGSlotGroudtruth(FullSlotFileName, RetrievedTrue);
		}
		fclose(fileDescriptor);
	}
		
	int TrueMatch = 0;
	int FalseMatch = 0;	
	int missDetection = 0;
	
	set<string> DifferentRetGT;
	set_difference(RetrievedTrue.begin(), RetrievedTrue.end(), GTMsgSet.begin(), GTMsgSet.end(), inserter(DifferentRetGT,DifferentRetGT.end()));
	FalseMatch = DifferentRetGT.size();

	set<string> Diff_GT_Ret;
	set_difference(GTMsgSet.begin(), GTMsgSet.end(),RetrievedTrue.begin(), RetrievedTrue.end(),  inserter(Diff_GT_Ret, Diff_GT_Ret.end()));
	missDetection = Diff_GT_Ret.size();

	set<string> CommonRetGT;
	set_intersection(GTMsgSet.begin(), GTMsgSet.end(), RetrievedTrue.begin(), RetrievedTrue.end(), inserter(CommonRetGT, CommonRetGT.end()));
	TrueMatch = CommonRetGT.size();

	float P_miss = (float)missDetection / GTMsgSet.size();
	float P_Fa = (float)FalseMatch / NonGTMsgSet.size();
	   
	/*
	float Precision = (float)TrueMatch / RetrievedTrue.size();
	float Recall = (float)TrueMatch / GTMsgSet.size();
	float F1 = (float)2.0 * (Precision * Recall) / (Precision + Recall);

	cout << path << "\t PMiss=" << P_miss << "\t PFa=" << P_Fa << "\t F1=" << F1 <<"\t Precision="<<Precision<<
		"\t Recall="<<Recall<<"\t MissDetection="<<missDetection<<"\t FalseMatch="<<FalseMatch<< endl;
		*/
	cout << path << "\t PMiss=" << P_miss << "\t PFa=" << P_Fa << endl;

	DifferentRetGT.clear();
	Diff_GT_Ret.clear();
	CommonRetGT.clear();

	RetrievedTrue.clear();
	GTMsgSet.clear();
	NonGTMsgSet.clear();
	
	return 0;
}

int CompareMSGSlotGroudtruth(char* FullFileName, set<string>& RetrievedTrue)
{
	int ret = 0;

	char buffer[BUFFERSIZE];
	string line;

	int isMSG = 0;
	int isRelevant = 0;	
	string msgid;
	FILE* resultFile = NULL;
	
	if ((fopen_s(&resultFile, FullFileName, "r")) != 0) {
		;//printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, resultFile)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<IsEvent>") == 0)
				{					
					i++;
					isMSG = 0;					
					while (strcmp(strtok.token(i).c_str(), "</IsEvent>") != 0) {
						isRelevant = atoi(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}				
				//================			

				if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
					i++;
					isMSG = 1;
					while (strcmp(strtok.token(i).c_str(), "</msgid>") != 0) {
						msgid = strtok.token(i);
						if(isRelevant)
							RetrievedTrue.insert(msgid);
						i++;
					}
					i++;
					continue;
				}								
				i++;
			}			
		}
		fclose(resultFile);
	}
	ret = RetrievedTrue.size();
	return ret;
}

int ReadGTMsg(char* GTmsgs, set<string>& GTNonGTset) {

	int ret = 0;

	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	if ((err = fopen_s(&fileDescriptor, GTmsgs, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", GTmsgs);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
			if (length > 0)
			{
				int hashkey = hashString(strtok.token(0), HTSize);
				GTNonGTset.insert(strtok.token(0));
				/*int hashkey = hashString(strtok.token(2), HTSize);
				GTNonGTset.insert(strtok.token(2));*/
			}
		}
		fclose(fileDescriptor);
	}
	ret = GTNonGTset.size();

	return ret;
}
int ReadHashtags(char* HashTags) {
	int ret = 0;
	
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	if ((err = fopen_s(&fileDescriptor, HashTags, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", HashTags);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
			if (length > 0)
			{
				int hashkey=hashString(strtok.token(0), HTSize);
				GTHashtagHashTable[hashkey].push_back(strtok.token(0));
				ret++;
			}
		}
		fclose(fileDescriptor);
	}
	
	return ret;
}
//SAX string hash
unsigned hashString(string const& key, unsigned tableSize)
{
	unsigned hashVal = 0;
	for (int x = 0; x < key.length(); ++x)
	{
		hashVal ^= (hashVal << 5) +
			(hashVal >> 2) +
			key[x];
	}
	return hashVal % tableSize;
}

void LoadkeywordConceptTokenDict()
{
	char FullFileName[200];
	strcpy_s(FullFileName, "concept_nepal(clean).txt");

	FILE* fileDescriptor = NULL;
	FILE* resultDescriptor = NULL;

	char outputFile[200];
	strcpy_s(outputFile, "concept_nepal_token.txt");
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	KeywordConceptDictEle kcDe;
	conceptWeightPair cwp, tokencwp;
	vector<conceptWeightPair> conceptTokenSet;
	vector<conceptWeightPair>::iterator cwpit;

	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else
	{
		if(fopen_s(&resultDescriptor,outputFile,"a+")==0){
			while (fgets(buffer, BUFFERSIZE, fileDescriptor))
			{
				line = buffer;
				strtokenizer strtok(line, " \t\r\n");
				int length = strtok.count_tokens();

				int i = 0;
				if (length > 0) {
					kcDe.keyword = strtok.token(0);
					conceptTokenSet.clear();
					i++;
				}
				while (i < length)
				{
					cwp.concept = strtok.token(i);
					i++;
					cwp.weight = atof(strtok.token(i).c_str());
					i++;
					if (cwp.weight >= 1) {
						int len = cwp.concept.length();
						if (len <= GramSize) {
							//kcDe.cWPlist.push_back(cwp);
							char str[MSGLEN];
							string tmpstr = "_";
							int gapsize = GramSize - cwp.concept.size();
							for (int j = 0; j < gapsize; j++) {
								cwp.concept = tmpstr + cwp.concept;
							}
							////=======
							cwpit = conceptTokenSet.begin();
							while (cwpit != conceptTokenSet.end()) {
								if (tokencwp.concept == (*cwpit).concept)
									break;
								cwpit++;
							}
							if (cwpit == conceptTokenSet.end()) {
								//===========
								strcpy_s(str, cwp.concept.c_str());
								cwp.FourGramV = FourGramToVal(str);
								conceptTokenSet.push_back(cwp);
							}
						}
						else {
							for (int j = 0; j <= len - GramSize; j++) {
								tokencwp.concept = cwp.concept.substr(j, GramSize);
								
								cwpit = conceptTokenSet.begin();								
								while(cwpit!=conceptTokenSet.end()){
									if (tokencwp.concept == (*cwpit).concept)
										break;
									cwpit++;
								}
								if (cwpit == conceptTokenSet.end()) {
									tokencwp.weight = cwp.weight;
									char str[MSGLEN];
									strcpy_s(str, cwp.concept.c_str());
									tokencwp.FourGramV = FourGramToVal(str);
									conceptTokenSet.push_back(tokencwp);
								}
								if (j == 2)
									break;
							}
						}

					}
				}
				//put kcDe into the dictionary
				//if (kcDe.cWPlist.size() > 0) {
				if (conceptTokenSet.size() > 0) {
					//int hashkey = hashString(kcDe.keyword, HTSize);
					//keywordConceptDict[hashkey].push_back(kcDe);
					fprintf(resultDescriptor,"%s\t", kcDe.keyword.c_str());
					cout << kcDe.keyword << endl;
					cwpit = conceptTokenSet.begin();
					while (cwpit != conceptTokenSet.end()) {
						fprintf(resultDescriptor, "%s %.2f %lld\t", (*cwpit).concept.c_str(),(*cwpit).weight,(*cwpit).FourGramV);
						cwpit++;
					}
					fprintf(resultDescriptor, "\n");
					conceptTokenSet.clear();
				}
				kcDe.keyword = "";
				kcDe.cWPlist.clear();

			}	
			fclose(resultDescriptor);			
		}

		fclose(fileDescriptor);
	}

}
void LoadkeywordConceptDict() {
	char FullFileName[200];
	//strcpy_s(FullFileName, "concept_nepal.txt");
	strcpy_s(FullFileName, "concept_flood.txt");
		
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	KeywordConceptDictEle kcDe;
	conceptWeightPair cwp;

	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else
	{
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			int i = 0;
			if (length > 0) {
				kcDe.keyword = strtok.token(0);
				i++;
			}
			while (i < length)
			{
				cwp.concept = strtok.token(i);
				i++;
				cwp.weight = atof(strtok.token(i).c_str());
				i++;
				
				if(cwp.weight>1.01)
				kcDe.cWPlist.push_back(cwp);
			}
			//put kcDe into the dictionary
			if (kcDe.cWPlist.size() > 0) {
				int hashkey = hashString(kcDe.keyword, HTSize);
				keywordConceptDict[hashkey].push_back(kcDe);
			}
			kcDe.keyword = "";
			kcDe.cWPlist.clear();
		}

		fclose(fileDescriptor);
	}
	
}

int ReadYoutubeUserProfiles(char* FullUserNameFile)  //for YoutubeUserPHashTable[HTSize]
{
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	YoutubeUserProfile curUserP;	
	int UserIndexID = 0;

	if ((err = fopen_s(&fileDescriptor, FullUserNameFile, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullUserNameFile);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			int i = 0;
			int inserted = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<userid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</userid>") != 0) {
						curUserP.userId = atoi(strtok.token(i).c_str());
						if (curUserP.userId > UserIndexID)
							UserIndexID = curUserP.userId;
						i++;
					}
					i++;
					continue;
				}
				if (strcmp(strtok.token(i).c_str(), "<userOid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</userOid>") != 0) {
						curUserP.userOid = strtok.token(i);
						i++;
					}
					i++;
					continue;
				}

				/*if (strcmp(strtok.token(i).c_str(), "<location>") == 0) {
					i++;
					inserted = 1;
					while (strcmp(strtok.token(i).c_str(), "</location>") != 0) {
						curUserP.UserPhysicalLocation.lat = atof(strtok.token(i).c_str());
						i++;
						curUserP.UserPhysicalLocation.longi = atof(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}*/
				i++;
			}
			if (inserted) {
				//search curUserP.userId from UserPHashTable
				int hashkey = compute_hash(curUserP.userOid) % HTSize;
				int flag = 0; //a flag to show if the userId is found in hashtable
				int j = 0;
				for (j = 0; j < YoutubeUserPHashTable[hashkey].size(); j++) {
					if (strcmp(YoutubeUserPHashTable[hashkey][j].userOid.c_str(), curUserP.userOid.c_str())==0)//found
					{
						flag = 1;
						break;
					}
				}
				if (!flag)//not found, then insert
				{
					YoutubeUserPHashTable[hashkey].push_back(curUserP);
				}
			}
			////////////////////////////			
		}
		fclose(fileDescriptor);
	}
	return UserIndexID;
}


int ReadUserProfiles(char* FullUserNameFile)  //for UserPHashTable[HTSize]
{
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	UserProfile curUserP;
	curUserP.UserResponseNumbers.clear();
	curUserP.PostNum = 0;

	int UserIndexID = 0;

	if ((err = fopen_s(&fileDescriptor, FullUserNameFile, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullUserNameFile);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			int i = 0;			
			int inserted = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<userid>") == 0) {					
					i++;
					while (strcmp(strtok.token(i).c_str(), "</userid>") != 0){
						curUserP.userId = atoi(strtok.token(i).c_str());
						if (curUserP.userId > UserIndexID)
							UserIndexID = curUserP.userId;
						i++;
					}
					i++;
					continue;
				}
				if (strcmp(strtok.token(i).c_str(), "<userOid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</userOid>") != 0) {						
						curUserP.userOid = atof(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<location>") == 0) {
					i++;
					inserted = 1;
					while (strcmp(strtok.token(i).c_str(), "</location>") != 0) {
						curUserP.UserPhysicalLocation.lat = atof(strtok.token(i).c_str());
						i++;
						curUserP.UserPhysicalLocation.longi = atof(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}
				i++;
			}
			if (inserted) {
				//search curUserP.userId from UserPHashTable
				int hashkey = curUserP.userOid % HTSize;
				int flag = 0; //a flag to show if the userId is found in hashtable
				int j = 0;
				for (j = 0; j < UserPHashTable[hashkey].size(); j++) {
					if (UserPHashTable[hashkey][j].userOid == curUserP.userOid)//found
					{
						flag = 1;
						break;
					}
				}
				if (!flag)//not found, then insert
				{
					UserPHashTable[hashkey].push_back(curUserP);					
				}
			}
			////////////////////////////			
		}
		fclose(fileDescriptor);
	}
	return UserIndexID;
}

int BulkOutputGroudtruth(char* flistname, char* path) {
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		int count = 0;
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			count++;
			//if (count <= 24)
			if (count <= 168)
				continue;
			//if (count > 168)  //ignore the first 7 days
			/*if (count > 48)  //ignore the first 7 days
				break;*/
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			//printf("%s", buffer);
			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".GT");								   
			OutputMSGSlotGroudtruth(FullSlotFileName);
		}
		fclose(fileDescriptor);
	}

	for (int i = 0; i < HTSize; i++)
		GTHashtagHashTable[i].clear();
	GTHashtagHashTable->clear();
	
	//output groundtruth message ids
	char outFullGTFile[200];
	//strcpy_s(outFullGTFile, "Texas_GT_msglist_False_Xi7Emily.txt");
	strcpy_s(outFullGTFile, "Texas_GT_msglist_False_Emily(May29-June5).txt");
	if ((err = fopen_s(&fileDescriptor, outFullGTFile, "a+")) != 0)
	{
		printf("fileDescriptor outFullGTFile was not open\n");
	}
	else
	{
		set<string>::iterator git = NonGTMsgSet.begin();
		while (git != NonGTMsgSet.end()) {
			auto search = GTMsgSet.find(*git);
			if (search == GTMsgSet.end()) //not found
			{
				fprintf_s(fileDescriptor, "%s\n", (*git).c_str());
				cout << (*git).c_str() << endl;
			}
			git++;
		}
		NonGTMsgSet.clear();
		fclose(fileDescriptor);
	}
	//strcpy_s(outFullGTFile, "Texas_GT_msglist_True_Xi7Emily.txt");
	strcpy_s(outFullGTFile, "Texas_GT_msglist_True_Emily(May29-June5).txt");
	if ((err = fopen_s(&fileDescriptor, outFullGTFile, "a+")) != 0)
	{
		printf("fileDescriptor outFullGTFile was not open\n");
	}
	else
	{
		set<string>::iterator git = GTMsgSet.begin();
		while (git != GTMsgSet.end()) {
			fprintf_s(fileDescriptor, "%s\n", (*git).c_str());
			cout << (*git).c_str() << endl;
			git++;
		}
		GTMsgSet.clear();
		fclose(fileDescriptor);
	}

	
	return 0;
}

int OutputMSGSlotGroudtruth(char* FullFileName)
{
	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	
	//=========================
	string curMsgid;
	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else {		
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			int i = 0;
			int IsGT = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<GT>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</GT>") != 0) {
						IsGT=atoi(strtok.token(i).c_str());
						i++;
					}
					if (!IsGT)
						break;
					i++;
					continue;
				}
					
				if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</msgid>") != 0) {
						curMsgid = strtok.token(i).c_str();
						i++;
					}
					if (IsGT) {
						GTMsgSet.insert(curMsgid);
					}
					
					break;
				}
				i++;
			}		
		}
		fclose(fileDescriptor);
	}

	
	return 0;
}

int BulkLabelGroudtruth(char* flistname, char* path, char* outpath) {
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char outFullSlotFileName[MSGLEN];
	char buffer[MSGLEN];
			
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		int count = 0;
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			
			count++;
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			/*if (count <= 168)
				continue;*/
			if (count > 168)
				break;

			//printf("%s", buffer);

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");
			

			strcpy_s(outFullSlotFileName, outpath);
			strcat_s(outFullSlotFileName, strtok.token(0).c_str());
			strcat_s(outFullSlotFileName, ".GT");
			
						
			//LabelMSGSlotGroudtruth(FullSlotFileName, outFullSlotFileName);
			LabelSlotGroudtruthMSG(FullSlotFileName, outFullSlotFileName);
		}
		fclose(fileDescriptor);
	}

	for (int i = 0; i < HTSize; i++)
		GTHashtagHashTable[i].clear();
	GTHashtagHashTable->clear();
	return 0;
}

int LabelSlotGroudtruthMSG(char* FullFileName, char* outFullGTFile)
{
	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	string curMsgid;

	char outFullGTFileName[200];
	//strcpy_s(outFullGTFileName, "TexasGTMsgs.txt");
	//strcpy_s(outFullGTFileName, "TexasGTMsgs(May29-June5)New.txt");
	//strcpy_s(outFullGTFileName, "TexasGTMsgsID(May29-June5).txt");

	//strcpy_s(outFullGTFileName, "TexasGTMsgsID(May29-June5)WithEmily.txt");
	//strcpy_s(outFullGTFileName, "Nepal_GT_msglist_True_425to525WithEmily.txt");
	//strcpy_s(outFullGTFileName, "testEventMsgEmily.txt");
	strcpy_s(outFullGTFileName, "Nepal_GT_msglist_True_425to501WithEmily.txt");
	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else {
		if ((err = fopen_s(&ResultFileDescriptor, outFullGTFileName, "a+")) != 0)
			printf("ResultFileDescriptor was not open\n");
		else{
			while (fgets(buffer, BUFFERSIZE, fileDescriptor)){
				line = buffer;
				strtokenizer strtok(line, " \t\r\n");
				int length = strtok.count_tokens();
				if (length <= 0) {
					printf("Invalid (empty) document!\n");
					fclose(ResultFileDescriptor);
					return 1;
				}

				int i = 0;
				while (i < length){										
					if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
						i++;
						while (strcmp(strtok.token(i).c_str(), "</msgid>") != 0) {
							curMsgid = strtok.token(i).c_str();
							i++;
						}
						i++;
						break;
					}
					i++;
				}	
				auto search = GTMsgSet.find(curMsgid);
				if (search != GTMsgSet.end()) {
					//fprintf(ResultFileDescriptor, "%s\n", curMsgid.c_str());
					fprintf(ResultFileDescriptor, "%s\t %s", curMsgid.c_str(), buffer);
					GTMsgSet.erase(curMsgid); //remove repeat
					//cout << curMsgid<<"\t"<< buffer << endl;
					//TexasGTMsgs
				}
			}
			//=================================
			fclose(ResultFileDescriptor);
		}
		fclose(fileDescriptor);
	}
	return 0;
}

int LabelMSGSlotGroudtruth(char* FullFileName, char* outFullGTFile)
{
	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	int retweetstatus = 0;
	
	int hashtagedGT = 0;
	int IsNoHashtagedGT = 0;
	int msgIndex = 0;
	vector<string> hashtags;
	vector<string> keywords;

	//for nepal earthquake
	/*keywords.push_back("nepal");
	keywords.push_back("earthquak");
	keywords.push_back("quak");
	keywords.push_back("nepali");
	keywords.push_back("nepales");*/
	//=============================
	//for texasFlood
	keywords.push_back("flood");
	keywords.push_back("floods");
	keywords.push_back("floodspot");
	keywords.push_back("flooding");
	keywords.push_back("floodwaters");
	keywords.push_back("floodlight");
	keywords.push_back("flooded");
	keywords.push_back("flashflooding");	
	keywords.push_back("spotampflood");
	keywords.push_back("texasfloods");
	keywords.push_back("tstorm");
	keywords.push_back("storms");
	keywords.push_back("storm");
	keywords.push_back("tstorms");
	keywords.push_back("texas");
	keywords.push_back("thunderstorm");
	keywords.push_back("thunderstorms"); 
	keywords.push_back("oklahoma");
	keywords.push_back("thunderstor");
	keywords.push_back("rain");
	keywords.push_back("clouds");
	keywords.push_back("donations");
	keywords.push_back("houston");
	keywords.push_back("houstons");
	keywords.push_back("tornado");
	keywords.push_back("tornadoes"); 
	keywords.push_back("arkansas");
	keywords.push_back("flooddevastated");
	keywords.push_back("floodvictims");
	keywords.push_back("water");
	keywords.push_back("rainflood");
	keywords.push_back("rainstorm");
	keywords.push_back("rainstoms");
	keywords.push_back("rainfall");
	keywords.push_back("houstonians");
	keywords.push_back("texans");
	keywords.push_back("california");
	keywords.push_back("rescue");
	keywords.push_back("stormfloodhurricane");
	keywords.push_back("hurricane");
	keywords.push_back("hurricanes");
	keywords.push_back("shelter");
	keywords.push_back("austin");
	keywords.push_back("squirtflooded");
	keywords.push_back("floodgate");
	keywords.push_back("tedxstormont");
	keywords.push_back("waterfalls");
	keywords.push_back("rainbowtexas");
	keywords.push_back("floodingspurs");
	
	//=========================
	int keywordlistSize = keywords.size();
	string curMsgid;
	set<string> TmpGTmsgset;
	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else {
		if ((err = fopen_s(&ResultFileDescriptor, outFullGTFile, "a+")) != 0)
		{
			printf("ResultFileDescriptor was not open\n");
		}
		else
		{
			while (fgets(buffer, BUFFERSIZE, fileDescriptor)) 
			{
				line = buffer;
				strtokenizer strtok(line, " \t\r\n");
				int length = strtok.count_tokens();

				if (length <= 0) {
					printf("Invalid (empty) document!\n");
					fclose(ResultFileDescriptor);
					return 1;
				}

				int i = 0;
				hashtagedGT = 0;
				IsNoHashtagedGT = 0;
				hashtags.clear();
				while (i < length)
				{
					if (strcmp(strtok.token(i).c_str(), "<hashtags>") == 0) {
						hashtagedGT = 1;
						i++;
						while (strcmp(strtok.token(i).c_str(), "</hashtags>") != 0) {
							hashtags.push_back(strtok.token(i));							
							i++;
						}
						i++;						
						continue;
					}				
					
					/*if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
						fprintf_s(ResultFileDescriptor, "%s ", "<msgid>");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</msgid>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "%s\t", "</msgid>");
						i++;
						continue;
					}		

					if (strcmp(strtok.token(i).c_str(), "<text>") == 0) {
						fprintf_s(ResultFileDescriptor, "%s ", "<text>");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</text>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "%s\t", "</text>");
					}*/
					if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
						i++;
						while (strcmp(strtok.token(i).c_str(), "</msgid>") != 0) {
							curMsgid= strtok.token(i).c_str();
							i++;
						}						
						i++;
						continue;
					}
					if (strcmp(strtok.token(i).c_str(), "<text>") == 0) {						
						i++;
						while (strcmp(strtok.token(i).c_str(), "</text>") != 0) {
							for (int j = 0; j < keywordlistSize; j++) {
								if (strcmp(keywords[j].c_str(), strtok.token(i).c_str()) == 0)
								{
									IsNoHashtagedGT = 1;
									break;
								}
							}
							if (IsNoHashtagedGT)
								break;
							i++;
						}						
					}

					i++;
				}

				int IsGT = 0;
				if (hashtagedGT) {
					for(int j=0;j<hashtags.size();j++)					
					{							
						int hashkey = hashString(hashtags[j], HTSize);
						int HTlistSize = GTHashtagHashTable[hashkey].size();
						for (int k = 0; k < HTlistSize; k++) {
							if (hashtags[j] == GTHashtagHashTable[hashkey][k])
								IsGT = 1;
						}
					}	

					if (IsGT) {
						fprintf_s(ResultFileDescriptor, "%s ", "<hashtags>");
						for (int j = 0; j < hashtags.size(); j++)
							fprintf_s(ResultFileDescriptor, "%s ", hashtags[j].c_str());							
						fprintf_s(ResultFileDescriptor, "%s\t", "</hashtags>");
					}
					
					if (IsGT|| IsNoHashtagedGT)
					{
						fprintf_s(ResultFileDescriptor, "<GT>\t 1 \t </GT>");
						TmpGTmsgset.insert(curMsgid);
						fprintf_s(ResultFileDescriptor, "\t%s", line.substr(45, line.length() - 45).c_str());
					}
					/*else
						fprintf_s(ResultFileDescriptor, "<GT>\t 0 \t </GT>");

					fprintf_s(ResultFileDescriptor, "\t%s", line.substr(45, line.length() - 45).c_str());*/
				}
				else {
					if (IsNoHashtagedGT) {
						fprintf_s(ResultFileDescriptor, "<GT>\t 1 \t </GT>");
						TmpGTmsgset.insert(curMsgid);
						fprintf_s(ResultFileDescriptor, "\t%s", line.substr(45, line.length() - 45).c_str());
					}
					/*else 
						fprintf_s(ResultFileDescriptor, "\t<GT>\t\t </GT>");

					fprintf_s(ResultFileDescriptor, "\t%s", line.substr(45, line.length() - 45).c_str());*/
				}
				/*else {
					fprintf_s(ResultFileDescriptor, "\t<GT>\t\t </GT>");
					fprintf_s(ResultFileDescriptor, "\t%s", line.substr(45, line.length() - 45).c_str());
				}*/
			//	fprintf_s(ResultFileDescriptor, "\n");
				hashtags.clear();
				////////////////////////////			
			}
			//output groundtruth message ids
			set<string>::iterator git = TmpGTmsgset.begin();
			while (git != TmpGTmsgset.end()) {
				fprintf_s(ResultFileDescriptor, "%s\n", (*git).c_str());
				cout << (*git).c_str() << endl;
				git++;
			}
			TmpGTmsgset.clear();
			//=================================
			fclose(ResultFileDescriptor);			
		}
		fclose(fileDescriptor);		
	}

	keywords.clear();
	return 0;
}

//======extract keywords
int BulkExtractDataSetKeyWord(char* flistname, char* path) {
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
//	char outFullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	int tpno = 0;
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");
			
			ReadMessageSlots(FullSlotFileName);
			tpno++;
		}
		fclose(fileDescriptor);
	}

	return 0;
}

int ReadMessageSlots(char* FullFileName)
{
	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;	

	int TotalMSG = 0;
	std::vector<KeywordNumPair> msgTexts;
	KeywordNumPair kNPair;
	vector<KeywordNumPair>::iterator knpit;
	//read the words into keywordHashTable[HTSize]
	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else {		
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) document!\n");					
				return 1;
			}

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<text>") == 0) {					
					int j = 0;
					i++;								
					
					while (strcmp(strtok.token(i).c_str(), "</text>") != 0) {
						std::size_t str_hash = std::hash<std::string>()(strtok.token(i).c_str());
						int hashkey = str_hash % HTSize;
						knpit = keywordHashTable[hashkey].begin();
						while (knpit != keywordHashTable[hashkey].end()) {
							if (strcmp((*knpit).keyword.c_str(), strtok.token(i).c_str()) == 0) {
								(*knpit).Knum++;
								break;
							}
							else
								knpit++;
						}
						if (knpit == keywordHashTable[hashkey].end())//not found
						{
							kNPair.Knum = 1;
							kNPair.keyword= strtok.token(i);
							keywordHashTable[hashkey].push_back(kNPair);
						}
						
						i++;
					}						
					i++;
					break;
				}										
				i++;
			}		
			TotalMSG++;
		}
		fclose(fileDescriptor);
	}

	//compute TFIDF of each word in a tweet
	vector<conceptWeightPair> resultKeywordlist;
	vector<conceptWeightPair>::iterator rkit;
	conceptWeightPair resKeyword;
	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else {

		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) document!\n");
				return 1;
			}

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<text>") == 0) {
					int j = 0;
					i++;
					msgTexts.clear();
					while (strcmp(strtok.token(i).c_str(), "</text>") != 0) {
						knpit = msgTexts.begin();
						while (knpit != msgTexts.end()) {
							if (strcmp((*knpit).keyword.c_str(), strtok.token(i).c_str()) == 0) {
								(*knpit).Knum++;
								break;
							}
							knpit++;
						}
						if (knpit == msgTexts.end()) {
							kNPair.Knum = 1;
							kNPair.keyword=strtok.token(i);
							msgTexts.push_back(kNPair);
						}
						i++;
					}
					i++;
					break;
				}
				i++;
			}
			//select top k=3 keywords that have maximal TFIDF values from a tweet 
			float TotalTF = 0;
			for (i = 0; i < msgTexts.size(); i++) {
				TotalTF += msgTexts[i].Knum;
			}
			knpit = msgTexts.begin();
			while (knpit != msgTexts.end()) {
				//compute TFIDF
				//compute TF values first					
				resKeyword.concept= (*knpit).keyword;
				resKeyword.weight = (float)(*knpit).Knum / TotalTF;

				//compute TF/IDF vector
				std::size_t str_hash = std::hash<std::string>()((*knpit).keyword);
				int hashkey = str_hash % HTSize;
				vector<KeywordNumPair>::iterator knpit1 = keywordHashTable[hashkey].begin();
				while (knpit1 != keywordHashTable[hashkey].end()) {
					if (strcmp((*knpit).keyword.c_str(), (*knpit1).keyword.c_str()) == 0) 						
						break;
					else
						knpit1++;
				}
				if (knpit1 != keywordHashTable[hashkey].end()){
					float idfVal = log(TotalMSG / (1.0 + (*knpit1).Knum));
					resKeyword.weight = resKeyword.weight * idfVal;
				}
				rkit = resultKeywordlist.begin();
				int insertFlag = 0;
				while (rkit != resultKeywordlist.end()) {
					if ((*rkit).weight <= resKeyword.weight) {
						resultKeywordlist.insert(rkit, resKeyword);
						insertFlag = 1;
						break;
					}
					rkit++;
				}
				if (!insertFlag) {
					resultKeywordlist.push_back(resKeyword);
				}

				knpit++;
			}
			//output top k keywords
			int k = 3;
			if (resultKeywordlist.size() < k)
				k = resultKeywordlist.size();
			for (i = 0; i < k; i++)
				printf_s("%s\t%.4f\n", resultKeywordlist[i].concept.c_str(), resultKeywordlist[i].weight);
			msgTexts.clear();
			resultKeywordlist.clear();
		}
		fclose(fileDescriptor);
	}
	//clean the keywordHashTable
	for (int i = 0; i < HTSize; i++)
		keywordHashTable[i].clear();

	return 0;
}

void BulkReadYoutubeUserID(char* flistname, int startUserIndexID,char* path)
{
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	int CurUserIndex = 0;
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");

			printf("FullSlotFileName: %s", buffer);
			CurUserIndex=ReadYoutubeUserID(FullSlotFileName, CurUserIndex);
		}
		fclose(fileDescriptor);
	}
}
int ReadYoutubeUserID(char* FullUserNameFile, int startUserIndexID) {
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	YoutubeUserProfile curUserP;

	int UserIndexID = startUserIndexID;

	if ((err = fopen_s(&fileDescriptor, FullUserNameFile, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullUserNameFile);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			int i = 0;
			//curUserP.UserResponseNumbers.clear();
			//curUserP.PostNum = 0;
			curUserP.userId = UserIndexID;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<authorid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</authorid>") != 0)
					{
						curUserP.userOid = strtok.token(i);//;
						//===================================
						//search curUserP.userId from YoutubeUserPHashTable
						int hashkey = compute_hash(curUserP.userOid) % HTSize;
						int flag = 0; //a flag to show if the userId is found in hashtable
						int j = 0;
						for (j = 0; j < YoutubeUserPHashTable[hashkey].size(); j++) {
							if (strcmp(YoutubeUserPHashTable[hashkey][j].userOid.c_str(), curUserP.userOid.c_str()) == 0)//found
							{
								flag = 1;
								break;
							}
						}
						if (!flag)//not found, then insert
						{
							curUserP.userId = UserIndexID;
							YoutubeUserPHashTable[hashkey].push_back(curUserP);
							sortedUPlistForUserid2UserOid.push_back(curUserP);
							UserIndexID++;
						}
						//===================================
						i++;
					}
					i++;
					continue;
				}
				if (strcmp(strtok.token(i).c_str(), "<userlist>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</userlist>") != 0)
					{
						curUserP.userOid = strtok.token(i);// .c_str();
						//===================================
						//search curUserP.userId from YoutubeUserPHashTable
						int hashkey = compute_hash(curUserP.userOid) % HTSize;
						int flag = 0; //a flag to show if the userId is found in hashtable
						int j = 0;
						for (j = 0; j < YoutubeUserPHashTable[hashkey].size(); j++) {
							if (strcmp(YoutubeUserPHashTable[hashkey][j].userOid.c_str(), curUserP.userOid.c_str()) == 0)//found
							{
								flag = 1;
								break;
							}
						}
						if (!flag)//not found, then insert
						{
							curUserP.userId = UserIndexID;
							YoutubeUserPHashTable[hashkey].push_back(curUserP);
							sortedUPlistForUserid2UserOid.push_back(curUserP);
							UserIndexID++;
						}
						//===================================
						i++;
					}
					i++;
					continue;
				}
				i++;
			}			
			////////////////////////////			
		}
		fclose(fileDescriptor);
	}
	return UserIndexID;
}

//=============can be used for mainusers and also comment users===========
int ReadCommentUserIDandLocation(char* FullUserNameFile, int startUserIndexID) {
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	UserProfile curUserP;

	int UserIndexID = startUserIndexID;

	if ((err = fopen_s(&fileDescriptor, FullUserNameFile, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullUserNameFile);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			int i = 0;
			curUserP.UserResponseNumbers.clear();
			curUserP.PostNum = 0;
			curUserP.userId = UserIndexID;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<userid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</userid>") != 0)
					{
						curUserP.userOid = atoll(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}
				if (strcmp(strtok.token(i).c_str(), "<coordinates>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</coordinates>") != 0) {
						curUserP.UserPhysicalLocation.lat = atof(strtok.token(i).c_str());
						i++;
						curUserP.UserPhysicalLocation.longi = atof(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}
				i++;
			}
			if (length > 0) {
				//search curUserP.userId from UserPHashTable
				int hashkey = curUserP.userOid % HTSize;
				int flag = 0; //a flag to show if the userId is found in hashtable
				int j = 0;
				for (j = 0; j < UserPHashTable[hashkey].size(); j++) {
					if (UserPHashTable[hashkey][j].userOid == curUserP.userOid)//found
					{
						flag = 1;
						break;
					}
				}
				if (!flag)//not found, then insert
				{
					UserPHashTable[hashkey].push_back(curUserP);
					UserIndexID++;
				}
			}
			////////////////////////////			
		}
		fclose(fileDescriptor);
	}
	return UserIndexID;
}


int BulkReadUserIDandLocation(char* UserNameFile, char* path, int startUserIndexID) {
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	int CurUserIndex = startUserIndexID;
	string line;
	if ((err = fopen_s(&fileDescriptor, UserNameFile, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", UserNameFile);
	}
	else {
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");

			CurUserIndex=ReadCommentUserIDandLocation(FullSlotFileName, CurUserIndex);
		}
		fclose(fileDescriptor);
	}
	return CurUserIndex;
}

//count postnum in the whole training set, here flistname contains the files of tweets
void BulkCountMainUserPostNum(char* flistname, char* path) 
{
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	int CurUserIndex = 0;
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");

			CountMainUserPostNum(FullSlotFileName);
		}
		fclose(fileDescriptor);
	}
}
//count postnum in a time slot
void CountMainUserPostNum(char* FullFileName) 
{
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	
	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else 
	{		
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<userid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</userid>") != 0) 
					{
						long long int uid=atoll(strtok.token(i).c_str());
						int hashkey = uid % HTSize;
						int j = 0;
						for (j = 0; j < UserPHashTable[hashkey].size(); j++) 
						{
							if (UserPHashTable[hashkey][j].userOid == uid)//found
							{
								UserPHashTable[hashkey][j].PostNum++;
								break;
							}
						}
						i++;
					}
					i++;
					continue;
				}
				i++;
			}
		}
		
		fclose(fileDescriptor);
	}
}
//initialize the interaction //insert user herself into the interaction
void InitializeInteraction() {
	UPRespnseEle curUPRele;
	int i, j;
	for (i = 0; i < HTSize; i++) 
	{
		int sizeh = UserPHashTable[i].size();		
		for (j = 0; j < sizeh; j++) 
		{
			curUPRele.userid = UserPHashTable[i][j].userId;
			curUPRele.userOid = UserPHashTable[i][j].userOid;
			if (UserPHashTable[i][j].PostNum == 0)
				UserPHashTable[i][j].PostNum = 1;

			curUPRele.userResponse = UserPHashTable[i][j].PostNum;

			UserPHashTable[i][j].UserResponseNumbers.push_back(curUPRele);
		}
	}	
}
void InitializeInteractionSlot() {
	UPRespnseEle curUPRele;
	int i, j;
	for (i = 0; i < HTSize; i++)
	{
		int sizeh = UserPHashTable[i].size();
		for (j = 0; j < sizeh; j++)
		{
			curUPRele.userid = UserPHashTable[i][j].userId;
			curUPRele.userOid = UserPHashTable[i][j].userOid;
			if (UserPHashTable[i][j].PostNum > 0) {
				curUPRele.userResponse = UserPHashTable[i][j].PostNum;
				UserPHashTable[i][j].UserResponseNumbers.push_back(curUPRele);
			}
		}
	}
}
//count UserResponseNumbers in the whole time period of training set, here flistname contains the interactions crawled from user history over twitter
void BulkReadInteractionFile(char* flistname, char* path) 
{
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	int CurUserIndex = 0;
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");

			printf("InteractionSlotFileName: %s",buffer);
			ReadInteractionFile(FullSlotFileName);
		}
		fclose(fileDescriptor);
	}	
}
//count UserResponseNumbers in a time slot of training set
void ReadInteractionFile(char* FullFileName) 
{
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	UPRespnseEle curUPRele;
	int count = 0;	

	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else
	{
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

		/*	if(count==8)
				printf("%d\t", count);
				count++;
				if (count % 20 == 0)
					printf("\n");
			*/

			int i = 0;
			long long int mainOUid, uOid;
			int mainUid, uid;
			int hashkey;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<mainuserid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</mainuserid>") != 0)
					{
						mainOUid = atoll(strtok.token(i).c_str());
						//===search mainUid=========
						hashkey = mainOUid % HTSize;
						int j = 0;
						for (j = 0; j < UserPHashTable[hashkey].size(); j++)
						{
							if (UserPHashTable[hashkey][j].userOid == mainOUid)//found
							{
								mainUid = UserPHashTable[hashkey][j].userId;
								break;
							}
						}
						if (j == UserPHashTable[hashkey].size())
							printf("mainuserid: %lld\n", mainOUid);
						/////////////
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<timestamp_ms>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</timestamp_ms>") != 0)
					{						
						i++;
					}
					i++;
					continue;
				}
				
				if (strcmp(strtok.token(i).c_str(), "<userid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</userid>") != 0)
					{
						uOid = atoll(strtok.token(i).c_str());
						//===search uid=========
						hashkey = uOid % HTSize;
						int j = 0;

						uid = -1;
						for (j = 0; j < UserPHashTable[hashkey].size(); j++)
						{
							if (UserPHashTable[hashkey][j].userOid == uOid)//found
							{
								uid = UserPHashTable[hashkey][j].userId;
								break;
							}
						}
						if (j == UserPHashTable[hashkey].size()) //not found, output this userOid
							printf("uOid %lld\n",uOid);
						/////////////
						i++;
					}
					i++;
					continue;
				}
				i++;
			}

			
			if (length > 0&&uid>=0) {
				hashkey = mainOUid % HTSize;
				int j = 0;
				for (j = 0; j < UserPHashTable[hashkey].size(); j++)
				{
					if (UserPHashTable[hashkey][j].userOid == mainOUid)//found
					{
						//check the interaction list of UserPHashTable[hashkey][j]
						int insertFlag = 0;
						vector<UPRespnseEle>::iterator uit = UserPHashTable[hashkey][j].UserResponseNumbers.begin();
						while (uit != UserPHashTable[hashkey][j].UserResponseNumbers.end()) 
						{
							if ((*uit).userid == uid) {
								(*uit).userResponse++;
								insertFlag = 1;
								break;
							}
							else if ((*uit).userid > uid)
							{
								curUPRele.userid = uid;
								curUPRele.userOid = uOid;
								curUPRele.userResponse = 1;
								UserPHashTable[hashkey][j].UserResponseNumbers.insert(uit, curUPRele);
								insertFlag = 1;
								break;
							}
							uit++;
						}
						if (!insertFlag) {//not found, insert 
							curUPRele.userid = uid;
							curUPRele.userOid = uOid;
							curUPRele.userResponse = 1;
							UserPHashTable[hashkey][j].UserResponseNumbers.push_back(curUPRele);
						}
						break;
					}
				}
			}
		}
		fclose(fileDescriptor);
	}
}

void YoutubeUserProfile2File(char* resultfile) 
{
	/*vector<YoutubeUserProfile> sortedUPlist;	
	//sorting
	for (int i = 0; i < HTSize; i++) {
		for (int j = 0; j < YoutubeUserPHashTable[i].size(); j++)
		{
			int startp = 0;
			int endp = sortedUPlist.size();
			int midP = (startp + endp) / 2;
			int premidP = midP;
			if (sortedUPlist.size() == 0) {
				sortedUPlist.push_back(YoutubeUserPHashTable[i][j]);
				continue;
			}
			else if (sortedUPlist[sortedUPlist.size() - 1].userId < YoutubeUserPHashTable[i][j].userId) {
				sortedUPlist.push_back(YoutubeUserPHashTable[i][j]);
				continue;
			}
			else {
				int loop = 1;
				while (loop) 
				{
					if (YoutubeUserPHashTable[i][j].userId > sortedUPlist[midP].userId) {
						startp = midP;
						premidP = midP;
						midP = (startp + endp) / 2;
						if (midP == premidP) {
							loop = 0;
							break;
						}
					}
					else if (YoutubeUserPHashTable[i][j].userId < sortedUPlist[midP].userId) {
						endp = midP;
						premidP = midP;
						midP = (startp + endp) / 2;
						if (midP == premidP) {
							loop = 0;
							break;
						}
					}
					else if (YoutubeUserPHashTable[i][j].userId == sortedUPlist[midP].userId) {
						loop = 0;
						break;
					}
				}
				if (sortedUPlist[midP].userId < YoutubeUserPHashTable[i][j].userId) {
					int len = sortedUPlist.size();
					for (int k = midP; k < len; k++) {
						if (sortedUPlist[k].userId > YoutubeUserPHashTable[i][j].userId) {
							sortedUPlist.insert(sortedUPlist.begin() + k, YoutubeUserPHashTable[i][j]);
							break;
						}
					}
					
				}
				else if (sortedUPlist[midP].userId > YoutubeUserPHashTable[i][j].userId) {	
					if (midP == 0) {
						sortedUPlist.insert(sortedUPlist.begin(), YoutubeUserPHashTable[i][j]);
					}
					else
					{
						for (int k = midP; k > 0; k--) {
							if (sortedUPlist[k].userId < YoutubeUserPHashTable[i][j].userId) {
								sortedUPlist.insert(sortedUPlist.begin() + k + 1, YoutubeUserPHashTable[i][j]);
								break;
							}
						}
					}
				}
			}
			cout << sortedUPlist.size() << endl;
		}		
	}

	for (int i = 0; i < HTSize; i++) {
		YoutubeUserPHashTable[i].clear();
	}
	YoutubeUserPHashTable->clear();*/
	//===========

	FILE* fileDescriptor = NULL;
	errno_t err;

	if ((err = fopen_s(&fileDescriptor, resultfile, "a+")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", resultfile);
	}
	else {
		int i = 0;
		int userDictSize = sortedUPlistForUserid2UserOid.size();
		for (i = 0; i < userDictSize; i++) {
			fprintf_s(fileDescriptor, "<userid> %d </userid>\t", sortedUPlistForUserid2UserOid[i].userId);
			fprintf_s(fileDescriptor, "<userOid> %s </userOid>\n", sortedUPlistForUserid2UserOid[i].userOid.c_str());
		}		
		fclose(fileDescriptor);
	}
	
	sortedUPlistForUserid2UserOid.clear();
}

void UserProfile2File(char* resultfile) {
	//output userprofile interaction file UserPHashTable 
	//char resultFile[MSGLEN];
	//strcpy_s(resultFile, "userProfile_Napeltest.txt");
	FILE* fileDescriptor = NULL;
	errno_t err;

	if ((err = fopen_s(&fileDescriptor, resultfile, "a+")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", resultfile);
	}
	else {
		vector<UserProfile>::iterator uit;
		int i = 0;
		int userDictSize = 0;
		for (i = 0; i < HTSize; i++) {
			userDictSize += UserPHashTable[i].size();
		}
		
		int outputNum = 0;
		int j;
		while (outputNum < userDictSize) {
			for (i = 0; i < HTSize; i++) {
				for (j = 0; j < UserPHashTable[i].size(); j++)
				{
					if (UserPHashTable[i][j].userId == outputNum) {
						if (UserPHashTable[i][j].PostNum > 0) {
							//output UserPHashTable[i][j]
							fprintf_s(fileDescriptor, "<userid> %d </userid>\t", UserPHashTable[i][j].userId);
							fprintf_s(fileDescriptor, "<userOid> %lld </userOid>\n", UserPHashTable[i][j].userOid);
							fprintf_s(fileDescriptor, "<location> %.6f %.6f </location>\n",
								UserPHashTable[i][j].UserPhysicalLocation.lat, UserPHashTable[i][j].UserPhysicalLocation.longi);
							fprintf_s(fileDescriptor, "<MSGNUM> %d </MSGNUM>\n", UserPHashTable[i][j].PostNum);

							std::vector<UPRespnseEle>::iterator reit = UserPHashTable[i][j].UserResponseNumbers.begin();
							fprintf_s(fileDescriptor, "<RESPONSENUMBERS> ", (*reit).userid, (*reit).userResponse);

							while (reit != UserPHashTable[i][j].UserResponseNumbers.end()) {
								fprintf_s(fileDescriptor, "%d %d \t", (*reit).userid, (*reit).userResponse);
								reit++;
							}
							fprintf_s(fileDescriptor, "</RESPONSENUMBERS>\n");
						}
						outputNum++;
						break;
					}
				}
				if (j < UserPHashTable[i].size())
					break;
			}			
		}
		fclose(fileDescriptor);
	}

	for (int i = 0; i < HTSize; i++) {
		for (int j = 0; j < UserPHashTable[i].size(); j++)
		{
			UserPHashTable[i][j].UserResponseNumbers.clear();
		}
		UserPHashTable[i].clear();
	}
	UserPHashTable->clear();
}

void SlotUserProfile2File(char* resultfile) {
	//output userprofile interaction file UserPHashTable 
	//char resultFile[MSGLEN];
	//strcpy_s(resultFile, "userProfile_Napeltest.txt");
	FILE* fileDescriptor = NULL;
	errno_t err;

	if ((err = fopen_s(&fileDescriptor, resultfile, "a+")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", resultfile);
	}
	else {
		vector<UserProfile>::iterator uit,eraseit;
		int i = 0;
		int userDictSize = 0;
		for (i = 0; i < HTSize; i++) 
		{					
			if (UserPHashTable[i].size() > 1) 
			{
				uit = UserPHashTable[i].begin() + UserPHashTable[i].size()-1;
				while (uit != UserPHashTable[i].begin()) {
					if ((*uit).PostNum == 0)
					{
						eraseit = uit;
						uit--;
						UserPHashTable[i].erase(eraseit);
					}
					else
						uit--;
				}
			}
			
			if (UserPHashTable[i].size() > 0)
			{
				uit = UserPHashTable[i].begin();
				if ((*uit).PostNum == 0)
					UserPHashTable[i].erase(uit);
			}
		}

		for (i = 0; i < HTSize; i++)
			userDictSize += UserPHashTable[i].size();

		int outputNum = 0;
		while (outputNum < userDictSize) 
		{
			int minUidP = -1;
			for (i = 0; i < HTSize; i++) {
				if (UserPHashTable[i].size()>0)
				{			
					if (minUidP >= 0) {
						if (UserPHashTable[i][0].userId < UserPHashTable[minUidP][0].userId)
							minUidP = i;
					}
					else
						minUidP = i;
				}
			}

			if (minUidP == -1)
				break;
			//output UserPHashTable[i][j]
			fprintf_s(fileDescriptor, "<userid> %d </userid>\t", UserPHashTable[minUidP][0].userId);
			fprintf_s(fileDescriptor, "<userOid> %lld </userOid>\n", UserPHashTable[minUidP][0].userOid);
			fprintf_s(fileDescriptor, "<location> %.6f %.6f </location>\n",
				UserPHashTable[minUidP][0].UserPhysicalLocation.lat, UserPHashTable[minUidP][0].UserPhysicalLocation.longi);
			fprintf_s(fileDescriptor, "<MSGNUM> %d </MSGNUM>\n", UserPHashTable[minUidP][0].PostNum);

			std::vector<UPRespnseEle>::iterator reit = UserPHashTable[minUidP][0].UserResponseNumbers.begin();
			fprintf_s(fileDescriptor, "<RESPONSENUMBERS> ", (*reit).userid, (*reit).userResponse);

			while (reit != UserPHashTable[minUidP][0].UserResponseNumbers.end()) {
				fprintf_s(fileDescriptor, "%d %d \t", (*reit).userid, (*reit).userResponse);
				reit++;
			}
			fprintf_s(fileDescriptor, "</RESPONSENUMBERS>\n");

			//remove this element
			eraseit = UserPHashTable[minUidP].begin();
			(*eraseit).UserResponseNumbers.clear();
			UserPHashTable[minUidP].erase(eraseit);
			outputNum++;
		}
		fclose(fileDescriptor);
	}

	for (int i = 0; i < HTSize; i++) {
		for (int j = 0; j < UserPHashTable[i].size(); j++)
		{
			UserPHashTable[i][j].UserResponseNumbers.clear();
		}
		UserPHashTable[i].clear();
	}
	UserPHashTable->clear();
}
/////////////////////////
void GenerateUserProfile(char * FullFileName) {
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;	

	UserProfile curUserP;
	UPRespnseEle UResE;
	
	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else {		
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
				
			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<userid>") == 0) {
					i++;	
					curUserP.userId = atoi(strtok.token(i).c_str());
					i++;
					curUserP.UserPhysicalLocation.lat = atoi(strtok.token(i).c_str());
					i++;
					curUserP.UserPhysicalLocation.longi = atoi(strtok.token(i).c_str());


					curUserP.UserResponseNumbers.clear();

					//search curUserP.userId from UserPHashTable
					int hashkey = curUserP.userId % HTSize;
					int flag = 0; //a flag to show if the userId is found in hashtable
					int j=0;
					for (j = 0; j < UserPHashTable[hashkey].size(); j++) {
						if (UserPHashTable[hashkey][j].userId == curUserP.userId)//found
						{							
							flag = 1;
							break;
						}
					}
					i++;
					while (strcmp(strtok.token(i).c_str(), "</userid>") != 0) {
						UResE.userid = atoi(strtok.token(i).c_str());
						UResE.userResponse = 1;
						i++;
						i++;
												
						if (!flag)	{
							curUserP.UserResponseNumbers.push_back(UResE);
						}
						else {
							int k = 0;
							for (k = 0; k < UserPHashTable[hashkey][j].UserResponseNumbers.size(); k++) {
								if (UserPHashTable[hashkey][j].UserResponseNumbers[k].userid == curUserP.userId)  //found
									UserPHashTable[hashkey][j].UserResponseNumbers[k].userResponse++;
							}
							if (k == UserPHashTable[hashkey][j].UserResponseNumbers.size())//not found
							{
								std::vector<UPRespnseEle>::iterator upit = UserPHashTable[hashkey][j].UserResponseNumbers.begin();
								while (upit != UserPHashTable[hashkey][j].UserResponseNumbers.end()) {
									if ((*upit).userid < UResE.userid)
										upit++;
									else{
										UserPHashTable[hashkey][j].UserResponseNumbers.insert(upit, UResE);
										break;
									}
								}
								if(upit== UserPHashTable[hashkey][j].UserResponseNumbers.end())  
									UserPHashTable[hashkey][j].UserResponseNumbers.push_back(UResE);
							}
						}
						i++;
					}				
				}
				i++;
			}
			////////////////////////////			
		}
		fclose(fileDescriptor);
	}	
}
void BulkGenerateUserProfiles(char* flistname,char *path) {
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	int CurUserIndex = 0;
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");

			InitializeUserProfiles(FullSlotFileName);					
		}
		fclose(fileDescriptor);
	}

	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");

			GenerateUserProfile(FullSlotFileName);			
		}
		fclose(fileDescriptor);
	}

	//output userprofile interaction file UserPHashTable 
	char resultFile[MSGLEN]; 
	strcpy_s(resultFile,"userProfile_Napeltest.txt");
	if ((err = fopen_s(&fileDescriptor, resultFile, "a+")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", resultFile);
	}
	else {
		std::vector<UserProfile>::iterator uit;
		int i = 0;
		int userDictSize = 0;
		for (i = 0; i < HTSize; i++) {
			userDictSize += UserPHashTable[i].size();
		}
		int col = 0;
		int outputNum = 0;
		while (outputNum < userDictSize) {
			for (i = 0; i < HTSize; i++) {
				if (outputNum < userDictSize) {
					//output UserPHashTable[i][col]
					fprintf_s(fileDescriptor, "<userid> %d </userid>\n", UserPHashTable[i][col].userId);
					fprintf_s(fileDescriptor, "<location> %.6f %.6f </location>\n",
						UserPHashTable[i][col].UserPhysicalLocation.lat, UserPHashTable[i][col].UserPhysicalLocation.longi);
					fprintf_s(fileDescriptor, "<MSGNUM> %d </MSGNUM>\n", UserPHashTable[i][col].PostNum);

					std::vector<UPRespnseEle>::iterator reit = UserPHashTable[i][col].UserResponseNumbers.begin();
					while (reit != UserPHashTable[i][col].UserResponseNumbers.end()) {
						fprintf_s(fileDescriptor, "<RESPONSENUMBERS> %d %d \t", (*reit).userid, (*reit).userResponse);
						reit++;
					}
					fprintf_s(fileDescriptor, "</RESPONSENUMBERS>\n");
				}
				else
					break;
				outputNum++;				
			}
			col++;
		}
		fclose(fileDescriptor);
	}
}

void InitializeUserProfiles(char* FullFileName) {  //keep user profiles into UserPHashTable with userid and location only
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	UserProfile curUserP;
	UPRespnseEle UResE;

	if ((err = fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<userid>") == 0) {
					i++;
					curUserP.userId = atoi(strtok.token(i).c_str());
					i++;
					curUserP.UserPhysicalLocation.lat = atoi(strtok.token(i).c_str());
					i++;
					curUserP.UserPhysicalLocation.longi = atoi(strtok.token(i).c_str());
					curUserP.PostNum = 1;
					
					curUserP.UserResponseNumbers.clear();
					UResE.userid = curUserP.userId;
					UResE.userResponse = 1;
					curUserP.UserResponseNumbers.push_back(UResE);

					//search curUserP.userId from UserPHashTable
					int hashkey = curUserP.userId % HTSize;
					std::vector<UserProfile>::iterator uit = UserPHashTable[hashkey].begin();
					while (uit != UserPHashTable[hashkey].end()) {
						if ((*uit).userId < curUserP.userId)
							uit++;
						else if ((*uit).userId == curUserP.userId) 
							break;
						else{ 
							UserPHashTable[hashkey].insert(uit, curUserP);
							break;
						}
					}
															
					i++;
					while (strcmp(strtok.token(i).c_str(), "</userid>") != 0) {
						curUserP.userId = atoi(strtok.token(i).c_str());
						i++;
						curUserP.UserPhysicalLocation.lat = atoi(strtok.token(i).c_str());
						i++;
						curUserP.UserPhysicalLocation.longi = atoi(strtok.token(i).c_str());
						curUserP.PostNum = 1;

						curUserP.UserResponseNumbers.clear();
						UResE.userid = curUserP.userId;
						UResE.userResponse = 1;
						curUserP.UserResponseNumbers.push_back(UResE);
						//search curUserP.userId from UserPHashTable
						hashkey = curUserP.userId % HTSize;
						uit = UserPHashTable[hashkey].begin();
						while (uit != UserPHashTable[hashkey].end()) {
							if ((*uit).userId < curUserP.userId)
								uit++;
							else if ((*uit).userId == curUserP.userId)
								break;
							else {
								UserPHashTable[hashkey].insert(uit, curUserP);
								break;
							}
						}
						i++;
					}	
					curUserP.UserResponseNumbers.clear();
				}
				i++;
			}			
		}
		fclose(fileDescriptor);
	}
}
/////////////////////////
int SetUserIndex(char* fname, int maxUid) {
	int ret = maxUid;
	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	int retweetstatus = 0;

	UserIndexPair uiPair;

	if ((err = fopen_s(&fileDescriptor, fname, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", fname);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) document!\n");
				fclose(ResultFileDescriptor);
				return 1;
			}

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<userid>") == 0) {					
					i++;
					while (strcmp(strtok.token(i).c_str(), "</userid>") != 0) {
						int uindex = GetUserIndex(atoi(strtok.token(i).c_str()));
						if (uindex == -1)  //not in UserIndexHashTable, then insert it
						{
							uiPair.userid = atoi(strtok.token(i).c_str());
							uiPair.userIndex=ret;
							int hashkey = uiPair.userid % HTSize;
							UserIndexHashTable[hashkey].push_back(uiPair);
							ret++;
						}							
						i++;
					}					
					i++;
					continue;
				}
				i++;
			}
		}
		fclose(fileDescriptor);
	}
	return ret;
}
int BulkSetUserIndex(char* flistname, char* path){	
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	int CurUserIndex = 0;
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");

			CurUserIndex = SetUserIndex(FullSlotFileName, CurUserIndex);
		}
		fclose(fileDescriptor);
	}

	char UserIndexFile[MSGLEN];
	strcpy_s(UserIndexFile, "UserIDindexDict.txt");
	if ((err = fopen_s(&fileDescriptor, UserIndexFile, "a+")) != 0)
		printf("cannot open %s\n", UserIndexFile);
	else {
		fprintf(fileDescriptor, "<TotalUserNum>  %d </TotalUserNum>\t", CurUserIndex);
		for (int i = 0; i < HTSize; i++) {
			std::vector<UserIndexPair>::iterator uipit = UserIndexHashTable[i].begin();
			fprintf(fileDescriptor, "<hashkey>  %d </hashkey>\t", i);
			
			fprintf(fileDescriptor, "<uidIndexP> ");
			while (uipit != UserIndexHashTable[i].end()) {
				fprintf(fileDescriptor, "%d %d \t", (*uipit).userid, (*uipit).userIndex);
				uipit++;
			}
			fprintf(fileDescriptor, "</uidIndexP>\n");
		}
		fclose(fileDescriptor);
	}
	return CurUserIndex;
}
//code the message ids into 1, 2...
int BulkSetMSGNoIndex(char* flistname, char* path) {
	int ret = 0;
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	int CurMsgno = 0;
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");
			
			CurMsgno=SetMSGNoIndex(FullSlotFileName, CurMsgno);			
		}
		fclose(fileDescriptor);
	}

	return ret;
}

int SetMSGNoIndex(char* fname, int CurMsgno) {
	int ret = CurMsgno;
/*	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	int retweetstatus = 0;

	std::vector<string> msgTexts;
	std::vector<float> msgVec;
	std::vector<float>::iterator mvit;

	if ((err = fopen_s(&fileDescriptor, FullSlotFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else {	
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) document!\n");
				fclose(ResultFileDescriptor);
				return 1;
			}

			int i = 0;
			while (i < length)
			{					
				if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
					fprintf_s(ResultFileDescriptor, "%s ", "<msgid>");
					i++;
					while (strcmp(strtok.token(i).c_str(), "</msgid>") != 0) {
						int msgno = GetMSGNoIndex(atoi(strtok.token(i).c_str()));
						fprintf_s(ResultFileDescriptor, "%d ", msgno);
						i++;
					}
					fprintf_s(ResultFileDescriptor, "%s\t", "</msgid>");
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<rtmsgid>") == 0) {
					i++;
					fprintf_s(ResultFileDescriptor, "%s ", "<rtmsgid>");
					while (strcmp(strtok.token(i).c_str(), "</rtmsgid>") != 0) {
						fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
						i++;
					}
					fprintf_s(ResultFileDescriptor, "%s\t", "</rtmsgid>");
					i++;
					continue;
				}
					
				i++;
			}				
		}
		fclose(fileDescriptor);
	}*/

	return ret;
}

//read the dimensions of each time slot into DimensionDict
int ReadDimensionDict(char *DimDict){
	int ret = 0;

	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	
	int tpno = 0;
	int dimNum = 0;

	if ((err = fopen_s(&fileDescriptor, DimDict, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", DimDict);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) document!\n");
			}

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<tpno>") == 0) {
					i++;
					tpno = atoi(strtok.token(i).c_str());

					i++;
					while (strcmp(strtok.token(i).c_str(), "</tpno>") != 0)
						i++;

					i++;
					continue;
				}
				if (strcmp(strtok.token(i).c_str(), "<dimNum>") == 0) {
					i++;
					dimNum = atoi(strtok.token(i).c_str());
					i++;
					while (strcmp(strtok.token(i).c_str(), "</dimNum>") != 0)
						i++;

					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<DimNo>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</DimNo>") != 0)
					{
						DimensionDict.resize(tpno + 1);
						DimensionDict[tpno].push_back(atoi(strtok.token(i).c_str()));
						i++;
					}
					i++;
					continue;
				}
				i++;
			}
		}
		fclose(fileDescriptor);
	}
	return ret;
}

int ReadGramDocNumHashTable(char* TrainingSetGramMSGNoFname) {
	int ret=0;
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	
	int hashkey = 0;
	FourGramMSGNumPair FourGramMsgnumP;

	if ((err = fopen_s(&fileDescriptor, TrainingSetGramMSGNoFname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", TrainingSetGramMSGNoFname);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) document!\n");
			}

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<TotalmsgNum>") == 0) {
					i++;
					TRAIN_MSG = atoi(strtok.token(i).c_str());
					i++;
					while (strcmp(strtok.token(i).c_str(), "</TotalmsgNum>") != 0)
						i++;

					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<hashkey>") == 0) {
					i++;
					hashkey = atoi(strtok.token(i).c_str());
					i++;
					while (strcmp(strtok.token(i).c_str(), "</hashkey>") != 0)
						i++;

					i++;
					continue;
				}
				
				if (strcmp(strtok.token(i).c_str(), "<GramMSGnum>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</GramMSGnum>") != 0)
					{
						FourGramMsgnumP.Gram = strtok.token(i).c_str();
						i++;
						FourGramMsgnumP.GramVal = atoi(strtok.token(i).c_str());
						i++;
						FourGramMsgnumP.MSGNum = atoi(strtok.token(i).c_str());

						GramDocNumHashTable[hashkey].push_back(FourGramMsgnumP);
						i++;
					}
					i++;
					continue;
				}
				i++;
			}
		}
		fclose(fileDescriptor);
	}
	return ret;
}

int ProcessMessageSlotAddUsers(char* FullSlotFileName, char * FullSlotFileUsers, char* outFullSlotFileName)
{
	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	int retweetstatus = 0;

	std::vector<msgUserUlist> msgUList;
	msgUserUlist curMsgUsers;

	//read FullSlotFileUsers
	if ((err = fopen_s(&fileDescriptor, FullSlotFileUsers, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else {		
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) document!\n");
				fclose(ResultFileDescriptor);
				return 1;
			}

			curMsgUsers.msgid = -1;
			curMsgUsers.userId = -1;
			curMsgUsers.userIdlist.clear();

			int i = 0;
			while (i < length)
			{					
				if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</msgid>") != 0) {
						curMsgUsers.msgid = strtok.token(i);
						i++;
					}
					i++;
					continue;
				}					
															
				if (strcmp(strtok.token(i).c_str(), "<userid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</userid>") != 0) {
						int userIndex = GetUserIndex(atoll(strtok.token(i).c_str()));
						curMsgUsers.userId = userIndex;

						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<useridlist>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</useridlist>") != 0) {
						int userIndex = GetUserIndex(atoll(strtok.token(i).c_str()));
						curMsgUsers.userIdlist.push_back(userIndex);
						i++;
					}
					i++;
					continue;
				}

				i++;
			}
			msgUList.push_back(curMsgUsers);					
		}
		fclose(fileDescriptor);
	}
	///====================

	int msgIndex=0;
	if ((err = fopen_s(&fileDescriptor, FullSlotFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else {
		if ((err = fopen_s(&ResultFileDescriptor, outFullSlotFileName, "a+")) != 0)
		{
			printf("ResultFileDescriptor was not open\n");
		}
		else
		{
			while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
				line = buffer;
				strtokenizer strtok(line, " \t\r\n");
				int length = strtok.count_tokens();

				if (length <= 0) {
					printf("Invalid (empty) document!\n");
					fclose(ResultFileDescriptor);
					return 1;
				}

				int i = 0;
				while (i < length)
				{
					if (strcmp(strtok.token(i).c_str(), "<hashtags>") == 0) {
						fprintf_s(ResultFileDescriptor, "%s ", "<hashtags>");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</hashtags>") != 0) {
							//output hashtag
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						i++;
						fprintf_s(ResultFileDescriptor, "%s\t", "</hashtags>");
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<msgcontfidf>") == 0) {
						fprintf_s(ResultFileDescriptor, "%s ", "<msgcontfidf>");
						int j = 0;
						i++;
						
						while (strcmp(strtok.token(i).c_str(), "</msgcontfidf>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
							fprintf_s(ResultFileDescriptor, "%s\t", strtok.token(i).c_str());
							i++;
						}

						fprintf_s(ResultFileDescriptor, "%s\t", "</msgcontfidf>");
						
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
						fprintf_s(ResultFileDescriptor, "%s ", "<msgid>");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</msgid>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "%s\t", "</msgid>");
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<rtmsgid>") == 0) {
						i++;
						fprintf_s(ResultFileDescriptor, "%s ", "<rtmsgid>");
						while (strcmp(strtok.token(i).c_str(), "</rtmsgid>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "%s\t", "</rtmsgid>");
						i++;
						continue;
					}
					if (strcmp(strtok.token(i).c_str(), "<coordinates>") == 0) {
						i++;
						int j = 0;
						fprintf_s(ResultFileDescriptor, "%s ", "<coordinates>");
						while (strcmp(strtok.token(i).c_str(), "</coordinates>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}

						fprintf_s(ResultFileDescriptor, "%s\t", "</coordinates>");
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<timestamp_ms>") == 0) {
						i++;
						fprintf_s(ResultFileDescriptor, "%s ", "<timestamp_ms>");
						while (strcmp(strtok.token(i).c_str(), "</timestamp_ms>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						i++;
						fprintf_s(ResultFileDescriptor, "%s\t", "</timestamp_ms>");
						continue;
					}					
					i++;
				}

				if (length > 0)
				{
					fprintf_s(ResultFileDescriptor, "%s ", "<userid>");
					fprintf_s(ResultFileDescriptor, "%d ", msgUList[msgIndex].userId);
					fprintf_s(ResultFileDescriptor, "%s\t", "</userid>");

					fprintf_s(ResultFileDescriptor, "%s ", "<useridlist>");
					for (int j = 0; j < msgUList[msgIndex].userIdlist.size(); j++) {
						if(msgUList[msgIndex].userIdlist[j]>=0)
							fprintf_s(ResultFileDescriptor, "%d ", msgUList[msgIndex].userIdlist[j]);
					}
					//fprintf_s(ResultFileDescriptor, "%d ", msgUList[msgIndex].userId);
					fprintf_s(ResultFileDescriptor, "%s\t", "</useridlist>");
					msgIndex++;
				}

				fprintf_s(ResultFileDescriptor, "\n");
				////////////////////////////			
			}
			fclose(ResultFileDescriptor);
		}
		fclose(fileDescriptor);

		for (int i = 0; i < msgUList.size(); i++)
			msgUList[i].userIdlist.clear();
		msgUList.clear();
		curMsgUsers.userIdlist.clear();
	}

	
	return 0;
}
int BulkProcessEventSlotMsgComments(char* flistname, char* path, char* outpath) {
	int ret = 0;
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char outFullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	char FullSlotFileUsers[MSGLEN];

	int tpno = 0;
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		int count = 0;
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			count++;
			if (count % 2 > 0)
				continue;
			printf("%s", buffer);

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".UPdata");
			//strcat_s(FullSlotFileName, ".dat");

			strcpy_s(outFullSlotFileName, outpath);
			strcat_s(outFullSlotFileName, strtok.token(0).c_str());
			strcat_s(outFullSlotFileName, ".UPTensor");
			ProcessUserProfileEventsMsgComments(FullSlotFileName, outFullSlotFileName, tpno);

			tpno++;
		}
		fclose(fileDescriptor);
	}
	return ret;
}
int ProcessUserProfileEventsMsgComments(char* UEventfname, char* outFullSlotFileName, int StartClusterNo) {
	int ret = 0;

	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;

	char buffer[BUFFERSIZE];
	float vec[TFIDF_DIM];
	std::vector<string> msgTexts;
	std::vector<msgGramFrequencyEle> msgGramFre;

	string line;
	int eid = 0;
	if ((fopen_s(&fileDescriptor, UEventfname, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", UEventfname);
	}
	else
	{
		if ((fopen_s(&ResultFileDescriptor, outFullSlotFileName, "a+")) != 0)
		{
			printf("ResultFileDescriptor was not open\n");
		}
		else
		{
			while (fgets(buffer, BUFFERSIZE, fileDescriptor))
			{
				line = buffer;
				strtokenizer strtok(line, " \t\r\n");
				int length = strtok.count_tokens();

				if (length <= 0) {
					printf("Invalid (empty) line!\n");
					return 1;
				}

				int i = 0;

				while (i < length)
				{
					if (strcmp(strtok.token(i).c_str(), "<clusterOid>") == 0) {

						fprintf_s(ResultFileDescriptor, "<clusterOid>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</clusterOid>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</clusterOid>\n");
						i++;
						continue;
					}
					if (strcmp(strtok.token(i).c_str(), "<clusterMsgIds>") == 0) {

						fprintf_s(ResultFileDescriptor, "<clusterMsgIds>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</clusterMsgIds>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</clusterMsgIds>\n");
						i++;
						continue;
					}
					if (strcmp(strtok.token(i).c_str(), "<HashkeyValues>") == 0) {

						fprintf_s(ResultFileDescriptor, "<HashkeyValues>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</HashkeyValues>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</HashkeyValues>\n");
						i++;
						continue;
					}


					if (strcmp(strtok.token(i).c_str(), "<clusterid>") == 0) {

						fprintf_s(ResultFileDescriptor, "<clusterid>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</clusterid>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</clusterid>\n");
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<meta4Grams>") == 0) {
						fprintf_s(ResultFileDescriptor, "<meta4Grams>\t");
						i++;
						for (int j = 0; j < 4; j++)	{
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "\t");
						while (strcmp(strtok.token(i).c_str(), "</meta4Grams>") != 0) {
							msgTexts.push_back(strtok.token(i).c_str());
							i++;
						}
						//===================
						if (msgTexts.size() > 0) {//generate fourgram frequency representation for the message				
							//call a function that convert msgTexts to a vector, and output the vector
							msgGramFre.clear();
							Text2GramFrequency(msgTexts, msgGramFre);
							msgTexts.clear();
							for (int j = 0; j < msgGramFre.size(); j++) {
								if (msgGramFre[j].DimFreVal > 0)
									fprintf(ResultFileDescriptor, "%lld %d\t", msgGramFre[j].GramVal, msgGramFre[j].DimFreVal);
							}
							msgGramFre.clear();
						}
						fprintf_s(ResultFileDescriptor, "</meta4Grams>\n");
						//====================

						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<comment4Grams>") == 0) {						
						fprintf_s(ResultFileDescriptor, "<comment4Grams>\t");
						i++;
						for (int j = 0; j < 4; j++) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "\t");

						while (strcmp(strtok.token(i).c_str(), "</comment4Grams>") != 0) {
							msgTexts.push_back(strtok.token(i).c_str());
							i++;
						}

						//===================
						if (msgTexts.size() > 0) {//generate fourgram frequency representation for the message				
							//call a function that convert msgTexts to a vector, and output the vector
							msgGramFre.clear();
							Text2GramFrequency(msgTexts, msgGramFre);
							msgTexts.clear();
							for (int j = 0; j < msgGramFre.size(); j++) {
								if (msgGramFre[j].DimFreVal > 0)
									fprintf(ResultFileDescriptor, "%lld %d\t", msgGramFre[j].GramVal, msgGramFre[j].DimFreVal);
							}
							msgGramFre.clear();
						}
						fprintf_s(ResultFileDescriptor, "</comment4Grams>\n");
						//====================

						i++;
						continue;
					}
					if (strcmp(strtok.token(i).c_str(), "<svd>") == 0) {

						fprintf_s(ResultFileDescriptor, "<svd>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</svd>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</svd>\n");
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<msgcontfidf>") == 0) {

						fprintf_s(ResultFileDescriptor, "<msgcontfidf>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</msgcontfidf>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</msgcontfidf>\n");
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<SpaceRange>") == 0) {

						fprintf_s(ResultFileDescriptor, "<SpaceRange>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</SpaceRange>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</SpaceRange>\n");
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<TimeRange>") == 0) {

						fprintf_s(ResultFileDescriptor, "<TimeRange>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</TimeRange>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</TimeRange>\n");
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<SpaceRangeSet>") == 0) {

						fprintf_s(ResultFileDescriptor, "<SpaceRangeSet>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</SpaceRangeSet>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</SpaceRangeSet>\n");
						i++;
						continue;
					}
					if (strcmp(strtok.token(i).c_str(), "<TimeRangeSet>") == 0) {

						fprintf_s(ResultFileDescriptor, "<TimeRangeSet>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</TimeRangeSet>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</TimeRangeSet>\n");
						i++;
						continue;
					}
					if (strcmp(strtok.token(i).c_str(), "<useridlist>") == 0) {

						fprintf_s(ResultFileDescriptor, "<useridlist>\t");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</useridlist>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "</useridlist>\n");
						i++;
						continue;
					}	
					
					i++;
				}
			}			
			fclose(ResultFileDescriptor);
		}
		//=====================
		fclose(fileDescriptor);
	}

	return ret;
}

void Text2GramFrequency(std::vector<string>& msgText, std::vector<msgGramFrequencyEle>& msgVec) {
	std::vector<FourGramWeightPair> fourGramlist;
	std::vector<FourGramWeightPair>::iterator fglit;
	std::vector<conceptWeightPair> CWPlist;
	std::vector<conceptWeightPair>::iterator clit;
	std::vector<msgGramFrequencyEle>::iterator msgvit;
	//=================
	int msgTextSize = msgText.size();
	for (int i = 0; i < msgTextSize; i++) {
		std::vector<conceptWeightPair>::iterator cwplit = CWPlist.begin();
		while (cwplit != CWPlist.end()) {
			if (strcmp(msgText[i].c_str(), (*cwplit).concept.c_str()) == 0) {
				(*cwplit).weight++;
				break;
			}
			cwplit++;
		}
		if (cwplit == CWPlist.end()) {//not in the CWPlist, then insert it as a new concept
			conceptWeightPair cwPair;
			cwPair.concept = msgText[i];
			cwPair.weight = 1;
			CWPlist.push_back(cwPair);
		}
	}
	//================
	clit = CWPlist.begin();
	while (clit != CWPlist.end()) {
		strTo4grams((*clit).concept, fourGramlist);
		clit++;
	}

	msgGramFrequencyEle msgVe;
	//compute msgGramFrequencyEle values 
	fglit = fourGramlist.begin();
	while (fglit != fourGramlist.end()) {
		char str[MSGLEN];
		strcpy_s(str, (*fglit).Gram.c_str());
		long long int fourGramVal = FourGramToVal(str);
		
		int Insert = 1;
		for (int i = 0; i < msgVec.size(); i++)
		{
			if (msgVec[i].GramVal == fourGramVal) {
				msgVec[i].DimFreVal += (*fglit).weight;
				Insert = 0;  //not need to insert
				break;
			}
			else if (msgVec[i].GramVal > fourGramVal) {
				msgVe.GramVal = fourGramVal;
				msgVe.DimFreVal = (*fglit).weight;
				
				msgvit = msgVec.begin() + i;
				msgVec.insert(msgvit, msgVe);
				Insert = 0;
				break;
			}
		}

		if (Insert) {
			msgVe.GramVal = fourGramVal;
			msgVe.DimFreVal = (*fglit).weight;
			msgVec.push_back(msgVe);
		}
		fglit++;
	}
	
	fourGramlist.clear();
	CWPlist.clear();
}
//preprocessing all the Youtube test data. convert keywords into 4gram vectors, format userid and timestamp etc.
int BulkProcessYoutubeVideo(char* flistname, char* path, char* outpath) {
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char outFullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	char FullSlotFileUsers[MSGLEN];

	int tpno = 0;
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		int count = 0;
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			printf("%s", buffer);

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");
			//strcat_s(FullSlotFileName, ".dat");

			strcpy_s(outFullSlotFileName, outpath);
			strcat_s(outFullSlotFileName, strtok.token(0).c_str());
			strcat_s(outFullSlotFileName, ".UPtensor");
			ProcessUserProfileVideos(FullSlotFileName, outFullSlotFileName, tpno);

			tpno++;
		}
		fclose(fileDescriptor);
	}

	return 0;
}
//preprocessing all the test data. convert keywords into 4gram vectors, format userid and timestamp etc.
int BulkProcessEventSlot(char* flistname, char* path, char* outpath) {
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char outFullSlotFileName[MSGLEN];
	char buffer[MSGLEN];

	char FullSlotFileUsers[MSGLEN];

	int tpno = 0;
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		int count = 0;
		while (fgets(buffer, MSGLEN, fileDescriptor)) {			
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			printf("%s", buffer);

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");
			//strcat_s(FullSlotFileName, ".dat");

			strcpy_s(outFullSlotFileName, outpath);
			strcat_s(outFullSlotFileName, strtok.token(0).c_str());
			strcat_s(outFullSlotFileName, ".UPtensor");
			ProcessUserProfileEvents(FullSlotFileName, outFullSlotFileName, tpno);

			tpno++;
		}
		fclose(fileDescriptor);
	}

	return 0;
}
//preprocessing all the test data. convert keywords into 4gram vectors, format userid and timestamp etc.
int BulkProcessMessageSlot(char* flistname, char* path, char* outpath) {
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char outFullSlotFileName[MSGLEN];
	char buffer[MSGLEN];	

	char FullSlotFileUsers[MSGLEN];
	
	int tpno = 0;
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		int count = 0;
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			/*if (count >= 511)
				break;
			
			count++;*/
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			printf("%s", buffer);
			
			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");
			//strcat_s(FullSlotFileName, ".dat");

			strcpy_s(outFullSlotFileName, outpath);
			strcat_s(outFullSlotFileName, strtok.token(0).c_str());
			strcat_s(outFullSlotFileName, ".dat");
			ProcessMessageSlot(FullSlotFileName, outFullSlotFileName, tpno);

			//strcpy_s(FullSlotFileUsers, "C:\\scratch\\MyProgramsRMIT\\PVLDB21CPP\\Datasets\\Nepal_data\\filtered_earthquake\\");
			/*strcpy_s(FullSlotFileUsers, "C:\\Users\\e20477\\Dropbox\\DatasetsFromXi\\nepal_parsed_data_userlist\\");

			strcat_s(FullSlotFileUsers, strtok.token(0).c_str());
			strcat_s(FullSlotFileUsers, ".txt");
			ProcessMessageSlotAddUsers(FullSlotFileName, FullSlotFileUsers, outFullSlotFileName);*/
			tpno++;
		}
		fclose(fileDescriptor);
	}

	return 0;
}
int ProcessMessageSlot(char* FullSlotFileName, char * outFullSlotFileName, int tpno)
{
	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	int retweetstatus = 0;
	
	std::vector<string> msgTexts;
	std::vector<msgVecEle> msgVec;
	

	if ((err = fopen_s(&fileDescriptor, FullSlotFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else {
		if ((err = fopen_s(&ResultFileDescriptor, outFullSlotFileName, "a+")) != 0)
		{
			printf("ResultFileDescriptor was not open\n");
		}
		else
		{
			while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
				line = buffer;
				strtokenizer strtok(line, " \t\r\n");
				int length = strtok.count_tokens();

				if (length <= 0) {
					printf("Invalid (empty) document!\n");
					fclose(ResultFileDescriptor);
					return 1;
				}

				int i = 0;
				while (i < length)
				{
					if (strcmp(strtok.token(i).c_str(), "<hashtags>") == 0)	{
						fprintf_s(ResultFileDescriptor, "%s ", "<hashtags>");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</hashtags>") != 0) {
							//output hashtag
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						i++;
						fprintf_s(ResultFileDescriptor, "%s\t", "</hashtags>");
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<text>") == 0) {
						fprintf_s(ResultFileDescriptor, "%s ", "<msgcontfidf>");
						int j = 0;
						i++;
						msgTexts.clear();
						while (strcmp(strtok.token(i).c_str(), "</text>") != 0)	{	
						/*	if (strtok.token(i).length()<=2||strtok.token(i).length() > 20||
								strtok.token(i).c_str()[0]<'a'||strtok.token(i).c_str()[0] > 'z')  //noise
							{
								i++;
								continue;
							}*/
							msgTexts.push_back(strtok.token(i).c_str());
							i++;
						}
						//call a function that convert msgTexts to a vector, and output the vector
						msgVec.clear();
						/*msgVec.resize(DimensionDict[tpno].size());
						Text2Vec(msgTexts, msgVec, tpno);
						
						for (int j = 0; j < msgVec.size(); j++)	{
							if(msgVec[j]>0)
								//fprintf(ResultFileDescriptor, "%d %.4f\t",j, msgVec[j]);
								fprintf(ResultFileDescriptor, "%lld %.4f\t", DimensionDict[tpno][j], msgVec[j]);
						}*/
										
						Text2VecNew(msgTexts, msgVec);
						for (int j = 0; j < msgVec.size(); j++) {
							if (msgVec[j].DimVal> 0)
								fprintf(ResultFileDescriptor, "%lld %.4f\t", msgVec[j].GramVal, msgVec[j].DimVal);
						}

						fprintf_s(ResultFileDescriptor, "%s\t", "</msgcontfidf>");
						msgVec.clear();
						msgTexts.clear();
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
						fprintf_s(ResultFileDescriptor, "%s ", "<msgid>");
						i++;
						while (strcmp(strtok.token(i).c_str(), "</msgid>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "%s\t", "</msgid>");
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<rtmsgid>") == 0) {
						i++;
						fprintf_s(ResultFileDescriptor, "%s ", "<rtmsgid>");
						while (strcmp(strtok.token(i).c_str(), "</rtmsgid>") != 0) {
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}
						fprintf_s(ResultFileDescriptor, "%s\t", "</rtmsgid>");
						i++;
						continue;
					}
					if (strcmp(strtok.token(i).c_str(), "<coordinates>") == 0) {
						i++;
						int j = 0;
						fprintf_s(ResultFileDescriptor, "%s ", "<coordinates>");
						while (strcmp(strtok.token(i).c_str(), "</coordinates>") != 0)	{
							fprintf_s(ResultFileDescriptor, "%s ", strtok.token(i).c_str());
							i++;
						}

						fprintf_s(ResultFileDescriptor, "%s\t", "</coordinates>");
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<timestamp_ms>") == 0) {
						i++;
						fprintf_s(ResultFileDescriptor, "%s ", "<timestamp_ms>");
						while (strcmp(strtok.token(i).c_str(), "</timestamp_ms>") != 0) {
							char substrTime[MSGLEN];
							strcpy_s(substrTime, strtok.token(i).substr(5, 5).c_str());
							fprintf_s(ResultFileDescriptor, "%s ", substrTime);
							i++;
						}
						i++;
						fprintf_s(ResultFileDescriptor, "%s\t", "</timestamp_ms>");
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<userid>") == 0) {
						i++;
						fprintf_s(ResultFileDescriptor, "%s ", "<userid>");
						while (strcmp(strtok.token(i).c_str(), "</userid>") != 0){
							int userIndex = GetUserIndex(atoll(strtok.token(i).c_str()));
							fprintf_s(ResultFileDescriptor, "%d ", userIndex);
							i++;
						}
						fprintf_s(ResultFileDescriptor, "%s\t", "</userid>");
						i++;
						continue;
					}

					if (strcmp(strtok.token(i).c_str(), "<useridlist>") == 0) {
						i++;
						fprintf_s(ResultFileDescriptor, "%s ", "<useridlist>");
						while (strcmp(strtok.token(i).c_str(), "</useridlist>") != 0) {
							int userIndex = GetUserIndex(atoll(strtok.token(i).c_str()));
							if(userIndex>=0) //ignore the ids not in user id set
								fprintf_s(ResultFileDescriptor, "%d ", userIndex);
							i++;
						}
						fprintf_s(ResultFileDescriptor, "%s\t", "</useridlist>");
						i++;
						continue;
					}
					i++;
				}
				fprintf_s(ResultFileDescriptor, "\n");
				////////////////////////////			
			}
			fclose(ResultFileDescriptor);
		}
		fclose(fileDescriptor);
	}

	return 0;
}

void WeightedText2TensorNew(std::vector<string>& msgText, std::vector<string>& descriptionText, std::vector<EventTensorEle>& msgVec)
{
	std::vector<FourGramWeightPair> fourGramlist;
	std::vector<FourGramWeightPair>::iterator fglit;
	std::vector<conceptWeightPair> CWPlist;
	std::vector<conceptWeightPair>::iterator clit;
	std::vector<EventTensorEle>::iterator msgvit;
	//=================
	int msgTextSize = msgText.size();
	for (int i = 0; i < msgTextSize; i++) {
		std::vector<conceptWeightPair>::iterator cwplit = CWPlist.begin();
		while (cwplit != CWPlist.end()) {
			if (strcmp(msgText[i].c_str(), (*cwplit).concept.c_str()) == 0) {
				(*cwplit).weight+=0.6;
				break;
			}
			cwplit++;
		}
		if (cwplit == CWPlist.end()) {//not in the CWPlist, then insert it as a new concept
			conceptWeightPair cwPair;
			cwPair.concept = msgText[i];
			cwPair.weight = 0.6;
			CWPlist.push_back(cwPair);
		}
	}
	//================
	int descriptionSize = descriptionText.size();
	for (int i = 0; i < descriptionSize; i++) {
		std::vector<conceptWeightPair>::iterator cwplit = CWPlist.begin();
		while (cwplit != CWPlist.end()) {
			if (strcmp(descriptionText[i].c_str(), (*cwplit).concept.c_str()) == 0) {
				(*cwplit).weight+=0.4;
				break;
			}
			cwplit++;
		}
		if (cwplit == CWPlist.end()) {//not in the CWPlist, then insert it as a new concept
			conceptWeightPair cwPair;
			cwPair.concept = descriptionText[i];
			cwPair.weight = 0.4;
			CWPlist.push_back(cwPair);
		}
	}
	//================
	clit = CWPlist.begin();
	while (clit != CWPlist.end()) {
		WeightedstrTo4grams((*clit), fourGramlist);
		clit++;
	}

	EventTensorEle msgVe;
	//compute TF values first,
	fglit = fourGramlist.begin();
	while (fglit != fourGramlist.end()) {
		char str[MSGLEN];
		strcpy_s(str, (*fglit).Gram.c_str());
		long long int fourGramVal = FourGramToVal(str);
		int valuePair[2] = { 0 };
		FourGramToValRowCol(str, valuePair);
		int Insert = 1;
		for (int i = 0; i < msgVec.size(); i++)
		{
			if (msgVec[i].GramVal == fourGramVal) {
				msgVec[i].DimVal += (*fglit).weight;
				Insert = 0;  //not need to insert
				break;
			}
			else if (msgVec[i].GramVal > fourGramVal) {
				msgVe.GramVal = fourGramVal;
				msgVe.DimVal = (*fglit).weight;
				msgVe.rowVal = valuePair[0];
				msgVe.colVal = valuePair[1];

				msgvit = msgVec.begin() + i;
				msgVec.insert(msgvit, msgVe);
				Insert = 0;
				break;
			}
		}
		if (Insert) {
			msgVe.GramVal = fourGramVal;
			msgVe.rowVal = valuePair[0];
			msgVe.colVal = valuePair[1];
			msgVe.DimVal = (*fglit).weight;
			msgVec.push_back(msgVe);
		}
		fglit++;
	}
	//normalize TF
	float TotalTF = 0;
	for (int i = 0; i < msgVec.size(); i++) {
		TotalTF += msgVec[i].DimVal;
	}
	for (int i = 0; i < msgVec.size(); i++) {
		msgVec[i].DimVal /= TotalTF;
	}

	//compute TF/IDF vector
	std::vector<FourGramMSGNumPair>::iterator GDit;
	for (int i = 0; i < msgVec.size(); i++)
	{
		long long int dim = msgVec[i].GramVal;
		//find idf value
		int hashkey = dim % HTSize;
		GDit = GramDocNumHashTable[hashkey].begin();
		while (GDit != GramDocNumHashTable[hashkey].end()) {
			if ((*GDit).GramVal == dim)  //get idf
			{
				float idfVal = log(TRAIN_MSG / (1.0 + (*GDit).MSGNum));
				msgVec[i].DimVal = msgVec[i].DimVal * idfVal;
				break;
			}
			GDit++;
		}
	}
	fourGramlist.clear();
	CWPlist.clear();
}

void Text2TensorNew(std::vector<string>& msgText, std::vector<EventTensorEle>& msgVec)
{
	std::vector<FourGramWeightPair> fourGramlist;
	std::vector<FourGramWeightPair>::iterator fglit;
	std::vector<conceptWeightPair> CWPlist;
	std::vector<conceptWeightPair>::iterator clit;
	std::vector<EventTensorEle>::iterator msgvit;
	//=================
	int msgTextSize = msgText.size();
	for (int i = 0; i < msgTextSize; i++) {
		std::vector<conceptWeightPair>::iterator cwplit = CWPlist.begin();		
		while (cwplit != CWPlist.end()) {
			if (strcmp(msgText[i].c_str(), (*cwplit).concept.c_str()) == 0) {
				(*cwplit).weight++;
				break;
			}
			cwplit++;
		}
		if (cwplit == CWPlist.end()) {//not in the CWPlist, then insert it as a new concept
			conceptWeightPair cwPair;
			cwPair.concept = msgText[i];
			cwPair.weight = 1;
			CWPlist.push_back(cwPair);
		}
	}
	//================
	clit = CWPlist.begin();
	while (clit != CWPlist.end()) {
		strTo4grams((*clit).concept, fourGramlist);
		clit++;
	}

	EventTensorEle msgVe;
	//compute TF values first,
	fglit = fourGramlist.begin();
	while (fglit != fourGramlist.end()) {
		char str[MSGLEN];
		strcpy_s(str, (*fglit).Gram.c_str());
		long long int fourGramVal = FourGramToVal(str);
		int valuePair[2] = { 0 };
		FourGramToValRowCol(str, valuePair);
		int Insert = 1;
		for (int i = 0; i < msgVec.size(); i++)
		{
			if (msgVec[i].GramVal == fourGramVal) {
				msgVec[i].DimVal += (*fglit).weight;
				Insert = 0;  //not need to insert
				break;
			}
			else if (msgVec[i].GramVal > fourGramVal) {
				msgVe.GramVal = fourGramVal;
				msgVe.DimVal = (*fglit).weight;
				msgVe.rowVal = valuePair[0];
				msgVe.colVal = valuePair[1];

				msgvit = msgVec.begin() + i;
				msgVec.insert(msgvit, msgVe);
				Insert = 0;
				break;
			}
		}

		if (Insert) {
			msgVe.GramVal = fourGramVal;
			msgVe.rowVal = valuePair[0];
			msgVe.colVal = valuePair[1];
			msgVe.DimVal = (*fglit).weight;
			msgVec.push_back(msgVe);
		}
		fglit++;
	}
	//normalize TF
	float TotalTF = 0;
	for (int i = 0; i < msgVec.size(); i++) {
		TotalTF += msgVec[i].DimVal;
	}
	for (int i = 0; i < msgVec.size(); i++) {
		msgVec[i].DimVal /= TotalTF;
	}

	//compute TF/IDF vector
	std::vector<FourGramMSGNumPair>::iterator GDit;
	for (int i = 0; i < msgVec.size(); i++)
	{
		long long int dim = msgVec[i].GramVal;
		//find idf value
		int hashkey = dim % HTSize;
		GDit = GramDocNumHashTable[hashkey].begin();
		while (GDit != GramDocNumHashTable[hashkey].end()) {
			if ((*GDit).GramVal == dim)  //get idf
			{
				float idfVal = log(TRAIN_MSG / (1.0 + (*GDit).MSGNum));
				msgVec[i].DimVal = msgVec[i].DimVal * idfVal;
				break;
			}
			GDit++;
		}
	}
	fourGramlist.clear();
	CWPlist.clear();
}

void Text2VecNew(std::vector<string>& msgText, std::vector<msgVecEle>& msgVec) 
{
	std::vector<FourGramWeightPair> fourGramlist;
	std::vector<FourGramWeightPair>::iterator fglit;
	string wholeStr;	

	std::vector<conceptWeightPair> CWPlist;
	std::vector<conceptWeightPair>::iterator clit;
	std::vector<msgVecEle>::iterator msgvit;

	bulkExtractConcept(msgText, CWPlist);

	clit = CWPlist.begin();
	while (clit != CWPlist.end()) {
		strTo4grams((*clit).concept, fourGramlist);		
		clit++;
	}
	
	msgVecEle msgVe;
	//compute TF values first,
	fglit = fourGramlist.begin();
	while (fglit != fourGramlist.end()) {
		char str[MSGLEN];
		strcpy_s(str, (*fglit).Gram.c_str());
		long long int fourGramVal= FourGramToVal(str);
		int Insert=1;
		for (int i = 0; i < msgVec.size(); i++)
		{
			if (msgVec[i].GramVal == fourGramVal) {
				msgVec[i].DimVal += (*fglit).weight;
				Insert = 0;  //not need to insert
				break;
			}
			else if (msgVec[i].GramVal > fourGramVal) {
				msgVe.GramVal = fourGramVal;
				msgVe.DimVal = (*fglit).weight;
				
				msgvit = msgVec.begin() + i;
				msgVec.insert(msgvit,msgVe);
				Insert = 0;
				break;
			}
		}

		if (Insert) {
			msgVe.GramVal = fourGramVal;
			msgVe.DimVal = (*fglit).weight;
			msgVec.push_back(msgVe);
		}
		fglit++;
	}	
	//normalize TF
	float TotalTF = 0;
	for (int i = 0; i < msgVec.size(); i++) {		
		TotalTF += msgVec[i].DimVal;
	}
	for (int i = 0; i < msgVec.size(); i++) {
		msgVec[i].DimVal /= TotalTF;
	}

	//compute TF/IDF vector
	std::vector<FourGramMSGNumPair>::iterator GDit;

	for (int i = 0; i < msgVec.size(); i++)
	{
		long long int dim = msgVec[i].GramVal;
		//find idf value
		int hashkey = dim % HTSize;
		GDit = GramDocNumHashTable[hashkey].begin();
		while (GDit != GramDocNumHashTable[hashkey].end()) {
			if ((*GDit).GramVal == dim)  //get idf
			{
				float idfVal = log(TRAIN_MSG / (1.0 + (*GDit).MSGNum));
				msgVec[i].DimVal = msgVec[i].DimVal * idfVal;
				break;
			}
			GDit++;
		}
	}
	fourGramlist.clear();
	wholeStr.clear();
	CWPlist.clear();
}

void Text2Vec(std::vector<string>& msgText, std::vector<float>& msgVec, int tpno) {
	std::vector<FourGramWeightPair> fourGramlist;
	std::vector<FourGramWeightPair>::iterator fglit;
	string wholeStr;

	std::vector<conceptWeightPair> CWPlist;
	std::vector< conceptWeightPair>::iterator clit;

	bulkExtractConcept(msgText, CWPlist);

	clit = CWPlist.begin();
	while (clit != CWPlist.end()) {
		strTo4grams((*clit).concept, fourGramlist);
		clit++;
	}
	std::vector<string>::iterator mit= msgText.begin();
	wholeStr.clear();
	while (mit != msgText.end()) {
		wholeStr += (*mit);
		mit++;
	}
	strTo4grams(wholeStr, fourGramlist);

	//compute TF values first
	fglit = fourGramlist.begin();
	while (fglit != fourGramlist.end()) {
		char str[MSGLEN];
		strcpy_s(str, (*fglit).Gram.c_str());
		long long int fourGramVal = FourGramToVal(str);
		for (int i = 0; i < DimensionDict[tpno].size(); i++)
		{
			if (DimensionDict[tpno][i] == fourGramVal) {
				msgVec[i] += (*fglit).weight;
				break;
			}
		}
		fglit++;
	}
	//normalize TF
	float TotalTF = 0;
	for (int i = 0; i < DimensionDict[tpno].size(); i++) {		
			TotalTF += msgVec[i];
	}
	for (int i = 0; i < DimensionDict[tpno].size(); i++) {		
		msgVec[i]/= TotalTF;
	}

	//compute TF/IDF vector
	std::vector<FourGramMSGNumPair>::iterator GDit; 

	for (int i = 0; i < DimensionDict[tpno].size(); i++)
	{
		//find idf value
		int hashkey = DimensionDict[tpno][i] % HTSize;
		GDit= GramDocNumHashTable[hashkey].begin();
		while (GDit != GramDocNumHashTable[hashkey].end()) {
			if ((*GDit).GramVal == DimensionDict[tpno][i])  //get idf
			{
				float idfVal =log(TRAIN_MSG/(1.0+ (*GDit).MSGNum));
				msgVec[i] = msgVec[i] * idfVal;
				break;
			}
			GDit++;
		}
	}
}


int GetUserIndex(long long int userid) {
	int UserIndex = -1;
	int hashkey = userid % HTSize;

	std::vector<UserProfile>::iterator uit= UserPHashTable[hashkey].begin();
	while (uit != UserPHashTable[hashkey].end()) {
		if ((*uit).userOid == userid){
			UserIndex = (*uit).userId;
			break;
		}
		uit++;
	}
	return UserIndex;
}

void BulkGetMessageSlotsDims(char* flistname,char *path) {
	//printf("loading concept Dict for BG...\n");
	//LoadkeywordConceptDict();
	//printf("loading complete\n");

	FILE* fileDescriptor = NULL;
	FILE* ResultFileDescriptor = NULL;
	errno_t err;
	char FullSlotFileName[MSGLEN];
	char DimensionDict[MSGLEN];
	char buffer[MSGLEN];
	//strcpy_s(DimensionDict, "DimDict.txt");
	strcpy_s(DimensionDict, "DimDict_NepalGramSize8.txt");

	int SlotNum = 0;
	
	string line;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else 
	{
		if ((err = fopen_s(&ResultFileDescriptor, DimensionDict, "a+")) != 0) 
			printf("cannot open %s\n", DimensionDict);
		else 
		{
			while (fgets(buffer, MSGLEN, fileDescriptor))
			{
				fprintf(ResultFileDescriptor, "<tpno>  %d </tpno>\t", SlotNum);
				
				line = buffer;
				strtokenizer strtok(line, " \t\r\n");

				strcpy_s(FullSlotFileName, path);
				strcat_s(FullSlotFileName, strtok.token(0).c_str());
				strcat_s(FullSlotFileName, ".txt");

				GetMessageSlotDimensions(FullSlotFileName);

				//output dim num for this time slot
				int dimnum = 0;
				for (int i = 0; i < HTSize; i++)
					dimnum += FourGramHashTable[i].size();
				fprintf(ResultFileDescriptor, "<dimNum>  %d </dimNum>\t", dimnum);
				//output dims for the slot
				long long int curmin = -1;
				long long int minCap = FindMinCapVal(curmin);

				fprintf(ResultFileDescriptor, "<DimNo> ");
				while (minCap < LLONG_MAX)//found
				{
					fprintf(ResultFileDescriptor, "%lld ", minCap);
					curmin = minCap;
					minCap = FindMinCapVal(curmin);
				}
				fprintf(ResultFileDescriptor, "</DimNo>\n");
				//clear FourGramHashTable
				for (int i = 0; i < HTSize; i++)
					FourGramHashTable[i].clear();	

				SlotNum++;
			}
			fclose(ResultFileDescriptor);
		}
		fclose(fileDescriptor);
	}
}

//find the minimal value that is smaller than curmin
long long int FindMinCapVal(long long int curmin) 
{
	long long int ret = LLONG_MAX;

	for (int i = 0; i < HTSize; i++) {
		std::vector<long long int>::iterator fgit = FourGramHashTable[i].begin();
		while (fgit != FourGramHashTable[i].end()) {
			if ((*fgit) > curmin && (*fgit) < ret)
				ret = (*fgit);
			fgit++;
		}
	}
	return ret;
}

//read message texts, get concepts, change to 4-grams, and output the dimensions
int GetMessageSlotDimensions(char* FullSlotFileName)  
{
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;		
	std::vector<string> msgTexts;

	printf("slot file: %s\n", FullSlotFileName);
	
	if ((err = fopen_s(&fileDescriptor, FullSlotFileName, "r")) != 0) {		
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else {	
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
			int i = 0;
			while (i < length)	{					
				if (strcmp(strtok.token(i).c_str(), "<text>") == 0) {
					i++;
					msgTexts.clear();
					while (strcmp(strtok.token(i).c_str(), "</text>") != 0)	{
						msgTexts.push_back(strtok.token(i).c_str());
						i++;
					}
					//get concepts of msgTexts;convert msgTexts into 4-grams.
					//if a 4-gram is not in 4-gram dictionary, add it.
					msgTextsTo4gramsDict(msgTexts);
					i++;
					continue;
				}					
				i++;
			}						
		}		
		fclose(fileDescriptor);
	}
	return 0;
}

void msgTextsTo4gramsDict(std::vector<string>& textlist)
{
	std::vector<conceptWeightPair> conceptlist;
	bulkExtractConcept(textlist, conceptlist);

	/*//check textlist, the textlist as a single string
	string wholeStr;
	
	std::vector<string>::iterator tlit = textlist.begin();
	wholeStr.clear();
	while (tlit != textlist.end()) {
		wholeStr+= (*tlit).c_str();
		wholeStr+= "_";
		tlit++;
	}
	
	strTo4gramsDict(wholeStr);*/

	//process the textlist	
	std::vector<string>::iterator tlit = textlist.begin();	
	while (tlit != textlist.end()) {
		strTo4gramsDict(*tlit);
		tlit++;
	}
	//check conceptlist, each concept as a string
	std::vector<conceptWeightPair>::iterator clit = conceptlist.begin();
	while (clit != conceptlist.end()) 
	{
		strTo4gramsDict((*clit).concept);
		clit++;
	}
}


int FourGramToValRowCol(char* FGToken, int valuePair[]) {
	int index = 0;

	//valuePair[0]: row number; valuePair[1]: column number
	for (int j = 0; j < GramSize/2; j++) {
		int base, exp;
		base = 27;
		//base = 37;
		exp = GramSize/2 - j - 1;
		int result = 0;

		if (FGToken[j] >= 'a' && FGToken[j] <= 'z') {
			//result = FGToken[j] - 'a' + 11;
			result = FGToken[j] - 'a' + 1;
			while (exp != 0) {
				result *= base;
				--exp;
			}
			valuePair[0] += result;
		}
		else {
			result = 0;
			while (exp != 0) {
				result *= base;
				--exp;
			}
			valuePair[0] += result;
		}
	}
	
	for (int j = 2; j < GramSize; j++) {
		int base, exp;
		base = 27;
		//base = 37;
		exp = GramSize - j - 1;
		int result = 0;

		if (FGToken[j] >= 'a' && FGToken[j] <= 'z') {
			//result = FGToken[j] - 'a' + 11;
			result = FGToken[j] - 'a' + 1;
			while (exp != 0) {
				result *= base;
				--exp;
			}
			valuePair[1] += result;
		}
		else {
			result = 0;
			while (exp != 0) {
				result *= base;
				--exp;
			}
			valuePair[1] += result;
		}
	}
	index = valuePair[0];
	return index;
}

long long int FourGramToVal(char* FGToken) {
	long long int index;
	index = 0;

	//if(strcmp(FGToken,"_quarter")==0)
	//	printf("dbug\n");

	for (int j = 0; j < GramSize; j++) {
		int base, exp;
		//base = 27;
		base = 37;
		exp = GramSize - j - 1;
		long long int result = 0;

		if (FGToken[j] >= 'a' && FGToken[j] <= 'z') {
			result = FGToken[j] - 'a' + 11;
			//result = FGToken[j] - 'a' + 1;
			while (exp != 0) {
				result *= base;
				--exp;
			}
			index += result;
		}

		if (FGToken[j] >= '0' && FGToken[j] <= '9') {
			result = FGToken[j] - '0' + 1;
			while (exp != 0) {
				result *= base;
				--exp;
			}
			index += result;
		}/**/
	}
	//if (index < 0)
	//	printf("dbug\n");
	return index;
}
void strTo4gramsDict(string wholeStr) {
	int hashkey;
	char FourGToken[MSGLEN];
	long long int index;
	int wholeStrSize = wholeStr.length();

	for (int i = 0; i < wholeStrSize; i++)
	{
		/*if (wholeStr[i] < 'a' || wholeStr[i]>'z')*/
		if (wholeStr[i] >= 'a' && wholeStr[i] <= 'z')
			;
		else if (wholeStr[i] >= '0' && wholeStr[i] <= '9')
			;
		else
			wholeStr[i] = '_';
	}

	if (wholeStr.length() < GramSize) {
		//the whole str is a 4 gram with 4-wholeStr.length '-' at the begining of the string
		string curGram = "_";
		while (curGram.length() < GramSize - wholeStr.length())
			curGram += "_";
		
		wholeStr = curGram+ wholeStr;
	}
	wholeStrSize = wholeStr.length();
	for (int i = 0; i <= wholeStrSize - GramSize; i++) {
		strcpy_s(FourGToken, wholeStr.substr(i, GramSize).c_str());
		//convert FourGToken into a digital value based on ASCII code, which means the index order of the token in the dictionary
		index = FourGramToVal(FourGToken);

		//printf("Token:\t%s\t Index:\t %lld \n", wholeStr.c_str(),index);

		//check if index is in FourGramHashTable
		hashkey = index % HTSize;
		std::vector<long long int>::iterator fgit = FourGramHashTable[hashkey].begin();
		while (fgit != FourGramHashTable[hashkey].end()) {
			if ((*fgit) != index)
				fgit++;
			else
				break;
		}
		if (fgit == FourGramHashTable[hashkey].end())  //not in the table, insert it
		{
			FourGramHashTable[hashkey].push_back(index);
		}

		//use break to extract the first gram only
		//use break to extract the first three grams only
		if(i==3)
			break;
	}
}
void bulkExtractConcept(std::vector<string>& textlist, std::vector<conceptWeightPair>& conceptlist) 
{
	std::vector<string>::iterator tlit = textlist.begin();
	std::vector<KeywordNumPair> keynumPairlist;
	std::vector<KeywordNumPair>::iterator knPit;
	KeywordNumPair curKNpair;

	while (tlit != textlist.end()) { //combine the duplicate keywords
		knPit = keynumPairlist.begin();
		while (knPit != keynumPairlist.end()) {
			if (strcmp((*tlit).c_str(), (*knPit).keyword.c_str()) == 0) { //found duplicate
				(*knPit).Knum++;
				break;
			}
			knPit++;
		}
		if (knPit == keynumPairlist.end()) {//not found
			curKNpair.keyword= (*tlit);
			curKNpair.Knum = 1;
			keynumPairlist.push_back(curKNpair);
		}
		tlit++;
	}

	// Get the concepts of keynumPairlist	
	conceptWeightPair cwPair;	
	conceptlist.clear();
	knPit = keynumPairlist.begin();
	while (knPit != keynumPairlist.end()) {
		cwPair.concept = (*knPit).keyword;
		cwPair.weight = (*knPit).Knum;
		conceptlist.push_back(cwPair);
		knPit++;
	}
	//for keyword vector representation, return directly
	//return;
	//extract concepts
	knPit = keynumPairlist.begin();
	while (knPit != keynumPairlist.end()) {
		getconcepts((*knPit), conceptlist);
		knPit++;
	}
}
void getconcepts(KeywordNumPair keywordnumPair, std::vector<conceptWeightPair>& conceptlist)
{
	int hashkey = hashString(keywordnumPair.keyword, HTSize);
	std::vector<conceptWeightPair>::iterator cwpit;
	conceptWeightPair curCWP;
		
	for (int i = 0; i < keywordConceptDict[hashkey].size(); i++) 
	{
		if (keywordnumPair.keyword == keywordConceptDict[hashkey][i].keyword) 
		{
			int cwplsize = keywordConceptDict[hashkey][i].cWPlist.size();
			for (int j = 0; j < cwplsize; j++) 
			{
				curCWP.concept = keywordConceptDict[hashkey][i].cWPlist[j].concept;				
				curCWP.weight = keywordnumPair.Knum/cwplsize;
				
				cwpit = conceptlist.begin();
				while (cwpit != conceptlist.end()) 
				{
					if ((*cwpit).concept==curCWP.concept) 
					{
						(*cwpit).weight += keywordnumPair.Knum/cwplsize; //here weight means the frequency of the concept in the message
						break;
					}
					cwpit++;
				}
				if (cwpit == conceptlist.end()) { //not found, add curCWP
					conceptlist.push_back(curCWP);
				}
			}			
		}
	}

	
/*	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	char KeywordName[MSGLEN];
	
	strcpy_s(KeywordName, "C:\\Users\\e20477\\Dropbox\\DatasetsFromXi\\concepts_nepal\\");
	strcat_s(KeywordName, keywordnumPair.keyword.c_str());

	std::vector<conceptWeightPair>::iterator cwpit;
	conceptWeightPair curCWP;

	if ((err = fopen_s(&fileDescriptor, KeywordName, "r")) != 0)
		;// printf("The file 'crt_fopen_s.c' was not opened: %s\n", KeywordName);
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length == 0)
				continue;
			int i = 0;
			curCWP.concept = strtok.token(i);
			i++;
			curCWP.weight = atof(strtok.token(i).c_str());
			if (curCWP.weight > 1) {
				curCWP.weight = keywordnumPair.Knum;
				//check if curCWP.concept is in conceptlist
				cwpit = conceptlist.begin();
				while (cwpit != conceptlist.end()) {
					if (strcmp((*cwpit).concept.c_str(), curCWP.concept.c_str()) == 0) {
						(*cwpit).weight += keywordnumPair.Knum; //here weight means the frequency of the concept in the message
						break;
					}
					cwpit++;
				}
				if (cwpit == conceptlist.end()) { //not found, add curCWP
					conceptlist.push_back(curCWP);
				}
			}
		}
		fclose(fileDescriptor);
	}*/
}

void ProcessTrainingSet(char* flistname, char *path) {
	//std::vector<FourGramMSGNumPair> GramDocNumHashTable[HTSize];
	//printf("loading concept Dict...\n");
	//LoadkeywordConceptDict();
	//printf("loading complete\n");

	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char buffer[MSGLEN];
	char dimensiondict[MSGLEN];
	//strcpy_s(dimensiondict, "TrainingSetGramMSGNo(25April-9May).txt");
	//strcpy_s(dimensiondict, "TrainingSetGramMSGNo(15April-24April).txt");
	strcpy_s(dimensiondict, "NepalTrainingSet4GramMSGNo(15April-24April).txt");

	//strcpy_s(dimensiondict, "FloodTrainingSet4GramMSGNo(12-21May).txt");

	int SlotNum = 0;
	std::vector<FourGramMSGNumPair>::iterator fgpit;

	string line;
	int TotalmsgNum=0;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else{		
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");

			printf("%s\n", FullSlotFileName);

			int msgNum=ReadMessageSlotConcepts(FullSlotFileName);
			TotalmsgNum += msgNum;
		}
		fclose(fileDescriptor);
	}

	if ((err = fopen_s(&fileDescriptor, dimensiondict, "a+")) != 0)
		printf("cannot open %s\n", dimensiondict);
	else{		
		fprintf(fileDescriptor, "<TotalmsgNum>  %d </TotalmsgNum>\t", TotalmsgNum);
		for (int i = 0; i < HTSize; i++) {
			fgpit = GramDocNumHashTable[i].begin();
			fprintf(fileDescriptor, "<hashkey>  %d </hashkey>\t", i);
			fprintf(fileDescriptor, "<GramMSGnum> ");
			while (fgpit != GramDocNumHashTable[i].end()) {
				char str[MSGLEN];
				strcpy_s(str, (*fgpit).Gram.c_str());
				long long int GramVal = FourGramToVal(str);
				fprintf(fileDescriptor, "%s %lld %d\t", (*fgpit).Gram.c_str(), GramVal, (*fgpit).MSGNum);
				fgpit++;
			}
			fprintf(fileDescriptor, "</GramMSGnum>\n");
		}

		fclose(fileDescriptor);
	}

	for (int i = 0; i < HTSize; i++) {
		GramDocNumHashTable[i].clear();
		for (int j = 0; j < keywordConceptDict[i].size(); j++)
			keywordConceptDict[i][j].cWPlist.clear();
		keywordConceptDict[i].clear();
	}
}

void ProcessTrainingSetCCIGVideoTensor(char* flistname, char* path) {
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char buffer[MSGLEN];
	char dimensiondict[MSGLEN];

	//strcpy_s(dimensiondict, "FloodEventTrainingSet4GramMSGNo(12-21May).txt");
	//strcpy_s(dimensiondict, "NepalEventTrainingSet4GramMSGNo(15April-24April).txt");
	strcpy_s(dimensiondict, "YoutubeFileListTest4GramMSGNo.txt");
	
	int SlotNum = 0;
	std::vector<FourGramMSGNumPair>::iterator fgpit;

	string line;
	int TotalmsgNum = 0;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");

			printf("%s\n", FullSlotFileName);

			int msgNum = ReadYoutubeKeywords(FullSlotFileName);
			TotalmsgNum += msgNum;
		}
		fclose(fileDescriptor);
	}

	if ((err = fopen_s(&fileDescriptor, dimensiondict, "a+")) != 0)
		printf("cannot open %s\n", dimensiondict);
	else {
		fprintf(fileDescriptor, "<TotalmsgNum>  %d </TotalmsgNum>\t", TotalmsgNum);
		for (int i = 0; i < HTSize; i++) {
			fgpit = GramDocNumHashTable[i].begin();
			fprintf(fileDescriptor, "<hashkey>  %d </hashkey>\t", i);
			fprintf(fileDescriptor, "<GramMSGnum> ");
			while (fgpit != GramDocNumHashTable[i].end()) {
				char str[MSGLEN];
				strcpy_s(str, (*fgpit).Gram.c_str());
				long long int GramVal = FourGramToVal(str);
				fprintf(fileDescriptor, "%s %lld %d\t", (*fgpit).Gram.c_str(), GramVal, (*fgpit).MSGNum);
				fgpit++;
			}
			fprintf(fileDescriptor, "</GramMSGnum>\n");
		}

		fclose(fileDescriptor);
	}

	for (int i = 0; i < HTSize; i++) {
		GramDocNumHashTable[i].clear();
		for (int j = 0; j < keywordConceptDict[i].size(); j++)
			keywordConceptDict[i][j].cWPlist.clear();
		keywordConceptDict[i].clear();
	}
}

void ProcessTrainingSetCCIGTensor(char* flistname, char* path) {
	FILE* fileDescriptor = NULL;

	errno_t err;
	char FullSlotFileName[MSGLEN];
	char buffer[MSGLEN];
	char dimensiondict[MSGLEN];
	
	//strcpy_s(dimensiondict, "FloodEventTrainingSet4GramMSGNo(12-21May).txt");
	strcpy_s(dimensiondict, "NepalEventTrainingSet4GramMSGNo(15April-24April).txt");

	int SlotNum = 0;
	std::vector<FourGramMSGNumPair>::iterator fgpit;

	string line;
	int TotalmsgNum = 0;
	if ((err = fopen_s(&fileDescriptor, flistname, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", flistname);
	}
	else {
		while (fgets(buffer, MSGLEN, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");

			strcpy_s(FullSlotFileName, path);
			strcat_s(FullSlotFileName, strtok.token(0).c_str());
			strcat_s(FullSlotFileName, ".txt");

			printf("%s\n", FullSlotFileName);

			int msgNum = ReadMessageSlotKeywords(FullSlotFileName);
			TotalmsgNum += msgNum;
		}
		fclose(fileDescriptor);
	}

	if ((err = fopen_s(&fileDescriptor, dimensiondict, "a+")) != 0)
		printf("cannot open %s\n", dimensiondict);
	else {
		fprintf(fileDescriptor, "<TotalmsgNum>  %d </TotalmsgNum>\t", TotalmsgNum);
		for (int i = 0; i < HTSize; i++) {
			fgpit = GramDocNumHashTable[i].begin();
			fprintf(fileDescriptor, "<hashkey>  %d </hashkey>\t", i);
			fprintf(fileDescriptor, "<GramMSGnum> ");
			while (fgpit != GramDocNumHashTable[i].end()) {
				char str[MSGLEN];
				strcpy_s(str, (*fgpit).Gram.c_str());
				long long int GramVal = FourGramToVal(str);
				fprintf(fileDescriptor, "%s %lld %d\t", (*fgpit).Gram.c_str(), GramVal, (*fgpit).MSGNum);
				fgpit++;
			}
			fprintf(fileDescriptor, "</GramMSGnum>\n");
		}

		fclose(fileDescriptor);
	}

	for (int i = 0; i < HTSize; i++) {
		GramDocNumHashTable[i].clear();
		for (int j = 0; j < keywordConceptDict[i].size(); j++)
			keywordConceptDict[i][j].cWPlist.clear();
		keywordConceptDict[i].clear();
	}
}

void ReadTrainingSetGramStatistics(char* flistname) {
	//std::vector<FourGramMSGNumPair> GramDocNumHashTable[HTSize];
	FILE* fileDescriptor = NULL;

	errno_t err;
	char DimensionDict[MSGLEN];
	char buffer[BUFFERSIZE];
	strcpy_s(DimensionDict, "TrainingSetGramMSGNo.txt");
	FourGramMSGNumPair curFGNP;
	int SlotNum = 0;
	std::vector<FourGramMSGNumPair>::iterator fgpit;
	int hashkey;
	string line;
	if ((err = fopen_s(&fileDescriptor, DimensionDict, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", DimensionDict);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
			int i = 0;
			while (i < length) {								
				if (strcmp(strtok.token(i).c_str(), "<hashkey>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</hashkey>") != 0)
					{
						hashkey = atoi(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}

				if (strcmp(strtok.token(i).c_str(), "<GramMSGnum>") == 0) {
					i++;					
					while (strcmp(strtok.token(i).c_str(), "</GramMSGnum>") != 0) {
						curFGNP.Gram = strtok.token(i);
						i++;
						curFGNP.GramVal = atoi(strtok.token(i).c_str());

						i++;
						curFGNP.MSGNum = atoi(strtok.token(i).c_str());
						GramDocNumHashTable[hashkey].push_back(curFGNP);
						i++;
					}
					
					i++;
					continue;
				}
				i++;
			}
		}
		fclose(fileDescriptor);
	}	
}

int ReadYoutubeKeywords(char* FullSlotFileName)
{
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	std::vector<string> msgTexts, descriptionTexts;
	std::vector<conceptWeightPair> conceptlist;
	std::vector<conceptWeightPair>::iterator clit;
	std::vector<string>::iterator sit;
	KeywordNumPair knpair;
	knpair.Knum = 1;
	std::vector<FourGramWeightPair> fourGramlist;
	std::vector<FourGramWeightPair>::iterator fglit;
	string wholeStr;
	conceptWeightPair cwPair;

	FourGramMSGNumPair curFGMpair;
	int msgNum = 0;

	int skipcount = 0;
	if ((err = fopen_s(&fileDescriptor, FullSlotFileName, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<title>") == 0) {
					int j = 0;
					i++;
					msgTexts.clear();
					wholeStr.clear();
					while (strcmp(strtok.token(i).c_str(), "</title>") != 0)
					{
						string keyword = strtok.token(i).c_str();

						//check if keyword is in msgTexts already to avoid the duplicate keywords
						sit = msgTexts.begin();
						while (sit != msgTexts.end()) {
							if ((*sit) == keyword)
								break;
							sit++;
						}
						if (sit == msgTexts.end()) //not in msgTexts, then insert keyword
							msgTexts.push_back(keyword);
						i++;
					}
					i++;
					continue;
				}
				if (strcmp(strtok.token(i).c_str(), "<description>") == 0) 
				{
					int j = 0;
					i++;
					descriptionTexts.clear();
					wholeStr.clear();
					while (strcmp(strtok.token(i).c_str(), "</description>") != 0)
					{
						string keyword = strtok.token(i).c_str();

						//check if keyword is in msgTexts already to avoid the duplicate keywords
						sit = descriptionTexts.begin();
						while (sit != descriptionTexts.end()) {
							if ((*sit) == keyword)
								break;
							sit++;
						}
						if (sit == descriptionTexts.end()) //not in msgTexts, then insert keyword
							descriptionTexts.push_back(keyword);
						i++;
					}
					i++;

					//==================================================
					// Get the concepts of msgTexts			
					sit = msgTexts.begin();
					conceptlist.clear();
					while (sit != msgTexts.end()) {
						cwPair.concept = (*sit).c_str();
						cwPair.weight = 0.6;
						conceptlist.push_back(cwPair);
						sit++;
					}
					sit = descriptionTexts.begin();
					while (sit != descriptionTexts.end()) {
						cwPair.concept = (*sit).c_str();
						cwPair.weight = 0.4;
						conceptlist.push_back(cwPair);
						sit++;
					}

					//convert into fourgrams
					fourGramlist.clear();
					clit = conceptlist.begin();
					while (clit != conceptlist.end()) {
						WeightedstrTo4grams((*clit), fourGramlist);
						clit++;
					}
					//strTo4grams(wholeStr, fourGramlist);
					//check if each 4gram is in std::vector<std::vector<FourGramWeightPair>> TrainingSetMessages;
					fglit = fourGramlist.begin();
					while (fglit != fourGramlist.end()) {
						char FourGram[MSGLEN];
						strcpy_s(FourGram, (*fglit).Gram.c_str());
						long long int index = FourGramToVal(FourGram);
						int hashkey = index % HTSize;
						std::vector<FourGramMSGNumPair>::iterator fgpit = GramDocNumHashTable[hashkey].begin();

						while (fgpit != GramDocNumHashTable[hashkey].end()) {
							if ((*fgpit).Gram == (*fglit).Gram) {
								(*fgpit).MSGNum++;
								break;
							}
							fgpit++;
						}
						if (fgpit == GramDocNumHashTable[hashkey].end()) {
							curFGMpair.MSGNum = 1;
							curFGMpair.Gram = (*fglit).Gram;
							curFGMpair.GramVal = index;
							GramDocNumHashTable[hashkey].push_back(curFGMpair);
						}
						fglit++;
					}
					msgNum++;
					//==================================================
					continue;
				}
				i++;
			}

		}
		fclose(fileDescriptor);
	}
	return msgNum;
}

int ReadMessageSlotKeywords(char* FullSlotFileName)
{
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;
	std::vector<string> msgTexts;
	std::vector<conceptWeightPair> conceptlist;
	std::vector<conceptWeightPair>::iterator clit;
	std::vector<string>::iterator sit;
	KeywordNumPair knpair;
	knpair.Knum = 1;
	std::vector<FourGramWeightPair> fourGramlist;
	std::vector<FourGramWeightPair>::iterator fglit;
	string wholeStr;
	conceptWeightPair cwPair;

	FourGramMSGNumPair curFGMpair;
	int msgNum = 0;

	int skipcount = 0;
	if ((err = fopen_s(&fileDescriptor, FullSlotFileName, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {			
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<text>") == 0) {
					int j = 0;
					i++;
					msgTexts.clear();
					wholeStr.clear();
					while (strcmp(strtok.token(i).c_str(), "</text>") != 0)
					{
						string keyword = strtok.token(i).c_str();
						
						//check if keyword is in msgTexts already to avoid the duplicate keywords
						sit = msgTexts.begin();
						while (sit != msgTexts.end()) {
							if ((*sit) == keyword)
								break;
							sit++;
						}
						if (sit == msgTexts.end()) //not in msgTexts, then insert keyword
							msgTexts.push_back(keyword);
						i++;
					}
					i++;
					continue;
				}
				
				i++;
			}
			// Get the concepts of msgTexts			
			sit = msgTexts.begin();
			conceptlist.clear();
			while (sit != msgTexts.end()) {
				cwPair.concept = (*sit).c_str();
				cwPair.weight = 1;
				conceptlist.push_back(cwPair);
				sit++;
			}
			
			
			//convert into fourgrams
			fourGramlist.clear();
			clit = conceptlist.begin();
			while (clit != conceptlist.end()) {
				strTo4grams((*clit).concept, fourGramlist);
				clit++;
			}
			//strTo4grams(wholeStr, fourGramlist);
			//check if each 4gram is in std::vector<std::vector<FourGramWeightPair>> TrainingSetMessages;
			fglit = fourGramlist.begin();
			while (fglit != fourGramlist.end()) {
				char FourGram[MSGLEN];
				strcpy_s(FourGram, (*fglit).Gram.c_str());
				long long int index = FourGramToVal(FourGram);
				int hashkey = index % HTSize;
				std::vector<FourGramMSGNumPair>::iterator fgpit = GramDocNumHashTable[hashkey].begin();
				
				while (fgpit != GramDocNumHashTable[hashkey].end()) {
					if ((*fgpit).Gram == (*fglit).Gram) {
						(*fgpit).MSGNum++;
						break;
					}
					fgpit++;
				}
				if (fgpit == GramDocNumHashTable[hashkey].end()) {
					curFGMpair.MSGNum = 1;
					curFGMpair.Gram = (*fglit).Gram;
					curFGMpair.GramVal = index;
					GramDocNumHashTable[hashkey].push_back(curFGMpair);
				}
				fglit++;
			}
			msgNum++;			
		}
		fclose(fileDescriptor);
	}
	return msgNum;
}

int ReadMessageSlotConcepts(char* FullSlotFileName)
{
	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;	
	std::vector<string> msgTexts;
	std::vector<conceptWeightPair> conceptlist;
	std::vector<conceptWeightPair>::iterator clit;
	std::vector<string>::iterator sit;
	KeywordNumPair knpair;
	knpair.Knum = 1;
	std::vector<FourGramWeightPair> fourGramlist;
	std::vector<FourGramWeightPair>::iterator fglit;
	string wholeStr;
	conceptWeightPair cwPair;

	FourGramMSGNumPair curFGMpair;
	int msgNum = 0;

	int skipcount = 0;
	if ((err = fopen_s(&fileDescriptor, FullSlotFileName, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			//for message sampling. read 1 from 20 messages.
		/*	if (skipcount < 3) {
			//if (skipcount < 300) {
				skipcount++;
				continue;
			}
			else
				skipcount = 0;*/
			//=============================
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			int i = 0;
			while (i < length)
			{
				if (strcmp(strtok.token(i).c_str(), "<text>") == 0) {					
					int j = 0;
					i++;
					msgTexts.clear();
					wholeStr.clear();
					while (strcmp(strtok.token(i).c_str(), "</text>") != 0)
					{
						string keyword = strtok.token(i).c_str();
						//wholeStr += keyword;
						//wholeStr += "_";
						//check if keyword is in msgTexts already to avoid the duplicate keywords
						sit = msgTexts.begin();
						while (sit != msgTexts.end()) {
							if ((*sit) == keyword)
								break;
							sit++;
						}
						if(sit==msgTexts.end()) //not in msgTexts, then insert keyword
							msgTexts.push_back(keyword);
						i++;
					}		
					i++;
					continue;
				}
				i++;
			}
			// Get the concepts of msgTexts			
			sit = msgTexts.begin();
			conceptlist.clear();
			while (sit != msgTexts.end()) {
				cwPair.concept = (*sit).c_str();
				cwPair.weight = 1;
				conceptlist.push_back(cwPair);
				sit++;
			}
			sit = msgTexts.begin();
			while (sit != msgTexts.end()) {				
				knpair.keyword = (*sit).c_str();
				getconcepts(knpair, conceptlist);
				sit++;
			}	

			//convert into fourgrams
			fourGramlist.clear();
			clit = conceptlist.begin();
			while (clit != conceptlist.end()) {
				strTo4grams((*clit).concept, fourGramlist);
				clit++;
			}		
			//strTo4grams(wholeStr, fourGramlist);
			//check if each 4gram is in std::vector<std::vector<FourGramWeightPair>> TrainingSetMessages;
			fglit = fourGramlist.begin();
			while (fglit != fourGramlist.end()) {
				char FourGram[MSGLEN];
				strcpy_s(FourGram, (*fglit).Gram.c_str());
				long long int index = FourGramToVal(FourGram);
				int hashkey = index % HTSize;
				std::vector<FourGramMSGNumPair>::iterator fgpit = GramDocNumHashTable[hashkey].begin();
//				if (index == 0)
				//	std::cout << "dbug\n" << std::endl;
				while (fgpit != GramDocNumHashTable[hashkey].end()) {
					if ((*fgpit).Gram == (*fglit).Gram) {
						(*fgpit).MSGNum++;
						break;
					}
					fgpit++;
				}
				if (fgpit == GramDocNumHashTable[hashkey].end()) {
					curFGMpair.MSGNum = 1;
					curFGMpair.Gram = (*fglit).Gram;					
					curFGMpair.GramVal = index;
					GramDocNumHashTable[hashkey].push_back(curFGMpair);
				}
				fglit++;
			}
			msgNum++;
			//if(msgNum%20==0)
			//std::cout<<msgNum<<" ";
		}
		fclose(fileDescriptor);
	}

	return msgNum;
}

void strTo4grams(string wholeStr, std::vector<FourGramWeightPair> & fourGramlist) {
	int wholeStrSize = wholeStr.length();
	FourGramWeightPair curGram;
	std::vector<FourGramWeightPair>::iterator fglit;

	for (int i = 0; i < wholeStrSize; i++)
	{
		//if (wholeStr[i] < 'a' || wholeStr[i]>'z')
		if (wholeStr[i] >= 'a' && wholeStr[i] <= 'z')
			;
		else if (wholeStr[i] >= '0' && wholeStr[i] <= '9')
			;
		else
			wholeStr[i] = '_';
	}

	if (wholeStr.length() < GramSize) {
		//the whole str is a 4 gram with 4-wholeStr.length '-' at the begining of the string
		curGram.Gram = "_";
		while (curGram.Gram.length() < GramSize - wholeStr.length())
			curGram.Gram += "_";
		curGram.Gram+= wholeStr;
		curGram.weight = 1;
		//check if it is in list
		fglit = fourGramlist.begin();
		while (fglit != fourGramlist.end()) {
			if ((*fglit).Gram == curGram.Gram)
			{
				(*fglit).weight += curGram.weight;
				break;
			}
			fglit++;
		}
		if (fglit == fourGramlist.end()) {
			fourGramlist.push_back(curGram);
		}
	}
	else {
		for (int i = 0; i <= wholeStrSize - GramSize; i++) {
			curGram.Gram = wholeStr.substr(i, GramSize);
			curGram.weight = 1;
			//check if it is in list
			fglit = fourGramlist.begin();
			while (fglit != fourGramlist.end()) {
				if ((*fglit).Gram == curGram.Gram) {
					(*fglit).weight += curGram.weight;
					break;
				}
				fglit++;
			}
			if (fglit == fourGramlist.end()) {
				fourGramlist.push_back(curGram);
			}
			//only get at most four 4 Gram for one concept		
			//if(i==4)
			//	break;
		}
	}
}

void WeightedstrTo4grams(conceptWeightPair wholeStr, std::vector<FourGramWeightPair>& fourGramlist) {
	int wholeStrSize = wholeStr.concept.length();
	FourGramWeightPair curGram;
	std::vector<FourGramWeightPair>::iterator fglit;

	for (int i = 0; i < wholeStrSize; i++)
	{
		//if (wholeStr[i] < 'a' || wholeStr[i]>'z')
		if (wholeStr.concept[i] >= 'a' && wholeStr.concept[i] <= 'z')
			;
		else if (wholeStr.concept[i] >= '0' && wholeStr.concept[i] <= '9')
			;
		else
			wholeStr.concept[i] = '_';
	}

	if (wholeStr.concept.length() < GramSize) {
		//the whole str is a 4 gram with 4-wholeStr.length '-' at the begining of the string
		curGram.Gram = "_";
		while (curGram.Gram.length() < GramSize - wholeStr.concept.length())
			curGram.Gram += "_";
		curGram.Gram += wholeStr.concept;
		curGram.weight = wholeStr.weight;
		//check if it is in list
		fglit = fourGramlist.begin();
		while (fglit != fourGramlist.end()) {
			if ((*fglit).Gram == curGram.Gram)
			{
				(*fglit).weight += curGram.weight;
				break;
			}
			fglit++;
		}
		if (fglit == fourGramlist.end()) {
			fourGramlist.push_back(curGram);
		}
	}
	else {
		for (int i = 0; i <= wholeStrSize - GramSize; i++) {
			curGram.Gram = wholeStr.concept.substr(i, GramSize);
			curGram.weight = wholeStr.weight;
			//check if it is in list
			fglit = fourGramlist.begin();
			while (fglit != fourGramlist.end()) {
				if ((*fglit).Gram == curGram.Gram) {
					(*fglit).weight += curGram.weight;
					break;
				}
				fglit++;
			}
			if (fglit == fourGramlist.end()) {
				fourGramlist.push_back(curGram);
			}			
		}
	}
}