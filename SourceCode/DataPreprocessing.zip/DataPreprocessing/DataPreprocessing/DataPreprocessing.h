#pragma once

#define MSGLEN 300
#define BUFFERSIZE 50000//2000//
//#define FourGHTS 1000
//#define MSGNOHTS 1000
#define HTSize 300000//50000//1000
#define GramSize 4  //8//10//6//4 gram
#include <set>
#include <iostream> 
#include <algorithm>  
#include <iterator >
const int TFIDF_DIM = 7000;
using namespace std;

struct conceptWeightPair {
	string concept;
	float weight;
	long long int FourGramV;
};

struct KeywordConceptDictEle {
	string keyword;
	vector<conceptWeightPair> cWPlist;
};
struct KeywordNumPair {
	string keyword;
	int Knum;
};

struct FourGramWeightPair{
	string Gram;
	float weight;
	long long int GramVal;
};
/*
struct MsgNoIndexPair {
	int msgno;  //original no from raw media data
	int msgIndex; //converted one 0, 1...
};*/

struct UserIndexPair {
	long long int userid;  //this userid is the original user id, i.e. userOid in UPRespnseEle
	int userIndex;
};

struct FourGramMSGNumPair {  //record how many messages contain a fourgram in the training set
	string Gram;
	long long int GramVal;  //the index value to Gram
	int MSGNum; 
};

struct UPInfluDistriEle
{
	int userid;	
	float userInflu; //the ratio of comments, ...for a user interacting with other users--use training data to get this
};

struct UPRespnseEle
{
	int userid;
	long long int userOid;  //the original user id
	int userResponse; //the number of response, ...for a user interacting with other users--use training data to get this
				   //ith element is the number of userID's messages followed by ith user in the training dataset.
};

struct SpaceRange
{
	float lat;
	float longi;
	float radius;
};

struct UserProfile
{
	int userId;  //the index no of user in user dictionary
	long long int userOid;  //the original user id
	
	SpaceRange UserPhysicalLocation;
	int PostNum;//the toal number of posts for this user
	std::vector<UPRespnseEle> UserResponseNumbers; //user variable length array to reduce the memory cost
};

struct YoutubeUserProfile
{
	int userId;  //the index no of user in user dictionary
	string userOid;  //the original user id	
};

struct msgVecEle {
	long long int GramVal;  //the index value to Gram
	float DimVal;
};

struct msgGramFrequencyEle {
	long long int GramVal;  //the index value to Gram
	int DimFreVal;
};
struct EventTensorEle {
	long long int GramVal;  //the index value to Gram
	int rowVal; //the index value to the first bigram, it is the row number of the tensor
	int colVal; //the index value to the second bigram, it is the colume number of the tensor
	float DimVal;
};

struct msgUserUlist {
	string msgid;
	int userId; //the index no of user in user dictionary
	vector<int> userIdlist;
};

struct UserInteractlist {
	long long int userOid;  //the original user id
	vector<long long int> userOidlist;  //the original user id
};

std::vector<UserProfile> UserPHashTable[HTSize];  //hashing the userOid in UserProfile
std::vector<YoutubeUserProfile> YoutubeUserPHashTable[HTSize];

std::vector<FourGramMSGNumPair> GramDocNumHashTable[HTSize];

std::vector<long long int> FourGramHashTable[HTSize] ;  //1000 tuples

std::vector<UserIndexPair> UserIndexHashTable[HTSize];
std::vector<std::vector<FourGramWeightPair>> TrainingSetMessages;

std::vector<std::vector<long long int>> DimensionDict;

vector<KeywordNumPair> keywordHashTable[HTSize];// keep keywords in keywordHashTable, record how many messages have this keywords

vector<KeywordConceptDictEle> keywordConceptDict[HTSize];

vector<string> GTHashtagHashTable[HTSize]; //keep event related hashtags

set<string> GTMsgSet; //keep the groud truth messages
set<string> NonGTMsgSet; //keep the non groud truth messages

vector<YoutubeUserProfile> sortedUPlistForUserid2UserOid;

//preprocessing all the test data. convert keywords into 4gram vectors, format userid and timestamp etc.
extern int BulkProcessMessageSlot(char* flistname, char* path, char* outpath);
extern int ProcessMessageSlot(char* FullSlotFileName, char* outFullSlotFileName, int tpno);
extern int ReadDimensionDict(char* DimDict);
extern int ReadGramDocNumHashTable(char* TrainingSetGramMSGNoFname);
extern int SetMSGNoIndex(char* fname, int CurMsgno);
extern int BulkSetMSGNoIndex(char* flistname, char* path);
extern int SetUserIndex(char* fname, int maxUid);
extern int BulkSetUserIndex(char* flistname, char* path);

extern int ProcessMessageSlotAddUsers(char* FullSlotFileName, char* FullSlotFileUsers, char* outFullSlotFileName);

//generate the dimensions for each timeslot
extern void Text2Vec(std::vector<string>& msgText, std::vector<float>& msgVec, int tpno);
//extern int GetMSGNoIndex(int msgno);
extern int GetUserIndex(long long int userid);
extern int GetMessageSlotDimensions(char* FullSlotFileName);
extern void BulkGetMessageSlotsDims(char* flistname, char* path);
extern long long int FindMinCapVal(long long int curmin);

//produce 4gram/ngram dictionary (we use 8gram)
extern void getconcepts(KeywordNumPair keywordnumPair, std::vector<conceptWeightPair>& conceptlist);
extern void msgTextsTo4gramsDict(std::vector<string>& textlist);
extern void strTo4gramsDict(string wholeStr);
extern void bulkExtractConcept(std::vector<string>& textlist, std::vector<conceptWeightPair>& conceptlist);

//produce the statistics of training set for the concept idf calcuation. 
extern int ReadMessageSlotConcepts(char* FullSlotFileName);
extern void ProcessTrainingSet(char* flistname, char* path);
extern void strTo4grams(string wholeStr, std::vector<FourGramWeightPair>& fourGramlist);
extern long long int FourGramToVal(char* FGToken);

//for tensor construction
extern int ReadMessageSlotKeywords(char* FullSlotFileName);
extern void ProcessTrainingSetCCIGTensor(char* flistname, char* path);
extern int ProcessUserProfileEvents(char* UEventfname, char* outFullSlotFileName, int StartClusterNo);
extern int BulkProcessEventSlot(char* flistname, char* path, char* outpath);
extern void Text2TensorNew(std::vector<string>& msgText, std::vector<EventTensorEle>& msgVec);
extern int FourGramToValRowCol(char* FGToken, int valuePair[]);
extern int BulkProcessEventSlotMsgComments(char* flistname, char* path, char* outpath);
extern int ProcessUserProfileEventsMsgComments(char* UEventfname, char* outFullSlotFileName, int StartClusterNo);
extern void Text2GramFrequency(std::vector<string>& msgText, std::vector<msgGramFrequencyEle>& msgVec);


//produce user profiles and its interaction statistics information from training set //The old version that emily did
extern void GenerateUserProfile(char* FullFileName);
extern void BulkGenerateUserProfiles(char* flistname, char* path);
extern void InitializeUserProfiles(char* FullFileName);

//produce user profiles and its interaction statistics information from training set 
//new version, the user interactions are captured from user profiles over twitter (for ReadInteractionFile)
extern int BulkReadUserIDandLocation(char* UserNameFile, char *path, int startUserIndexID); //Main users are those appear in tweet dataset
extern void BulkCountMainUserPostNum(char* flistname, char* path); //count postnum in the whole training set
extern void CountMainUserPostNum(char* FullFileName); //count postnum in a time slot
extern void BulkReadInteractionFile(char* flistname, char* path); //count UserResponseNumbers in the whole time period of training set
extern void ReadInteractionFile(char* FullFileName); //count UserResponseNumbers in a time slot of training set
extern void UserProfile2File(char* resultfile); //output the userprofile into resultfile
extern int ReadCommentUserIDandLocation(char* FullUserNameFile, int startUserIndexID); //full user list, including those posting tweets and those commenting tweets
extern void InitializeInteraction();

//extract keywords of datasets
extern int BulkExtractDataSetKeyWord(char* flistname, char* path);
extern int ReadMessageSlots(char* FullFileName);

extern int ReadUserProfiles(char* FullUserNameFile);  //for UserPHashTable[HTSize]
extern void InitializeInteractionSlot();
extern void SlotUserProfile2File(char* resultfile);

extern unsigned hashString(string const& key, unsigned tableSize);
extern void LoadkeywordConceptDict();
extern void Text2VecNew(std::vector<string>& msgText, std::vector<msgVecEle>& msgVec);
extern void LoadkeywordConceptTokenDict();

//for automatically lable event related massages based on hashtags
extern int LabelMSGSlotGroudtruth(char* FullFileName, char *outFullGTFile);
extern int BulkLabelGroudtruth(char* flistname, char* path, char* outpath);
extern int ReadHashtags(char* HashTags);
extern int LabelSlotGroudtruthMSG(char* FullFileName, char* outFullGTFile);

extern int OutputMSGSlotGroudtruth(char* FullFileName);
extern int BulkOutputGroudtruth(char* flistname, char* path);
extern int OutputGroudtruthMsg(char* FullFileName);

extern int rankGroudtruthMsgbyLocation(char* FullFileName);
extern int rankGroudtruthMsgbyHashTags(char* FullFileName);

extern int ReadGTMsg(char* GTmsgs, set<string>& GTNonGTset);
extern int BulkCompareGroudtruth(char* flistname, char* path, char* outpath);
extern int CompareMSGSlotGroudtruth(char* FullFileName, set<string>& RetrievedTrue);

//for video tensor feature extraction
extern void ProcessTrainingSetCCIGVideoTensor(char* flistname, char* path);
extern void WeightedstrTo4grams(conceptWeightPair wholeStr, std::vector<FourGramWeightPair>& fourGramlist);
extern int ReadYoutubeKeywords(char* FullSlotFileName);
extern int BulkProcessYoutubeVideo(char* flistname, char* path, char* outpath);
extern int ReadYoutubeUserID(char* FullUserNameFile, int startUserIndexID);
extern void YoutubeUserProfile2File(char* resultfile);
extern void BulkReadYoutubeUserID(char* flistname, int startUserIndexID, char* path);
extern int ReadYoutubeUserProfiles(char* FullUserNameFile);
extern void WeightedText2TensorNew(std::vector<string>& msgText, std::vector<string>& descriptionText, std::vector<EventTensorEle>& msgVec);