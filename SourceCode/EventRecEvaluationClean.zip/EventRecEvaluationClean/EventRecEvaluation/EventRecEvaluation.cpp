// EventRecEvaluation.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "GlobalStructureVar.h"
#include "strtokenizer.h"

#define FNAMELEN 300

extern void EventReset(SubEvent& event);
extern int SubLoadUserInteraction(char* FullSlotFileName, vector<SubEvent>& eventClusters);
extern void subLoadRecResults(char* FullFileName, vector<SubEvent>& elist);

extern unsigned hashString(string const& key, unsigned tableSize);
extern int ReadGTMsg(char* GTmsgs, set<long long int>& GTNonGTset);

extern void EventRecEvaluationByGroundTruthNew(char * QGTmsgs,char* GTmsgs, char* filelist, char* RecResultPath, char* HistUPath,
	char* fullfilelist, char* fullfilepath);

extern void subReadUserInteractMessage(char* FullFileName);
extern void ReadUserInteractMessage(char* filelist, char* filePath);




int TOPK;
set<long long int> GTMsgSet; //keep the groud truth messages
set<long long int> QGTMsgSet; //keep the groud truth messages that are used as evaluated clusters
vector<SubEvent> UPEventList; //store the events in user profiles. user profiles only keep the event no, not the attributes of events

int main(int argc, char* argv[])
{
    //TOPK = 5;
	bool		failed = false;
	char		c = -1;
	char		tpara[200];
	int			cnt = 1;
	char* cp = NULL;

	char* flistname = NULL;
	char* RecResultPath=NULL;
	char* HistUPath=NULL;
	char* GTmsgs=NULL;
	char* QueryGTmsgs = NULL;

	char* fullflistname = NULL;
	char* fullfilepath = NULL;

	while (cnt < argc && !failed)
	{
		cp = argv[cnt];
		c = cp[0];
		if (c != '-')
		{
			failed = true;
			break;
		}

		strcpy_s(tpara, cp + 1);
		cnt++;
		if (cnt == argc) {
			failed = true;
			break;
		}

		cp = argv[cnt];

		if (strcmp(tpara, "K") == 0) {
			TOPK = atoi(cp);
		}
		else if (strcmp(tpara, "fn") == 0)
		{
			flistname = cp;			
		}
		else if (strcmp(tpara, "ffn") == 0)
		{
			fullflistname = cp;
		}
		else if (strcmp(tpara, "ffp") == 0) {
			fullfilepath = cp;
		}
		else if (strcmp(tpara, "gtm") == 0) {
			GTmsgs = cp;
		}
		else if (strcmp(tpara, "qgtm") == 0) {
			QueryGTmsgs = cp;
		}
		else if (strcmp(tpara, "rrp") == 0) {
			RecResultPath = cp;			
		}
		else if (strcmp(tpara, "hup") == 0) {
			HistUPath = cp;			
		}
		
		cnt++;
	}
	
	cout << RecResultPath << "\t";
	cout << HistUPath << "\t" << endl;
	EventRecEvaluationByGroundTruthNew(QueryGTmsgs,GTmsgs, flistname, RecResultPath, HistUPath, fullflistname,fullfilepath);
		
}


void ReadUserInteractMessage(char* filelist, char* filePath)
{
	char  FullSlotFileName[FNAMELEN];
	char buffer[200];
	FILE* fileDescriptor = NULL;
	int count = 0;
	if ((fopen_s(&fileDescriptor, filelist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", filelist);
	}
	else {
		while (fscanf_s(fileDescriptor, "%s ", buffer, 200) != EOF)
		{   //load data
			//int userid = atoi(buffer);
			count++;
			if (count <= 168)
				continue;
			
			strcpy_s(FullSlotFileName, FNAMELEN, filePath);
			strcat_s(FullSlotFileName, FNAMELEN, buffer);
			strcat_s(FullSlotFileName, FNAMELEN, ".dat");

			//cout << buffer << endl;

			subReadUserInteractMessage(FullSlotFileName);
		}
		fclose(fileDescriptor);
	}
}

void subReadUserInteractMessage(char* FullFileName) {
	FILE* fileDescriptor = NULL;
	char buffer[BUFFERSIZE];

	string line;
	long long int curmsgno;
		
	if ((fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else
	{
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) line!\n");
			}
						
			//==================
			int i = 0;
			while (i < length)
			{
				//=================
				if (strcmp(strtok.token(i).c_str(), "<msgid>") == 0) {
					i++;
					while (strcmp(strtok.token(i).c_str(), "</msgid>") != 0) {
						curmsgno = atoll(strtok.token(i).c_str());
						i++;
					}
					i++;
					continue;
				}
				if (strcmp(strtok.token(i).c_str(), "<useridlist>") == 0) {
					i++;
					int userID;
					while (strcmp(strtok.token(i).c_str(), "</useridlist>") != 0) {
						userID = atoi(strtok.token(i).c_str());
						UserEventHistProfileTable[userID].msglist.insert(curmsgno);
						i++;
					}					
					i++;
					continue;
				}
				i++;
			}
		}

		fclose(fileDescriptor);
	}
}

void EventRecEvaluationByGroundTruthNew(char * QGTmsgs, char* GTmsgs, char* filelist, char* RecResultPath, char* HistUPath, 
	char *fullfilelist, char *fullfilepath) 
{
	ReadGTMsg(GTmsgs, GTMsgSet); //all event reated messages
	ReadGTMsg(QGTmsgs, QGTMsgSet); //all event related messages in recommemdation evaluated clusters
	//assign the user ids for UserEventHistProfileTable.
	UserEventHistProfile curUEHP;
	for (int i = 0; i < TUNUM; i++) {
		curUEHP.userID = i;
		UserEventHistProfileTable.push_back(curUEHP);
	}
	ReadUserInteractMessage(fullfilelist, fullfilepath);
		
	//=======================
	FILE* dataSetDescriptor = NULL, * resultFile = NULL;
	char FullSlotFileName[200], SlotFileName[200];
	vector<SubEvent> Eventclusters;
	vector<SubEvent>::iterator seit;
	int ValidEventNumber = 0;
	float SumPrecisionAtK = 0;
	int HitNum = 0;
	set<long long int> CommonRetGTevent, CommonRetGTuser;

	int StartRecEvent = 0;
	if ((fopen_s(&dataSetDescriptor, filelist, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", filelist);
	}
	else {
		int count = 0;
		while (fscanf_s(dataSetDescriptor, "%s ", SlotFileName, 200) != EOF)
		{
			count++;
			if (count % 2 > 0)
				continue;

			//cout << count << endl;

			strcpy_s(FullSlotFileName, 200, HistUPath);
			strcat_s(FullSlotFileName, 200, SlotFileName);
			strcat_s(FullSlotFileName, 200, ".UPdata");
			//cout << "SlotFileName:" << SlotFileName << endl;

			Eventclusters.clear();
			SubLoadUserInteraction(FullSlotFileName, Eventclusters);

			if (count <= 24) {  //for processing the first day social events, only read it to user profile
				for (int i = 0; i < Eventclusters.size(); i++) {
					UPEventList.push_back(Eventclusters[i]);
					//put this event id to the corresponding user profile history event list
					int eventUsize = Eventclusters[i].eventUserIdsFre.size();
					for (int j = 0; j < eventUsize; j++)
						UserEventHistProfileTable[Eventclusters[i].eventUserIdsFre[j].userid].histEventIds.push_back(Eventclusters[i].eventno);
					int eventAsize = Eventclusters[i].eventAuthorIDs.size();
					for (int j = 0; j < eventAsize; j++)
						UserEventHistProfileTable[Eventclusters[i].eventAuthorIDs[j]].histEventIds.push_back(Eventclusters[i].eventno);
				}
				if (count == 24)
					StartRecEvent = UPEventList.size();
			}
			else {
				//load recommendation results
				strcpy_s(FullSlotFileName, 200, RecResultPath);
				strcat_s(FullSlotFileName, 200, SlotFileName);
				strcat_s(FullSlotFileName, 200, ".txt");
				subLoadRecResults(FullSlotFileName, Eventclusters);				
				//=======================================
				//insert the current Eventclusters into UPEventList and user history
				for (int i = 0; i < Eventclusters.size(); i++) {
					UPEventList.push_back(Eventclusters[i]);
					//put this event id to the corresponding user profile history event list
					int eventUsize = Eventclusters[i].eventUserIdsFre.size();
					for (int j = 0; j < eventUsize; j++)
						UserEventHistProfileTable[Eventclusters[i].eventUserIdsFre[j].userid].histEventIds.push_back(Eventclusters[i].eventno);
					int eventAsize = Eventclusters[i].eventAuthorIDs.size();
					for (int j = 0; j < eventAsize; j++)
						UserEventHistProfileTable[Eventclusters[i].eventAuthorIDs[j]].histEventIds.push_back(Eventclusters[i].eventno);
				}
			}

			//clean Eventclusters for next loop use
			seit = Eventclusters.begin();
			while (seit != Eventclusters.end()) {
				(*seit).eventAuthorIDs.clear();
				(*seit).eventUserIdsFre.clear();
				(*seit).clusterMsgIds.clear();
				(*seit).recList.clear();
				(*seit).recEIList.clear();
				seit++;
			}
			Eventclusters.clear();
		}
		fclose(dataSetDescriptor);
	}
	//=====================
	//check the current event and recommendation list of each event to get the hit;
	seit = UPEventList.begin()+StartRecEvent;
	while (seit != UPEventList.end()) {	
		int TrueMatch = 0;
		set_intersection(QGTMsgSet.begin(), QGTMsgSet.end(), (*seit).clusterMsgIds.begin(), (*seit).clusterMsgIds.end(), inserter(CommonRetGTevent, CommonRetGTevent.end()));
		TrueMatch = CommonRetGTevent.size();
			
		if (TrueMatch) //the current cluster is a relevant event
		{
			//ValidEventNumber++;
			HitNum = 0;
			int reclistSize = (*seit).recList.size();
			int j;
			
			for (j = 0; j < reclistSize; j++) 
			{
				int curUserID = (*seit).recList[j].UserID;
				if (j >= TOPK)
					break;
				//check the history of curUserID profile
				int upEventSize = UserEventHistProfileTable[curUserID].histEventIds.size();
				int k = 0;
				for (k = 0; k < upEventSize; k++) {					
					int CurENo = UserEventHistProfileTable[curUserID].histEventIds[k];
					//==============
					if (UPEventList[CurENo].Cluster_TR.TimeStampCentre < (*seit).Cluster_TR.TimeStampCentre)
						continue;
					//==============
					CommonRetGTuser.clear();
					set_intersection(GTMsgSet.begin(), GTMsgSet.end(), UPEventList[CurENo].clusterMsgIds.begin(), UPEventList[CurENo].clusterMsgIds.end(), inserter(CommonRetGTuser, CommonRetGTuser.end()));
					//remove the messages in CommonRetGTevent
					set<long long>::iterator mit = CommonRetGTuser.begin();
					while (mit != CommonRetGTuser.end()) {
						set<long long>::iterator it1 = CommonRetGTevent.find((*mit));
						if (it1 != CommonRetGTevent.end()) {
							CommonRetGTuser.erase(mit);
							break;
						}
						mit++;
					}
					//======================================
					int TrueUserMatch = CommonRetGTuser.size();
					if (TrueUserMatch) {  //a user match, it is a hit						
						HitNum++;						
						break;
					}
					CommonRetGTuser.clear();					
				}
				//not found in the recent history, check the messages after 7days
				if (k == upEventSize) {
					CommonRetGTuser.clear();
					set_intersection(GTMsgSet.begin(), GTMsgSet.end(), UserEventHistProfileTable[curUserID].msglist.begin(),
						UserEventHistProfileTable[curUserID].msglist.end(), inserter(CommonRetGTuser, CommonRetGTuser.end()));
					//remove the messages in CommonRetGTevent
					set<long long>::iterator mit = CommonRetGTuser.begin();
					while (mit != CommonRetGTuser.end()) {
						set<long long>::iterator it1 = CommonRetGTevent.find((*mit));
						if (it1 != CommonRetGTevent.end()) {
							CommonRetGTuser.erase(mit);
							break;
						}
						mit++;
					}
					//======================================
					if (!CommonRetGTuser.empty()) {
						HitNum++;
					}
					CommonRetGTuser.clear();
				}
			}
			float PrecisionAtK = 0;
			if (j == 0)
				cout << "dbug" <<"clusterNo:"<< (*seit).eventno<<endl;
			else {				
				PrecisionAtK = (float)HitNum / j;
				ValidEventNumber++;
			}
		
			SumPrecisionAtK += PrecisionAtK;
		}
		CommonRetGTevent.clear();
		seit++;
	}

	//compute the average precision@k, for the events without any user interaction, ignore them.
	float AveragePrecisionAtK = SumPrecisionAtK / ValidEventNumber;
	printf("ValidEventNumber:%d\tTOPK:%d\tPreAtK:\t%.4f\n", ValidEventNumber, TOPK, AveragePrecisionAtK);

	//clear UserInterPHashTable
	for (int i = 0; i < TUNUM; i++) {
		UserEventHistProfileTable[i].histEventIds.clear();
		UserEventHistProfileTable[i].msglist.clear();
	}
	UserEventHistProfileTable.clear();
	//clear eventList
	seit = UPEventList.begin();
	while (seit != UPEventList.end()) {
		(*seit).eventAuthorIDs.clear();
		(*seit).eventUserIdsFre.clear();
		(*seit).clusterMsgIds.clear();
		(*seit).recList.clear();
		(*seit).recEIList.clear();
		seit++;
	}
	UPEventList.clear();
	GTMsgSet.clear();
	QGTMsgSet.clear();
	//=======================
}
//SAX string hash
unsigned hashString(string const& key, unsigned tableSize)
{
	unsigned hashVal = 0;
	for (int x = 0; x < key.length(); ++x)
	{
		hashVal ^= (hashVal << 5) +
			(hashVal >> 2) +
			key[x];
	}
	return hashVal % tableSize;
}

int ReadGTMsg(char* GTmsgs, set<long long int>& GTNonGTset) {

	int ret = 0;

	FILE* fileDescriptor = NULL;
	errno_t err;

	char buffer[BUFFERSIZE];
	string line;

	if ((err = fopen_s(&fileDescriptor, GTmsgs, "r")) != 0) {
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", GTmsgs);
	}
	else {
		while (fgets(buffer, BUFFERSIZE, fileDescriptor)) {
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();
			if (length > 0)
			{
				int hashkey = hashString(strtok.token(0), HTSize);
				GTNonGTset.insert(atoll(strtok.token(0).c_str()));
			}
		}
		fclose(fileDescriptor);
	}
	ret = GTNonGTset.size();

	return ret;
}


void subLoadRecResults(char* FullFileName, vector<SubEvent>& elist) {
	FILE* fileDescriptor = NULL;
	char buffer[BUFFERSIZE];	

	string line;
	int cureventno;
	int eid = 0;
	vector<SubEvent>::iterator eit;
	int PosInelist = 0;
	int elistLen = elist.size();
	if ((fopen_s(&fileDescriptor, FullFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullFileName);
	}
	else
	{
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) line!\n");
			}

			int i = 0;
			if (strcmp(strtok.token(i).c_str(), "<clusterid>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</clusterid>") != 0) {
					cureventno = atoi(strtok.token(i).c_str());
					i++;
				}
				//search cureventno in elist
				for(int j=0;j<elistLen;j++){
					if (elist[j].eventno >= cureventno) {
						PosInelist = j;
						break;		
					}														
				}	
				i++;
				continue;
			}	
			if (strcmp(strtok.token(i).c_str(), "<recitem>") == 0) {
				if (elist[PosInelist].recList.size() == TOPK){  //skip and not insert				
					i++;
					continue;
				}
				i++;
				RecItem ritem;
				while (strcmp(strtok.token(i).c_str(), "</recitem>") != 0) {					
					ritem.UserID = atoi(strtok.token(i).c_str());
					i++;
					ritem.simi = atof(strtok.token(i).c_str());
					i++;
					i++;
				}
				if (PosInelist < elistLen) {
					if (elist[PosInelist].eventno == cureventno){//found this event from elist											
						//search if ritem.UserID is in elist[PosInelist].eventAuthorIDs
						int j=0;
						for (j = 0; j < elist[PosInelist].eventAuthorIDs.size(); j++){
							if (ritem.UserID == elist[PosInelist].eventAuthorIDs[j])
								break;
						}
						if (j == elist[PosInelist].eventAuthorIDs.size()) { //not in the eventAuthorIDs
							//if(activeUserSet.find(ritem.UserID)!=activeUserSet.end()) //only consider active users, in activeuserSet
								elist[PosInelist].recList.push_back(ritem);
						}/**/
						
					}
				}
				i++;
				continue;
			}
		}
		fclose(fileDescriptor);
	}
}

int SubLoadUserInteraction(char* FullSlotFileName, vector<SubEvent>& eventClusters)
{
	int ret = 0;

	FILE* fileDescriptor = NULL;
	char buffer[BUFFERSIZE];
	
	TimeRange newTR = { 0.0,0.0 };
	SpaceRange newSR = { 0.0,0.0,0.0 };
	vector<EUserFrePair> euids;
	vector<EUserFrePair>::iterator euit;

	string line;
	SubEvent curEvent;
	int eid = 0;
	if ((fopen_s(&fileDescriptor, FullSlotFileName, "r")) != 0) {
		printf("load msg error \n");
		printf("The file 'crt_fopen_s.c' was not opened: %s\n", FullSlotFileName);
	}
	else
	{
		while (fgets(buffer, BUFFERSIZE, fileDescriptor))
		{
			line = buffer;
			strtokenizer strtok(line, " \t\r\n");
			int length = strtok.count_tokens();

			if (length <= 0) {
				printf("Invalid (empty) line!\n");
				return 1;
			}

			int i = 0;
			if (strcmp(strtok.token(i).c_str(), "<clusterid>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</clusterid>") != 0) {
					curEvent.eventno = atoi(strtok.token(i).c_str());
					i++;
				}
				i++;
				continue;
			}			
			if (strcmp(strtok.token(i).c_str(), "<clusterMsgIds>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</clusterMsgIds>") != 0) {
					curEvent.clusterMsgIds.insert(atoll(strtok.token(i).c_str()));
					i++;
				}
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<SpaceRange>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</SpaceRange>") != 0)
				{
					curEvent.Cluster_SR.lat = (float)atof(strtok.token(i).c_str());
					i++;
					curEvent.Cluster_SR.longi = (float)atof(strtok.token(i).c_str());
					i++;
					curEvent.Cluster_SR.radius = (float)atof(strtok.token(i).c_str());
					i++;
				}
				
				i++;
				continue;
			}
			if (strcmp(strtok.token(i).c_str(), "<TimeRange>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</TimeRange>") != 0) {
					curEvent.Cluster_TR.TimeStampCentre = (float)atof(strtok.token(i).c_str());
					i++;
					curEvent.Cluster_TR.range = (float)atof(strtok.token(i).c_str());;
					i++;
				}
				
				i++;
				continue;
			}
			
			if (strcmp(strtok.token(i).c_str(), "<authoridlist>") == 0) {
				i++;
				while (strcmp(strtok.token(i).c_str(), "</authoridlist>") != 0)
				{				
					int authoruserid = atoi(strtok.token(i).c_str());
								
					//sort based on user id
					vector<int>::iterator uit = curEvent.eventAuthorIDs.begin();
					while (uit != curEvent.eventAuthorIDs.end()) {
						if ((*uit) > authoruserid) {
							curEvent.eventAuthorIDs.insert(uit, authoruserid);
							uit = curEvent.eventAuthorIDs.begin();
							break;
						}
						uit++;
					}
					if (uit == curEvent.eventAuthorIDs.end())
						curEvent.eventAuthorIDs.push_back(authoruserid);
					i++;
				}				
				i++;				
			}

			if (strcmp(strtok.token(i).c_str(), "<useridlist>") == 0) 
			{
				i++;
				while (strcmp(strtok.token(i).c_str(), "</useridlist>") != 0)
				{
					EUserFrePair eufPair;
					eufPair.userid = atoi(strtok.token(i).c_str());
					i++;
					eufPair.frequency = atoi(strtok.token(i).c_str());
					//sort based on user id
					euit = curEvent.eventUserIdsFre.begin();//euids.begin();
					while (euit != curEvent.eventUserIdsFre.end()) {
						if ((*euit).userid > eufPair.userid) {
							curEvent.eventUserIdsFre.insert(euit, eufPair);
							euit = curEvent.eventUserIdsFre.begin();
							break;
						}
						euit++;
					}
					if (euit == curEvent.eventUserIdsFre.end())
						curEvent.eventUserIdsFre.push_back(eufPair);
					i++;
				}
				
				eventClusters.push_back(curEvent);
				i++;
				//reset curEvent;
				EventReset(curEvent);
			}
		}
		//=====================
		fclose(fileDescriptor);
	}
	ret = eventClusters.size();
	return ret;
}

void EventReset(SubEvent& event) {
	event.Cluster_SR.lat = 0;
	event.Cluster_SR.longi = 0;
	event.Cluster_SR.radius = 0;
	event.Cluster_TR.TimeStampCentre = 0;
	event.Cluster_TR.range = 0;
	event.eventno = 0;
	event.eventUserIdsFre.clear();
	event.eventAuthorIDs.clear();
	event.recList.clear();
	event.clusterMsgIds.clear();
	event.recEIList.clear();
}
