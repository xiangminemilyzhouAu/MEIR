﻿#pragma once
#include <vector>
#include <iterator>
#include <algorithm> 
#include <set>
#include <iostream>
#include <math.h> 
#include <string>
#include <ctime>
using namespace std;

#define PI 3.14159265358979
#define EARTH_RADIUS 6378.137 //地球半径
#define EARTH_Half_CIRCUMFERENCE 20037.5 //地球半周长
#define BUFFERSIZE 60000//50000
#define USERLEN 100
#define MSGLEN 200
//#define MVALUE 10//5 //the number of hash functions, 5 for TFIDF vectors, 5 for user influence vectors
#define MVALUE 12//the number of hash functions, 6 for TFIDF vectors, 6 for user influence vectors

#define MAXFLOAT FLT_MAX//5256000 //minutes for one year
#define MINFLOAT FLT_MIN
#define MAXINT INT_MAX
#define MININT INT_MIN
//#define ELIPSE 0.8  //social message similarity threshold, can be variable.
#define INFLUENCETHRE 0.300000001 //user influence threshold
#define ROWSV 400//670  //for c[ROWSV+1][ROWSV+1]
#define CONVEC_DIM 2  //location cluster number for partition

#define TUNUM 135783//14978//20//10000 //total number of users in nepal training dataset
//#define TUNUM 64240 //total number of users in Texas Flood training dataset
//#define WUIPV 0.7   
#define HTSize 5000//1000//50000

const int TFIDF_DIM = 50;//160; //30000;//Top TFIDF_DIM 4-grams will be selected for one time slot
const int TPNUM = 720; //one month, 720 1-hour periods

extern float SPACERADIUST;// = 20;
extern float TIMERADIUST;// = 30;
extern float ELIPSE;  //social message similarity threshold, can be variable. Get value from main parameter list
extern float omeg1; //concept net weight
extern float omeg2; //time weight, then the weight of location is 1-omeg1-omeg2
extern int MethodChoice;
extern float WUIPV;
extern int TOPK;

struct strFre {
	string token;
	int frequency;
};

struct EUserFrePair
{
	int userid;

	/*the number of comments, ...for a user interacting with a sub-event or a message 
	in his history user profile--use training data to get this*/
	int frequency; 					
};

struct TimeRange
{
	float TimeStampCentre;   //time stamp: change date-time into int, we use float to fit the composite time point
	float range;  //the uncertainty threshold range \tau with time stamp 
};

struct SpaceRange
{
	float lat;
	float longi;
	float radius;
};

struct EventUserSimi {
	int userid;
	float simi;
};


struct UPInfluDistriEle
{
	int userid;
	float userInflu; //the ratio of comments, ...for a user interacting with other users--use training data to get this
};

struct UPRespnseEle
{
	int userid;
	long long int userOid;  //the original user id
	int userResponse; //the number of response, ...for a user interacting with other users--use training data to get this
				   //ith element is the number of userID's messages followed by ith user in the training dataset.
};

struct NewURespnEle
{
	int startUid;
	int endUid;
	int userResponse;
};

struct EventNoSimiPair {
	int eventNo;
	int migEno;
	float simi;
};

struct RecItem {  //remember: recommend a given item to users, USERID should be output
	int UserID;
	float simi;
};
struct RecEventItem {  //remember: recommend a given item to users related to top k relevant events, EventID is output for evaluation. USERID should be output
	int EventID;
	float simi;
	set<int> UserID;
};

struct SubEvent {
	TimeRange Cluster_TR;
	SpaceRange Cluster_SR;

	vector<EUserFrePair> eventUserIdsFre; // a number of user-event interaction recorders, here users are those attached with this message
	vector<int> eventAuthorIDs;  // a number of users who posted the event messages
	set<long long int> clusterMsgIds;  //event msg id list
	vector<RecItem> recList;
	vector<RecEventItem> recEIList;
	int eventno;	
};

struct UserProfile
{
	int userId;  //the index no of user in user dictionary
	long long int userOid;  //the original user id

	SpaceRange UserPhysicalLocation;
	int PostNum;//the toal number of posts for this user
	std::vector<UPRespnseEle> UserResponseNumbers; //user variable length array to reduce the memory cost

	set<long long int> msglist;  //this is the set containing messages after May 1 for nepal, and after 28 may for texas
};

std::vector<UserProfile> UserPHashTable[HTSize];  //hashing the userOid in UserProfile

struct InteractEle {
	int InterUserID; //the index no of user in user dictionary
	TimeRange tr; //the time stamp of interact
};
struct UserInteractProfile {
	int userID; //the index no of user in user dictionary
	std::vector<InteractEle> InteractList;  
};

std::vector<UserInteractProfile> UserInterPHashTable;
std::set<int> activeUserSet;

struct UserEventHistProfile {
	int userID; ////the index no of user in user dictionary
	std::vector<int> histEventIds;
	set<long long int> msglist;  //this is the set containing messages after May 1 for nepal, and after 28 may for texas
};
std::vector<UserEventHistProfile> UserEventHistProfileTable;